
$("#slider-example1").slider({
    value: 5,
    min: 0,
    max: 100,
    step: 1,
    slide: function(event, ui) {
        return $("#slider-example1-amount").text(ui.value+"%");
    }
});
$("#slider-example1-amount").text($("#slider-example1").slider("value"));

$("#slider-example2").slider({
    value: 5,
    min: 0,
    max: 100,
    step: 1,
    slide: function(event, ui) {
        return $("#slider-example2-amount").text(ui.value+"%");
    }
});
$("#slider-example2-amount").text($("#slider-example2").slider("value"));

$("#slider-example3").slider({
    value: 5,
    min: 0,
    max: 100,
    step: 1,
    slide: function(event, ui) {
        return $("#slider-example3-amount").text(ui.value+"%");
    }
});
$("#slider-example3-amount").text($("#slider-example3").slider("value")); 

$("#slider-example11").slider({
    value: 5,
    min: 0,
    max: 100,
    step: 1,
    slide: function(event, ui) {
        return $("#slider-example11-amount").text(ui.value+"%");
    }
});
$("#slider-example11-amount").text($("#slider-example11").slider("value"));

$("#slider-example22").slider({
    value: 5,
    min: 0,
    max: 100,
    step: 1,
    slide: function(event, ui) {
        return $("#slider-example22-amount").text(ui.value+"%");
    }
});
$("#slider-example22-amount").text($("#slider-example22").slider("value"));

$("#slider-example33").slider({
    value: 5,
    min: 0,
    max: 100,
    step: 1,
    slide: function(event, ui) {
        return $("#slider-example33-amount").text(ui.value+"%");
    }
});
$("#slider-example33-amount").text($("#slider-example33").slider("value"));

$("#slider-example4").slider({
    value: 0,
    min: 0,
    max: 1000,
    step: 10,
    slide: function(event, ui) {
        return $("#slider-example4-amount").text(ui.value+"GB");
    }
});
$("#slider-example4-amount").text($("#slider-example4").slider("value"));

$("#slider-example5").slider({
    value: 0,
    min: 0,
    max: 1000,
    step: 10,
    slide: function(event, ui) {
        return $("#slider-example5-amount").text(ui.value+"GB");
    }
});
$("#slider-example5-amount").text($("#slider-example5").slider("value"));
