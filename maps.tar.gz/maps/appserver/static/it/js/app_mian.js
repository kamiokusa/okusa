$(function() {
	 


//查看密码
$(".eyes_box").click(function(){
	if($(this).attr("data-show")==1){//明文
		$(this).attr("data-show","2");

		$(".mima_dd").hide();
		$(".mima_wz").show();
		$(".mima_wz").val($(".mima_dd").val()); 
		return;
		}
	if($(this).attr("data-show")==2){//密文
		$(this).attr("data-show","1");

		$(".mima_dd").show();
		$(".mima_wz").hide();
		$(".mima_dd").val($(".mima_wz").val()); 
		return;
		} 
	});
	
 

 
});	

$(function() {
	 


//查看密码
$(".eyes_box1").click(function(){
	if($(this).attr("data-show")==1){//明文
		$(this).attr("data-show","2");

		$(".mima_dd1").hide();
		$(".mima_wz1").show();
		$(".mima_wz1").val($(".mima_dd1").val()); 
		return;
		}
	if($(this).attr("data-show")==2){//密文
		$(this).attr("data-show","1");

		$(".mima_dd1").show();
		$(".mima_wz1").hide();
		$(".mima_dd1").val($(".mima_wz1").val()); 
		return;
		} 
	});
	
 

 
});	