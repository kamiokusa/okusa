/* Sidebar Menu*/
$(document).ready(function () {
  $('.nav > li > a').click(function(){
    if ($(this).attr('class') != 'active'){
      $('.nav li ul').slideUp();
      $(this).next().slideToggle();
      $('.nav li a').removeClass('active');
      $(this).addClass('active');
    }
  });
});

/* Top Stats Show Hide */
$(document).ready(function(){
    $("#topstats").click(function(){
        $(".topstats").slideToggle(100);
    });
});

/* Sidepanel Show-Hide */
$(document).ready(function(){
    $(".smzq-ck").click(function(){
        $(".sidepanel").toggle(300);
    });
});

$(".smzq-gb").click(function(){
    $(".sidepanel").hide(300);
});

$(document).ready(function(){
    $(".dsh-ck").click(function(){
        $(".smzq-dsh-ck").toggle(300);
    });
});


$(".dsh-gb, .nav-tabs1").click(function(){
    $(".smzq-dsh-ck").hide(300);
});



$(document).ready(function(){
    $(".shtg-ck").click(function(){
        $(".smzq-shtg-ck").toggle(300);
    });
});


$(".shtg-gb, .nav-tabs1").click(function(){
    $(".smzq-shtg-ck").hide(300);
});

$(document).ready(function(){
    $(".shjj-ck").click(function(){
        $(".smzq-shjj-ck").toggle(300);
    });
});


$(".shjj-gb, .nav-tabs1").click(function(){
    $(".smzq-shjj-ck").hide(300);
});

$(document).ready(function(){
    $(".yhgl-bmxq").click(function(){
        $(".yhgl-bmxq-ck").toggle(300);
    });
});


$(".yhgl-bmxq-gb, .nav-tabs1").click(function(){
    $(".yhgl-bmxq-ck").hide(300);
});


$(document).ready(function(){
    $(".yhgl-ptxq").click(function(){
        $(".yhgl-ptxq-ck").toggle(300);
    });
});


$(".yhgl-ptxq-gb, .nav-tabs1").click(function(){
    $(".yhgl-ptxq-ck").hide(300);
});

$(document).ready(function(){
    $(".sjzx").click(function(){
        $(".sjzx-ck").toggle(300);
    });
    $(".sjzx-gb").click(function(){
        $(".sjzx-ck").hide(300);
    });
});





/* Sidebar Show-Hide On Mobile */
$(document).ready(function(){
    $(".sidebar-open-button-mobile").click(function(){
        $(".sidebar").toggle(150);
    });
});


/* Sidebar Show-Hide */
$(document).ready(function(){

    $('.sidebar-open-button').on('click', function(){
        if($('.sidebar').hasClass('hidden')){
            $('.sidebar').removeClass('hidden');
            $('.content').css({
                'marginLeft' : 170
            });  
        }else{
            $('.sidebar').addClass('hidden');
            $('.content').css({
                'marginLeft' : 0
            });    
        }
    });

});


/* ===========================================================
PANEL TOOLS
===========================================================*/
/* Minimize */
$(document).ready(function(){
  $(".panel-tools .minimise-tool").click(function(event){
  $(this).parents(".panel").find(".panel-body").slideToggle(100);

  return false;
}); 

 }); 

/* Close */
$(document).ready(function(){
  $(".panel-tools .closed-tool").click(function(event){
  $(this).parents(".panel").fadeToggle(400);

  return false;
}); 

 }); 

 /* Search */
$(document).ready(function(){
  $(".panel-tools .search-tool").click(function(event){
  $(this).parents(".panel").find(".panel-search").toggle(100);

  return false;
}); 

 }); 




/* expand */
$(document).ready(function(){

    $('.panel-tools .expand-tool').on('click', function(){
        if($(this).parents(".panel").hasClass('panel-fullsize'))
        {
            $(this).parents(".panel").removeClass('panel-fullsize');
        }
        else
        {
            $(this).parents(".panel").addClass('panel-fullsize');
 
        }
    });

});


/* ===========================================================
Widget Tools
===========================================================*/


/* Close */
$(document).ready(function(){
  $(".widget-tools .closed-tool").click(function(event){
  $(this).parents(".widget").fadeToggle(400);

  return false;
}); 

 }); 


/* expand */
$(document).ready(function(){

    $('.widget-tools .expand-tool').on('click', function(){
        if($(this).parents(".widget").hasClass('widget-fullsize'))
        {
            $(this).parents(".widget").removeClass('widget-fullsize');
        }
        else
        {
            $(this).parents(".widget").addClass('widget-fullsize');
 
        }
    });

});

/* Kode Alerts */
/* Default */
$(document).ready(function(){
  $(".kode-alert .closed").click(function(event){
  $(this).parents(".kode-alert").fadeToggle(350);

  return false;
}); 

 }); 


/* Click to close */
$(document).ready(function(){
  $(".kode-alert-click").click(function(event){
  $(this).fadeToggle(350);

  return false;
}); 

 }); 



/* Tooltips */
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})

/* Popover */
$(function () {
  $('[data-toggle="popover"]').popover()
})


/* Page Loading */
$(window).load(function() {
  $(".loading").fadeOut(2000);
})


$(function () {
    var pathName = location.pathname;
    a=pathName.substr(pathName.lastIndexOf("/")+1);
    $(".sidebar-panel a[href='"+a+"']").addClass("treeview1");
    $(".sidebar-panel a[href='"+a+"']").css("color","#FFF");
});

function test(Names){
  var Name
  for (var i=1;i<3;i++){  //  更改数字4可以改变选择的内容数量，在下拉总数值的基础上+1.比如：下拉菜单有5个值，则4变成6
    var tempname="mune_kami"+i                                                                            
    var NewsHot="kami"+i //  “X”是ID名称，比如：ID命名为“case1”，这里的“X”即为“case”
    if (Names==tempname){
      Nnews=document.getElementById(NewsHot)
      Nnews.style.display='';
    }else{
      Nnews=document.getElementById(NewsHot)
      Nnews.style.display='none';   
    }
  }
}

function test1(Names){
  var Name
  for (var i=1;i<5;i++){  //  更改数字4可以改变选择的内容数量，在下拉总数值的基础上+1.比如：下拉菜单有5个值，则4变成6
    var tempname="mune_kami1"+i                                                                            
    var NewsHot="kami1"+i //  “X”是ID名称，比如：ID命名为“case1”，这里的“X”即为“case”
    if (Names==tempname){
      Nnews=document.getElementById(NewsHot)
      Nnews.style.display='';
    }else{
      Nnews=document.getElementById(NewsHot)
      Nnews.style.display='none';   
    }
  }
}

function test2(Names){
  var Name
  for (var i=1;i<3;i++){  //  更改数字4可以改变选择的内容数量，在下拉总数值的基础上+1.比如：下拉菜单有5个值，则4变成6
    var tempname="mune_kami2"+i                                                                            
    var NewsHot="kami2"+i //  “X”是ID名称，比如：ID命名为“case1”，这里的“X”即为“case”
    if (Names==tempname){
      Nnews=document.getElementById(NewsHot)
      Nnews.style.display='';
    }else{
      Nnews=document.getElementById(NewsHot)
      Nnews.style.display='none';   
    }
  }
}

function test3(Names){
  var Name
  for (var i=1;i<5;i++){  //  更改数字4可以改变选择的内容数量，在下拉总数值的基础上+1.比如：下拉菜单有5个值，则4变成6
    var tempname="mune_kami3"+i                                                                            
    var NewsHot="kami3"+i //  “X”是ID名称，比如：ID命名为“case1”，这里的“X”即为“case”
    if (Names==tempname){
      Nnews=document.getElementById(NewsHot)
      Nnews.style.display='';
    }else{
      Nnews=document.getElementById(NewsHot)
      Nnews.style.display='none';   
    }
  }
}

function test4(Names){
  var Name
  for (var i=1;i<3;i++){  //  更改数字4可以改变选择的内容数量，在下拉总数值的基础上+1.比如：下拉菜单有5个值，则4变成6
    var tempname="mune_kami4"+i                                                                            
    var NewsHot="kami4"+i //  “X”是ID名称，比如：ID命名为“case1”，这里的“X”即为“case”
    if (Names==tempname){
      Nnews=document.getElementById(NewsHot)
      Nnews.style.display='';
    }else{
      Nnews=document.getElementById(NewsHot)
      Nnews.style.display='none';   
    }
  }
}


