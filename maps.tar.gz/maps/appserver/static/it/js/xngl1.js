$(function () {
    $('#xngl1').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        xAxis: {
            categories: ['lab', 'test']
        },
        yAxis: {
            allowDecimals: false,
            min: 0,
            title: {
                text: ''
            }
        },
        legend: {
            enabled: false
        },
        series: [{
            name: '物理主机数',
            data: [5, 3],
            stack: 'male'
        }]
    });
});
