$(function () {
    $('#zyc-gzxzycl').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        xAxis: {
            categories: ['周家渡机房', '南汇机房']
        },
        yAxis: {
            allowDecimals: false,
            min: 0,
            title: {
                text: ''
            }
        },
        legend: {
            enabled: false
        },
        series: [{
            name: '数量',
            data: [5, 3],
            stack: 'male'
        }]
    });
});
