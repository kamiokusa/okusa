$(document).ready(function(){
    $(".form1bd").attr("disabled", "disabled");
    $(".form2bd").attr("disabled", "disabled");
});
$('.xtsz-bj').bind('click', function() { 
    $(".form1bd").removeAttr("disabled");
    $(".xtsz-bj").hide();
    $(".xtsz-qx").show();
    $(".xtsz-qr").css("margin-left","0px");
    $(".xtsz-qr").show();
 }); 
 $('.xtsz-qx').bind('click', function() { 
    $(".form1bd").attr("disabled", "disabled");
    $(".xtsz-bj").show();
    $(".xtsz-qx").hide();
    $(".xtsz-qr").hide();
    $(".xtsz-qr").css("margin-left","6px");
 });
 $('.xtsz-bj1').bind('click', function() { 
    $(".form2bd").removeAttr("disabled");
    $(".xtsz-bj1").hide();
    $(".xtsz-qx1").show();
    $(".xtsz-qr1").css("margin-left","0px");
    $(".xtsz-qr1").show();
 }); 
 $('.xtsz-qx1').bind('click', function() { 
    $(".form2bd").attr("disabled", "disabled");
    $(".xtsz-bj1").show();
    $(".xtsz-qx1").hide();
    $(".xtsz-qr1").hide();
    $(".xtsz-qr1").css("margin-left","6px");
 }); 