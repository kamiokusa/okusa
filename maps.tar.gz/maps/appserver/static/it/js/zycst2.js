// 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('zycst2'));
        // 指定图表的配置项和数据
        var option = {
    tooltip: {
        textStyle: {
            fontSize: 12
        }
    },
    toolbox: {
        show: false,
        feature: {
            mark: {
                show: false
            },
            dataView: {
                readOnly: true,
                show: false
            },
            restore: {
                show: false
            },
            saveAsImage: {
                show: false
            },
            dataZoom: {
                show: false
            }
        }
    },
    calculable: true,
    series: [
        {
            name: "CPU",
            type: "pie",
            itemStyle: {
                normal: {
                    labelLine: {
                        show: false
                    },
                    label: {
                        show: false
                    }
                },
            },
            data: [
                {
                    value: 85,
                    name: "未使用"
                },
                {
                    value: 15,
                    name: "已使用"
                }
            ],
            radius: ["80%", "60%"],
            startAngle: 90
        }
    ],
    title: {
        x: "center",
        textStyle: {
            color: "rgb(0, 0, 0)",
            fontSize: 14,
            fontStyle: "normal",
            fontWeight: "normal",
            baseline: "top",
            align: "right"
        },
        text: "内存15%",
        y: "center",
        subtext: "已使用",
        subtextStyle: {
            align: "right",
            baseline: "top",
            fontSize: 20,
            fontStyle: "normal",
            fontWeight: "normal",
            color: "rgb(0, 0, 0)"
        }
    },
    color: ["rgb(191, 191, 191)", "rgb(20, 129, 205)", "#da70d6", "#32cd32", "#6495ed", "#ff69b4", "#ba55d3", "#cd5c5c", "#ffa500", "#40e0d0", "rgb(30, 144, 255)", "#ff6347", "#7b68ee", "#00fa9a", "#ffd700", "#6699FF", "#ff6666", "#3cb371", "#b8860b", "#30e0e0"]
}
// 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);