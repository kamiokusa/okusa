window.Q = function(t, i, n) {
    "use strict";
    function e(t, i, n) {
        if (t[$h]()) {
            var s = t._g2 || t[Gh]();
            if (s) {
                s = s._jg || s;
                for (var h = 0,
                r = s[Fh]; r > h; h++) if (i[zh](n, s[h]) === !1 || e(s[h], i, n) === !1) return ! 1;
                return ! 0
            }
        }
    }
    function s(t) {
        if (!t[$h]()) return t instanceof OU ? t: null;
        for (var i, n = t._g2._jg,
        e = n[Fh] - 1; e >= 0;) {
            if (i = n[e], i = s(i)) return i;
            e--
        }
        return null
    }
    function h(t, i, n, e) {
        return e ? r(t, i, n) : a(t, i, n)
    }
    function r(t, i, n) {
        t = t._jg || t;
        for (var e, s = 0,
        h = t[Fh]; h > s; s++) if (e = t[s], e.hasChildren() && !r(e[Yh], i, n) || i[zh](n, e) === !1) return ! 1;
        return ! 0
    }
    function a(t, i, n) {
        t = t._jg || t;
        for (var e, s = 0,
        h = t.length; h > s; s++) if (e = t[s], i[zh](n, e) === !1 || e[$h]() && !a(e[Yh], i, n)) return ! 1;
        return ! 0
    }
    function o(t, i, n, e) {
        return e ? f(t, i, n) : c(t, i, n)
    }
    function f(t, i, n) {
        t = t._jg || t;
        for (var e, s = t[Fh], h = s - 1; h >= 0; h--) if (e = t[h], e[$h]() && !f(e[Yh], i, n) || i[zh](n, e) === !1) return ! 1;
        return ! 0
    }
    function c(t, i, n) {
        t = t._jg || t;
        for (var e, s = t.length,
        h = s - 1; h >= 0; h--) if (e = t[h], i[zh](n, e) === !1 || e[$h]() && !c(e[Yh], i, n)) return ! 1;
        return ! 0
    }
    function u(t, i, n) {
        for (var e, s = (t._jg || t)[Hh](0); s.length;) {
            e = s[0],
            s = s[Uh](1);
            var h = i[zh](n, e);
            if (h === !1) return ! 1;
            if (e[$h]()) {
                var r = e.children;
                r = r._jg || r,
                s = s.concat(r)
            }
        }
        return ! 0
    }
    function _(t, i, n) {
        for (var e, s = (t._jg || t).slice(0); s[Fh];) {
            e = s[s[Fh] - 1],
            s = s[Uh](0, s[Fh] - 1);
            var h = i.call(n, e);
            if (h === !1) return ! 1;
            if (e.hasChildren()) {
                var r = e.children;
                r = r._jg || r,
                s = s.concat(r)
            }
        }
        return ! 0
    }
    function d(t, i) {
        function n(t, n) {
            for (var e = t[Fh], s = n[Fh], h = e + s, r = new Array(h), a = 0, o = 0, f = 0; h > f;) r[f++] = a === e ? n[o++] : o === s || i(t[a], n[o]) <= 0 ? t[a++] : n[o++];
            return r
        }
        function e(t) {
            var i = t[Fh],
            s = Math[Wh](i / 2);
            return 1 >= i ? t: n(e(t[Hh](0, s)), e(t.slice(s)))
        }
        return e(t)
    }
    function l(t, i, n, e) {
        t instanceof hz && (t = t._jg);
        for (var s = 0,
        h = (t._jg || t)[Fh]; h > s; s++) {
            var r = i.call(n, t[s], s, e);
            if (r === !1) return ! 1
        }
        return ! 0
    }
    function v(t, i, n) {
        for (var e = t instanceof hz,
        s = t._jg || t,
        h = 0,
        r = s.length; r > h; h++) {
            var a = s[h];
            i[zh](n, a) && (e ? t.remove(a) : t[Uh](h, 1), h--, r--)
        }
    }
    function b(t, i, n, e) {
        t instanceof hz && (t = t._jg);
        for (var s = (t._jg || t)[Fh] - 1; s >= 0; s--) {
            var h = i[zh](n, t[s], s, e);
            if (h === !1) return ! 1
        }
        return ! 0
    }
    function g(t) {
        if (t[qh] instanceof Function) return t[qh](!0);
        var i, n = [];
        return l(t,
        function(t) {
            i = t && t[qh] instanceof Function ? t[qh]() : t,
            n.push(i)
        },
        this),
        n
    }
    function y(t, i, e) {
        e === n || 0 > e ? t[Xh](i) : t[Uh](e, 0, i)
    }
    function x(t, i) {
        var n = t[Vh](i);
        return 0 > n || n >= t.length ? !1 : t[Uh](n, 1)
    }
    function m(t, i) {
        var n = !1;
        return l(t,
        function(t) {
            return i == t ? (n = !0, !1) : void 0
        }),
        n
    }
    function E(t, i) {
        var n = t;
        for (var e in i) if (i.__lookupGetter__) {
            var s = i.__lookupGetter__(e),
            h = i.__lookupSetter__(e);
            s || h ? (s && n.__defineGetter__(e, s), h && n.__defineSetter__(e, h)) : n[e] = i[e]
        } else n[e] = i[e];
        return n
    }
    function p(t, i, n) {
        if (! (t instanceof Function)) throw new Error("subclass must be type of Function");
        var e = null;
        Kh == typeof i && (e = i, i = t, t = function() {
            i[Zh](this, arguments)
        });
        var s = t[Jh],
        h = function() {};
        return h[Jh] = i[Jh],
        t[Jh] = new h,
        t[Qh] = i.prototype,
        t[Qh].constructor = i,
        E(t[Jh], s),
        e && E(t[Jh], e),
        n && E(t[Jh], n),
        t[Jh].class = t,
        t
    }
    function w(t, i, n) {
        return T(t, i, "constructor", n)
    }
    function T(t, i, n, e) {
        var s = i.superclass;
        if (s) {
            var h = s[n];
            return h ? h[Zh](t, e) : void 0
        }
    }
    function O(t, i, n, e) {
        if ("constructor" == n) return I(t, i, e);
        if (i[tr] instanceof Function) {
            var s = i.super_[Jh][n];
            return s instanceof Function ? s[Zh](t, e) : void 0
        }
    }
    function I(t, i, n) {
        return i[tr] instanceof Function ? i[tr].apply(t, n) : void 0
    }
    function M(t, i) {
        return t[tr] = i,
        t[Jh] = Object[ir](i.prototype, {
            super_: {
                value: i,
                enumerable: !1
            },
            constructor: {
                value: t,
                enumerable: !1
            }
        }),
        t
    }
    function A(t, i, n) {
        if (! (t instanceof Function) && t instanceof Object) {
            i = t[nr];
            var e;
            return t.hasOwnProperty("constructor") ? (e = t.constructor, delete t.constructor) : e = i ?
            function() {
                i[Zh](this, arguments)
            }: function() {},
            A(e, i, t)
        }
        if (i && !(i instanceof Function) && i instanceof Object) return A(t, i.super, i);
        if (i && M(t, i), n) {
            var s = t[Jh];
            for (var h in n) s[h] = n[h]
        }
        return t
    }
    function j(t, i, e, s, h) {
        if (s) return void Object.defineProperty(t, i, {
            value: e,
            enumerable: !0
        });
        var r = {
            configurable: !0,
            enumerable: !0
        },
        a = er + i;
        e !== n && (t[a] = e),
        r.get = function() {
            return this[a]
        },
        r.set = function(t) {
            var n = this[a];
            if (n == t) return ! 1;
            var e = new Tz(this, i, t, n);
            return this[sr](e) ? (this[a] = t, h && h[zh](this, t, n), this.onEvent(e), !0) : !1
        },
        Object[hr](t, i, r)
    }
    function S(t, i) {
        for (var n = 0,
        e = i.length; e > n; n++) {
            var s = i[n];
            j(t, s[rr] || s, s.defaultValue || s[ar], s[or], s.onSetting)
        }
    }
    function C(t, i, n) {
        return i instanceof Object ? t = t[fr](i) : i && !n && (n = parseInt(i)),
        i && !n && (n = parseInt(i)),
        n ? setTimeout(t, n) : setTimeout(t)
    }
    function k(i, n) {
        return n && (i = i.bind(n)),
        t.requestAnimationFrame(i)
    }
    function L(t, i) {
        return t[cr] = i,
        t
    }
    function P(t, i) {
        if (!t.hasOwnProperty(ur)) {
            var n = t[_r](dr);
            if (!n) return L(t, i);
            for (var e = n[lr](vr), s = 0, h = e.length; h > s; s++) if (e[s] == i) return;
            return n += vr + i,
            L(t, n)
        }
        t[ur].add(i)
    }
    function R(t, i) {
        if (!t.hasOwnProperty(ur)) {
            var n = t.getAttribute(dr);
            if (!n || !n[Vh](i)) return;
            for (var e = "",
            s = n[lr](vr), h = 0, r = s[Fh]; r > h; h++) s[h] != i && (e += s[h] + vr);
            return L(t, e)
        }
        t[ur].remove(i)
    }
    function D(t) {
        return ! isNaN(t) && t instanceof Number || br == typeof t
    }
    function N(t) {
        return t !== n && (t instanceof String || gr == typeof t)
    }
    function B(t) {
        return t !== n && (t instanceof Boolean || yr == typeof t)
    }
    function $(t) {
        return Array[xr](t)
    }
    function G(i) {
        i || (i = t[mr]),
        i[Er] ? i.preventDefault() : i[pr] = !1
    }
    function F(i) {
        i || (i = t[mr]),
        i.stopPropagation ? i[wr]() : i[Tr] || (i[Tr] = !0)
    }
    function z(t) {
        G(t),
        F(t)
    }
    function Y(t) {
        return Math[Or](Math[Ir]() * t)
    }
    function H() {
        return Math.random() >= .5
    }
    function U(t) {
        var i = !0;
        for (var n in t) {
            i = !1;
            break
        }
        return i
    }
    function W(t) {
        if (t && t > 0 && 1 > t) {
            var i = Math.floor(16777215 * Math[Ir]());
            return Mr + (i >> 16 & 255) + Ar + (i >> 8 & 255) + Ar + (255 & i) + Ar + t[jr](2) + Sr
        }
        return V(Math[Or](16777215 * Math.random()))
    }
    function q(t) {
        return t > 0 ? Math[Or](t) : Math[Wh](t)
    }
    function X(t) {
        return t > 0 ? Math.ceil(t) : Math.floor(t)
    }
    function V(t) {
        return 16777216 > t ? Cr + (kr + t.toString(16))[Hh]( - 6) : Mr + (t >> 16 & 255) + Ar + (t >> 8 & 255) + Ar + (255 & t) + Ar + ((t >> 24 & 255) / 255)[jr](2) + Sr
    }
    function K(t, i, n) {
        Kh != typeof n || n.hasOwnProperty(Lr) || (n[Lr] = !0),
        Object[hr](t, i, n)
    }
    function Z(t, i) {
        for (var n in i) if (Pr != n[0]) {
            var e = i[n];
            Kh != typeof e || e.hasOwnProperty(Lr) || (e[Lr] = !0)
        }
        Object[Rr](t, i)
    }
    function J(i, n) {
        n || (n = t);
        for (var e = i.split(Dr), s = 0, h = e[Fh]; h > s; s++) {
            var r = e[s];
            n = n[r]
        }
        return n
    }
    function Q(t) {
        return t instanceof MouseEvent || t instanceof Object && t[Nr] !== n
    }
    function ti(i) {
        t[Br] && console.log(i)
    }
    function ii(i) {
        t[Br] && console[$r](i)
    }
    function ni(i) {
        t[Br] && console.error(i)
    }
    function ei(t, i, n) {
        var e, s, h;
        0 == t._ne ? (e = -1, h = 0, s = i) : 0 == t._nh ? (e = 0, h = 1, s = n) : (e = -1 / t._ne, s = (t._ne - e) * i + t._ng, h = 1);
        var r = new cz;
        return r._ne = e,
        r._ng = s,
        r._nh = h,
        r._nc = i,
        r._nb = n,
        r._l0 = Math.atan2(e, h),
        r._nhos = Math.cos(r._l0),
        r._sin = Math.sin(r._l0),
        r
    }
    function si(t, i, n, e, s) {
        var h, r;
        i > e ? h = -1 : e > i && (h = 1),
        n > s ? r = -1 : s > n && (r = 1);
        var a, o;
        if (!h) return o = 0 > r ? t.y: t.bottom,
        {
            x: i,
            y: o
        };
        if (!r) return a = 0 > h ? t.x: t[Gr],
        {
            x: a,
            y: n
        };
        var f = (n - s) / (i - e),
        c = n - f * i,
        u = 0 > h ? i - t.x: i - t.right,
        _ = 0 > r ? n - t.y: n - t[Fr];
        return Math.abs(f) >= Math.abs(_ / u) ? (o = 0 > r ? t.y: t[Fr], a = (o - c) / f) : (a = 0 > h ? t.x: t[Gr], o = f * a + c),
        {
            x: a,
            y: o
        }
    }
    function hi(t, i, n, e, s, h, r, a) {
        return 0 >= r || 0 >= a || 0 >= n || 0 >= e ? !1 : (r += s, a += h, n += t, e += i, (s > r || r > t) && (h > a || a > i) && (t > n || n > s) && (i > e || e > h))
    }
    function ri(t, i, n, e, s, h) {
        return s >= t && t + n >= s && h >= i && i + e >= h
    }
    function ai(t, i, n, e, s, h, r, a, o) {
        return o && (t -= o, i -= o, n += o + o, e += o + o),
        s >= t && h >= i && t + n >= s + r && i + e >= h + a
    }
    function oi(t, i, n, e, s, h, r, a) {
        var o = t;
        o += n;
        var f = i;
        f += e;
        var c = s;
        c += r;
        var u = h;
        return u += a,
        s > t && (t = s),
        h > i && (i = h),
        o > c && (o = c),
        f > u && (f = u),
        o -= t,
        f -= i,
        0 > o || 0 > f ? null: new _z(t, i, o, f)
    }
    function fi(t, i, e) {
        if (N(t) && (t = lz[zr](t)), !t) return {
            x: 0,
            y: 0
        };
        if (t.x !== n) return {
            x: t.x,
            y: t.y
        };
        var s, h, r = t[Yr],
        a = t[Hr];
        switch (r) {
        case vz:
            s = 0;
            break;
        case gz:
            s = i;
            break;
        default:
            s = i / 2
        }
        switch (a) {
        case yz:
            h = 0;
            break;
        case mz:
            h = e;
            break;
        default:
            h = e / 2
        }
        return {
            x: s,
            y: h
        }
    }
    function ci(t, i, n) {
        t[Yh].add(i, n),
        t[Ur](i, n)
    }
    function ui(t, i) {
        t._g2 && (t._g2.remove(i), t[Wr](i))
    }
    function _i(t) {
        return t.replace(/^-ms-/, qr).replace(/-([\da-z])/gi,
        function(t, i) {
            return i.toUpperCase()
        })
    }
    function di(t) {
        return t[Xr](/[A-Z]/g,
        function(t) {
            return Vr + t.toLowerCase()
        })[Xr](/^ms-/, Kr)
    }
    function li(t, i) {
        var n = t.style;
        if (!n) return ! 1;
        var e, s;
        for (e in i) i.hasOwnProperty(e) && (s = Gz(e)) && (n[s] = i[e]);
        return t
    }
    function vi(t) {
        var i, n, e = "";
        for (i in t) t.hasOwnProperty(i) && (n = Gz(i)) && (e += di(n) + Zr + t[i] + Jr);
        return e ? e[Qr](0, e[Fh] - 1) : e
    }
    function bi(t, i, n) { (i = Gz(i)) && (t[ta][i] = n)
    }
    function gi(t, i) {
        return Bz ? (i && !N(i) && (i = vi(i)), Bz[ia] ? void Bz[ia](t + na + i + ea, 0) : void(Bz[sa] && Bz[sa](t, i, 0))) : !1
    }
    function yi(i, n) {
        i[Nr] && (i = i.changedTouches && i.changedTouches[Fh] ? i.changedTouches[0] : i[Nr][0]);
        var e = n[ha](),
        s = i[ra] || 0,
        h = i[aa] || 0;
        return nz && ZF && (t[oa] && s == i[fa] && (s -= t[oa]), t.pageYOffset && h == i[ca] && (h -= t.pageYOffset)),
        {
            x: s - e.left,
            y: h - e.top
        }
    }
    function xi(t, i, n) {
        this._mk = t,
        this[ua] = n,
        this[_a] = i,
        this[da] = new Ei,
        this[la]()
    }
    function mi(t) {
        return JF && t.metaKey || !JF && t[va]
    }
    function Ei() {
        this[ba] = []
    }
    function pi(t, i, n, e, s) {
        Ti(t,
        function(e) {
            if (i) {
                var s = e[ga];
                if (!s) return void(n || yY)(ya + t + xa);
                i(s)
            }
        },
        n, e, s)
    }
    function wi(t, i, n, e, s) {
        Ti(t,
        function(e) {
            if (i) {
                var s, h = e.responseText;
                if (!h) return (n || yY)(ya + t + ma),
                s = new Error(ya + t + ma),
                i(h, s);
                try {
                    h = JSON[Ea](h)
                } catch(r) { (n || yY)(r),
                    s = r
                }
                i(h, s)
            }
        },
        n, e, s)
    }
    function Ti(t, i, n, e, s) { (n === !1 || e === !1) && (s = !1);
        try {
            var h = new XMLHttpRequest,
            r = encodeURI(t);
            if (s !== !1) {
                var a;
                a = r[Vh](pa) > 0 ? "&": pa,
                r += a + wa + Date.now()
            }
            h[Ta](Oa, r),
            h[Ia] = function() {
                return 4 == h[Ma] ? h[Aa] && 200 != h.status ? void(n || yY)(ya + t + ja) : void(i && i(h)) : void 0
            },
            h.send(e)
        } catch(o) { (n || yY)(ya + t + ja, o)
        }
    }
    function hi(t, i, n, e, s, h, r, a) {
        return 0 >= r || 0 >= a || 0 >= n || 0 >= e ? !1 : (r += s, a += h, n += t, e += i, (s > r || r > t) && (h > a || a > i) && (t > n || n > s) && (i > e || e > h))
    }
    function ai(t, i, n, e, s, h, r, a) {
        return s >= t && h >= i && t + n >= s + r && i + e >= h + a
    }
    function Oi(t, i, n) {
        return t instanceof Object && t.x ? Mi(t, i, 0, 0) : Ii(t, i, n, 0, 0)
    }
    function Ii(t, i, n, e, s) {
        var h = Math.sin(n),
        r = Math.cos(n),
        a = t - e,
        o = i - s;
        return t = a * r - o * h + e,
        i = a * h + o * r + s,
        new oz(t, i, n)
    }
    function Mi(t, i, n, e) {
        n = n || 0,
        e = e || 0;
        var s = Math.sin(i),
        h = Math.cos(i),
        r = t.x - n,
        a = t.y - e;
        return t.x = r * h - a * s + n,
        t.y = r * s + a * h + e,
        t
    }
    function Ai(t, i, n) {
        return ji(t, i, n, 0, 0)
    }
    function ji(t, i, n, e, s) {
        var h = Ii(t.x, t.y, i, e, s),
        r = Ii(t.x + t[Sa], t.y, i, e, s),
        a = Ii(t.x + t[Sa], t.y + t[Ca], i, e, s),
        o = Ii(t.x, t.y + t[Ca], i, e, s);
        return n ? n.clear() : n = new _z,
        n[ka](h),
        n.addPoint(r),
        n[ka](a),
        n.addPoint(o),
        n
    }
    function Si(t, i) {
        var n = this[La] || 1;
        this[ta][Sa] = t + Pa,
        this[ta][Ca] = i + Pa,
        this.width = t * n,
        this[Ca] = i * n
    }
    function Ci(t) {
        var i = t[Ra] || t[Da] || t[Na] || t[Ba] || t[$a] || 1;
        return EY / i
    }
    function ki(t, n, e) {
        var s = i[Ga](Fa);
        if (s.g = s.getContext(za), t !== !0 && !e) return t && n && (s.width = t, s.height = n),
        s;
        var h = s.g;
        return h[La] = s.ratio = Ci(h),
        s[Ya] = Si,
        h._l3 = function() {
            this.canvas[Sa] = this[Fa][Sa]
        },
        t && n && s[Ya](t, n),
        s
    }
    function Li(t, i, e) {
        if (t === n || null === t) return {
            width: 0,
            height: 0
        };
        var s = Pi();
        e = e || sz[Ha],
        s[Ua] != e && (s[Ua] = e);
        for (var h = i * sz[Wa], r = 0, a = 0, o = t[lr](qa), f = 0, c = o[Fh]; c > f; f++) {
            var u = o[f];
            r = Math.max(s.measureText(u)[Sa], r),
            a += h
        }
        return {
            width: r,
            height: a
        }
    }
    function Pi(t, i) {
        return pY || (pY = ki()),
        t && i && (pY.width = t, pY[Ca] = i),
        pY.g
    }
    function Ri(t, i, n, e, s) {
        var h;
        if (HF) try {
            h = t[Xa](i, n, e, s)
        } catch(r) {} else h = t[Xa](i, n, e, s);
        return h
    }
    function Di(t) {
        return Math.log(t + Math.sqrt(t * t + 1))
    }
    function Ni(t, i) {
        i = i || t(1);
        var n = 1 / i,
        e = .5 * n,
        s = Math.min(1, i / 100);
        return function(h) {
            if (0 >= h) return 0;
            if (h >= i) return 1;
            for (var r = h * n,
            a = 0; a++<10;) {
                var o = t(r),
                f = h - o;
                if (Math.abs(f) <= s) return r;
                r += f * e
            }
            return r
        }
    }
    function Bi(t, i, n) {
        var e = 1 - t,
        s = e * e * i[0] + 2 * e * t * i[2] + t * t * i[4],
        h = e * e * i[1] + 2 * e * t * i[3] + t * t * i[5];
        if (n) {
            var r = (i[0] + i[4] - 2 * i[2]) * t + i[2] - i[0],
            a = (i[1] + i[5] - 2 * i[3]) * t + i[3] - i[1];
            return {
                x: s,
                y: h,
                rotate: Math[Va](a, r)
            }
        }
        return {
            t: t,
            x: s,
            y: h
        }
    }
    function $i(t, i, n) {
        var e = t - 2 * i + n;
        return 0 != e ? (t - i) / e: -1
    }
    function Gi(t, i) {
        i.add(t[4], t[5]);
        var n = $i(t[0], t[2], t[4]);
        if (n > 0 && 1 > n) {
            var e = Bi(n, t);
            i.add(e.x, e.y)
        }
        var s = $i(t[1], t[3], t[5]);
        if (s > 0 && 1 > s) {
            var e = Bi(s, t);
            i.add(e.x, e.y)
        }
        return i
    }
    function Fi(t, i) {
        return Math.abs(t - i) < 1e-7
    }
    function zi(t) {
        if (Fi(t[1], t[3]) && (Fi(t[0], t[2]) || Fi(t[1], t[5]))) {
            var i = t[0],
            n = t[1],
            e = t[4],
            s = t[5],
            h = Math.sqrt(wY(i, n, e, s));
            return function(t) {
                return h * t
            }
        }
        var r = t[0],
        a = t[2],
        o = t[4],
        f = r - 2 * a + o,
        c = 2 * a - 2 * r;
        r = t[1],
        a = t[3],
        o = t[5];
        var u = r - 2 * a + o,
        _ = 2 * a - 2 * r,
        d = 4 * (f * f + u * u),
        l = 4 * (f * c + u * _),
        v = c * c + _ * _,
        h = 4 * d * v - l * l,
        b = 1 / h,
        g = .125 * Math.pow(d, -1.5),
        y = 2 * Math[Ka](d),
        x = (h * Di(l / Math.sqrt(h)) + 2 * Math[Ka](d) * l * Math.sqrt(v)) * g;
        return function(t) {
            var i = l + 2 * t * d,
            n = i / Math[Ka](h),
            e = i * i * b;
            return (h * Math.log(n + Math.sqrt(e + 1)) + y * i * Math[Ka](v + t * l + t * t * d)) * g - x
        }
    }
    function Yi(t, i, n) {
        var e = 1 - t,
        s = i[0],
        h = i[2],
        r = i[4],
        a = i[6],
        o = s * e * e * e + 3 * h * t * e * e + 3 * r * t * t * e + a * t * t * t;
        if (n) var f = 3 * t * t * a + (6 * t - 9 * t * t) * r + (9 * t * t - 12 * t + 3) * h + ( - 3 * t * t + 6 * t - 3) * s;
        s = i[1],
        h = i[3],
        r = i[5],
        a = i[7];
        var c = s * e * e * e + 3 * h * t * e * e + 3 * r * t * t * e + a * t * t * t;
        if (n) {
            var u = 3 * t * t * a + (6 * t - 9 * t * t) * r + (9 * t * t - 12 * t + 3) * h + ( - 3 * t * t + 6 * t - 3) * s;
            return {
                x: o,
                y: c,
                rotate: Math[Va](u, f)
            }
        }
        return {
            x: o,
            y: c
        }
    }
    function Hi(t, i, n, e) {
        var s = -t + 3 * i - 3 * n + e;
        if (0 == s) return [(t - i) / (2 * n - 4 * i + 2 * t)];
        var h = 2 * t - 4 * i + 2 * n,
        r = i - t,
        a = h * h - 4 * s * r;
        return 0 > a ? void 0 : 0 == a ? [ - h / (2 * s)] : (a = Math[Ka](a), [(a - h) / (2 * s), ( - a - h) / (2 * s)])
    }
    function Ui(t, i) {
        i.add(t[6], t[7]);
        var n = Hi(t[0], t[2], t[4], t[6]);
        if (n) for (var e = 0; e < n.length; e++) {
            var s = n[e];
            if (! (0 >= s || s >= 1)) {
                var h = Yi(s, t);
                i.add(h.x, h.y)
            }
        }
        if (n = Hi(t[1], t[3], t[5], t[7])) for (var e = 0; e < n[Fh]; e++) {
            var s = n[e];
            if (! (0 >= s || s >= 1)) {
                var h = Yi(s, t);
                i.add(h.x, h.y)
            }
        }
    }
    function Wi(t) {
        var i = {
            x: t[0],
            y: t[1]
        },
        n = {
            x: t[2],
            y: t[3]
        },
        e = {
            x: t[4],
            y: t[5]
        },
        s = {
            x: t[6],
            y: t[7]
        },
        h = i.x - 0,
        r = i.y - 0,
        a = n.x - 0,
        o = n.y - 0,
        f = e.x - 0,
        c = e.y - 0,
        u = s.x - 0,
        _ = s.y - 0,
        d = 3 * ( - h + 3 * a - 3 * f + u),
        l = 6 * (h - 2 * a + f),
        v = 3 * ( - h + a),
        b = 3 * ( - r + 3 * o - 3 * c + _),
        g = 6 * (r - 2 * o + c),
        y = 3 * ( - r + o),
        x = function(t) {
            var i = d * t * t + l * t + v,
            n = b * t * t + g * t + y;
            return Math[Ka](i * i + n * n)
        },
        m = (x(0) + 4 * x(.5) + x(1)) / 6;
        return m
    }
    function qi(t, i) {
        function n(t, i, n, e) {
            var s = -t + 3 * i - 3 * n + e,
            h = 2 * t - 4 * i + 2 * n,
            r = i - t;
            return function(t) {
                return 3 * (s * t * t + h * t + r)
            }
        }
        function e(t, i) {
            var n = s(t),
            e = h(t);
            return Math.sqrt(n * n + e * e) * i
        }
        var s = n(t[0], t[2], t[4], t[6]),
        h = n(t[1], t[3], t[5], t[7]);
        i = i || 100;
        var r = 1 / i;
        return function(t) {
            if (!t) return 0;
            for (var i, n = 0,
            s = 0;;) {
                if (i = n + r, i >= t) return s += e(n, i - n);
                s += e(n, r),
                n = i
            }
        }
    }
    function Xi(t, i, n) {
        return wY(i, n, t.cx, t.cy) <= t[Za] + TY
    }
    function Vi(t, i, n, e) {
        return n = n || Ki(t, i),
        new Zi((t.x + i.x) / 2, (t.y + i.y) / 2, n / 2, t, i, null, e)
    }
    function Ki(t, i) {
        return fz(t.x, t.y, i.x, i.y)
    }
    function Zi(t, i, n, e, s, h, r) {
        this.cx = t,
        this.cy = i,
        this.r = n,
        this[Za] = n * n,
        this.p1 = e,
        this.p2 = s,
        this.p3 = h,
        this[Ja] = r
    }
    function Ji(t, i, n, e) {
        this.cx = t,
        this.cy = i,
        this[Sa] = n,
        this[Ca] = e
    }
    function Qi(t) {
        var i = t[0],
        n = t[1],
        e = t[2],
        s = Zi[Qa](i, n, e);
        return nn(t, i, n, e, s)
    }
    function tn(t, i) {
        i = i || en(t);
        for (var n, e = i[Sa] / i[Ca], s = [], h = t[Fh], r = 0; h > r; r++) n = t[r],
        s[Xh]({
            x: n.x,
            y: n.y * e
        });
        var a = Qi(s);
        return a ? new Ji(a.cx, a.cy / e, 2 * a.r, 2 * a.r / e) : void 0
    }
    function nn(t, i, n, e, s) {
        for (var h, r, a = t[Fh], o = s._squareR, f = 0; a > f; f++) if (h = t[f], h != i && h != n && h != e) {
            var c = wY(s.cx, s.cy, h.x, h.y);
            c - TY > o && (o = c, r = h)
        }
        if (!r) return s;
        var u, _ = Zi._jqCircle(r, i, n),
        d = Zi[Qa](r, i, e),
        l = Zi._jqCircle(r, e, n);
        return Xi(_, e.x, e.y) && (u = _),
        Xi(d, n.x, n.y) && (!u || u.r > d.r) && (u = d),
        Xi(l, i.x, i.y) && (!u || u.r > l.r) && (u = l),
        i = u.p1,
        n = u.p2,
        e = u.p3 || u[Ja],
        nn(t, i, n, e, u)
    }
    function en(t) {
        for (var i, n = t.length,
        e = new _z,
        s = 0; n > s; s++) i = t[s],
        e.add(i.x, i.y);
        return e
    }
    function sn(t, i, n, e, s) {
        this._6h && this[to]();
        var h = s ? this[io](s) : this[no],
        r = n / h[Sa],
        a = t - r * h.x,
        o = e / h[Ca],
        f = i - o * h.y,
        c = this._fx,
        u = [];
        return l(c,
        function(t) {
            var i = t[qh](),
            n = i.points;
            if (n && n.length) {
                for (var e = n[Fh], s = [], h = 0; e > h; h++) {
                    var c = n[h];
                    h++;
                    var _ = n[h];
                    c = r * c + a,
                    _ = o * _ + f,
                    s.push(c),
                    s[Xh](_)
                }
                i[ba] = s
            }
            u[Xh](i)
        },
        this),
        new iH(u)
    }
    function hn(t, i, n, e, s, h) {
        if (s = s || 0, n = n || 0, !s && !h) return ! 1;
        if (!e) {
            var r = this.getBounds(s);
            if (!r.intersectsPoint(t, i, n)) return ! 1
        }
        var a = Math[eo](2 * n) || 1,
        o = Pi(a, a),
        f = (o.canvas, -t + n),
        c = -i + n;
        if (o.setTransform(1, 0, 0, 1, f, c), !o[so]) {
            this._lt(o),
            s && o[ho](),
            h && o[ro]();
            var u = Ri(o, 0, 0, a, a);
            if (!u) return ! 1;
            u = u[ao];
            for (var _ = u[Fh] / 4; _ > 0;) {
                if (u[4 * _ - 1] > tH) return ! 0; --_
            }
            return ! 1
        }
        return o.lineWidth = (s || 0) + 2 * n,
        this._lt(o),
        s && o.isPointInStroke(n, n) ? !0 : h ? o.isPointInPath(n, n) : !1
    }
    function rn(t, i, n) {
        if (!this._jb) return null;
        var e = this._fx;
        if (e[Fh] < 2) return null;
        n === !1 && (t += this._jb);
        var s = e[0];
        if (0 >= t) return Bs(s[ba][0], s[ba][1], e[1][ba][0], e[1][ba][1], t, i);
        if (t >= this._jb) {
            s = e[e[Fh] - 1];
            var h, r, a = s[ba],
            o = a[Fh],
            f = a[o - 2],
            c = a[o - 1];
            if (o >= 4) h = a[o - 4],
            r = a[o - 3];
            else {
                s = e[e.length - 2];
                var u = s[oo];
                h = u.x,
                r = u.y
            }
            return Bs(f, c, f + f - h, c + c - r, t - this._jb, i)
        }
        for (var _, d = 0,
        l = 1,
        o = e[Fh]; o > l; l++) if (_ = e[l], _._jb) {
            if (! (d + _._jb < t)) {
                var v, u = s[oo];
                if (_[fo] == ZY) {
                    var b = _[ba];
                    v = an(t - d, _, u.x, u.y, b[0], b[1], b[2], b[3], _._r)
                } else {
                    if (!_._lf) return Bs(u.x, u.y, _.points[0], _[ba][1], t - d, i);
                    var g = Ni(_._lf, _._jb)(t - d),
                    b = _[ba];
                    v = _[fo] == KY && 6 == b.length ? Yi(g, [u.x, u.y][co](b), !0) : Bi(g, [u.x, u.y][co](b), !0)
                }
                return i && (v.x -= i * Math.sin(v.rotate || 0), v.y += i * Math.cos(v[uo] || 0)),
                v
            }
            d += _._jb,
            s = _
        } else s = _
    }
    function an(t, i, n, e, s, h, r, a) {
        if (t <= i._l1) return Bs(n, e, s, h, t, t);
        if (t >= i._jb) return t -= i._jb,
        Bs(i[_o], i[lo], r, a, t, t);
        if (t -= i._l1, i._o) {
            var o = t / i._r;
            i[vo] && (o = -o);
            var f = Ii(i[bo], i._p1y, o, i._o.x, i._o.y);
            return f.rotate += i._ne1 || 0,
            f.rotate += Math.PI,
            f
        }
        return Bs(i[bo], i[go], i._p2x, i[lo], t, t)
    }
    function ei(t, i, n) {
        var e, s, h;
        0 == t._ne ? (e = -1, h = 0, s = i) : 0 == t._nh ? (e = 0, h = 1, s = n) : (e = -1 / t._ne, s = (t._ne - e) * i + t._ng, h = 1);
        var r = new cz;
        return r._ne = e,
        r._ng = s,
        r._nh = h,
        r._nc = i,
        r._nb = n,
        r
    }
    function on(t) {
        return t %= 2 * Math.PI,
        0 > t && (t += 2 * Math.PI),
        t
    }
    function fn(t, i, n, e, s, h, r, a) {
        var o = fz(i, n, e, s),
        f = fz(e, s, h, r);
        if (!o || !f) return t._d = 0,
        t._r = 0,
        t._l1 = o,
        t._l2 = f,
        t._jb = 0;
        var c = un(e, s, i, n),
        u = un(e, s, h, r);
        t[yo] = c,
        t[xo] = u;
        var _ = c - u;
        _ = on(_),
        _ > Math.PI && (_ = 2 * Math.PI - _, t[vo] = !0);
        var d = Math.PI - _,
        l = Math.tan(_ / 2),
        v = a / l,
        b = Math.min(o, f);
        v > b && (v = b, a = l * v);
        var g, y = e + Math.cos(c) * v,
        x = s + Math.sin(c) * v,
        m = e + Math.cos(u) * v,
        E = s + Math.sin(u) * v,
        p = new cz(i, n, e, s),
        w = new cz(e, s, h, r),
        T = ei(p, y, x),
        O = ei(w, m, E),
        I = T._3s(O),
        M = Math.atan2(x - I.y, y - I.x),
        A = Math.atan2(E - I.y, m - I.x);
        g = t[vo] ? A: M;
        for (var j, S = 0; 4 > S;) {
            var C = S * rz;
            if (on(C - g) <= d) {
                var k, L;
                if (j ? j++:j = 1, 0 == S ? (k = I.x + a, L = I.y) : 1 == S ? (k = I.x, L = I.y + a) : 2 == S ? (k = I.x - a, L = I.y) : (k = I.x, L = I.y - a), t[mo + j] = {
                    x: k,
                    y: L
                },
                2 == j) break
            }
            S++
        }
        return t._p1x = y,
        t[go] = x,
        t[_o] = m,
        t._p2y = E,
        t._o = I,
        t._d = v,
        t._r = a,
        t._l1 = o - v,
        t._l2 = f - v,
        t._jb = t._l1 + d * a
    }
    function cn(t, i, n, e, s, h, r) {
        var a = un(n, e, t, i),
        o = un(n, e, s, h),
        f = a - o;
        return r ? f: (0 > f && (f = -f), f > Math.PI && (f -= Math.PI), f)
    }
    function un(t, i, n, e) {
        return Math.atan2(e - i, n - t)
    }
    function _n(t) {
        var i = IY[Eo](t);
        if (i) return i[1];
        var n = t[po](Dr);
        return n >= 0 && n < t.length - 1 ? t[Qr](n + 1) : void 0
    }
    function dn(t) {
        if (!t) return null;
        if (t instanceof iH) return LY;
        if (t[wo] instanceof Function) return kY;
        if (N(t)) {
            var i = _n(t);
            if (i) {
                if (!HF && MY.test(i)) return CY;
                if (AY[To](i)) return SY
            }
            return jY
        }
    }
    function ln(t, i, n) {
        if (this._lr = dn(t), !this._lr) throw new Error("the image format is not supported", t);
        this._mn = t,
        this._neu = i,
        this._8z = n,
        this.width = i || sz[Oo],
        this.height = n || sz[Io],
        this._jn = {}
    }
    function vn(t, i, n, e) {
        return i ? (NY[t] = new ln(i, n, e), t) : void delete NY[t]
    }
    function bn(t) {
        if (t._l7) return t._l7;
        var i = N(t);
        if (!i && !t[rr]) return t._l7 = new ln(t);
        var n = t.name || t;
        return n in NY ? NY[n] : NY[n] = new ln(t)
    }
    function gn(t) {
        return t in NY
    }
    function yn(t, i, n) {
        n = n || {};
        var e = t[io](n.lineWidth);
        if (!e[Sa] || !e[Ca]) return ! 1;
        var s = i[Mo](za),
        h = i[La] || 1,
        r = n[Ao] || jo,
        a = /full/i.test(r),
        o = /uniform/i.test(r),
        f = 1,
        c = 1;
        if (a) {
            var u = i[Sa],
            _ = i.height,
            d = n[So],
            l = 0,
            v = 0;
            if (d) {
                var b, g, y, x;
                D(d) ? b = g = y = x = d: (b = d.top || 0, g = d[Fr] || 0, y = d[Co] || 0, x = d.right || 0),
                u -= y + x,
                _ -= b + g,
                l += y,
                v += b
            }
            f = u / e.width,
            c = _ / e[Ca],
            o && (f > c ? (l += (u - c * e[Sa]) / 2, f = c) : c > f && (v += (_ - f * e[Ca]) / 2, c = f)),
            (l || v) && s.translate(l, v)
        }
        s.translate( - e.x * f, -e.y * c),
        t[wo](s, h, n, f, c, !0)
    }
    function xn(t, i, n) {
        var e = bn(t);
        return e ? (e[to](), (e._lr == CY || e._6j()) && e[ko](function(t) {
            t[Lo] && (this.width = this[Sa], yn(t[Lo], this, n))
        },
        i), void yn(e, i, n)) : (xY[Po](Ro + t), !1)
    }
    function mn(t, i, e, s) {
        var h = t[Fh];
        if (h && !(0 > h)) {
            s = s || 1;
            for (var r, a, o, f = [], c = 0; c++<h;) if (r = t.getLocation(c, 0), r && fz(i, e, r.x, r.y) <= s) {
                a = c,
                o = r[uo];
                break
            }
            if (a !== n) {
                for (var r, u, _, d = 0,
                c = 0,
                l = t._fx[Fh]; l > c; c++) {
                    if (r = t._fx[c], !u && (d += r._jb || 0, d > a)) if (u = !0, r.type == XY || r.type == JY) f.push(new QY(XY, [i, e]));
                    else {
                        var v = Math.max(10, r._jb / 6),
                        b = v * Math.sin(o),
                        g = v * Math.cos(o);
                        if (r[fo] == KY) {
                            var y = r.points[0],
                            x = r[ba][1];
                            if (_) {
                                var m = new cz(i, e, i + g, e + b),
                                E = m._3s(new cz(_[oo].x, _[oo].y, r[ba][0], r[ba][1]));
                                E.x !== n && (y = E.x, x = E.y)
                            }
                            f.push(new QY(KY, [y, x, i - g, e - b, i, e]))
                        } else f[Xh](new QY(VY, [i - g, e - b, i, e]));
                        if (r[ba]) if (r[fo] == KY) {
                            r[ba][0] = i + g,
                            r[ba][1] = e + b;
                            var m = new cz(i, e, i + g, e + b),
                            E = m._3s(new cz(r.points[2], r[ba][3], r[ba][4], r.points[5]));
                            E.x !== n && (r[ba][2] = E.x, r.points[3] = E.y)
                        } else if (r[fo] == VY) {
                            r[fo] = KY,
                            r[ba] = [i + g, e + b][co](r[ba]);
                            var m = new cz(i, e, i + g, e + b),
                            E = m._3s(new cz(r.points[2], r[ba][3], r[ba][4], r[ba][5]));
                            E.x !== n && (r[ba][2] = E.x, r[ba][3] = E.y)
                        } else r[fo] == XY && (r[fo] = VY, r[ba] = [i + g, e + b].concat(r[ba]), c == l - 1 && (r.invalidTerminal = !0))
                    }
                    f[Xh](r),
                    _ = r
                }
                return f
            }
        }
    }
    function En(t) {
        var i = t.width,
        n = t.height,
        e = Ri(t.g, 0, 0, i, n);
        return e ? wn(e[ao], i, n) : void 0
    }
    function pn(t, i, n) {
        this._12(t, i, n)
    }
    function wn(t, i, n) {
        return new pn(t, i, n)
    }
    function Tn(t) {
        if (Cr == t[0]) {
            if (t = t[Qr](1), 3 == t[Fh]) t = t[0] + t[0] + t[1] + t[1] + t[2] + t[2];
            else if (6 != t[Fh]) return;
            return t = parseInt(t, 16),
            [t >> 16 & 255, t >> 8 & 255, 255 & t]
        }
        if (/^rgb/i[To](t)) {
            var i = t[Vh](Do),
            n = t.indexOf(Sr);
            if (0 > i || i > n) return;
            if (t = t[Qr](i + 1, n), t = t[lr](Ar), t.length < 3) return;
            var e = parseInt(t[0]),
            s = parseInt(t[1]),
            h = parseInt(t[2]),
            r = 3 == t[Fh] ? 255 : parseInt(t[3]);
            return [e, s, h, r]
        }
    }
    function On(t, i, n) {
        return n || (n = sz.BLEND_MODE),
        n == mY.BLEND_MODE_MULTIPLY ? t * i: n == mY[No] ? Math.min(t, i) : n == mY[Bo] ? 1 - (1 - i) / t: n == mY[$o] ? t + i - 1 : n == mY.BLEND_MODE_LIGHTEN ? Math.max(t, i) : n == mY[Go] ? t + i - t * i: i
    }
    function In(t, i, n) {
        var e = Tn(i);
        if (!e) return void xY.error(Fo + i + zo);
        var s = Ri(t.g, 0, 0, t.width, t[Ca]);
        if (s) {
            var h = s[ao];
            if (n instanceof Function) h = n(t, h, e) || h;
            else {
                var r = e[0] / 255,
                a = e[1] / 255,
                o = e[2] / 255;
                if (n == mY[Yo]) for (var f = 0,
                c = h[Fh]; c > f; f += 4) {
                    var u = 77 * h[f] + 151 * h[f + 1] + 28 * h[f + 2] >> 8;
                    h[f] = u * r | 0,
                    h[f + 1] = u * a | 0,
                    h[f + 2] = u * o | 0
                } else for (var f = 0,
                c = h.length; c > f; f += 4) h[f] = 255 * On(r, h[f] / 255, n) | 0,
                h[f + 1] = 255 * On(a, h[f + 1] / 255, n) | 0,
                h[f + 2] = 255 * On(o, h[f + 2] / 255, n) | 0
            }
            var t = ki(t[Sa], t[Ca]);
            return t.g[Ho](s, 0, 0),
            t
        }
    }
    function Mn(t, i, n, e) {
        return 1 > n && (n = 1),
        An(t - n, i - n, 2 * n, 2 * n, e)
    }
    function An(t, i, n, e, s) {
        n = Math[eo](n) || 1,
        e = Math.round(e) || 1;
        var h = Pi(n, e);
        h[Uo](1, 0, 0, 1, -t, -i),
        s[wo](h);
        var r = Ri(h, 0, 0, n, e);
        if (!r) return ! 1;
        r = r.data;
        for (var a = r.length / 4; a-->0;) if (r[4 * a - 1] > tH) return ! 0;
        return ! 1
    }
    function jn(t, i, n, e, s, h) {
        t -= s.$x,
        i -= s.$y;
        var r = s._fr[Wo](t, i, n, e);
        if (!r) return ! 1;
        t = r.x * h,
        i = r.y * h,
        n = r[Sa] * h,
        e = r[Ca] * h,
        n = Math[eo](n) || 1,
        e = Math[eo](e) || 1;
        var a = Pi(),
        o = a.canvas;
        o[Sa] < n || o.height < e ? (o[Sa] = n, o.height = e) : (a[Uo](1, 0, 0, 1, 0, 0), a[qo](0, 0, n, e)),
        a[Uo](1, 0, 0, 1, -t - s.$x * h, -i - s.$y * h),
        a.scale(h, h),
        s._jz(a, 1);
        var f = Ri(a, 0, 0, n, e);
        if (!f) return ! 1;
        f = f[ao];
        for (var c = f[Fh] / 4; c-->0;) if (f[4 * c - 1] > tH) return ! 0;
        return ! 1
    }
    function Sn(t, i, n, e, s, h, r, a, o) {
        if (ri(t, i, n, e, a, o)) return null;
        var f, c, u, _ = new QY(XY, [t + n - s, i]),
        d = new QY(VY, [t + n, i, t + n, i + h]),
        l = new QY(XY, [t + n, i + e - h]),
        v = new QY(VY, [t + n, i + e, t + n - s, i + e]),
        b = new QY(XY, [t + s, i + e]),
        g = new QY(VY, [t, i + e, t, i + e - h]),
        y = new QY(XY, [t, i + h]),
        x = new QY(VY, [t, i, t + s, i]),
        m = (new QY(JY), [_, d, l, v, b, g, y, x]),
        E = new _z(t + s, i + h, n - s - s, e - h - h);
        t > a ? (f = vz, u = 5) : a > t + n ? (f = gz, u = 1) : (f = bz, u = 0),
        i > o ? (c = yz, f == vz && (u = 7)) : o > i + e ? (c = mz, f == gz ? u = 3 : f == bz && (u = 4)) : (c = xz, f == vz ? u = 6 : f == gz && (u = 2));
        var p = Dn(u, t, i, n, e, s, h, r, a, o, E),
        w = p[0],
        T = p[1],
        O = new iH,
        I = O._fx;
        I.push(new QY(qY, [w.x, w.y])),
        I[Xh](new QY(XY, [a, o])),
        I[Xh](new QY(XY, [T.x, T.y])),
        T._mm && (I[Xh](T._mm), T._mmNO++);
        for (var M = T[Xo] % 8, A = w._mmNO; I[Xh](m[M]), ++M, M %= 8, M != A;);
        return w._mm && I.push(w._mm),
        O[Vo](),
        O
    }
    function Cn(t, i, e, s, h, r, a, o, f, c, u, _, d, l) {
        var v = new cz(_, d, e, s),
        b = new cz(i[0], i[1], i[4], i[5]),
        g = b._3s(v, u),
        y = g[0],
        x = g[1];
        if (y[Ko] !== n) {
            y[Xo] = (t - 1) % 8,
            x[Xo] = (t + 1) % 8;
            var m = y[Ko];
            7 == t ? (y.y = r + c + Math.min(l[Ca], m), x.x = h + f + Math.min(l[Sa], m)) : 5 == t ? (y.x = h + f + Math.min(l[Sa], m), x.y = r + o - c - Math.min(l[Ca], m)) : 3 == t ? (y.y = r + o - c - Math.min(l.height, m), x.x = h + a - f - Math.min(l[Sa], m)) : 1 == t && (y.x = h + a - f - Math.min(l.width, m), x.y = r + c + Math.min(l[Ca], m))
        } else {
            v._mz(v._nc, v._nb, y.x, y.y),
            y = v._$e(i),
            v._mz(v._nc, v._nb, x.x, x.y),
            x = v._$e(i);
            var E = Nn(i, [y, x]),
            p = E[0],
            w = E[2];
            y._mmNO = t,
            x._mmNO = t,
            y._mm = new QY(VY, p.slice(2)),
            x._mm = new QY(VY, w[Hh](2))
        }
        return [y, x]
    }
    function kn(t, i, n, e, s, h, r, a, o, f) {
        var c, u;
        if (o - a >= i + h) c = {
            y: n,
            x: o - a
        },
        c[Xo] = 0;
        else {
            c = {
                y: n + r,
                x: Math.max(i, o - a)
            };
            var _ = [i, n + r, i, n, i + h, n],
            d = new cz(o, f, c.x, c.y);
            if (c = d._$e(_)) {
                $(c) && (c = c[0].t > c[1].t ? c[0] : c[1]);
                var l = Nn(_, [c]);
                l = l[0],
                l && (c._mm = new QY(VY, l.slice(2))),
                c._mmNO = 7
            } else c = {
                y: n,
                x: i + h
            },
            c._mmNO = 0
        }
        if (i + e - h >= o + a) u = {
            y: n,
            x: o + a
        },
        u[Xo] = 0;
        else {
            u = {
                y: n + r,
                x: Math.min(i + e, o + a)
            };
            var v = [i + e - h, n, i + e, n, i + e, n + r],
            d = new cz(o, f, u.x, u.y);
            if (u = d._$e(v)) {
                $(u) && (u = u[0].t < u[1].t ? u[0] : u[1]);
                var l = Nn(v, [u]);
                l && l[l[Fh] - 1] && (u._mm = new QY(VY, l[l[Fh] - 1][Hh](2))),
                u._mmNO = 1
            } else u = {
                y: n,
                x: i + e - h
            },
            u[Xo] = 0
        }
        return [c, u]
    }
    function Ln(t, i, n, e, s, h, r, a, o, f) {
        var c, u;
        if (f - a >= n + r) c = {
            x: i + e,
            y: f - a
        },
        c[Xo] = 2;
        else {
            c = {
                x: i + e - h,
                y: Math.max(n, f - a)
            };
            var _ = [i + e - h, n, i + e, n, i + e, n + r],
            d = new cz(o, f, c.x, c.y);
            if (c = d._$e(_)) {
                $(c) && (c = c[0].t > c[1].t ? c[0] : c[1]);
                var l = Nn(_, [c]);
                l = l[0],
                l && (c._mm = new QY(VY, l[Hh](2))),
                c[Xo] = 1
            } else c = {
                x: i + e,
                y: n + r
            },
            c._mmNO = 2
        }
        if (n + s - r >= f + a) u = {
            x: i + e,
            y: f + a
        },
        u[Xo] = 2;
        else {
            u = {
                x: i + e - h,
                y: Math.min(n + s, f + a)
            };
            var v = [i + e, n + s - r, i + e, n + s, i + e - h, n + s],
            d = new cz(o, f, u.x, u.y);
            if (u = d._$e(v)) {
                $(u) && (u = u[0].t < u[1].t ? u[0] : u[1]);
                var l = Nn(v, [u]);
                l[1] && (u._mm = new QY(VY, l[1][Hh](2))),
                u._mmNO = 3
            } else u = {
                x: i + e,
                y: n + s - r
            },
            u[Xo] = 2
        }
        return [c, u]
    }
    function Pn(t, i, n, e, s, h, r, a, o, f) {
        var c, u;
        if (o - a >= i + h) u = {
            y: n + s,
            x: o - a
        },
        u[Xo] = 4;
        else {
            u = {
                y: n + s - r,
                x: Math.max(i, o - a)
            };
            var _ = [i + h, n + s, i, n + s, i, n + s - r],
            d = new cz(o, f, u.x, u.y);
            if (u = d._$e(_)) {
                $(u) && (u = u[0].t < u[1].t ? u[0] : u[1]);
                var l = Nn(_, [u]);
                l = l[l[Fh] - 1],
                l && (u._mm = new QY(VY, l[Hh](2))),
                u[Xo] = 5
            } else u = {
                y: n + s,
                x: i + h
            },
            u[Xo] = 4
        }
        if (i + e - h >= o + a) c = {
            y: n + s,
            x: o + a
        },
        c._mmNO = 4;
        else {
            c = {
                y: n + s - r,
                x: Math.min(i + e, o + a)
            };
            var v = [i + e, n + s - r, i + e, n + s, i + e - h, n + s],
            d = new cz(o, f, c.x, c.y);
            if (c = d._$e(v)) {
                $(c) && (c = c[0].t > c[1].t ? c[0] : c[1]);
                var l = Nn(v, [c]);
                l[0] && (c._mm = new QY(VY, l[0][Hh](2))),
                c[Xo] = 3
            } else c = {
                y: n + s,
                x: i + e - h
            },
            c[Xo] = 4
        }
        return [c, u]
    }
    function Rn(t, i, n, e, s, h, r, a, o, f) {
        var c, u;
        if (f - a >= n + r) u = {
            x: i,
            y: f - a
        },
        u[Xo] = 6;
        else {
            u = {
                x: i + h,
                y: Math.max(n, f - a)
            };
            var _ = [i, n + r, i, n, i + h, n],
            d = new cz(o, f, u.x, u.y);
            if (u = d._$e(_)) {
                $(u) && (u = u[0].t < u[1].t ? u[0] : u[1]);
                var l = Nn(_, [u]);
                l = l[l.length - 1],
                l && (u._mm = new QY(VY, l[Hh](2)))
            } else u = {
                x: i,
                y: n + r
            };
            u[Xo] = 7
        }
        if (n + s - r >= f + a) c = {
            x: i,
            y: f + a
        },
        c._mmNO = 6;
        else {
            c = {
                x: i + h,
                y: Math.min(n + s, f + a)
            };
            var v = [i + h, n + s, i, n + s, i, n + s - r],
            d = new cz(o, f, c.x, c.y);
            if (c = d._$e(v)) {
                $(c) && (c = c[0].t > c[1].t ? c[0] : c[1]);
                var l = Nn(v, [c]);
                l[0] && (c._mm = new QY(VY, l[0][Hh](2))),
                c[Xo] = 5
            } else c = {
                x: i,
                y: n + s - r
            },
            c[Xo] = 6
        }
        return [c, u]
    }
    function Dn(t, i, n, e, s, h, r, a, o, f, c) {
        var u = a / 2;
        switch (t) {
        case 7:
            var _ = [i, n + r, i, n, i + h, n],
            d = i + h,
            l = n + r;
            return Cn(t, _, d, l, i, n, e, s, h, r, a, o, f, c);
        case 5:
            return _ = [i + h, n + s, i, n + s, i, n + s - r],
            d = i + h,
            l = n + s - r,
            Cn(t, _, d, l, i, n, e, s, h, r, a, o, f, c);
        case 3:
            return _ = [i + e, n + s - r, i + e, n + s, i + e - h, n + s],
            d = i + e - h,
            l = n + s - r,
            Cn(t, _, d, l, i, n, e, s, h, r, a, o, f, c);
        case 1:
            return _ = [i + e - h, n, i + e, n, i + e, n + r],
            d = i + e - h,
            l = n + r,
            Cn(t, _, d, l, i, n, e, s, h, r, a, o, f, c);
        case 0:
            return kn(t, i, n, e, s, h, r, u, o, f, c);
        case 2:
            return Ln(t, i, n, e, s, h, r, u, o, f, c);
        case 4:
            return Pn(t, i, n, e, s, h, r, u, o, f, c);
        case 6:
            return Rn(t, i, n, e, s, h, r, u, o, f, c)
        }
    }
    function Nn(t, i) {
        for (var e, s, h, r, a, o, f = t[0], c = t[1], u = t[2], _ = t[3], d = t[4], l = t[5], v = [], b = 0; b < i[Fh]; b++) a = i[b],
        o = a.t,
        0 != o && 1 != o ? (e = f + (u - f) * o, s = c + (_ - c) * o, h = u + (d - u) * o, r = _ + (l - _) * o, v[Xh]([f, c, e, s, a.x, a.y]), f = a.x, c = a.y, u = h, _ = r) : v[Xh](null);
        return h !== n && v[Xh]([a.x, a.y, h, r, d, l]),
        v
    }
    function Bn(t) {
        return this[Zo] && this._ner && (t.x -= this[Jo].x, t.y -= this[Jo].y),
        this[Qo] && Mi(t, this[Qo]),
        t.x += this[tf] || 0,
        t.y += this[nf] || 0,
        this[ef] && this.$_hostRotate ? Mi(t, this.$_hostRotate) : t
    }
    function $n(t) {
        return this.$rotatable && this[sf] && Mi(t, -this[sf]),
        t.x -= this.$offsetX || 0,
        t.y -= this[nf] || 0,
        this.$rotate && Mi(t, -this.$rotate),
        this[Zo] && this[Jo] && (t.x += this[Jo].x, t.y += this._ner.y),
        t
    }
    function Gn() {
        var t = this[hf];
        this.$invalidateSize && (this[hf] = !1, this[rf] = !0, this._7w.setByRect(this._ji), this[af] && this._7w[of](this[af]), this[ff] && this._7w[of](this.$border));
        var i = this._$n();
        if (i) var n = this.showPointer && this[cf];
        return this[rf] && this.$layoutByAnchorPoint && (this[rf] = !1, n && (t = !0), this[Jo] = fi(this[uf], this._7w.width, this._7w[Ca]), this[Jo].x += this._7w.x, this[Jo].y += this._7w.y),
        i ? (t && (this[_f] = !0, Fn[zh](this, n)), this[_f] && (this[_f] = !1, this[df] = this[lf] && this[vf] && this[vf][no] ? BY.prototype[bf][zh](this[lf], this._m1Shape[no]) : null), t) : (this.__mvPointer = !1, t)
    }
    function Fn(t) {
        var i = this._7w.x + this[ff] / 2,
        n = this._7w.y + this[ff] / 2,
        e = this._7w[Sa] - this[ff],
        s = this._7w[Ca] - this.$border,
        h = 0,
        r = 0;
        if (this.$borderRadius && (D(this[gf]) ? h = r = this[gf] : (h = this[gf].x || 0, r = this.$borderRadius.y || 0), h = Math.min(h, e / 2), r = Math.min(r, s / 2)), t && (this._pointerX = this[Jo].x - this.$offsetX + this[yf], this._pointerY = this[Jo].y - this[nf] + this[xf], !this._7w[mf](this[Ef], this[pf]))) {
            var a = new eH(i, n, e, s, h, r, this[cf], this[Ef], this[pf]);
            return this[vf] = a._mm,
            this[vf].bounds.set(i, n, e, s),
            void(this.__mvPointer = !0)
        }
        this[vf] && this[vf][wf](),
        this[vf] = MU[Tf](i, n, e, s, h, r, this[vf]),
        this[vf][no].set(i, n, e, s)
    }
    function zn(t, i, n, e) {
        return e && (t[Sa] < 0 || t[Ca] < 0) ? (t.x = i, t.y = n, void(t[Sa] = t[Ca] = 0)) : (i < t.x ? (t.width += t.x - i, t.x = i) : i > t.x + t.width && (t[Sa] = i - t.x), void(n < t.y ? (t[Ca] += t.y - n, t.y = n) : n > t.y + t.height && (t[Ca] = n - t.y)))
    }
    function Yn(t, i, e) {
        var s, h = t[Of],
        r = t[If] === n ? this.layoutByPath: t.layoutByPath;
        return this[Mf] instanceof iH && r ? (s = OY[Af](h, this[Mf], this[jf], i, e), s.x *= this._jw, s.y *= this._jr) : (s = fi(h, this._7w.width, this._7w[Ca]), s.x += this._7w.x, s.y += this._7w.y),
        Bn.call(this, s)
    }
    function Hn(t, i) {
        if (i) if (i._7w[Sf]()) t.$x = i.$x,
        t.$y = i.$y;
        else {
            var n = Yn.call(i, t);
            t.$x = n.x,
            t.$y = n.y,
            t[Cf] = n.rotate
        } else t.$x = 0,
        t.$y = 0;
        t[kf] && rH[zh](t)
    }
    function Un(t) {
        if (t[Lf] === n) {
            var i, e;
            if (t[Pf]) i = t[Rf],
            e = t[Pf];
            else {
                var s;
                if (t[Df] !== n) s = Df;
                else {
                    if (t.webkitLineDash === n) return ! 1;
                    s = Nf
                }
                e = function(t) {
                    this[s] = t
                },
                i = function() {
                    return this[s]
                }
            }
            K(t, Lf, {
                get: function() {
                    return i[zh](this)
                },
                set: function(t) {
                    e[zh](this, t)
                }
            })
        }
        if (t[Bf] === n) {
            var h;
            if (t[$f] !== n) h = $f;
            else {
                if (t[Gf] === n) return;
                h = Gf
            }
            K(t, Bf, {
                get: function() {
                    return this[h]
                },
                set: function(t) {
                    this[h] = t
                }
            })
        }
    }
    function Wn(t, i, n, e, s) {
        var h, r, a, o, f, c, u, _, d = function(t) {
            return function(i) {
                t(i)
            }
        },
        l = function() {
            r = null,
            a = null,
            o = f,
            f = null,
            c = null
        },
        v = function(t) {
            h = t,
            u || (u = ki()),
            u.width = h[Sa],
            u.height = h[Ca],
            i.width = h[Sa],
            i.height = h[Ca]
        },
        b = function(t) {
            g(),
            l(),
            r = t[Ff] ? t[zf] : null,
            a = 10 * t.delayTime,
            f = t.disposalMethod
        },
        g = function() {
            if (c) {
                var t = c[Xa](0, 0, h[Sa], h[Ca]),
                n = {
                    data: t,
                    _pixels: wn(t[ao], h[Sa], h[Ca]),
                    delay: a
                };
                s[zh](i, n)
            }
        },
        y = function(t) {
            c || (c = u[Mo](za));
            var i = t[Yf] ? t.lct: h.gct,
            n = c.getImageData(t.leftPos, t[Hf], t.width, t[Ca]);
            t[Uf][Wf](function(t, e) {
                r !== t ? (n[ao][4 * e + 0] = i[t][0], n.data[4 * e + 1] = i[t][1], n[ao][4 * e + 2] = i[t][2], n[ao][4 * e + 3] = 255) : (2 === o || 3 === o) && (n[ao][4 * e + 3] = 0)
            }),
            c[qo](0, 0, h[Sa], h[Ca]),
            c[Ho](n, t[qf], t[Hf])
        },
        x = function() {},
        m = {
            hdr: d(v),
            gce: d(b),
            com: d(x),
            app: {
                NETSCAPE: d(x)
            },
            img: d(y, !0),
            eof: function() {
                g(),
                n[zh](i)
            }
        },
        E = new XMLHttpRequest;
        HF || E[Xf]("text/plain; charset=x-user-defined"),
        E.onload = function() {
            _ = new uH(E.responseText);
            try {
                dH(_, m)
            } catch(t) {
                e.call(i, Ea)
            }
        },
        E.onerror = function() {
            e[zh](i, Vf)
        },
        E.open(Oa, t, !0),
        E[Kf]()
    }
    function qn(t) {
        var i = [51, 10, 10, 100, 101, 109, 111, 46, 113, 117, 110, 101, 101, 46, 99, 111, 109, 44, 109, 97, 112, 46, 113, 117, 110, 101, 101, 46, 99, 111, 109, 10, 50, 46, 48, 10, 49, 52, 51, 49, 51, 51, 55, 51, 51, 55, 50, 49, 56, 10, 10, 48, 10];
        return i.forEach(function(n, e) {
            i[e] = t(n)
        }),
        i[Zf]("")
    }
    function Xn(t, i) {
        try {
            if (null == t || t.length < 8) return;
            if (null == i || i[Fh] <= 0) return;
            for (var n = "",
            e = 0; e < i[Fh]; e++) n += i.charCodeAt(e).toString();
            var s = Math[Or](n[Fh] / 5),
            h = parseInt(n[Jf](s) + n.charAt(2 * s) + n[Jf](3 * s) + n[Jf](4 * s) + n[Jf](5 * s), 10),
            r = Math[eo](i[Fh] / 2),
            a = Math.pow(2, 31) - 1,
            o = parseInt(t[Qr](t.length - 8, t.length), 16);
            for (t = t[Qr](0, t.length - 8), n += o; n.length > 10;) n = (parseInt(n.substring(0, 10), 10) + parseInt(n[Qr](10, n[Fh]), 10)).toString();
            n = (h * n + r) % a;
            for (var f = "",
            c = "",
            e = 0; e < t[Fh]; e += 2) f = parseInt(parseInt(t.substring(e, e + 2), 16) ^ Math[Or](n / a * 255), 10),
            c += String[Qf](f),
            n = (h * n + r) % a;
            return 0 | c[0] ? HH = xH[tc + pH + ic](c) : null
        } catch(u) {}
    }
    function Vn() {
        var t = vH;
        if (!t) return void(KH = !0);
        YH = t;
        var i;
        t = t[lr](Ar);
        for (var n = 0; n < t[Fh] && (i = Xn(t[n], gH), !(i && i[lr](qa)[Fh] >= 8));) 1 == t[Fh] && (i = Xn(t[n], nc)),
        n++;
        if (!i || i[lr](qa)[Fh] < 8) return qH = !0,
        "" === gH || gH == ec + IH + sc + MH + hc || gH == rc + OH + ac ? (XH = tU, KH = !1, JH = !1, void(zH = !1)) : (XH = tU, void(KH = !0));
        zH = i[lr](qa);
        var e = zH[3];
        if (e != sq) return qH = !0,
        void(JH = !0);
        KH = !1,
        JH = !1;
        var s = zH[0]; (oc == s || fc == s) && (qH = !1);
        var h = zH[5];
        VH = h;
        var r = zH[6];
        XH = r
    }
    function Kn() {
        var t = YH;
        if (t) {
            var i;
            t = t[lr](Ar);
            for (var n = 0; n < t.length && (i = iU(t[n], gH), !(i && i[lr](qa)[Fh] >= 8));) 1 == t.length && (i = iU(t[n], nc)),
            n++;
            if (i[lr](qa).length >= 8) return void(ZH = !1)
        }
        return gH && gH != ec + IH + sc + MH + hc && gH != rc + OH + ac ? void(ZH = !0) : void(ZH = !1)
    }
    function Zn() {
        if (qH) {
            var t = rh[kH + fo]._jz,
            i = WH;
            rh[kH + fo]._jz = function() {
                t[Zh](this, arguments),
                i[zh](this[cc], this.g)
            };
            var n = vU[kH + fo]._hp;
            vU[kH + fo]._hp = function(t) {
                n.apply(this, arguments),
                i[zh](this, t)
            }
        }
    }
    function Jn() {
        if (VH !== !0 && VH) {
            var t = VH.split(Dr);
            if (3 != t.length) return void(jU[Jh]._jz = null);
            var i = parseInt(t[0], 10),
            n = parseInt(t[1], 10),
            e = parseInt(t[2], 10),
            s = 3,
            h = (365.2425 * (i - 2e3 + 10 * s) + (n - 1) * s * 10 + e) * s * 8 * s * 1200 * 1e3;
            bH > h && (jU.prototype._jz = null)
        }
    }
    function Qn() {
        var t = 0 | XH;
        t && (hz[kH + fo]._kr = function(i, e) {
            var s = i.id;
            return s === n || this[uc](s) ? !1 : this._jg.length > t ? !1 : (y(this._jg, i, e), this._lu[s] = i, i)
        })
    }
    function te() {
        KH && (hz[kH + fo]._kr = hz[kH + fo]._gt)
    }
    function ie() {
        ZH && (vU[kH + fo]._jz = vU[kH + fo].render)
    }
    function ne() {
        QH && (xU[Jh]._hw = xU[Jh]._fm)
    }
    function ee() {
        JH && (lU[kH + fo].render = vU[kH + fo]._jz)
    }
    function se() {
        zH === n && (vU[kH + fo]._j9 = _z[_c])
    }
    function he(t) {
        var i = ki(!0);
        return Un(i.g),
        i[dc] = function() {
            return ! 1
        },
        t[lc](i),
        i[cr] = rU,
        i
    }
    function d(t, i) {
        function n(t, n) {
            for (var e = t.length,
            s = n[Fh], h = e + s, r = new Array(h), a = 0, o = 0, f = 0; h > f;) r[f++] = a === e ? n[o++] : o === s || i(t[a], n[o]) <= 0 ? t[a++] : n[o++];
            return r
        }
        function e(t) {
            var i = t[Fh],
            s = Math[Wh](i / 2);
            return 1 >= i ? t: n(e(t[Hh](0, s)), e(t[Hh](s)))
        }
        return e(t)
    }
    function re(t) {
        t[Sa] = t[Sa]
    }
    function ae(t) {
        _U || (_U = "imageSmoothingEnabled" in CanvasRenderingContext2D[Jh] ? "imageSmoothingEnabled": "mozImageSmoothingEnabled" in CanvasRenderingContext2D[Jh] ? "mozImageSmoothingEnabled": "msImageSmoothingEnabled" in CanvasRenderingContext2D.prototype ? "msImageSmoothingEnabled": "webkitImageSmoothingEnabled" in CanvasRenderingContext2D.prototype ? "webkitImageSmoothingEnabled": "imageSmoothingEnabled"),
        t[_U] = !1
    }
    function oe(t, i, n, e, s) {
        e = X(i + e) - (i = q(i)),
        s = X(n + s) - (n = q(n)),
        t.clearRect(i, n, e, s),
        t[vc](i, n, e, s)
    }
    function q(t) {
        return Math.floor(t)
    }
    function X(t) {
        return Math.ceil(t)
    }
    function fe(t) {
        var i = [];
        return t[Wf](function(t) {
            i.push( - t)
        }),
        i
    }
    function ce(t) {
        return t %= gU,
        0 > t && (t += gU),
        t
    }
    function ue(t, i, n, e, s, h, r, a) {
        var o = ((t * e - i * n) * (s - r) - (t - n) * (s * a - h * r)) / ((t - n) * (h - a) - (i - e) * (s - r)),
        f = ((t * e - i * n) * (h - a) - (i - e) * (s * a - h * r)) / ((t - n) * (h - a) - (i - e) * (s - r));
        if (isNaN(o) || isNaN(f)) return ! 1;
        if (t >= n) {
            if (! (o >= n && t >= o)) return ! 1
        } else if (! (o >= t && n >= o)) return ! 1;
        if (i >= e) {
            if (! (f >= e && i >= f)) return ! 1
        } else if (! (f >= i && e >= f)) return ! 1;
        if (s >= r) {
            if (! (o >= r && s >= o)) return ! 1
        } else if (! (o >= s && r >= o)) return ! 1;
        if (h >= a) {
            if (! (f >= a && h >= f)) return ! 1
        } else if (! (f >= h && a >= f)) return ! 1;
        return ! 0
    }
    function _e(t, i) {
        for (var n = 0,
        e = t[Fh]; e > n;) {
            for (var s = t[n], h = t[(n + 1) % e], r = 0; 4 > r;) {
                var a = i[r],
                o = i[(r + 1) % e];
                if (ue(s[0], s[1], h[0], h[1], a[0], a[1], o[0], o[1])) return ! 0;
                r++
            }
            n++
        }
        return ! 1
    }
    function de(t, i, n, e) {
        return [t * e - i * n, t * n + i * e]
    }
    function le(t) {
        return t[bc] ? (t = t[bc], t._e8 ? t._e8: t instanceof AU && t._gf === !1 ? t: null) : null
    }
    function ve(t, i, n) {
        if (n = n || i[gc], n == t) return ! 1;
        var e = t.getEdgeBundle(n);
        return e || (e = new qW(t, n), t[yc][n.id] = e),
        e._j0(i, t)
    }
    function be(t, i, n) {
        if (n = n || i[gc], n == t) return ! 1;
        var e = t[xc](n);
        return e ? e._nhr(i, t) : void 0
    }
    function ge(t, i, e) {
        return e === n && (e = i[gc]),
        e != t ? (t._8b || (t._8b = new hz), t._8b.add(i) === !1 ? !1 : void t._9i++) : void 0
    }
    function ye(t, i, n) {
        return t._8b && t._8b[mc](i) !== !1 ? (t._9i--, void be(t, i, n)) : !1
    }
    function xe(t, i) {
        return i[Ec] != t ? (t._9d || (t._9d = new hz), t._9d.add(i) === !1 ? !1 : void t[pc]++) : void 0
    }
    function me(t, i) {
        return t._9d && t._9d[mc](i) !== !1 ? (t._ngq--, void be(i.fromAgent, i, t)) : !1
    }
    function Ee(t, i) {
        if (i === n && (i = t instanceof TU), i) {
            if (t[wc]()) return null;
            var e = Ee(t[Tc], !1);
            if (t.isLooped()) return e;
            for (var s = Ee(t.to, !1); null != e && null != s;) {
                if (e == s) return e;
                if (e[Oc](s)) return s;
                if (s[Oc](e)) return e;
                e = Ee(e, !1),
                s = Ee(s, !1)
            }
            return null
        }
        for (var h = t[bc]; null != h;) {
            if (h._i0()) return h;
            h = h.parent
        }
        return null
    }
    function pe(t, i, n) {
        t._i0() && t.hasChildren() && t[Yh][Wf](function(t) {
            t instanceof OU && i.add(t) && pe(t, i, n)
        },
        this),
        t[Ic]() && t._e6.forEach(function(t) { (null == n || n.accept(t)) && i.add(t) && pe(t, i, n)
        })
    }
    function we(t, i) {
        i.parent ? i[bc].setChildIndex(i, i[bc][Mc] - 1) : t[Ac][jc](i, t.roots.length - 1)
    }
    function Te(t, i) {
        if (i instanceof TU) return void(i.isInvalid() || Ie(t, i));
        for (we(t, i); i = i[bc];) we(t, i)
    }
    function Oe(t, i) {
        if (i instanceof TU) return void(i.isInvalid() || Ie(t, i));
        for (we(t, i); i = i[bc];) we(t, i)
    }
    function Ie(t, i) {
        var n = i.fromAgent;
        if (i[Sc]()) we(t, n);
        else {
            var e = i.toAgent;
            we(t, n),
            we(t, e)
        }
    }
    function Me(t, i) {
        return t._9i++,
        t._gr ? (i._i7 = t._i9, t._i9._hz = i, void(t._i9 = i)) : (t._gr = i, void(t._i9 = i))
    }
    function Ae(t, i) {
        t._9i--,
        t._i9 == i && (t._i9 = i._i7),
        i._i7 ? i._i7._hz = i._hz: t._gr = i._hz,
        i._hz && (i._hz._i7 = i._i7),
        i._i7 = null,
        i._hz = null,
        be(t, i, i.$to)
    }
    function je(t, i) {
        return t._ngq++,
        t._i8 ? (i._kd = t._jp, t._jp._kg = i, void(t._jp = i)) : (t._i8 = i, void(t._jp = i))
    }
    function Se(t, i) {
        t[pc]--,
        t._jp == i && (t._jp = i._kd),
        i._kd ? i._kd._kg = i._kg: t._i8 = i._kg,
        i._kg && (i._kg._kd = i._kd),
        i._kd = null,
        i._kg = null
    }
    function Ce(t, i) {
        return i = i || new hz,
        t[Cc](function(t) {
            i.add({
                id: t.id,
                edge: t,
                fromAgent: t[kc]._e8,
                toAgent: t.$to._e8
            })
        }),
        t[Lc](function(t) {
            t instanceof OU && Ce(t, i)
        }),
        i
    }
    function ke(t, i, n) {
        return Pe(t, i, n) === !1 ? !1 : Le(t, i, n)
    }
    function Le(t, i, n) {
        if (t._gr) for (var e = t._gr; e;) {
            if (i.call(n, e) === !1) return ! 1;
            e = e._hz
        }
    }
    function Pe(t, i, n) {
        if (t._i8) for (var e = t._i8; e;) {
            if (i[zh](n, e) === !1) return ! 1;
            e = e._kg
        }
    }
    function Re(t, i, e, s, h, r, a) {
        return r || a ? (r = r || 0, a = a === n ? r: a || 0, r = Math.min(r, s / 2), a = Math.min(a, h / 2), t[Pc](i + r, e), t[Rc](i + s - r, e), t.quadTo(i + s, e, i + s, e + a), t[Rc](i + s, e + h - a), t[Dc](i + s, e + h, i + s - r, e + h), t[Rc](i + r, e + h), t[Dc](i, e + h, i, e + h - a), t.lineTo(i, e + a), t.quadTo(i, e, i + r, e), t[Vo](), t) : (t[Pc](i, e), t[Rc](i + s, e), t[Rc](i + s, e + h), t.lineTo(i, e + h), t[Vo](), t)
    }
    function De(t, i) {
        var n = i.r || 1,
        e = i.cx || 0,
        s = i.cy || 0,
        h = n * Math.tan(Math.PI / 8),
        r = n * Math.sin(Math.PI / 4);
        t.moveTo(e + n, s),
        t.quadTo(e + n, s + h, e + r, s + r),
        t[Dc](e + h, s + n, e, s + n),
        t[Dc](e - h, s + n, e - r, s + r),
        t[Dc](e - n, s + h, e - n, s),
        t[Dc](e - n, s - h, e - r, s - r),
        t[Dc](e - h, s - n, e, s - n),
        t.quadTo(e + h, s - n, e + r, s - r),
        t[Dc](e + n, s - h, e + n, s)
    }
    function Ne(t, i, n, e, s) {
        i instanceof Ji && (e = i[Sa], s = i[Ca], n = i.cy - s / 2, i = i.cx - e / 2);
        var h = .5522848,
        r = e / 2 * h,
        a = s / 2 * h,
        o = i + e,
        f = n + s,
        c = i + e / 2,
        u = n + s / 2;
        return t[Pc](i, u),
        t.curveTo(i, u - a, c - r, n, c, n),
        t[Nc](c + r, n, o, u - a, o, u),
        t.curveTo(o, u + a, c + r, f, c, f),
        t[Nc](c - r, f, i, u + a, i, u),
        t
    }
    function Be(t, i, n, e, s) {
        var h = 2 * e,
        r = 2 * s,
        a = i + e / 2,
        o = n + s / 2;
        return t.moveTo(a - h / 4, o - r / 12),
        t.lineTo(i + .306 * e, n + .579 * s),
        t.lineTo(a - h / 6, o + r / 4),
        t[Rc](i + e / 2, n + .733 * s),
        t.lineTo(a + h / 6, o + r / 4),
        t[Rc](i + .693 * e, n + .579 * s),
        t[Rc](a + h / 4, o - r / 12),
        t.lineTo(i + .611 * e, n + .332 * s),
        t.lineTo(a + 0, o - r / 4),
        t[Rc](i + .388 * e, n + .332 * s),
        t[Vo](),
        t
    }
    function $e(t, i, n, e, s) {
        return t[Pc](i, n),
        t[Rc](i + e, n + s / 2),
        t[Rc](i, n + s),
        t[Vo](),
        t
    }
    function Ge(t, i, n, e, s) {
        return t.moveTo(i, n + s / 2),
        t[Rc](i + e / 2, n),
        t[Rc](i + e, n + s / 2),
        t[Rc](i + e / 2, n + s),
        t.closePath(),
        t
    }
    function Fe(t, i, n, e, s, h) {
        return t[Pc](i, n),
        t[Rc](i + e, n + s / 2),
        t[Rc](i, n + s),
        h || (t.lineTo(i + .25 * e, n + s / 2), t.closePath()),
        t
    }
    function ze(t, i, n, e, s) {
        if (!t || 3 > t) throw new Error("edge number must greater than 2");
        t = 0 | t,
        e = e || 50,
        s = s || 0,
        i = i || 0,
        n = n || 0;
        for (var h, r, a = 0,
        o = 2 * Math.PI / t,
        f = new iH; t > a;) h = i + e * Math.cos(s),
        r = n + e * Math.sin(s),
        a ? f.lineTo(h, r) : f[Pc](h, r),
        ++a,
        s += o;
        return f[Vo](),
        f
    }
    function Ye() {
        var t = new iH;
        return t.moveTo(75, 40),
        t[Nc](75, 37, 70, 25, 50, 25),
        t[Nc](20, 25, 20, 62.5, 20, 62.5),
        t.curveTo(20, 80, 40, 102, 75, 120),
        t[Nc](110, 102, 130, 80, 130, 62.5),
        t[Nc](130, 62.5, 130, 25, 100, 25),
        t[Nc](85, 25, 75, 37, 75, 40),
        t
    }
    function He() {
        var t = new iH;
        return t.moveTo(20, 0),
        t.lineTo(80, 0),
        t[Rc](100, 100),
        t[Rc](0, 100),
        t[Vo](),
        t
    }
    function Ue() {
        var t = new iH;
        return t[Pc](100, 0),
        t.lineTo(100, 80),
        t[Rc](0, 100),
        t[Rc](0, 20),
        t[Vo](),
        t
    }
    function We() {
        var t = new iH;
        return t[Pc](20, 0),
        t[Rc](100, 0),
        t[Rc](80, 100),
        t.lineTo(0, 100),
        t.closePath(),
        t
    }
    function qe() {
        var t = new iH;
        return t[Pc](43, 23),
        t[Rc](28, 10),
        t[Rc](37, 2),
        t[Rc](63, 31),
        t[Rc](37, 59),
        t[Rc](28, 52),
        t[Rc](44, 38),
        t[Rc](3, 38),
        t[Rc](3, 23),
        t[Vo](),
        t
    }
    function Xe() {
        var t = new iH;
        return t.moveTo(1, 8),
        t[Rc](7, 2),
        t[Rc](32, 26),
        t[Rc](7, 50),
        t.lineTo(1, 44),
        t[Rc](18, 26),
        t.closePath(),
        t[Pc](27, 8),
        t[Rc](33, 2),
        t[Rc](57, 26),
        t.lineTo(33, 50),
        t[Rc](27, 44),
        t.lineTo(44, 26),
        t.closePath(),
        t
    }
    function Ve() {
        var t = new iH;
        return t.moveTo(0, 15),
        t[Rc](23, 15),
        t[Rc](23, 1),
        t[Rc](47, 23),
        t.lineTo(23, 43),
        t[Rc](23, 29),
        t[Rc](0, 29),
        t.closePath(),
        t
    }
    function Ke() {
        var t = new iH;
        return t[Pc](0, 21),
        t[Rc](30, 21),
        t[Rc](19, 0),
        t.lineTo(25, 0),
        t[Rc](47, 25),
        t[Rc](25, 48),
        t.lineTo(19, 48),
        t[Rc](30, 28),
        t.lineTo(0, 28),
        t[Vo](),
        t
    }
    function Ze() {
        var t = new iH;
        return t[Pc](0, 0),
        t[Rc](34, 24),
        t[Rc](0, 48),
        t[Rc](14, 24),
        t.closePath(),
        t
    }
    function Je() {
        var t = new iH;
        return t[Pc](20, 0),
        t[Rc](34, 14),
        t[Rc](20, 28),
        t[Rc](22, 18),
        t[Rc](1, 25),
        t.lineTo(10, 14),
        t[Rc](1, 3),
        t[Rc](22, 10),
        t.closePath(),
        t
    }
    function Qe() {
        var t = new iH;
        return t[Pc](4, 18),
        t.lineTo(45, 18),
        t[Rc](37, 4),
        t[Rc](83, 25),
        t[Rc](37, 46),
        t[Rc](45, 32),
        t[Rc](4, 32),
        t[Vo](),
        t
    }
    function ts() {
        var t = new iH;
        return t[Pc](17, 11),
        t[Rc](27, 11),
        t.lineTo(42, 27),
        t.lineTo(27, 42),
        t.lineTo(17, 42),
        t[Rc](28, 30),
        t.lineTo(4, 30),
        t[Rc](4, 23),
        t[Rc](28, 23),
        t[Vo](),
        t
    }
    function is() {
        MU.register(mY[Bc], Ne(new iH, 0, 0, 100, 100)),
        MU[$c](mY[Gc], Re(new iH, 0, 0, 100, 100)),
        MU[$c](mY.SHAPE_ROUNDRECT, Re(new iH, 0, 0, 100, 100, 20, 20)),
        MU[$c](mY[Fc], Be(new iH, 0, 0, 100, 100)),
        MU[$c](mY[zc], $e(new iH, 0, 0, 100, 100)),
        MU.register(mY.SHAPE_PENTAGON, ze(5)),
        MU[$c](mY.SHAPE_HEXAGON, ze(6)),
        MU[$c](mY[Yc], Ge(new iH, 0, 0, 100, 100)),
        MU[$c](mY[Hc], Ye()),
        MU[$c](mY[Uc], He()),
        MU[$c](mY[Wc], Ue()),
        MU[$c](mY[qc], We());
        var t = new iH;
        t[Pc](20, 0),
        t[Rc](40, 0),
        t.lineTo(40, 20),
        t[Rc](60, 20),
        t[Rc](60, 40),
        t[Rc](40, 40),
        t.lineTo(40, 60),
        t.lineTo(20, 60),
        t[Rc](20, 40),
        t[Rc](0, 40),
        t[Rc](0, 20),
        t.lineTo(20, 20),
        t.closePath(),
        MU[$c](mY.SHAPE_CROSS, t),
        MU.register(mY[Xc], Fe(new iH, 0, 0, 100, 100)),
        MU.register(mY.SHAPE_ARROW_1, qe()),
        MU[$c](mY[Vc], Xe()),
        MU[$c](mY[Kc], Ve()),
        MU[$c](mY.SHAPE_ARROW_4, Ke()),
        MU.register(mY[Zc], Ze()),
        MU[$c](mY.SHAPE_ARROW_6, Je()),
        MU.register(mY.SHAPE_ARROW_7, Qe()),
        MU[$c](mY[Jc], ts()),
        MU.register(mY[Qc], Fe(new iH, 0, 0, 100, 100, !0))
    }
    function ns() {
        w(this, ns, arguments),
        this[tu] = !0
    }
    function es() {
        w(this, es),
        this._$r = new Sz
    }
    function ss() {
        if (this._gf === !0) {
            var t = this._8b,
            i = this._9d;
            if (t) for (t = t._jg; t[Fh];) {
                var n = t[0];
                ye(this, n, n[gc])
            }
            if (i) for (i = i._jg; i[Fh];) {
                var n = i[0];
                me(this, n, n[Ec])
            }
            return void this.forEachChild(function(t) {
                t._i0() && ss.call(t)
            })
        }
        var e = Ce(this);
        e[Wf](function(t) {
            t = t.edge;
            var i = t[kc],
            n = t.$to,
            e = i.isDescendantOf(this),
            s = n.isDescendantOf(this);
            e && !s ? (ge(this, t), ve(this, t)) : s && !e && (xe(this, t), ve(t.fromAgent, t, this))
        },
        this)
    }
    function hs() {
        w(this, hs, arguments),
        this[iu] = null
    }
    function rs(t, i, n, e) {
        return t[i] = n,
        e ? {
            get: function() {
                return this[i]
            },
            set: function(t) {
                if (t !== this[i]) {
                    this[i] = t,
                    !this[nu],
                    this._1a = !0;
                    for (var n = e[Fh]; --n >= 0;) this[e[n]] = !0
                }
            }
        }: {
            get: function() {
                return this[i]
            },
            set: function(t) {
                t !== this[i] && (this[i] = t)
            }
        }
    }
    function as(t, i) {
        var n = {},
        e = {};
        for (var s in i) {
            var h = i[s];
            h[eu] && h.validateFlags[Wf](function(t, i, n) {
                n[i] = su + t,
                e[t] = !0
            }),
            n[s] = rs(t, er + s, h[ar], h.validateFlags)
        }
        for (var r in e) t[su + r] = !0;
        Object[Rr](t, n)
    }
    function os(t, i, n, e) {
        if (Array[xr](i)) for (var s = i[Fh]; --s >= 0;) os(t, i[s], n, e);
        else {
            var h = i.target;
            if (h) {
                if (h instanceof jU || (h = t[h]), !h) return
            } else h = t;
            if (e || (e = t[hu](i[ru], n)), i[au] && (h[i[au]] = e), i.callback) {
                var r = i[ou];
                r instanceof Function || (r = t[r]),
                r instanceof Function && r[zh](t, e, h)
            }
        }
    }
    function fs() {
        SU.forEach(function(t) {
            this[t] = {}
        },
        this)
    }
    function cs(t, i, n, e) {
        return e == mY[fu] ? void(t[n] = i) : e == mY.PROPERTY_TYPE_CLIENT ? void t.set(n, i) : e == mY.PROPERTY_TYPE_STYLE ? void t.setStyle(n, i) : !1
    }
    function us() {
        w(this, us, arguments)
    }
    function _s() {
        w(this, _s, arguments)
    }
    function ds(t, i, n, e) {
        var s = ls(t, i, n, e),
        h = [];
        if (ys(t)) vs(s, i, n, h, e[cu](CU.EDGE_EXTEND));
        else {
            As(t, i, n, h, s, e);
            var r = bs(t, e),
            a = r ? ws(t, s, i, n, e[cu](CU[uu])) : e[cu](CU[_u]);
            0 == a && (s = !s)
        }
        return h
    }
    function ls(t, i, n) {
        if (null != t) {
            if (t == mY.EDGE_TYPE_ELBOW_HORIZONTAL || t == mY.EDGE_TYPE_ORTHOGONAL_HORIZONTAL || t == mY[du] || t == mY.EDGE_TYPE_EXTEND_LEFT || t == mY.EDGE_TYPE_EXTEND_RIGHT) return ! 0;
            if (t == mY[lu] || t == mY[vu] || t == mY[bu] || t == mY.EDGE_TYPE_EXTEND_TOP || t == mY.EDGE_TYPE_EXTEND_BOTTOM) return ! 1
        }
        var e = Es(i, n),
        s = ps(i, n);
        return e >= s
    }
    function vs(t, i, n, e, s) {
        t ? Ls(i, n, e, s) : Ps(i, n, e, s)
    }
    function bs(t, i) {
        return i[cu](CU.EDGE_SPLIT_BY_PERCENT)
    }
    function gs(t) {
        return null != t && (t == mY[gu] || t == mY.EDGE_TYPE_EXTEND_LEFT || t == mY.EDGE_TYPE_EXTEND_BOTTOM || t == mY[yu])
    }
    function ys(t) {
        return t && (t == mY[xu] || t == mY[mu] || t == mY.EDGE_TYPE_ELBOW_VERTICAL)
    }
    function xs(t, i, n, e, s) {
        if (t == mY.EDGE_TYPE_HORIZONTAL_VERTICAL || t == mY[bu]) return new oz(e.x + e[Sa] / 2, e.y + e.height / 2);
        var h;
        if (gs(t)) {
            var r = Math.min(n.y, e.y),
            a = Math.min(n.x, e.x),
            o = Math.max(n[Fr], e[Fr]),
            f = Math.max(n.right, e.right);
            if (h = s[cu](CU.EDGE_EXTEND), t == mY[gu]) return new oz((a + f) / 2, r - h);
            if (t == mY[Eu]) return new oz(a - h, (r + o) / 2);
            if (t == mY[pu]) return new oz((a + f) / 2, o + h);
            if (t == mY[yu]) return new oz(f + h, (r + o) / 2)
        }
        var c = bs(t, s);
        if (h = c ? ws(t, i, n, e, s[cu](CU.EDGE_SPLIT_PERCENT)) : s[cu](CU[_u]), h == Number[wu] || h == Number[Tu]) return new oz(e.x + e[Sa] / 2, e.y + e[Ca] / 2);
        if (0 == h) return new oz(n.x + n.width / 2, n.y + n[Ca] / 2);
        if (i) {
            var u = n.x + n[Gr] < e.x + e[Gr];
            return new oz(Is(u, h, n.x, n[Sa]), n.y + n.height / 2)
        }
        var _ = n.y + n[Fr] < e.y + e[Fr];
        return new oz(n.x + n[Sa] / 2, Is(_, h, n.y, n[Ca]))
    }
    function ms(t, i, n, e) {
        var s = Math.max(i, e) - Math.min(t, n);
        return s - (i - t + e - n)
    }
    function Es(t, i) {
        var n = Math.max(t.x + t[Sa], i.x + i.width) - Math.min(t.x, i.x);
        return n - t[Sa] - i[Sa]
    }
    function ps(t, i) {
        var n = Math.max(t.y + t.height, i.y + i[Ca]) - Math.min(t.y, i.y);
        return n - t[Ca] - i[Ca]
    }
    function ws(t, i, n, e, s) {
        var h = Ts(s, i, n, e, null);
        return h * s
    }
    function Ts(t, i, n, e) {
        return i ? Os(t, n.x, n[Gr], e.x, e[Gr]) : Os(t, n.y, n.bottom, e.y, e[Fr])
    }
    function Os(t, i, n, e, s) {
        var h = ms(i, n, e, s),
        r = e + s > i + n;
        if (h > 0) {
            if (1 == t) return h + (s - e) / 2;
            if (t >= 0 && 1 > t) return h;
            if (0 > t) return r ? e - i: n - s
        }
        return Math.abs(r && t > 0 || !r && 0 > t ? n - s: i - e)
    }
    function Is(t, i, n, e) {
        return t == i > 0 ? n + e + Math.abs(i) : n - Math.abs(i)
    }
    function Ms(t, i) {
        var n = t[Fh];
        if (! (3 > n)) {
            var e = i[cu](CU[Ou]);
            if (e != mY[Iu]) {
                var s = i.getStyle(CU[Mu]),
                h = 0,
                r = 0;
                s && (D(s) ? h = r = s: (h = s.x || 0, r = s.y || 0));
                for (var a, o, f, c, u = t[0], _ = t[1], d = null, l = 2; n > l; l++) {
                    var v = t[l],
                    b = _.x - u.x,
                    g = _.y - u.y,
                    m = v.x - _.x,
                    E = v.y - _.y,
                    p = !b || b > -TY && TY > b,
                    w = !g || g > -TY && TY > g,
                    T = !m || m > -TY && TY > m,
                    O = !E || E > -TY && TY > E,
                    I = w; (p && O || w && T) && (I ? (a = Math.min(2 == l ? Math.abs(b) : Math.abs(b) / 2, h), o = Math.min(l == n - 1 ? Math.abs(E) : Math.abs(E) / 2, r), f = new oz(_.x - (b > 0 ? a: -a), _.y), c = new oz(_.x, _.y + (E > 0 ? o: -o))) : (a = Math.min(l == n - 1 ? Math.abs(m) : Math.abs(m) / 2, h), o = Math.min(2 == l ? Math.abs(g) : Math.abs(g) / 2, r), f = new oz(_.x, _.y - (g > 0 ? o: -o)), c = new oz(_.x + (m > 0 ? a: -a), _.y)), x(t, _), l--, n--, (f.x != u.x || f.y != u.y) && (y(t, f, l), l++, n++), e == mY[Au] ? (y(t, c, l), l++, n++) : e == mY[ju] && (y(t, [_, c], l), l++, n++)),
                    u = _,
                    _ = v
                }
                null != d && c.x == _.x && c.y == _.y && x(t, _)
            }
        }
    }
    function As(t, i, n, e, s, h) {
        var r = h[cu](CU[Su]),
        a = null == r;
        if (null != r) {
            var o = (new _z)[Cu](i)[Cu](n);
            o[ku](r) || (s = js(r.x, r.y, o.y, o.x, o[Fr], o.right))
        } else r = xs(t, s, i, n, h);
        s ? ks(i, n, r, e, a) : Cs(i, n, r, e, a)
    }
    function js(t, i, n, e, s, h) {
        return n > i && n - i > e - t && n - i > t - h || i > s && i - s > e - t && i - s > t - h ? !1 : !0
    }
    function Ss(t, i, n) {
        return i >= t.x && i <= t[Gr] && n >= t.y && n <= t[Fr]
    }
    function Cs(t, i, n, e, s) {
        var h = Math.max(t.y, i.y),
        r = Math.min(t.y + t[Ca], i.y + i[Ca]),
        a = null != n ? n.y: r + (h - r) / 2,
        o = t.x + t[Sa] / 2,
        f = i.x + i[Sa] / 2;
        if (0 == s && null != n && (n.x >= t.x && n.x <= t.x + t[Sa] && (o = n.x), n.x >= i.x && n.x <= i.x + i[Sa] && (f = n.x)), Ss(i, o, a) || Ss(t, o, a) || e.push(new oz(o, a)), Ss(i, f, a) || Ss(t, f, a) || e.push(new oz(f, a)), 0 == e[Fh]) if (null != n) Ss(i, n.x, a) || Ss(t, n.x, a) || e[Xh](new oz(n.x, a));
        else {
            var c = Math.max(t.x, i.x),
            u = Math.min(t.x + t[Sa], i.x + i[Sa]);
            e[Xh](new oz(c + (u - c) / 2, a))
        }
    }
    function ks(t, i, n, e, s) {
        var h = Math.max(t.x, i.x),
        r = Math.min(t.x + t[Sa], i.x + i[Sa]),
        a = null != n ? n.x: r + (h - r) / 2,
        o = t.y + t[Ca] / 2,
        f = i.y + i[Ca] / 2;
        if (0 == s && null != n && (n.y >= t.y && n.y <= t.y + t[Ca] && (o = n.y), n.y >= i.y && n.y <= i.y + i.height && (f = n.y)), Ss(i, a, o) || Ss(t, a, o) || e.push(new oz(a, o)), Ss(i, a, f) || Ss(t, a, f) || e[Xh](new oz(a, f)), 0 == e[Fh]) if (null != n) Ss(i, a, n.y) || Ss(t, a, n.y) || e.push(new oz(a, n.y));
        else {
            var c = Math.max(t.y, i.y),
            u = Math.min(t.y + t.height, i.y + i[Ca]);
            e[Xh](new oz(a, c + (u - c) / 2))
        }
    }
    function Ls(t, i, n, e) {
        var s = i.x + i[Sa] < t.x,
        h = t.x + t.width < i.x,
        r = s ? t.x: t.x + t.width,
        a = t.y + t.height / 2,
        o = h ? i.x: i.x + i.width,
        f = i.y + i[Ca] / 2,
        c = e,
        u = s ? -c: c,
        _ = new oz(r + u, a);
        u = h ? -c: c;
        var d = new oz(o + u, f);
        if (s == h) {
            var l = s ? Math.min(r, o) - e: Math.max(r, o) + e;
            n[Xh](new oz(l, a)),
            n[Xh](new oz(l, f))
        } else if (_.x < d.x == s) {
            var v = a + (f - a) / 2;
            n[Xh](_),
            n.push(new oz(_.x, v)),
            n[Xh](new oz(d.x, v)),
            n.push(d)
        } else n[Xh](_),
        n.push(d)
    }
    function Ps(t, i, n, e) {
        var s = i.y + i.height < t.y,
        h = t.y + t[Ca] < i.y,
        r = t.x + t[Sa] / 2,
        a = s ? t.y: t.y + t.height,
        o = i.x + i[Sa] / 2,
        f = h ? i.y: i.y + i[Ca],
        c = e,
        u = s ? -c: c,
        _ = new oz(r, a + u);
        u = h ? -c: c;
        var d = new oz(o, f + u);
        if (s == h) {
            var l = s ? Math.min(a, f) - e: Math.max(a, f) + e;
            n[Xh](new oz(r, l)),
            n.push(new oz(o, l))
        } else if (_.y < d.y == s) {
            var v = r + (o - r) / 2;
            n[Xh](_),
            n[Xh](new oz(v, _.y)),
            n[Xh](new oz(v, d.y)),
            n[Xh](d)
        } else n[Xh](_),
        n[Xh](d)
    }
    function Rs(t) {
        return t == mY[Lu] || t == mY[Pu] || t == mY.EDGE_TYPE_HORIZONTAL_VERTICAL || t == mY[vu] || t == mY[bu] || t == mY[gu] || t == mY[Eu] || t == mY[pu] || t == mY[yu] || t == mY[xu] || t == mY[mu] || t == mY.EDGE_TYPE_ELBOW_VERTICAL
    }
    function Ds(t, i) {
        var n, e;
        i && i[Sa] && i[Ca] ? (n = i[Sa], e = i[Ca]) : n = e = isNaN(i) ? sz[Ru] : i;
        var s = MU[Du](t, -n, -e / 2, n, e);
        return s || (s = new iH, s[Pc]( - n, -e / 2), s[Rc](0, 0), s[Rc]( - n, e / 2)),
        s
    }
    function Ns(t, i) {
        var n = Math.sin(i),
        e = Math.cos(i),
        s = t.x,
        h = t.y;
        return t.x = s * e - h * n,
        t.y = s * n + h * e,
        t
    }
    function Bs(t, i, n, e, s, h) {
        var r = Math[Va](e - i, n - t),
        a = new oz(s, h);
        return a[uo] = r,
        Ns(a, r),
        a.x += t,
        a.y += i,
        a
    }
    function $s(t, i, n, e, s) {
        i = si(e, i.x, i.y, n.x, n.y),
        n = si(s, n.x, n.y, i.x, i.y);
        var h = Math.PI / 2 + Math.atan2(n.y - i.y, n.x - i.x),
        r = t * Math.cos(h),
        a = t * Math.sin(h),
        o = n.x - i.x,
        f = n.y - i.y,
        c = i.x + .25 * o,
        u = i.y + .25 * f,
        _ = i.x + .75 * o,
        d = i.y + .75 * f;
        return [new QY(KY, [c + r, u + a, _ + r, d + a])]
    }
    function Gs(t, i, e) {
        if (y(t, new QY(qY, [i.x, i.y]), 0), e) {
            if (t[Fh] > 1) {
                var s = t[t[Fh] - 1];
                if (VY == s[fo] && (s[Nu] || s[ba][2] === n || null === s[ba][2])) return s[ba][2] = e.x,
                s.points[3] = e.y,
                void(s.invalidTerminal = !0);
                if (KY == s[fo] && (s[Nu] || s.points[4] === n || null === s.points[4])) return s[ba][4] = e.x,
                s[ba][5] = e.y,
                void(s[Nu] = !0)
            }
            t[Xh](new QY(XY, [e.x, e.y]))
        }
    }
    function Fs(t, i, n, e, s, h, r, a) {
        return i[Bu]() ? void(n._fx = i._9m[$u]()) : e == s ? void t[Gu](n, e, h, r) : void t[Fu](n, e, s, h, r, a)
    }
    function zs(t, i, n, e, s) {
        var h = e == s,
        r = t.graph.getUI(e),
        a = h ? r: t[zu][Yu](s);
        if (r && a) {
            var o = i[Hu],
            f = r[Uu][qh](),
            c = h ? f: a[Uu][qh](),
            u = t[cu](CU[Wu]),
            _ = t[cu](CU[qu]);
            u && (f.x += u.x || 0, f.y += u.y || 0),
            _ && (c.x += _.x || 0, c.y += _.y || 0);
            var d = i.hasPathSegments();
            if (!h && !o && !d) {
                var l = e[tu],
                v = s.busLayout;
                if (l != v) {
                    var b, g, y, x, m = i[Xu];
                    l ? (b = r, g = f, y = a, x = c) : (b = a, g = c, y = r, x = f);
                    var E = Xs(g, b, l, y, x, m);
                    if (E && 2 == E[Fh]) {
                        var p = E[0],
                        w = E[1];
                        return n[Pc](p.x, p.y),
                        w.x == p.x && w.y == p.y && (w.y += .01),
                        n.lineTo(w.x, w.y),
                        void(n._6h = !0)
                    }
                }
            }
            Fs(t, i, n, r, a, o, f, c),
            (!h || d) && Ys(t, i, n, r, a, o, f, c),
            n._6h = !0
        }
    }
    function Ys(t, i, e, s, h, r, a, o) {
        var f = a[Vu],
        c = o.center,
        u = t.fromAtEdge,
        _ = t.toAtEdge;
        if (!u && !_) return void Gs(e._fx, f, c);
        var d = e._fx;
        if (d.length) {
            if (u) {
                var l = d[0],
                v = l.firstPoint;
                a.contains(v.x, v.y) && (l[fo] == KY ? (f = v, v = {
                    x: l[ba][2],
                    y: l.points[3]
                },
                l[ba] = l[ba][Hh](2), l[fo] = VY) : l[fo] == VY && (f = v, v = {
                    x: l.points[0],
                    y: l[ba][1]
                },
                l[ba] = l[ba][Hh](2), l[fo] = XY)),
                Hs(s, a, v, f, n, n)
            }
            if (_) {
                var b, g = d[d[Fh] - 1],
                y = g[oo],
                x = g[ba][Fh],
                m = y.x === n || y.y === n;
                x >= 4 && (m || o[Ku](y.x, y.y)) && (m || (c = y), b = !0, y = {
                    x: g[ba][x - 4],
                    y: g.points[x - 3]
                },
                o[Ku](y.x, y.y) && (c = y, x >= 6 ? (y = {
                    x: g.points[x - 6],
                    y: g[ba][x - 5]
                },
                g[ba] = g[ba].slice(0, 4), g[fo] = VY) : 1 == d[Fh] ? (y = {
                    x: f.x,
                    y: f.y
                },
                g.points = g[ba].slice(0, 2), g[fo] = XY) : (g = d[d[Fh] - 2], y = g[oo]))),
                Hs(h, o, y, c, n, n),
                b && (x = g[ba][Fh], g[ba][x - 2] = c.x, g[ba][x - 1] = c.y, c = null)
            }
        } else {
            var E = Math[Va](c.y - f.y, c.x - f.x),
            p = Math.cos(E),
            w = Math.sin(E);
            u && Hs(s, a, c, f, p, w),
            _ && Hs(h, o, f, c, -p, -w)
        }
        Gs(e._fx, f, c)
    }
    function Hs(t, i, e, s, h, r) {
        if (h === n) {
            var a = Math[Va](e.y - s.y, e.x - s.x);
            h = Math.cos(a),
            r = Math.sin(a)
        }
        for (e = {
            x: e.x,
            y: e.y
        },
        i[Ku](e.x, e.y) || (e = si(i, s.x, s.y, e.x, e.y));;) {
            if (!i[Ku](e.x, e.y)) return s;
            if (t[Zu](e.x - h, e.y - r, sz[Ju])) {
                s.x = e.x - h / 2,
                s.y = e.y - r / 2;
                break
            }
            e.x -= h,
            e.y -= r
        }
        return s
    }
    function Us(t, i, n, e, s, h, r, a) {
        if (i[Bu]()) return i._9m;
        var o = i[Hu];
        if (Rs(o)) {
            var f = ds(o, n, e, t, s, h);
            if (!f || !f[Fh]) return null;
            y(f, r, 0),
            f.push(a),
            o != mY[xu] && Ms(f, t);
            for (var c = [], u = f[Fh], _ = 1; u - 1 > _; _++) {
                var d = f[_];
                c.push($(d) ? new QY(VY, [d[0].x, d[0].y, d[1].x, d[1].y]) : new QY(XY, [d.x, d.y]))
            }
            return c
        }
        if (i.$bundleEnabled) {
            var l = t._25();
            if (!l) return;
            return $s(l, r, a, n, e)
        }
    }
    function Ws(t, i, n) {
        var e = t.getStyle(CU.EDGE_LOOPED_EXTAND),
        s = t._25(),
        h = e + .2 * s,
        r = i.x + i[Sa] - h,
        a = i.y,
        o = i.x + i[Sa],
        f = i.y + h;
        e += s;
        var c = .707,
        u = -.707,
        _ = i.x + i[Sa],
        d = i.y,
        l = _ + c * e,
        v = d + u * e,
        b = {
            x: r,
            y: a
        },
        g = {
            x: l,
            y: v
        },
        y = {
            x: o,
            y: f
        },
        x = b.x,
        m = g.x,
        E = y.x,
        p = b.y,
        w = g.y,
        T = y.y,
        O = ((T - p) * (w * w - p * p + m * m - x * x) + (w - p) * (p * p - T * T + x * x - E * E)) / (2 * (m - x) * (T - p) - 2 * (E - x) * (w - p)),
        I = ((E - x) * (m * m - x * x + w * w - p * p) + (m - x) * (x * x - E * E + p * p - T * T)) / (2 * (w - p) * (E - x) - 2 * (T - p) * (m - x)),
        h = Math.sqrt((x - O) * (x - O) + (p - I) * (p - I)),
        M = Math.atan2(b.y - I, b.x - O),
        A = Math.atan2(y.y - I, y.x - O),
        j = A - M;
        return 0 > j && (j += 2 * Math.PI),
        qs(O, I, M, j, h, h, !0, n)
    }
    function qs(t, i, n, e, s, h, r, a) {
        var o, f, c, u, _, d, l, v, b, g, y;
        if (Math.abs(e) > 2 * Math.PI && (e = 2 * Math.PI), _ = Math[Wh](Math.abs(e) / (Math.PI / 4)), o = e / _, f = o, c = n, _ > 0) {
            d = t + Math.cos(c) * s,
            l = i + Math.sin(c) * h,
            moveTo ? a[Pc](d, l) : a[Rc](d, l);
            for (var x = 0; _ > x; x++) c += f,
            u = c - f / 2,
            v = t + Math.cos(c) * s,
            b = i + Math.sin(c) * h,
            g = t + Math.cos(u) * (s / Math.cos(f / 2)),
            y = i + Math.sin(u) * (h / Math.cos(f / 2)),
            a[Dc](g, y, v, b)
        }
    }
    function Xs(t, i, e, s, h, r) {
        var a = h.cx,
        o = h.cy,
        f = a < t.x,
        c = a > t.right,
        u = o < t.y,
        _ = o > t.bottom,
        d = t.cx,
        l = t.cy,
        v = f || c,
        b = u || _,
        g = r === n || null === r;
        g && (r = Math[Va](o - l, a - d), v || b || (r += Math.PI));
        var y = Math.cos(r),
        x = Math.sin(r),
        m = Ks(i, t, {
            x: a,
            y: o
        },
        -y, -x);
        m || (r = Math[Va](o - l, a - d), v || b || (r += Math.PI), y = Math.cos(r), x = Math.sin(r), m = Ks(i, t, {
            x: a,
            y: o
        },
        -y, -x) || {
            x: d,
            y: l
        });
        var E = Ks(s, h, {
            x: m.x,
            y: m.y
        },
        -m.perX || y, -m.perY || x, !1) || {
            x: a,
            y: o
        };
        return e ? [m, E] : [E, m]
    }
    function Vs(t, i, n, e, s, h) {
        var r = i < t.x,
        a = i > t[Gr],
        o = n < t.y,
        f = n > t[Fr];
        if (r && e > 0) {
            var c = t.x - i,
            u = n + c * s / e;
            if (u >= t.y && u <= t[Fr]) return {
                x: t.x,
                y: u,
                perX: e,
                perY: s
            }
        }
        if (a && 0 > e) {
            var c = t[Gr] - i,
            u = n + c * s / e;
            if (u >= t.y && u <= t[Fr]) return {
                x: t.right,
                y: u,
                perX: e,
                perY: s
            }
        }
        if (o && s > 0) {
            var _ = t.y - n,
            d = i + _ * e / s;
            if (d >= t.x && d <= t.right) return {
                x: d,
                y: t.y,
                perX: e,
                perY: s
            }
        }
        if (f && 0 > s) {
            var _ = t[Fr] - n,
            d = i + _ * e / s;
            if (d >= t.x && d <= t.right) return {
                x: d,
                y: t.bottom,
                perX: e,
                perY: s
            }
        }
        return h !== !1 ? Vs(t, i, n, -e, -s, !1) : void 0
    }
    function Ks(t, i, n, e, s, h) {
        if (!i.contains(n.x, n.y)) {
            if (n = Vs(i, n.x, n.y, e, s, h), !n) return;
            return Zs(t, i, n, n.perX, n[Qu])
        }
        return h === !1 ? Zs(t, i, n, e, s) : Zs(t, i, {
            x: n.x,
            y: n.y,
            perX: e,
            perY: s
        },
        e, s) || Zs(t, i, n, -e, -s)
    }
    function Zs(t, i, n, e, s) {
        for (;;) {
            if (!i[Ku](n.x, n.y)) return;
            if (t.hitTest(n.x + e, n.y + s)) break;
            n.x += e,
            n.y += s
        }
        return n
    }
    function Js(t) {
        return gn(t) ? t: t.match(/.(gif|jpg|jpeg|png)$/gi) ? t: (t = J(t), t instanceof Object && t.draw ? t: void 0)
    }
    function Qs(t) {
        for (var i = t[bc]; i;) {
            if (i[t_]) return i;
            i = i[bc]
        }
        return null
    }
    function th() {
        w(this, th, arguments)
    }
    function ih(t, n, e, s, h, r, a) {
        var o = i.createElement(i_);
        o[cr] = n_,
        li(o, VU),
        n && li(o, n);
        var f = i.createElement(e_);
        return r && (nz && (f[s_] = r), qz || (f[h_] = r)),
        f[rr] = a,
        f.src = e,
        li(f, KU),
        h && li(f, h),
        s && bi(f, r_, a_),
        o._img = f,
        o[lc](f),
        t[lc](o),
        o
    }
    function nh(t, n) {
        this[o_] = i.createElement(i_),
        this[o_][cr] = f_,
        li(this[o_], {
            "background-color": c_,
            overflow: u_,
            "user-select": __,
            position: d_
        }),
        this[l_] = ih(this[o_], {
            width: v_
        },
        sz.NAVIGATION_IMAGE_TOP, !1, null, n, b_),
        this._left = ih(this._navPane, {
            height: v_
        },
        sz[g_], !1, ZU, n, Co),
        this[y_] = ih(this[o_], {
            height: v_,
            right: x_
        },
        sz[g_], !0, ZU, n, Gr),
        this[m_] = ih(this[o_], {
            width: v_,
            bottom: x_
        },
        sz[E_], !0, null, n, Fr),
        t.appendChild(this[o_])
    }
    function eh(t, i) {
        if (!sz[g_]) {
            var n = ki(20, 40),
            e = n.g;
            e[p_](e[La], e.ratio),
            e.moveTo(16, 4),
            e[Rc](4, 20),
            e.lineTo(16, 36),
            e[jf] = 3,
            e[w_] = eo,
            e[T_] = eo,
            e[O_] = I_,
            e[M_] = A_,
            e[j_] = 5,
            e.stroke(),
            sz.NAVIGATION_IMAGE_LEFT = n[S_]();
            var s = ki(n[Ca], n.width, !1);
            s.g.translate(s.width, 0),
            s.g.rotate(Math.PI / 2),
            s.g.drawImage(n, 0, 0),
            sz[E_] = s[S_]()
        }
        this._ngaseCanvas = t;
        var h = function(i) {
            z(i);
            var n, e, s = i[C_],
            h = s[rr];
            if (Co == h) n = 1;
            else if (Gr == h) n = -1;
            else if (b_ == h) e = 1;
            else {
                if (Fr != h) return;
                e = -1
            }
            nz && (s[cr] = k_, setTimeout(function() {
                s.className = ""
            },
            100)),
            z(i),
            t._kt[L_](n, e)
        };
        nh[zh](this, i, h),
        this._3e(i[P_], i[R_])
    }
    function sh(t, i) {
        this[cc] = t,
        this[D_](i, t)
    }
    function hh() {
        w(this, hh, arguments)
    }
    function rh(t, i) {
        this[cc] = t,
        this._j8 = he(i),
        this.g = this._j8.g,
        this._9o = new hz
    }
    function ah(t) {
        var i = t[N_],
        n = [];
        return t[B_][Wf](function(i) {
            t[$_](i) && t[G_](i) && n.push(i)
        }),
        i.set(n)
    }
    function oh(t, i, n) {
        var e = t[no];
        n = n || e,
        i = i || 1;
        var s = null;
        s && n[Sa] * n.height * i * i > s && (i = Math[Ka](s / n[Sa] / n[Ca]));
        var h = ki();
        Un(h.g),
        h.width = n[Sa] * i,
        h[Ca] = n[Ca] * i,
        t._84._hp(h.g, i, n);
        var r = null;
        try {
            r = h.toDataURL(F_)
        } catch(a) {
            xY[Po](a)
        }
        return {
            canvas: h,
            data: r,
            width: h.width,
            height: h[Ca]
        }
    }
    function fh(t) {
        this[zu] = t,
        this[z_] = t[z_]
    }
    function ch(t, i) {
        this[Y_] = t,
        this[H_] = i || U_
    }
    function uh() {
        w(this, uh, arguments)
    }
    function _h(t, i) {
        if (!t) return i;
        var e = {};
        for (var s in t) e[s] = t[s];
        for (var s in i) e[s] === n && (e[s] = i[s]);
        return e
    }
    function dh() {
        w(this, dh, arguments)
    }
    function lh() {
        w(this, lh, arguments)
    }
    function vh() {
        w(this, vh, arguments)
    }
    function bh() {
        w(this, bh, arguments)
    }
    function gh(i, n, e) {
        i += t[oa],
        n += t[W_];
        var s = e[ha]();
        return {
            x: i + s.left,
            y: n + s.top
        }
    }
    function yh(t, i, n) {
        var e = t.offsetWidth,
        s = t[q_];
        t.style[Co] = i - e / 2 + Pa,
        t.style.top = n - s / 2 + Pa
    }
    function xh(t) {
        var n = i.createElement(Fa),
        e = n[Mo](za),
        s = getComputedStyle(t, null),
        h = s.font;
        h || (h = s.fontStyle + vr + s[X_] + vr + s[V_]),
        e[Ua] = h;
        var r = t[ar],
        a = r.split(qa),
        o = parseInt(s.fontSize),
        f = 0,
        c = 0;
        return xY[Wf](a,
        function(t) {
            var i = e.measureText(t)[Sa];
            i > f && (f = i),
            c += 1.2 * o
        }),
        {
            width: f,
            height: c
        }
    }
    function mh(t, n) {
        if (br == typeof t[K_] && br == typeof t[Z_]) {
            var e = t[ar],
            s = t[K_];
            t[ar] = e[Hh](0, s) + n + e.slice(t.selectionEnd),
            t[Z_] = t[K_] = s + n[Fh]
        } else if (J_ != typeof i[Q_]) {
            var h = i[Q_][td]();
            h[id] = n,
            h.collapse(!1),
            h.select()
        }
    }
    function Eh(i) {
        if (HF) {
            var n = t.scrollX || t[oa],
            e = t[nd] || t.pageYOffset;
            return i[ed](),
            void t[sd](n, e)
        }
        i.select()
    }
    function ph() {}
    function wh(t) {
        this.graph = t,
        this[z_] = t[z_],
        this[hd] = nz ? 8 : 5
    }
    function Th(t) {
        return t.type == VY || t[fo] == KY
    }
    function Oh(t) {
        this[zu] = t,
        this[z_] = t[z_],
        this.handlerSize = nz ? 8 : 4,
        this[rd] = nz ? 30 : 20
    }
    function Ih(t, i) {
        var n = new _z;
        return n[ka](Bn.call(t, {
            x: i.x,
            y: i.y
        })),
        n.addPoint(Bn[zh](t, {
            x: i.x + i[Sa],
            y: i.y
        })),
        n[ka](Bn[zh](t, {
            x: i.x + i[Sa],
            y: i.y + i.height
        })),
        n[ka](Bn[zh](t, {
            x: i.x,
            y: i.y + i.height
        })),
        n
    }
    function Mh(t) {
        t %= 2 * Math.PI;
        var i = Math[eo](t / tW);
        return 0 == i || 4 == i ? "ew-resize": 1 == i || 5 == i ? "nwse-resize": 2 == i || 6 == i ? "ns-resize": ad
    }
    function Ah(n, e, s) {
        var h = i[od],
        r = new xY[fd](t[oa], t[W_], h[P_] - 2, h.clientHeight - 2),
        a = n[cd],
        o = n.offsetHeight;
        e + a > r.x + r[Sa] && (e = r.x + r[Sa] - a),
        s + o > r.y + r.height && (s = r.y + r[Ca] - o),
        e < r.x && (e = r.x),
        s < r.y && (s = r.y),
        n[ta].left = e + Pa,
        n[ta].top = s + Pa
    }
    function jh(t, i, n, e, s) {
        this[Lo] = t,
        this[fo] = ud,
        this.kind = i,
        this[mr] = n,
        this.data = e,
        this.datas = s
    }
    function Sh(t) {
        this._50 = {},
        this._kt = t,
        this._kt._1d.addListener(this._97, this),
        this[_d] = mY[dd]
    }
    function Ch(t) {
        return t >= 100 && 200 > t
    }
    function kh(t) {
        return t == xW || t == MW || t == IW || t == pW || t == SW || t == CW
    }
    function Lh() {
        var t, i, n = {},
        e = [],
        s = 0,
        h = {},
        r = 0;
        this[zu].forEach(function(a) {
            if (this.isLayoutable(a)) if (a instanceof OU) {
                var o = {
                    node: a,
                    id: a.id,
                    x: a.x,
                    y: a.y
                };
                for (this[ld] && this.appendNodeInfo(a, o), n[a.id] = o, e[Xh](o), s++, i = a[bc]; i instanceof AU;) {
                    t || (t = {});
                    var f = t[i.id];
                    f || (f = t[i.id] = {
                        id: i.id,
                        children: []
                    }),
                    f.children[Xh](o),
                    i = i[bc]
                }
            } else if (a instanceof TU && !a[Sc]() && a[Ec] && a[gc]) {
                var o = {
                    edge: a
                };
                h[a.id] = o,
                r++
            }
        },
        this);
        var a = {};
        for (var o in h) {
            var f = h[o],
            c = f[vd],
            u = c[Ec],
            _ = c[gc],
            d = u.id + Vr + _.id,
            l = _.id + Vr + u.id;
            if (n[u.id] && n[_.id] && !a[d] && !a[l]) {
                var v = n[u.id],
                b = n[_.id];
                f.from = v,
                f.to = b,
                a[d] = f,
                this[bd] && this.appendEdgeInfo(c, f)
            } else delete h[o],
            r--
        }
        return {
            groups: t,
            nodesArray: e,
            nodes: n,
            nodeCount: s,
            edges: h,
            edgeCount: r,
            minEnergy: this[gd](s, r)
        }
    }
    function Ph(t) {
        this[zu] = t,
        this.currentMovingNodes = {}
    }
    function Rh() {
        w(this, Rh, arguments)
    }
    function Dh(t, i, n, e, s) {
        e ? t[Cc](function(e) {
            var h = e[yd](t);
            h != n && h[xd] != s && i(h, t)
        },
        this, !0) : t[md](function(e) {
            var h = e[gc];
            h != n && h[xd] != s && i(h, t)
        })
    }
    var Nh = "0b8009498403b5364e3205649c265d62e1416d488fa902b509a25edb94ce96d0002b90eeab3c79e911e2406b093c73eb4c177d640266b88e05bb7cb15ff4e7b1fa99f7e78832296bd17f726ff8b0fb1845c55088c51557e22731baa28e245e3b714dee8f1fb6f8d9de82656837e7d148367592e89dedd582f0abecb5fdf6d1ffeb0b87142b2e066171ff9307ccd426c8b969c38e0010e9134c8402be553d9de3ba67bfe15739706e5eeba46fa5ab6d82fcd13d7f99286e9a33eed3f6c39a14e5b1ba6b6e8b064bd7e8a02e7d35f2c95e80bb133a12c6fe900dc96e60546f28062c387e393f7c705a7ac0530487d99a444d4774509037d7ab9dd852c5214df0a68e6f42b4198eae36ea38566d8b358f53b5efa755cf66b5cdc68c24a70223b5e3452df40f9cbe432bb10f4f5e2f5970901a79e47e9c799311fe62ecd2d62e4e87faab211e43c3b9f1943ae9348c5f8766c570dd1f89548e2f33605ee2a59b9e1c353f1f9abc6e5f59eb01abc0e297be4dea61cc1b547efd6d73c86570fd1d412e42e9fee3b8d30072f2e58d80db01c3c72a83cec0d2ba07515f08280a1149df1d634e4146519069ff4845987da8223a7aeb117059528ac93639d4a52db4514cd0f49262ca576a52c10b5490f4b8fb4498b489f9b9869d6d0ccb565c59f10550da6c44213397dde9ec82a345ba3fe762acc8d2c889fb99f555f9897e809c64c16884d9e899d6fe164dc396fc764104bbe8fb2187f52d2ad8f3d854bf8819bf02c93e3c769755b6f5d89c98cea2e6198fe5ace4825eacd3d70e68b5f61fbc3102296d7c1700e9468b1b439ac8bde98f08aa8750037f73f2a8c8e17eff394f37791823ebc351cb28cf13ec0d348c5087246a44c719348bdda1a5001adcb1beb8a3d6e3813115bb43ded831b6811d825b87cfdf2ec218cf019a9c3bc3c7f97be0ff6c7f253888f5be9885d07d1af53a34c466589fbb6b715f5062b993bc2debc1b08c548e215412014d786bfc46257fe947c035945bd1b87965550ee1a17c72e2bb44347a89121512389e0ab8e46f9c4afce03b5b7915f54b4c1eb6d66641cb2fd65bc5eedc9a4a8af40123247054e79547e87e23261a287b7ab4ae24d1d0e624065e757bfbec827ae931cb40817f3d0477629f73fe05c6dcec5574be8627022bd95b81711d81774f145946f9ccfe3451218f7c73a3c9cd82bf17a78a1635340c799ac35316ab6e4f5d8d73acc6992f840e2da78070e21e0710a66e5246dc160033286d83b3832bb46d06cebb152aae7624913b443592ab84ddaf7e16352e3cb88b0e28ac8cd742247132c188accbfe55ee0990d7c9b5209414670f5ca11798b1b1d6410a6f70d688991ba3a158a4ae83b7704c0ab79360048b1fc699208887734fb13536856a9392ef4e355a4114e296afa179a1339c211fdada5daf51872c1a98708ffec0b725870d2bf02237b6deb7499c7ce268efa5d93ed7023365510316273c0123fada8d8dc03220561a5c2df88e647e09c8141b7d8754f39fc5873ab185446f28afbc1b45e5a4f9e9f128c44b9c0c0da6f6b27790d0da1d1f2ae527ee8b86c7b18fd1b55c1d3276db63f95503f04b6c8f28f028aba9709b0e25ed28051a54dd3fca630e76d1aa033692dc354499fee32b21688196b558aa1b1b6163266153b85119c65dde7712ace6c225deabefa8356333547195a584463c9fb06e4cc2d79c6a9e49c33a1c00620bbf294602b590b70801878a4714ac503c841cf7a807c5c67887f357c5c34607737aed2dfd07fc4629a4aeef42eee4cd6973a1c9ed4d117ec5ccfd49827a689e1645bcc907701b0cca0b889ce536d2c8a40b0120f7a4955f155491f3bf2d20eac5e4669774d97ccc3998d446ebcd8560b6b86a45dea881d722c618051e31cd6f54eb277e7157ba6017307ca8e6a063c1f732eb6628edc243afa900a8f349a836ed32d3c6378130aa59a4f0df315f31c242b71fa59aab2d0fa4b1de6f09742882ffdc600cb011d29fabdef1a1007a21bf2054d65518fb3ef300b731b03b4f03762f39a17328186d2dbfaa27554eb4b52b1e486c1a2c618ec758bb9ce7d5dbd766be017f95da6b02290751a54cf1ecb8f95eff32347f5a54a4f82b8c52d3c7ff6a547d5bd4e0c42a84e6555acc94576d153e452e23ec3926285a5a8b95bb672f54c1cd04b5eacaf5cd0c3dfe9ac0ce7b303afb68bd4dd3927bc308cf9fe6e385fe0d05eb5737f6e6f3e9d21da89b31cf1f481410863536cc87147ccd922f5a6f9a226f261ccc780e33f3a90ececf62448fbd51f020a31869670703cd0cab3d61485bbce9000d260c0e5f4a9865e7e8df2d9084aaf4e8fbedc3854ad2cd7f223ad52a50d8db2782372bb14544e10bde96cec6835ead07227f7914b302ff10980de7028ab60ae1b904c62707756a851b56a2f6c654a5a32d47d49d25763ed0e596590e405fc24f4a03d3f8407fa5d8058995f8dc0f201b86297258c47efa3ee8f4ecb2018f81a1605e69df4d842e7eb66f15b31c6bbccffd4a299827b765bb5ebb1259cced4cd3afaf8d5262ca47dba9bcce42498ad6a6f2b9806f8c56630bff940c04c38a12fdef50ed1fbafe59f6f27cebf863c19f1babb58645b438cd783d680dbded357d3f76c57a2789037484347d230c289543d7f01c6674b866b956f71c297cbe3fdbb7e03f572bc971ef7252d3b7bb9c51ec3c45125e4a665a65966f9a941df13676c474ea6a208eba142bf7ffc026758fee94f62f9f62da14d5dc6a88246ad5b9ae0e0507e0c9b740cfa884484efbd4dfc6087b68c5c924c4b5fb41f70c5f2edc9cbcb3ac1d9faa719dcc338438896dfc6dcc5e0c37cae8657b9732704f8aa9d18e184c42b97b85356cbd2310a3f21b1935f908e3141f38437526b153a6d717496ab52993b2e00a64e1dbaacc0f5c0cb3f0e29df20ed87d6ec01ad888221983d2ce6f3429a6c1ca01443b6b85349b07cbe7558c9c46e5c091b8087e0186343f8db46df3c3d007120a4b53e1234a276559fe0e1bd3cd60a06769e6cd4c727101819eb31a8b0920e73d69efa1ceb3c295f0d1c2ef32c6bfd8701f118895da7a0f4ecb723ac8b032b46b0197189c3730f68bdbe5ee285c5b949afb70ec41797faee3adb012c0d037cafe51b0fd31edf72f943cbb1c32b7a5082bb82cfacebd5ef90273b20b9fe11092da478a361540afe5f6b8f470db7bbb49a5c74487cb2b09f231d72cb2420b316cd961ee4e301fa9e795b53dff916118a4acde2dbea16296cb3f644948aadaca90582b74f80b55c96ee4a385d4be7da574cf215503a0de278fee13363694f966c8df041416b828f162d0e17cd13fc8f46be0d801105b33953f10cd7f8a6a358a5999cf4e23c209be154dc81f2b0ed78e2a1cce8e9ace5a359463cbcc80f26b9a716eea8eb679a6cf1a1d886652f5d86ca5657ed8b442a35248ee3855ae202ebce16210aafbcee4fb0ad4a5576229af139c7cff798bd6aa3cac2bf21095a8d03bccbe70702a85429691f7eebabe86364014190d2cb85b584bf018ffe3f1141073a97cf4072c027160952b7d099297b3e71e1ae157f6815f2fc6f007e6e791cb5d62dbf9b12dd5ce318cd13a11698af5af4cb7004fdf0c61d76825fe6a2226fad33b388bc135cde63c946c1266576163c9da4c8579cd43910555788b919318758ec703a3f1a397c82a6dec38d2e109e6a98389a135d1c1ac7b15bee836ee528d8c85879458f0c9ce00dd134f248efbdb22dd28c19305503b6876e17f0a7a748e657726539f99005bb7d9c50f8a7255e17cf2882fc20809ef66b27a691ee73de2679cbc3721ccabbd6d213018f99e44b92f962e6f6e81bad9fc4c2f8c7d36c1881d0b6cbaeb64a9ae1a8f4d96808beb0cb8b110c7bc9cbe73a6ba586add8d7e88be1cc147a5625a462d9344abca00c99bdd1edde4fa2c114b82a552f725e150fe570e78a396f4653758b9b0ef1b136d767edd19cde830c92ec1d1eed6164cc20fcebb884d2b9df3444a18ae22f20e2cd316c1945f5a23226e1fccc8889bebfc3e259843c3592962fc245dfb40733eb8e7f7d204b71bec89ff3d78fecfc67b76ba331446a5a45d3d90857ec8dabb8909ad269e2ef5b9800b49420b1836fc1d038be88f63aa76b781dab84987bdd326f35992b56456410912a6d4eed69169fd997e7f80e8941bf6bca0ef0114061b41306a4c74452fc6ad3c1853cfc3e093a470a493320b16f67347627a6ef86740fc191898802fb90b7d308601343e1b511bae6e3da5a730d29b40cceef22f84a19fdc9854258ceb75a4b8ab92b0eab39b7045655a2b3ee4835b4edf22d8756a95b0954767acd50fc1290ba03df828a9f7a5b9c539c6ad2d36f531bdab4e667ff39e01795dc31d8d2b65a5ae00d7b32f5b917b5d9929fa4bfa3fbeada210564835ab6ef4672871b5d0e2b6658e2bc04cb3eb6b04d5b48b6038a66b7e8da2ebab3df5d96c471323f97e7f7cecb47ba12feefddd91606ab8f8bcb0c1f8ef0f074d0fd9e610f74f8b279e8836ec3c51638aafda081d9dd3d049363449fa2991fb4608a7ec556f98063e6210569c3662b5634769fbe39c3dc4a83d1a8ac82ea8d3554622cab0aaed11ce76a79f6ccf2361cd68743e787198bea9c887bfcd3c509428a02d300c1ff737c98e11a613593ec1c30491ed7ba8dd2e04c3fd0af4b706fb82309a232d8853f828f41e60117f472d1b5893b4871fbe3d2503fc46277d26a6bba71961ecf24d719300e3bc1d67127298c961547d9f27b95a4532720b9b68e2cd3a1485d3d0367809432c2d24cb37e82efa70d7d24a0a9866d33d2aae365f35a2059582a97204a142a12d4e77aeab08c1b9e343154adc333d5e52d647a86abdfec89e073a6c91ff23006d67d6114e5e03e9c21bc08b5de6bb06070f12082a4c85dee1369cc3c5ce16eb264f19f5e3b6fb64095c551815b8ed3a630034c185952e7f10da40ae117a95656cf592fc2cd64b1c7d4d8742e7efafc93feb91472a09a8a0e2afdc27dd24922f8d8d5c4850c476fd2ffabaebe5910324979907edc0d389320d1b813b3e161dd6f384beff1966a0605845d1394952c7fd9271153401807fab96aca6071abfc292890dec1c05c84d24ec59b2a2ae74eb4e8bdaee18bebe6a2b9ed2b2309dc3615ef785f55d98f05198df816f8021f752c5156dad4416e8fab9a1ce5e433124005534c61992615df984a00606bcce7e3db8516b43a5c1da50f353fb1e8066441d56458f229fbaaae1383e63f5e3ab15c7bc8f72e2445d7376fca8ff2f5165ee1d87928554349aef0961add397cca417091370445b457a5b5ec99d32d40e7b9abcd319cdaf1fabd3dabbfc6a6c5e35263fce61b1711a2917750cb910b33905b7bd70de2b274cc67036dcb115bd4f4d58a5d008521e3e98187e870a7a989f6b77254a52e5a3bebed51546129d079374dbe384e4321ce4b5830d631865c390f2953d5f1d7bf7955031c13188491cf17f91d75a3e18a74bf0ad3da3f23d3438f995e785372fafa02203c3049129d80c84cd8c21dc1d17cdccee78e1836e082d530fa357d1c02e36c5202b6568603442cb1affabc00c017c18cf4f4a881a7afb5f3d3150f7bb86c6cf78e0abf50a54d7bf44a846181f407bef27d2f30f1c68f478f81cda6edb5b53f09cecd7ba86a7ee5eb9db28340896ba8342657113b300bdb88b3f71c3df2482a595c77f19c03f7503126af8324e2d7b789b548b58d41eb66a81b265c990a82dc0efe57d1db7d904781dba334aae66385bb4d58ab4572bce547cd60b6c69553e3851fba7e314a98de9f47a74051d5c0ef44d33b2af9d1fa49d91e4a4117f15bffda2c30e60a58b4464eaa7f120407ef0f9525c5963192308beee9dc329387c8178a3e190ba59ca153ae0ddc85abb90c3dde9459007cce9adf5e72167ac44a0173cdd04d53e6b85a784ba4bb39e88e82055bd88f5da48160e76ab5fedb7796192d9dcd663d96a0c4458109b90e52086f5de122786677a0f83c5dcf3009b8ea4370f4a0cff20f0aef6e25d368f17aefc61c4c638c18483437581209872b67abf3f85a93234a966841d815fd03c2e221981faafb98572dd9156a998d9a928e6c2d6a59829bb3c853d230621be7162b975b790308955c0f0e7389db233e2ec19424a88ae8fa0d26b3d9066ab6570b8bcadef17040af545f44530094cab1bec72f783265d85bcac7e036a7eb01deee7211393ad632cae8732562c71f055ca98e5dc995bbbadc23c1871a76473b28168be58f67c78bfeb293eeba20c88008b255ac4cb70a5f26956b9f599e13a77165642b5435b1d6472050c657c9a59b40d64a810e1cb8a8b980ba0787fece6716bdb071df2e41634d8b4068fb441b3164fee58fcdef33aac9973dedb0e26ec3d978eeb8e02e05c5c7bf329b3be3bc40b330d8cab1f57ddfaff33efd7dd6b05d7b4ca86d997cccd8b3dcc79835564d1825e13e9c25d2b476cb10c35801d8b39af80603fecf4970b299e6c89dbde1bf966871e63524ed9ca27480544cd303a36d1eba6e2a18bc6f7e039a2abd31c16f7802153fe16486bf73e0c2c4bda4ccd4ee1d009d3b2bc82fa0a3ac20046bc88e18d03b4b0b1ac6698c5b6ce6b5ae7a50b63df1d11c088e0dab9a6d21d68203bc4108a1fe2376bef758222f243e6ed3a8d9dd5dfbf3915d9e4bd706cf0de0c6476c49c1aaf9d932c3ab2ff1a9e6ba71f3f1d2234f6fe19211ef6cc5d1f2d0e8a1525629261d8ff5699e54072d2260cd8676ad9cdff200bb05aecf498aac43255f87d68205000272eb2dc35e85b9e9ab36d77dc1dce43ab43bd1da004a377ef1699f2ad9a8753df0b726a9650195630be29cd40d4b1cf6033a65d205654ce7c6e40227b119452255b09eefae154432a94d157a9d90f53e359870701a212d0316cef404597e19b2d2320f49b66337704e27c51ab19c513757db1fd7acd316003f1ff6251dfef033806cda731db3858f09a40650d92e0482f5803d723caac4781855c64ed9991add467fd816501528769d9fbfd21bdc85e8e6c7b0b24d05cfe864f888ba751687ccc4f4d1cad45f12c282ddbe022efe60caacba2cb73450f83403d67c509f08269cb194203817b99513cc6bc23c42c99debe36d4fd434ce4a6ed19f6a0f6ce99b7f5abfa2fb33648cea384c258d6aa3934329e29d14529e1858e8ec0d77b0430ece6f44c96723dcac41c5a6c55a8c2ca2b5803cb93fccb0d9e712874f7b587833a6dc7cba7b7c15f48b6744876d78d4c1da5c98ec47871dacda2f7f04d527e29441de2461899fa518b7fb97c04f4ab4900a5854d12fed380816d1d32a67c231db579933433647650f2635edeed3d378cce752012e992883b28a4f458365ea7a59f9f13d016578fef2fe0bda67ebaf044db82fde5656bf190adc6f548af8967fd2ddd38eb063b9eb7b4377f5eac5ddb5b789ab30434b76bcc6ed6fbc8746a726aa73af502a6355bdb46082e24a58390038545dbfe544f6ae5492c358e249ab33b5b28e2779d55811bf1665ae13aa062941620c8283cc6b8c142eb10e698a0f9e38aabe8b4b8218162a7315e6bfaceb42422c5e6c5823b7e558de548a50c858082a372841041531ae5d54058b27f1e88069016c6a0608783e3291fbad05504597f1775ed64c1ecaee7d03fc39279aa47f58e472cae737a31f793ca1085e592c8cf74710a7a6b4a91a8606375b11acd54c2bfc630794f8d3f373dba1665c70fa2d6b6aaff290288e8a431d103d9ed00de1f198be3b83a110a1b17718923a75862ce306d477bf5e00d2eae8cd8a8db1489bf7f2987848c4594649f3e6d6ed9bed81aa13904598ceb98357d82e7396651b6b2424cc48d3160868c851c536eaf4d30596d2b7af7163a0c570aa11f6aea38b57c05503ce4ffa957a8460767867fffaeacfecf351b931e8f24191c6d46d4ddc6f70fb8e27a1fc47b1fb2a820067937fff30248cda69f7781b33173490826c3ffaa1f4492743a5e8ba991be0806fd2eb1b8ba3ebba3becb2deb9eb066881922cff0a7097a12b91b881fcab6140ee2e501ed8396fd963320889d5eb424429032cb4ad8f106be1f8e6b2efcaac456ddee851fec08201c08020ca2ac6845384c85f9276371bc07c0198e5a0826bf24f642912cc73a4e697cf0274002f7bdc294eed6d29f73eebc7edcccbdbceb8eda62b2e5428b92567e61cf099341458edb8e0a73bae66fdcb44d434eaeb95e02dd3830c2a78c0b161e491abfe170cca21710c428b0965f87599e772bc797d7e6d1fb3472365254323c50acf46369bde721c18d00ca3b05386712951ae3364aa69a8cfb2e43f98c73109f863118d9224666c7d1c383d10addb4d0766343bab6a8a9a1e1972691dac3905a637458c6b6550c55ce0effc2b96a5c2082e3cb3283252a3eab20fa646caa5700eeb735f4c7bbe3580514dcec8bdcf7e04e9f01bdfe8c4c003a07afdf660a929e2ff633e840572440badfc19213167bf8f2c1a2bb93af4eb094b7c34d644de8f49db4232133bb1120d79f78d9198236d3a3fcfdb913b02ab2cc926978176b76fc105320edf83a84af5dbe3b55af1eba943c1fca42de15dcdd2a9577093b1c546f994f14dc892c20b0c56247ecfa30abedc4a338ecf872fd7c8049d4789bf747ef6c95e0fda174213a9746150979728a57f095e18a5667afdab22a3d9c795601726e39275b2755e52ac7e02ceb82e4d43acc19ada9165b665dbfc61ad41d2d77dc18fd2fbc0b3f76bf60cdf76cabf32328a4fac45f347e7375171fc36d8d1cf4625d7c262027c019ee99c788b1d41617cde2a5bc3a0e85d81b4cf509ac65b1eb10f893e1c709f32ae92ccd25fcda247287090088b27a37c0fb0b498e703c1f857f71b5557006bc9c75ddb1e2151aafabe9c57376e954b6ed0c4176648db4e75a9da7481bbc36b012097626dcc13559f3bf766271b2f4fe6e7c0c751d3a911296894675c602f7b618540c00246bc4fba268af9f72e0185a3fae8ee2ad251334378492e3be4f8176d6052e62f27eb3afdca21af726f59d7061fef9bb0df1680ebc8705b7bcc9aa37198526400f5fc8537a4993a82a3323f05c0c9f3718bb683fb2c8c4b157d282867f82383597a1f5c2be18609379f8c77eae5b8824097a47a7c404e350bd397d9c6e78d6d14aa2dac95b5cddee7d1355fe5730df735daed3073d872adce6128cd82ebec2e30343dbb491ec47abcc97225cb8e3de07620d228533e71461e17df2464719dd84541a9e2ffdd5be33538c8a638b9af152e18162fde262361103516534d22a41d4bbc0ca2e3bcd10823a9e6774b9f58190d643974561f9ac620f0e2c7f5e7ef9e19d22f430a5104b6e9c8a3915578108141c1c40c4588b937657ca1e0cd764e40e621eff08160fb4ddb1df89eb320dc3425dd1beae237b03d5cabbc76958c93c4206f71850ab9ff322c8d0f313851187da8b4ecfab9b2a811c5fd2f645170ddf86e0e7ae85a94f33e2cd37544db2537019b8f4c4259053313ce67a8d0b0ee9431aca1bd29ee9cc7ab1b5ce848e5849b8182b15f01901d381476a653de50b6e7c39a6233732780f1344a5038d94ab5729a3f996736661c6b8582f090e943f1abfeae1f635f1747459963ce98dd37b15384fd5ec5925d25b760d0ad6f880cd57fd51b9d860b27329a744c52c8e540e450e343f9ada9674895b6a30f284b8114065b7266e24c86a187537e1f0cb68aaeb19f71518bf3f3ccb3a0036c7b81a9671d23bd90641fb6ed4b56bc5be0772031d8d8d7c687019a087ae762427221f13cfd7385eac657cd49c2c5db966abc382e3b80a1b854f5ad2673c5d3ce2b565fcdb8b3acfe2e4a71ce2b4f620ce4ce2461133a30f8cddd7403f925b75ea63f0e2bcc27038db12e616a010d593b8ae8686901b968e1c18783da73c03505a17a773e2b67d174679b5224319a49a2f3a45d82f89989acd7bc9c4fa418df4b7e61ede81a98153c88be00c1596c4210eb6bfb70500d18c683f276b636f583014484e2f7a4c92a63f68c609535d0f813999cbc59a63195f218d2891cb718313e8d0195c631dfa0307701fc92e9fce0ff4a0ac83a13420e3cdb4ad918d8e48c97461edf87cb0e6d603bc5e5e7c7f40319c5b4a5bed92d1d776286b1be9a055aaf6dc2f9a6c33ab0a86327af3c6f27e14b58ef95fa90a874926aecdcb3a48cc08fdde79b327ffb328e90fd016bb4519291d09557bf7776a1517bfa6409e0c21d88cf3524be69dec47f376409cfe3b75cc7d9561d589f03f57b39e455ce196081fbe7fb390a1b90ca8c6f7e70224c9a3e742f691bd1f183940ac041f40394b29e1790107c543273b98b0d4928a7e339fd902d448457becc5a71f9b9ca201ecb5fbd39a3833e7fd58c8c8e0ae99cba5b0e19d3549ef0b88847c8ee3913a139668164ee0577a10dbbc8a405305877ff738749ebea806e74ea01ed1bed6b77315c7a3d5fd8309b79e311ead772fdf41dad5c43b5fef67b2e2f039005547cd6138028557542e20611ca2852221cb95daada0b3bc6934d2169ce90f58375747ccd15a1c2dff8be7b7ab433568868cd53177a4871a97da35b768003fdb8420beb5b05a87dee301488b05cd83e82daf3eaf0212d4902248367023b8045fc9d1fc0ddbd28450d6b2f8b06a282291c361bbd71b3781c633e6559b0b804aa756fc8baae73a55aceca31a1f3986bd13b27910a31aa1a96211d75ade1120e54752b03217788b03374d0409855733cd76dd61f1afab4b550e791fa7d7c2fac41a5f2d7fbe4f87eafedbbce967f62e26dab374d390438d0528c0bc365934e43a09f1ea099faa855c1f2feb441bdfc832b5b47ea0d8773e0bf33176d41fabc4ee7dc80a13b053aeb1869868b0b2e4f420aa16ff91650e728943039ed8d19a03d25c9f78ea21404e7d83dfa79b4ebc5aa9c3e43e14b2797a8fb9ccf84219dfcfd6af7c00d8e97b69dc11155d0db7081b2342927d62ccbf8998289564483274dc31a8cab3b4befab848d7d13653446cdfc9b3a2f7ce286c88f6a945c7c337b5ef4fc5029c8c2f4be927224b42421799993db304b6c27fb542daa0572067d68132850444d9d3d3db894a6ad5b1ae70689328ab586e2f8bee74b8f1c6a295b37b46a16ab08a356d266b41d34ef5e02030b1b12fbc5f3529d925c0d9f3968d3618d7d89c590c88b34c58205e1d8344e18e112b181b635bc754f0931dc7b9634b455948ecbb24fca0bad304a43c29c06bc3d9cb38e08c9f17006a76205d65467a3a5372cce73fc1ff5ce654e0108e71981252756107dcf267c7d32d50cb37e03a95b4a01e2eafd96b79897a4bc751ebdcff67ab12e17b512019d751f0c8ead48770f2831aeaa2bb02c258f6dbb45b880719e8e5147426b04b98643f1e602e544e3ce2304666ba8ee0e9877eec051c5681ca6c94d8affe186860841b3f23e64fdb042821505e18a7e6439b4d641a1bee78637a837575e2d6b307a8ce04b6e3c71b565b6f5f94d04d1ac2c0a4070fab13eebbe551259b317da4514d29a6957222498610b6a0cfbb1b3ba7ccb8a266c869c22744aa660b14c6192a9fe9de15b6a824a9e4aab7500353ab738e2371c32f766cf0467f5e51406e37908d21edd5f19d6e171064a3538aab48db3a63a55bbcb84061746d968a4fdce5cbf17b1e6519bd8dd5880da4cd867b2c47499929e7cbde1db948219f3b1f77c669ee696dc22fe42028a1ef32396580cf00c086180242f0cb9cfe6d1a3c4046c08f078f00a3555b4c579f5ad631d542167470d964f6ae32bf89e2dec3f3aa946b7de44771bbfa4ddad4b4af42edc7251eafd1583159d25deee149989bd629c12be3e21dc677dc69b6e3207c85db026c9cf2d14b82520e8507f8bae597bbe8d5ee497c955ef859195d21b925d8796ed715abec544ea0ba09c0d4866304f57c290402fc2cbbd0783b7799bc13ed9c991462e7c6644f01fd7a2dde1bdbcb7f21d0786219cc15e81728a53e16f38d0ad16dc621d6d4a7c6d19b1074c4d64319a9e79c3e8b104361cfcbd4800b1763e33412f1f28d9ca6d7e83bb5945d859a9109752a47fca3c173c5424bbc98012a13c5eb0faaa079d7aa345bc14b7c69ffdcce0db90c586b0c3ee67c1aac70c4c41c3148643389ec1d16d49776bd13507cbb1e28847007b6c90c25c728bba16ee5752ccc25f1e58750369e157481ec20c2d47e962e4816d9f537c9ad79dca71ea1bbfe8c5fc8337ddd1244b165f259e8cf48764f4d270ab3191df480c7393d0637a2ebfdea82f644b76fa4af485093d8a5612673b8dba08d6e48a1527fed54c8f90d298e16e2a0ecb2ab292a80067a75131e1a6d7384a606c790f17760fa179c60cdee20307967826032d4a69896415b73dce987b233d3c614470a6e848cf1eda7942a422f9ce82c72170b31123041d5b5bcf833c3ce98011c2f39c32752f58b23ed6116f6c7a219d9b0fd02f2f9bae0c15e036c023cead4432fcaf6508e2f8e3f6bfe7501b5af435cde0ce7d71ddc726c7e8684a6250bf02455eff9216d2182eb83ffb35825c64e4925d5261eee7efc2b9a5f2cd48ce9fe34ae5f3f29519e850d6cda5985aa7a1030b54eb9d3b52428fa92c2cdfc130af2627dcb37adc8ff9974c36ce1dad025e410dbb7d5c0811b66d4c3354da896551fb1db51decb5cae0ed4480230b8d75d3965d27e4ce8c25bc531d7c70aaffca3f6cc9e90a9eff1bfed28f3415a26d2d33566aa07dbfe6707213bbef88489811f66d7c51fa68fa63f10455429d8af077825685c38f8a420705f967e9477b7afec6b1eff5173f77cb9ef41caef9354e7186ba47564d118d366454df49b92b4ddadf1fb7f0926e6f17ee4cc67c7cbe4e91292847f8f493a595469cb2c95b0657f22836fa78d93e54660e0c247dd0a5de8dd29d13d103e697728e6dc8dc62d647c2faa04c0446af466ee148f68f792bbbc353ba0acb18bfba40f8ce30adb23a4b6a0e75dc7f3d50213d3648f5ab6b552e82b48fffaf5327fb067db57fdb01b8aa909cd6f481badee033dd637d017bce94b762b7aaa6c9824ea11d52e56ac5ac9fb0bcee27656b685184fdd5d79891eb17578f6e7c1725ffd539441cc9b652ff539a7fa3391652e4af0af6f8c40179ffe4c0ad54506601b440aac650c2924484f48c817ac334d2e2f371d125d358842c7fad69f9757e107e47b0f9fdb53dc8423cc8fcd716ac07494075ccb6619de75f0f9f5c247ccd0d97ca901a5f49116c00e22dede73d4fe45053596856f1eb5c118523e7af5cc9caa767a2f7529fc565372db57aefba1f457b20f99902e5ba7836d7fe8865575ac4ce03d62b60e4ef49e43d3a2bcbf668d17ca32a609f78204a380d60f5d033f35bc74c12aad7947af76fe795295a6ec10801aeec9c858f03f60d9b6d63c1184540676943733746c6af32a9bbca458abca491e04b5868f5371fd62adff248a4d23cdbdae89d63f7f87ab31dab914a0684f25dcd9612e825302bd1984050788d4162965c93ab1f4f261c817e7bb11b27b23dc250b84c447c75ba5e7cce435ece09da365e4bcf1048847d2c2ad89bd27e00ab64a14bb80931f6f6988cf670a16c1f61163d98d56951bfcb0b1de5f695364ded3bb7d1506704a80b2f47393bbfdd3530e643707ec8aabdb1682a530cffadaf5f15661ebdc59fa4fb4de22db1c6e6c82da7b214c364659e73cb6e7069a837675b97da09b9a9e866afcb381847e7c8389f75b7857298948823650072a453c7e5212354cb21514b2fe77475d8d63cd89d733f76b8922ad22fe74749d513bef80540e8dc5b5c51a9ae0c1ed763473728cf4c1bc782d48580dce6195e2d816974a1c9508850f1c05b0e3de935d6013472b56e50e1cdbb534a5a6ca6cbec40cedf19c12cee205b8aeaafccb82b22db82f05dee0213a973a8a2d79d2e3d12d299d3d3b8680d03169f09fac357e7a2849ef6ee7b87580d30777b6d92d76b50296c9bcde6483b8608e0e7a31aef32ea54ab1b8701283e6c4d0a3a951a8cc87c51d4f43dc710331394f0ba16ed4bb41b9cd6540943ee6be4adabbf5179bff3b30ccc9a54cc606a8457ed75416dd3558cbe3079e629de33866d6bcdea8930796e113bb5603e34b68f52e9f7df0ae821bf08a3ecd6b13b38558f8cf41a13f3b41024183059a7fa2d3b1807df705557441541812443631a53ab0c3834a553d1a3140bcba5dc64c5b327a421d512b85162d2a43e36d92bebb05d990ae099ecfe6b803c82ab82d63164de624b8fbc68e9330a891888aeeabbbb5c5b7d9eb9ebd5e2d2a4c18ce46ad26eed1e50957ef51776ce9e9f4c37b48c179dc104984867a11b9d9b750cdd21d97b635d0e66d12527990698de386fc33255d880c51650eeeab05528175e293bc17ac6aa271b38530afd949d385cb65237bd263210d119ad64140d006814606c4c15dd14198f1ffa663d1fd890212e579f5996da8b38e2894ca601064b9f5e673c56a80c4dec7dc8e8641429e9729078fcd6d0754562c81f7de8159a68497d1fec4a2a6b392f8342b05bb6661739086d99d32bfe454c919895041ec237cc1d262887126308b88534127c2b96ea96743b1ff93384e50675ef518416992ffd177aedf2bc173a104bf0ba57aa66a2b2c3384b3e7edbf624a6d8e6198ff79486cf723bf9d8094f5ff93129393144ae7e169943113d01a22cd91b02972c37b101a743abe8989a126c49a430fee6fc0177d6e4fe2d0e0dfd24b0287aed7c8e9dd092aeed0291b0f2aacdca5a7e789fa0d4537bcba35c1857e7e85263ca7baac1675579fd1352b8dfbc476ff2ac6cd33d92a41a396f99139847dcdbcbfdcb9e4de5948d2c43d6f17521d7d009056ca0f848ed9f77d9239329da8c5f15c5afc0db4a30f978465c50ee4dc2e9ffee2a54ab0d947000374c92f1ee72e6395cf2604036a02949269257e6220d163b9304d8c77a5f99a32e25c0f9ac39589a89cde62dc42008abc65d21b85525e1d5c438e9c8157c39f434e046ee21138119fbe05e81cc9c00e8e6207a749367df620c38b8ed7846329946a9a0125b2e7232192c40e12b3952f0a2812db93dbf039addaaa9e7791e624aae7fa3adeeda926c1eec66fd116c591e7f0ff10e5f8fbd109fbc4001e10b7b2efa4e861be8855120c2791585dd29cb86deabf0882986955c0c9ab63c3c4002c44845c4574b46de3dcdb3fe9fa2e6af392f97e587935bf6c51ee28ee70c5aa589f6ff9d046bf2034e751587d8814dabd7248403db271f716f9972cda1584d7b361785f5b76dbc7b7343a81a8e6600ff2378b44f6d8b9caec152bc476c1b0136bfa931ec2ebaa1834d3f29d88271a927b1b8896abb272f5d9bb0366c347e07492e5f8aecc1a012a403ccb2eaf0bbcbef7960b5061da17dd01a56c22748e542690388a234ac64850c9f42753a33e79910abae18451ab582e2bad48b9b321c70af24ca255acf3a26fef355c363fc972e0328677ffdde3e13fbfc3b895e8daeb140b2b01663a83079e607408e88697f8b6f9d0cd3a1c2a9d0948351761effb7efeecf29135a688d4fe42d275cca044e2a8b187394acecda649298c1a28859c8664f8d32c87023407b7",
    Bh = "[a,w,s,cf,f,ge,c,sa,Chil,A,WS,34,sd]"; !
    function(t) {
        function i(t, i) {
            for (var n = "",
            e = 0; e < i.length; e++) n += i.charCodeAt(e).toString();
            var s = Math.floor(n.length / 5),
            h = parseInt(n.charAt(s) + n.charAt(2 * s) + n.charAt(3 * s) + n.charAt(4 * s) + n.charAt(5 * s)),
            r = Math.round(i.length / 2),
            a = Math.pow(2, 31) - 1,
            o = parseInt(t.substring(t.length - 8, t.length), 16);
            for (t = t.substring(0, t.length - 8), n += o; n.length > 10;) n = (parseInt(n.substring(0, 10)) + parseInt(n.substring(10, n.length))).toString();
            n = (h * n + r) % a;
            for (var f = "",
            c = "",
            e = 0; e < t.length; e += 2) f = parseInt(parseInt(t.substring(e, e + 2), 16) ^ Math.floor(n / a * 255)),
            c += String.fromCharCode(f),
            n = (h * n + r) % a;
            return c
        }
        t = i(t, "QUNEE"),
        Bh = JSON.parse(String.fromCharCode(91) + t + String.fromCharCode(93))
    } (Nh);
    var $h = Bh[0] + Bh[1] + Bh[2],
    Gh = Bh[3] + Bh[1] + Bh[2],
    Fh = Bh[4],
    zh = Bh[5],
    Yh = Bh[6],
    Hh = Bh[7],
    Uh = Bh[8],
    Wh = Bh[9],
    qh = Bh[10],
    Xh = Bh[11],
    Vh = Bh[12] + Bh[13] + Bh[14],
    Kh = Bh[15],
    Zh = Bh[16],
    Jh = Bh[17],
    Qh = Bh[18],
    tr = Bh[19] + Bh[20],
    ir = Bh[21],
    nr = Bh[19],
    er = Bh[22],
    sr = Bh[23] + Bh[24] + Bh[25],
    hr = Bh[26] + Bh[27] + Bh[28],
    rr = Bh[29],
    ar = Bh[30],
    or = Bh[31] + Bh[13] + Bh[32],
    fr = Bh[33],
    cr = Bh[34] + Bh[35] + Bh[36],
    ur = Bh[34] + Bh[37] + Bh[38],
    _r = Bh[3] + Bh[39] + Bh[40],
    dr = Bh[34],
    lr = Bh[41],
    vr = Bh[42],
    br = Bh[43],
    gr = Bh[44],
    yr = Bh[45],
    xr = Bh[46] + Bh[39] + Bh[47],
    mr = Bh[48],
    Er = Bh[49] + Bh[50] + Bh[51],
    pr = Bh[52] + Bh[53] + Bh[54],
    wr = Bh[55] + Bh[27] + Bh[56],
    Tr = Bh[57] + Bh[58] + Bh[59],
    Or = Bh[60],
    Ir = Bh[61],
    Mr = Bh[62] + Bh[63],
    Ar = Bh[64],
    jr = Bh[65] + Bh[66] + Bh[67],
    Sr = Bh[68],
    Cr = Bh[69],
    kr = Bh[70],
    Lr = Bh[71],
    Pr = Bh[20],
    Rr = Bh[26] + Bh[27] + Bh[72],
    Dr = Bh[73],
    Nr = Bh[74],
    Br = Bh[75],
    $r = Bh[76],
    Gr = Bh[77],
    Fr = Bh[78],
    zr = Bh[79] + Bh[80] + Bh[81],
    Yr = Bh[82] + Bh[27] + Bh[83],
    Hr = Bh[84] + Bh[27] + Bh[83],
    Ur = Bh[85] + Bh[1] + Bh[86] + Bh[39] + Bh[87],
    Wr = Bh[85] + Bh[1] + Bh[86] + Bh[88] + Bh[89],
    qr = Bh[90] + Bh[91],
    Xr = Bh[92],
    Vr = Bh[91],
    Kr = Bh[91] + Bh[90] + Bh[91],
    Zr = Bh[93],
    Jr = Bh[94],
    Qr = Bh[95],
    ta = Bh[96],
    ia = Bh[97] + Bh[88] + Bh[98],
    na = Bh[99],
    ea = Bh[100],
    sa = Bh[101] + Bh[88] + Bh[98],
    ha = Bh[3] + Bh[58] + Bh[102] + Bh[1] + Bh[103] + Bh[88] + Bh[104],
    ra = Bh[105] + Bh[106],
    aa = Bh[105] + Bh[107],
    oa = Bh[108] + Bh[109] + Bh[110],
    fa = Bh[108] + Bh[106],
    ca = Bh[108] + Bh[107],
    ua = Bh[20] + Bh[111],
    _a = Bh[20] + Bh[112],
    da = Bh[20] + Bh[113] + Bh[27] + Bh[114],
    la = Bh[20] + Bh[115],
    va = Bh[116] + Bh[117] + Bh[118],
    ba = Bh[119],
    ga = Bh[120] + Bh[121],
    ya = Bh[122],
    xa = Bh[123] + Bh[121] + Bh[42] + Bh[124] + Bh[42] + Bh[125] + Bh[73],
    ma = Bh[123] + Bh[126] + Bh[42] + Bh[124] + Bh[42] + Bh[125] + Bh[73],
    Ea = Bh[127],
    pa = Bh[128],
    wa = Bh[129] + Bh[130] + Bh[131],
    Ta = Bh[132],
    Oa = Bh[133],
    Ia = Bh[134],
    Ma = Bh[135] + Bh[80] + Bh[136],
    Aa = Bh[137],
    ja = Bh[123] + Bh[138] + Bh[42] + Bh[125],
    Sa = Bh[139],
    Ca = Bh[140],
    ka = Bh[101] + Bh[27] + Bh[141],
    La = Bh[142],
    Pa = Bh[143],
    Ra = Bh[144] + Bh[58] + Bh[145] + Bh[80] + Bh[146] + Bh[27] + Bh[147] + Bh[88] + Bh[148],
    Da = Bh[149] + Bh[58] + Bh[145] + Bh[80] + Bh[146] + Bh[27] + Bh[147] + Bh[88] + Bh[148],
    Na = Bh[90] + Bh[58] + Bh[145] + Bh[80] + Bh[146] + Bh[27] + Bh[147] + Bh[88] + Bh[148],
    Ba = Bh[150] + Bh[58] + Bh[145] + Bh[80] + Bh[146] + Bh[27] + Bh[147] + Bh[88] + Bh[148],
    $a = Bh[151] + Bh[80] + Bh[146] + Bh[27] + Bh[147] + Bh[88] + Bh[148],
    Ga = Bh[21] + Bh[24] + Bh[152],
    Fa = Bh[153],
    za = Bh[154] + Bh[155],
    Ya = Bh[156] + Bh[80] + Bh[157],
    Ha = Bh[158],
    Ua = Bh[159],
    Wa = Bh[160] + Bh[20] + Bh[161],
    qa = Bh[162],
    Xa = Bh[3] + Bh[163] + Bh[164] + Bh[50] + Bh[165],
    Va = Bh[166] + Bh[154],
    Ka = Bh[167],
    Za = Bh[20] + Bh[168] + Bh[88],
    Ja = Bh[20] + Bh[169] + Bh[27] + Bh[141],
    Qa = Bh[20] + Bh[170] + Bh[1] + Bh[171],
    to = Bh[172],
    io = Bh[3] + Bh[58] + Bh[173],
    no = Bh[174],
    eo = Bh[175],
    so = Bh[46] + Bh[27] + Bh[141] + Bh[163] + Bh[176] + Bh[80] + Bh[177],
    ho = Bh[178],
    ro = Bh[179],
    ao = Bh[180],
    oo = Bh[181] + Bh[27] + Bh[141],
    fo = Bh[182],
    co = Bh[183],
    uo = Bh[184],
    _o = Bh[20] + Bh[185] + Bh[154] + Bh[186],
    lo = Bh[20] + Bh[185] + Bh[154] + Bh[187],
    vo = Bh[20] + Bh[188],
    bo = Bh[20] + Bh[185] + Bh[189] + Bh[186],
    go = Bh[20] + Bh[185] + Bh[189] + Bh[187],
    yo = Bh[20] + Bh[190] + Bh[189],
    xo = Bh[20] + Bh[190] + Bh[154],
    mo = Bh[22] + Bh[191] + Bh[27] + Bh[141],
    Eo = Bh[192],
    po = Bh[181] + Bh[163] + Bh[193] + Bh[13] + Bh[14],
    wo = Bh[194],
    To = Bh[195],
    Oo = Bh[196] + Bh[20] + Bh[197],
    Io = Bh[196] + Bh[20] + Bh[161],
    Mo = Bh[3] + Bh[1] + Bh[198],
    Ao = Bh[199] + Bh[200] + Bh[201],
    jo = Bh[202] + Bh[73] + Bh[203],
    So = Bh[204],
    Co = Bh[205],
    ko = Bh[20] + Bh[206],
    Lo = Bh[207],
    Po = Bh[125],
    Ro = Bh[194] + Bh[42] + Bh[208] + Bh[42] + Bh[125] + Bh[209],
    Do = Bh[63],
    No = Bh[210] + Bh[20] + Bh[211] + Bh[20] + Bh[212],
    Bo = Bh[210] + Bh[20] + Bh[211] + Bh[20] + Bh[213] + Bh[20] + Bh[214],
    $o = Bh[210] + Bh[20] + Bh[211] + Bh[20] + Bh[215] + Bh[20] + Bh[214],
    Go = Bh[210] + Bh[20] + Bh[211] + Bh[20] + Bh[216],
    Fo = Bh[217] + Bh[42] + Bh[125] + Bh[218],
    zo = Bh[219],
    Yo = Bh[210] + Bh[20] + Bh[211] + Bh[20] + Bh[220],
    Ho = Bh[221] + Bh[163] + Bh[164] + Bh[50] + Bh[165],
    Uo = Bh[156] + Bh[222] + Bh[223],
    Wo = Bh[224],
    qo = Bh[225] + Bh[88] + Bh[104],
    Xo = Bh[20] + Bh[226] + Bh[227],
    Vo = Bh[228] + Bh[27] + Bh[229],
    Ko = Bh[20] + Bh[230],
    Zo = Bh[22] + Bh[231] + Bh[58] + Bh[187] + Bh[39] + Bh[232] + Bh[27] + Bh[141],
    Jo = Bh[20] + Bh[233],
    Qo = Bh[22] + Bh[184],
    tf = Bh[22] + Bh[234] + Bh[106],
    nf = Bh[22] + Bh[234] + Bh[107],
    ef = Bh[22] + Bh[235],
    sf = Bh[236] + Bh[237] + Bh[88] + Bh[238],
    hf = Bh[22] + Bh[239] + Bh[80] + Bh[157],
    rf = Bh[22] + Bh[239] + Bh[39] + Bh[232] + Bh[27] + Bh[141],
    af = Bh[22] + Bh[204],
    of = Bh[240],
    ff = Bh[22] + Bh[241],
    cf = Bh[22] + Bh[242] + Bh[243] + Bh[244],
    uf = Bh[22] + Bh[245] + Bh[27] + Bh[83],
    _f = Bh[20] + Bh[246] + Bh[247] + Bh[248] + Bh[163] + Bh[249] + Bh[66] + Bh[250],
    df = Bh[20] + Bh[246] + Bh[247] + Bh[248],
    lf = Bh[251] + Bh[247] + Bh[248],
    vf = Bh[20] + Bh[252] + Bh[189] + Bh[80] + Bh[253],
    bf = Bh[254] + Bh[247] + Bh[248],
    gf = Bh[22] + Bh[241] + Bh[88] + Bh[255],
    yf = Bh[22] + Bh[242] + Bh[106],
    xf = Bh[22] + Bh[242] + Bh[107],
    mf = Bh[256] + Bh[27] + Bh[141],
    Ef = Bh[20] + Bh[242] + Bh[106],
    pf = Bh[20] + Bh[242] + Bh[107],
    wf = Bh[225],
    Tf = Bh[3] + Bh[88] + Bh[104],
    Of = Bh[257],
    If = Bh[231] + Bh[58] + Bh[187] + Bh[27] + Bh[229],
    Mf = Bh[22] + Bh[180],
    Af = Bh[20] + Bh[258] + Bh[259],
    jf = Bh[260] + Bh[243] + Bh[244],
    Sf = Bh[46] + Bh[24] + Bh[261],
    Cf = Bh[20] + Bh[237] + Bh[88] + Bh[238],
    kf = Bh[22] + Bh[239] + Bh[88] + Bh[238],
    Lf = Bh[260] + Bh[50] + Bh[262],
    Pf = Bh[156] + Bh[37] + Bh[263] + Bh[50] + Bh[262],
    Rf = Bh[3] + Bh[37] + Bh[263] + Bh[50] + Bh[262],
    Df = Bh[149] + Bh[50] + Bh[262],
    Nf = Bh[144] + Bh[37] + Bh[263] + Bh[50] + Bh[262],
    Bf = Bh[260] + Bh[50] + Bh[262] + Bh[13] + Bh[110],
    $f = Bh[149] + Bh[50] + Bh[262] + Bh[13] + Bh[110],
    Gf = Bh[144] + Bh[37] + Bh[263] + Bh[50] + Bh[262] + Bh[13] + Bh[110],
    Ff = Bh[264] + Bh[247] + Bh[265],
    zf = Bh[264] + Bh[163] + Bh[193],
    Yf = Bh[266] + Bh[66] + Bh[250],
    Hf = Bh[267] + Bh[27] + Bh[268],
    Uf = Bh[269],
    Wf = Bh[270] + Bh[24] + Bh[271],
    qf = Bh[205] + Bh[27] + Bh[268],
    Xf = Bh[272] + Bh[200] + Bh[273] + Bh[222] + Bh[274],
    Vf = Bh[275],
    Kf = Bh[276],
    Zf = Bh[277],
    Jf = Bh[278] + Bh[39] + Bh[279],
    Qf = Bh[79] + Bh[1] + Bh[280] + Bh[1] + Bh[201],
    tc = Bh[281] + Bh[282],
    ic = Bh[283],
    nc = Bh[284],
    ec = Bh[285],
    sc = Bh[286],
    hc = Bh[279],
    rc = Bh[287],
    ac = Bh[288] + Bh[73] + Bh[288] + Bh[73] + Bh[189],
    oc = Bh[154],
    fc = Bh[289],
    cc = Bh[20] + Bh[290] + Bh[1] + Bh[291],
    uc = Bh[292] + Bh[58] + Bh[187] + Bh[163] + Bh[155],
    _c = Bh[293],
    dc = Bh[294],
    lc = Bh[295] + Bh[1] + Bh[86],
    vc = Bh[296],
    bc = Bh[297],
    gc = Bh[65] + Bh[39] + Bh[298],
    yc = Bh[20] + Bh[299] + Bh[35] + Bh[300],
    xc = Bh[3] + Bh[24] + Bh[301] + Bh[58] + Bh[302],
    mc = Bh[303],
    Ec = Bh[79] + Bh[39] + Bh[298],
    pc = Bh[20] + Bh[304],
    wc = Bh[46] + Bh[163] + Bh[305],
    Tc = Bh[79],
    Oc = Bh[46] + Bh[50] + Bh[306] + Bh[13] + Bh[14],
    Ic = Bh[0] + Bh[66] + Bh[307],
    Mc = Bh[6] + Bh[1] + Bh[308],
    Ac = Bh[309],
    jc = Bh[156] + Bh[163] + Bh[193],
    Sc = Bh[46] + Bh[37] + Bh[310],
    Cc = Bh[270] + Bh[24] + Bh[271] + Bh[24] + Bh[301],
    kc = Bh[22] + Bh[79],
    Lc = Bh[270] + Bh[24] + Bh[271] + Bh[1] + Bh[86],
    Pc = Bh[311] + Bh[222] + Bh[150],
    Rc = Bh[260] + Bh[222] + Bh[150],
    Dc = Bh[312] + Bh[222] + Bh[150],
    Nc = Bh[313] + Bh[222] + Bh[150],
    Bc = Bh[314] + Bh[20] + Bh[315],
    $c = Bh[316],
    Gc = Bh[314] + Bh[20] + Bh[317],
    Fc = Bh[314] + Bh[20] + Bh[318],
    zc = Bh[314] + Bh[20] + Bh[319],
    Yc = Bh[314] + Bh[20] + Bh[320],
    Hc = Bh[314] + Bh[20] + Bh[321],
    Uc = Bh[314] + Bh[20] + Bh[322],
    Wc = Bh[314] + Bh[20] + Bh[323],
    qc = Bh[314] + Bh[20] + Bh[324],
    Xc = Bh[314] + Bh[20] + Bh[325] + Bh[20] + Bh[326],
    Vc = Bh[314] + Bh[20] + Bh[325] + Bh[20] + Bh[154],
    Kc = Bh[314] + Bh[20] + Bh[325] + Bh[20] + Bh[289],
    Zc = Bh[314] + Bh[20] + Bh[325] + Bh[20] + Bh[327],
    Jc = Bh[314] + Bh[20] + Bh[325] + Bh[20] + Bh[328],
    Qc = Bh[314] + Bh[20] + Bh[325] + Bh[20] + Bh[329],
    tu = Bh[330] + Bh[37] + Bh[331],
    iu = Bh[22] + Bh[208],
    nu = Bh[20] + Bh[332],
    eu = Bh[172] + Bh[66] + Bh[333],
    su = Bh[22] + Bh[239],
    hu = Bh[3] + Bh[27] + Bh[28],
    ru = Bh[334],
    au = Bh[335] + Bh[27] + Bh[28],
    ou = Bh[336],
    fu = Bh[337] + Bh[20] + Bh[338] + Bh[20] + Bh[339],
    cu = Bh[3] + Bh[80] + Bh[340],
    uu = Bh[341] + Bh[20] + Bh[342] + Bh[20] + Bh[343],
    _u = Bh[341] + Bh[20] + Bh[342] + Bh[20] + Bh[344],
    du = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[345] + Bh[20] + Bh[346],
    lu = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[347] + Bh[20] + Bh[346],
    vu = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[348] + Bh[20] + Bh[346],
    bu = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[346] + Bh[20] + Bh[345],
    gu = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[349] + Bh[20] + Bh[350],
    yu = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[349] + Bh[20] + Bh[351],
    xu = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[347],
    mu = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[347] + Bh[20] + Bh[345],
    Eu = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[349] + Bh[20] + Bh[352],
    pu = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[349] + Bh[20] + Bh[353],
    wu = Bh[354] + Bh[20] + Bh[355],
    Tu = Bh[356] + Bh[20] + Bh[355],
    Ou = Bh[341] + Bh[20] + Bh[357],
    Iu = Bh[341] + Bh[20] + Bh[357] + Bh[20] + Bh[358],
    Mu = Bh[341] + Bh[20] + Bh[357] + Bh[20] + Bh[359],
    Au = Bh[341] + Bh[20] + Bh[357] + Bh[20] + Bh[360],
    ju = Bh[341] + Bh[20] + Bh[357] + Bh[20] + Bh[361],
    Su = Bh[341] + Bh[20] + Bh[362] + Bh[20] + Bh[363],
    Cu = Bh[364],
    ku = Bh[256],
    Lu = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[348],
    Pu = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[348] + Bh[20] + Bh[345],
    Ru = Bh[325] + Bh[20] + Bh[365],
    Du = Bh[3] + Bh[80] + Bh[253],
    Nu = Bh[366] + Bh[222] + Bh[367],
    Bu = Bh[0] + Bh[27] + Bh[229] + Bh[80] + Bh[368],
    $u = Bh[65] + Bh[50] + Bh[369],
    Gu = Bh[194] + Bh[37] + Bh[310] + Bh[24] + Bh[301],
    Fu = Bh[194] + Bh[24] + Bh[301],
    zu = Bh[370],
    Yu = Bh[3] + Bh[371],
    Hu = Bh[372] + Bh[222] + Bh[274],
    Uu = Bh[373] + Bh[58] + Bh[173],
    Wu = Bh[341] + Bh[20] + Bh[374] + Bh[20] + Bh[375],
    qu = Bh[341] + Bh[20] + Bh[376] + Bh[20] + Bh[375],
    Xu = Bh[377],
    Vu = Bh[378],
    Ku = Bh[292],
    Zu = Bh[379] + Bh[222] + Bh[380],
    Ju = Bh[381] + Bh[20] + Bh[341] + Bh[20] + Bh[382] + Bh[20] + Bh[383],
    Qu = Bh[384] + Bh[107],
    t_ = Bh[385] + Bh[80] + Bh[386] + Bh[35] + Bh[387],
    i_ = Bh[388],
    n_ = Bh[389] + Bh[91] + Bh[247] + Bh[390] + Bh[91] + Bh[35] + Bh[391] + Bh[91] + Bh[58] + Bh[392],
    e_ = Bh[393],
    s_ = Bh[394],
    h_ = Bh[395],
    r_ = Bh[396],
    a_ = Bh[184] + Bh[63] + Bh[397] + Bh[398] + Bh[68],
    o_ = Bh[20] + Bh[399] + Bh[27] + Bh[400],
    f_ = Bh[389] + Bh[91] + Bh[247] + Bh[390] + Bh[91] + Bh[35] + Bh[391],
    c_ = Bh[62] + Bh[63] + Bh[288] + Bh[401] + Bh[288] + Bh[401] + Bh[288] + Bh[401] + Bh[288] + Bh[68],
    u_ = Bh[402],
    __ = Bh[403],
    d_ = Bh[404],
    l_ = Bh[20] + Bh[267],
    v_ = Bh[405] + Bh[406],
    b_ = Bh[267],
    g_ = Bh[407] + Bh[20] + Bh[196] + Bh[20] + Bh[352],
    y_ = Bh[20] + Bh[77],
    x_ = Bh[288] + Bh[143],
    m_ = Bh[20] + Bh[408],
    E_ = Bh[407] + Bh[20] + Bh[196] + Bh[20] + Bh[350],
    p_ = Bh[199],
    w_ = Bh[260] + Bh[1] + Bh[409],
    T_ = Bh[260] + Bh[410] + Bh[411],
    O_ = Bh[178] + Bh[80] + Bh[340],
    I_ = Bh[69] + Bh[412],
    M_ = Bh[413] + Bh[1] + Bh[414],
    A_ = Bh[69] + Bh[415],
    j_ = Bh[413] + Bh[58] + Bh[416],
    S_ = Bh[65] + Bh[50] + Bh[165] + Bh[417],
    C_ = Bh[418],
    k_ = Bh[419],
    L_ = Bh[20] + Bh[190] + Bh[288],
    P_ = Bh[105] + Bh[243] + Bh[244],
    R_ = Bh[105] + Bh[420] + Bh[421],
    D_ = Bh[422],
    N_ = Bh[423] + Bh[200] + Bh[424],
    B_ = Bh[370] + Bh[200] + Bh[424],
    $_ = Bh[46] + Bh[53] + Bh[425],
    G_ = Bh[46] + Bh[80] + Bh[426],
    F_ = Bh[208] + Bh[427] + Bh[428],
    z_ = Bh[267] + Bh[1] + Bh[291],
    Y_ = Bh[429],
    H_ = Bh[430] + Bh[1] + Bh[431],
    U_ = Bh[430],
    W_ = Bh[108] + Bh[432] + Bh[110],
    q_ = Bh[234] + Bh[420] + Bh[421],
    X_ = Bh[159] + Bh[80] + Bh[157],
    V_ = Bh[159] + Bh[66] + Bh[433],
    K_ = Bh[423] + Bh[80] + Bh[434],
    Z_ = Bh[423] + Bh[24] + Bh[435],
    J_ = Bh[436],
    Q_ = Bh[423],
    td = Bh[21] + Bh[88] + Bh[437],
    id = Bh[438],
    nd = Bh[439] + Bh[107],
    ed = Bh[440],
    sd = Bh[439] + Bh[222] + Bh[150],
    hd = Bh[112] + Bh[80] + Bh[157],
    rd = Bh[20] + Bh[184] + Bh[420] + Bh[441] + Bh[37] + Bh[442],
    ad = Bh[443] + Bh[91] + Bh[444],
    od = Bh[445] + Bh[24] + Bh[152],
    fd = Bh[88] + Bh[104],
    cd = Bh[234] + Bh[243] + Bh[244],
    ud = Bh[446],
    _d = Bh[447] + Bh[200] + Bh[201],
    dd = Bh[448] + Bh[20] + Bh[211] + Bh[20] + Bh[449],
    ld = Bh[295] + Bh[35] + Bh[201] + Bh[163] + Bh[450],
    vd = Bh[372],
    bd = Bh[295] + Bh[24] + Bh[301] + Bh[163] + Bh[450],
    gd = Bh[451] + Bh[24] + Bh[452] + Bh[66] + Bh[453],
    yd = Bh[169] + Bh[35] + Bh[201],
    xd = Bh[20] + Bh[454],
    md = Bh[270] + Bh[24] + Bh[271] + Bh[13] + Bh[455] + Bh[24] + Bh[301],
    Ed = Bh[456],
    pd = Bh[457] + Bh[39] + Bh[298],
    wd = Bh[458],
    Td = Bh[459] + Bh[39] + Bh[460] + Bh[66] + Bh[461],
    Od = Bh[144] + Bh[88] + Bh[462] + Bh[39] + Bh[460] + Bh[66] + Bh[461],
    Id = Bh[149] + Bh[88] + Bh[462] + Bh[39] + Bh[460] + Bh[66] + Bh[461],
    Md = Bh[150] + Bh[88] + Bh[462] + Bh[39] + Bh[460] + Bh[66] + Bh[461],
    Ad = Bh[90] + Bh[88] + Bh[462] + Bh[39] + Bh[460] + Bh[66] + Bh[461],
    jd = Bh[57] + Bh[39] + Bh[460] + Bh[66] + Bh[461],
    Sd = Bh[144] + Bh[1] + Bh[463] + Bh[39] + Bh[460] + Bh[66] + Bh[461],
    Cd = Bh[149] + Bh[1] + Bh[463] + Bh[39] + Bh[460] + Bh[66] + Bh[461],
    kd = Bh[150] + Bh[1] + Bh[463] + Bh[39] + Bh[460] + Bh[66] + Bh[461],
    Ld = Bh[90] + Bh[1] + Bh[463] + Bh[39] + Bh[460] + Bh[66] + Bh[461],
    Pd = Bh[225] + Bh[222] + Bh[464],
    Rd = Bh[69] + Bh[465],
    Dd = Bh[466],
    Nd = Bh[20] + Bh[159] + Bh[80] + Bh[157],
    Bd = Bh[20] + Bh[159] + Bh[66] + Bh[433],
    $d = Bh[20] + Bh[159] + Bh[1] + Bh[467],
    Gd = Bh[158] + Bh[20] + Bh[468],
    Fd = Bh[158] + Bh[20] + Bh[365],
    zd = Bh[143] + Bh[42],
    Yd = Bh[158] + Bh[20] + Bh[469],
    Hd = Bh[3] + Bh[58] + Bh[187] + Bh[163] + Bh[193],
    Ud = Bh[123] + Bh[470] + Bh[42] + Bh[471],
    Wd = Bh[20] + Bh[472],
    qd = Bh[3] + Bh[58] + Bh[187] + Bh[163] + Bh[155],
    Xd = Bh[473] + Bh[1] + Bh[86],
    Vd = Bh[473] + Bh[24] + Bh[152] + Bh[1] + Bh[86],
    Kd = Bh[474] + Bh[222] + Bh[274],
    Zd = Bh[475] + Bh[35] + Bh[36],
    Jd = Bh[65] + Bh[282] + Bh[476] + Bh[1] + Bh[477],
    Qd = Bh[478] + Bh[80] + Bh[479],
    tl = Bh[27] + Bh[141] + Bh[63],
    il = Bh[401],
    nl = Bh[480],
    el = Bh[20] + Bh[481],
    sl = Bh[20] + Bh[482],
    hl = Bh[80] + Bh[157] + Bh[63],
    rl = Bh[101] + Bh[88] + Bh[104],
    al = Bh[483] + Bh[20] + Bh[344],
    ol = Bh[484],
    fl = Bh[485] + Bh[35] + Bh[36],
    cl = Bh[486],
    ul = Bh[487],
    _l = Bh[488],
    dl = Bh[252],
    ll = Bh[489],
    vl = Bh[352] + Bh[20] + Bh[350],
    bl = Bh[352] + Bh[20] + Bh[353],
    gl = Bh[490] + Bh[20] + Bh[350],
    yl = Bh[490] + Bh[20] + Bh[491],
    xl = Bh[490] + Bh[20] + Bh[353],
    ml = Bh[351] + Bh[20] + Bh[350],
    El = Bh[351] + Bh[20] + Bh[491],
    pl = Bh[351] + Bh[20] + Bh[353],
    wl = Bh[352] + Bh[20] + Bh[491],
    Tl = Bh[492],
    Ol = Bh[256] + Bh[88] + Bh[104],
    Il = Bh[493],
    Ml = Bh[494],
    Al = Bh[207] + Bh[495],
    jl = Bh[401] + Bh[182] + Bh[495],
    Sl = Bh[401] + Bh[494] + Bh[495],
    Cl = Bh[496] + Bh[53] + Bh[54],
    kl = Bh[334] + Bh[222] + Bh[274],
    Ll = Bh[334] + Bh[73] + Bh[497],
    Pl = Bh[401] + Bh[334] + Bh[35] + Bh[36] + Bh[495],
    Rl = Bh[401] + Bh[496] + Bh[53] + Bh[54] + Bh[495],
    Dl = Bh[401] + Bh[30] + Bh[495],
    Nl = Bh[334] + Bh[35] + Bh[36],
    Bl = Bh[498] + Bh[163] + Bh[193],
    $l = Bh[496] + Bh[163] + Bh[193],
    Gl = Bh[499] + Bh[73] + Bh[101],
    Fl = Bh[499] + Bh[73] + Bh[303],
    zl = Bh[499] + Bh[73] + Bh[12],
    Yl = Bh[500],
    Hl = Bh[85] + Bh[24] + Bh[25],
    Ul = Bh[501],
    Wl = Bh[111],
    ql = Bh[502],
    Xl = Bh[303] + Bh[37] + Bh[503],
    Vl = Bh[504],
    Kl = Bh[12],
    Zl = Bh[401] + Bh[180] + Bh[495],
    Jl = Bh[401] + Bh[12] + Bh[495],
    Ql = Bh[401] + Bh[496] + Bh[163] + Bh[193] + Bh[495],
    tv = Bh[505] + Bh[20] + Bh[506],
    iv = Bh[101],
    nv = Bh[505] + Bh[20] + Bh[507],
    ev = Bh[505] + Bh[20] + Bh[508] + Bh[20] + Bh[509],
    sv = Bh[12] + Bh[73] + Bh[497],
    hv = Bh[20] + Bh[510] + Bh[511],
    rv = Bh[337] + Bh[20] + Bh[338] + Bh[20] + Bh[512],
    av = Bh[65] + Bh[1] + Bh[2],
    ov = Bh[3] + Bh[163] + Bh[155],
    fv = Bh[513],
    cv = Bh[20] + Bh[514],
    uv = Bh[20] + Bh[515],
    _v = Bh[516],
    dv = Bh[504] + Bh[1] + Bh[517] + Bh[50] + Bh[518],
    lv = Bh[20] + Bh[423] + Bh[200] + Bh[424],
    vv = Bh[423] + Bh[1] + Bh[517] + Bh[50] + Bh[518],
    bv = Bh[180] + Bh[1] + Bh[517] + Bh[50] + Bh[518],
    gv = Bh[101] + Bh[37] + Bh[503],
    yv = Bh[23] + Bh[50] + Bh[165] + Bh[27] + Bh[28] + Bh[1] + Bh[517],
    xv = Bh[297] + Bh[1] + Bh[517] + Bh[50] + Bh[518],
    mv = Bh[499] + Bh[163] + Bh[193] + Bh[1] + Bh[517] + Bh[50] + Bh[518],
    Ev = Bh[22] + Bh[309],
    pv = Bh[519],
    wv = Bh[129] + Bh[511] + Bh[520],
    Tv = Bh[20] + Bh[521] + Bh[163] + Bh[193] + Bh[66] + Bh[250],
    Ov = Bh[180] + Bh[522],
    Iv = Bh[20] + Bh[523] + Bh[1] + Bh[517] + Bh[37] + Bh[503],
    Mv = Bh[524],
    Av = Bh[525],
    jv = Bh[222] + Bh[223],
    Sv = Bh[65] + Bh[37] + Bh[526] + Bh[1] + Bh[477],
    Cv = Bh[21] + Bh[27] + Bh[527],
    kv = Bh[438] + Bh[427] + Bh[528],
    Lv = Bh[284] + Bh[91] + Bh[529],
    Pv = Bh[530],
    Rv = Bh[531],
    Dv = Bh[532],
    Nv = Bh[101] + Bh[24] + Bh[25] + Bh[37] + Bh[503],
    Bv = Bh[303] + Bh[24] + Bh[25] + Bh[37] + Bh[503],
    $v = Bh[533] + Bh[64] + Bh[534] + Bh[64] + Bh[535] + Bh[64] + Bh[536],
    Gv = Bh[537],
    Fv = Bh[538] + Bh[539] + Bh[80] + Bh[540],
    zv = Bh[541] + Bh[64] + Bh[542] + Bh[64] + Bh[543] + Bh[64] + Bh[544] + Bh[64] + Bh[545] + Bh[64] + Bh[546] + Bh[64] + Bh[547] + Bh[64] + Bh[548] + Bh[64],
    Yv = Bh[64] + Bh[533] + Bh[64] + Bh[534] + Bh[64] + Bh[535] + Bh[64] + Bh[536],
    Hv = Bh[222] + Bh[549] + Bh[24] + Bh[25],
    Uv = Bh[430] + Bh[27] + Bh[550],
    Wv = Bh[20] + Bh[551] + Bh[163] + Bh[552],
    qv = Bh[20] + Bh[85] + Bh[243] + Bh[553] + Bh[200] + Bh[539] + Bh[200] + Bh[554],
    Xv = Bh[20] + Bh[85] + Bh[243] + Bh[553] + Bh[200] + Bh[539] + Bh[282] + Bh[185],
    Vv = Bh[129] + Bh[555],
    Kv = Bh[546],
    Zv = Bh[543],
    Jv = Bh[130] + Bh[80] + Bh[556],
    Qv = Bh[129] + Bh[557],
    tb = Bh[20] + Bh[557],
    ib = Bh[20] + Bh[65] + Bh[558] + Bh[25],
    nb = Bh[20] + Bh[85] + Bh[24] + Bh[25],
    eb = Bh[85],
    sb = Bh[129] + Bh[559] + Bh[27] + Bh[560] + Bh[222] + Bh[561],
    hb = Bh[129] + Bh[85] + Bh[37] + Bh[562] + Bh[27] + Bh[560] + Bh[66] + Bh[453],
    rb = Bh[20] + Bh[486] + Bh[327] + Bh[24] + Bh[25],
    ab = Bh[129] + Bh[563] + Bh[1] + Bh[564],
    ob = Bh[565],
    fb = Bh[566] + Bh[154],
    cb = Bh[566],
    ub = Bh[129] + Bh[567] + Bh[1] + Bh[308] + Bh[1] + Bh[517],
    _b = Bh[129] + Bh[486] + Bh[327] + Bh[37] + Bh[562] + Bh[27] + Bh[560],
    db = Bh[129] + Bh[486] + Bh[327] + Bh[200] + Bh[568] + Bh[222] + Bh[549] + Bh[24] + Bh[25],
    lb = Bh[129] + Bh[569] + Bh[222] + Bh[549] + Bh[24] + Bh[25],
    vb = Bh[20] + Bh[199],
    bb = Bh[155] + Bh[80] + Bh[570],
    gb = Bh[571] + Bh[80] + Bh[570],
    yb = Bh[129] + Bh[572],
    xb = Bh[573],
    mb = Bh[20] + Bh[574],
    Eb = Bh[575],
    pb = Bh[576],
    wb = Bh[20] + Bh[577],
    Tb = Bh[129] + Bh[395],
    Ob = Bh[20] + Bh[578],
    Ib = Bh[542],
    Mb = Bh[20] + Bh[579],
    Ab = Bh[544],
    jb = Bh[20] + Bh[580] + Bh[1] + Bh[564] + Bh[24] + Bh[25],
    Sb = Bh[545],
    Cb = Bh[541],
    kb = Bh[581],
    Lb = Bh[582] + Bh[50] + Bh[583],
    Pb = Bh[584],
    Rb = Bh[585] + Bh[106],
    Db = Bh[585] + Bh[107],
    Nb = Bh[20] + Bh[486] + Bh[327] + Bh[50] + Bh[586] + Bh[50] + Bh[587],
    Bb = Bh[20] + Bh[486] + Bh[327] + Bh[113],
    $b = Bh[129] + Bh[588] + Bh[222] + Bh[561],
    Gb = Bh[589],
    Fb = Bh[129] + Bh[590],
    zb = Bh[579] + Bh[154],
    Yb = Bh[579],
    Hb = Bh[578] + Bh[154],
    Ub = Bh[578],
    Wb = Bh[20] + Bh[563] + Bh[37] + Bh[562] + Bh[27] + Bh[560] + Bh[222] + Bh[561],
    qb = Bh[591] + Bh[154],
    Xb = Bh[591],
    Vb = Bh[20] + Bh[592] + Bh[50] + Bh[586] + Bh[163] + Bh[450],
    Kb = Bh[574] + Bh[154],
    Zb = Bh[574],
    Jb = Bh[3] + Bh[1] + Bh[593] + Bh[80] + Bh[594],
    Qb = Bh[577] + Bh[154],
    tg = Bh[577],
    ig = Bh[20] + Bh[486] + Bh[289] + Bh[80] + Bh[595],
    ng = Bh[3] + Bh[24] + Bh[152] + Bh[58] + Bh[187] + Bh[200] + Bh[539] + Bh[24] + Bh[25],
    eg = Bh[3] + Bh[50] + Bh[165],
    sg = Bh[20] + Bh[176] + Bh[328] + Bh[50] + Bh[165],
    hg = Bh[20] + Bh[596] + Bh[289] + Bh[37] + Bh[597],
    rg = Bh[85] + Bh[1] + Bh[598],
    ag = Bh[20] + Bh[599] + Bh[600],
    og = Bh[20] + Bh[601] + Bh[163] + Bh[602],
    fg = Bh[20] + Bh[603] + Bh[163] + Bh[604] + Bh[37] + Bh[597],
    cg = Bh[129] + Bh[85] + Bh[24] + Bh[25],
    ug = Bh[129] + Bh[532] + Bh[24] + Bh[25],
    _g = Bh[605],
    dg = Bh[606],
    lg = Bh[20] + Bh[601] + Bh[163] + Bh[604],
    vg = Bh[20] + Bh[486] + Bh[327] + Bh[106],
    bg = Bh[607] + Bh[106],
    gg = Bh[607] + Bh[107],
    yg = Bh[608] + Bh[50] + Bh[583] + Bh[107],
    xg = Bh[609] + Bh[1] + Bh[308],
    mg = Bh[610],
    Eg = Bh[91] + Bh[144] + Bh[91] + Bh[611] + Bh[91] + Bh[612],
    pg = Bh[91] + Bh[144] + Bh[91] + Bh[611] + Bh[91] + Bh[613],
    wg = Bh[91] + Bh[144] + Bh[91] + Bh[614],
    Tg = Bh[91] + Bh[144] + Bh[91] + Bh[615],
    Og = Bh[91] + Bh[149] + Bh[91] + Bh[611] + Bh[91] + Bh[612],
    Ig = Bh[91] + Bh[149] + Bh[91] + Bh[611] + Bh[91] + Bh[613],
    Mg = Bh[91] + Bh[149] + Bh[91] + Bh[614],
    Ag = Bh[91] + Bh[149] + Bh[91] + Bh[615],
    jg = Bh[616],
    Sg = Bh[311],
    Cg = Bh[617] + Bh[63] + Bh[180] + Bh[93] + Bh[208] + Bh[427] + Bh[618] + Bh[94] + Bh[619] + Bh[620] + Bh[64] + Bh[621] + Bh[622] + Bh[623] + Bh[288] + Bh[624] + Bh[625] + Bh[626] + Bh[520] + Bh[627] + Bh[628] + Bh[629] + Bh[14] + Bh[328] + Bh[427] + Bh[259] + Bh[520] + Bh[630] + Bh[489] + Bh[154] + Bh[631] + Bh[288] + Bh[155] + Bh[154] + Bh[66] + Bh[187] + Bh[632] + Bh[259] + Bh[621] + Bh[633] + Bh[489] + Bh[634] + Bh[176] + Bh[635] + Bh[486] + Bh[636] + Bh[327] + Bh[637] + Bh[638] + Bh[639] + Bh[35] + Bh[640] + Bh[427] + Bh[27] + Bh[641] + Bh[27] + Bh[623] + Bh[200] + Bh[642] + Bh[643] + Bh[14] + Bh[644] + Bh[187] + Bh[645] + Bh[176] + Bh[427] + Bh[596] + Bh[646] + Bh[647] + Bh[648] + Bh[639] + Bh[39] + Bh[649] + Bh[247] + Bh[628] + Bh[106] + Bh[650] + Bh[651] + Bh[652] + Bh[653] + Bh[252] + Bh[654] + Bh[623] + Bh[189] + Bh[1] + Bh[655] + Bh[656] + Bh[486] + Bh[39] + Bh[189] + Bh[187] + Bh[39] + Bh[650] + Bh[657] + Bh[117] + Bh[520] + Bh[107] + Bh[623] + Bh[58] + Bh[658] + Bh[659] + Bh[660] + Bh[661] + Bh[662] + Bh[663] + Bh[628] + Bh[664] + Bh[628] + Bh[665] + Bh[328] + Bh[520] + Bh[427] + Bh[650] + Bh[666] + Bh[667] + Bh[668] + Bh[669] + Bh[327] + Bh[670] + Bh[671] + Bh[328] + Bh[42] + Bh[328] + Bh[64] + Bh[616],
    kg = Bh[672] + Bh[13] + Bh[455],
    Lg = Bh[672] + Bh[163] + Bh[176],
    Pg = Bh[20] + Bh[673],
    Rg = Bh[20] + Bh[459] + Bh[674],
    Dg = Bh[20] + Bh[85] + Bh[80] + Bh[675],
    Ng = Bh[20] + Bh[676],
    Bg = Bh[20] + Bh[677],
    $g = Bh[288] + Bh[73] + Bh[288],
    Gg = Bh[46] + Bh[222] + Bh[549] + Bh[80] + Bh[678],
    Fg = Bh[292] + Bh[88] + Bh[104],
    zg = Bh[80] + Bh[157],
    Yg = Bh[163] + Bh[679],
    Hg = Bh[24] + Bh[25],
    Ug = Bh[27] + Bh[28] + Bh[1] + Bh[517] + Bh[24] + Bh[25],
    Wg = Bh[37] + Bh[38] + Bh[24] + Bh[25],
    qg = Bh[420] + Bh[680],
    Xg = Bh[50] + Bh[518],
    Vg = Bh[27] + Bh[83],
    Kg = Bh[50] + Bh[165],
    Zg = Bh[80] + Bh[681] + Bh[200] + Bh[424],
    Jg = Bh[50] + Bh[165] + Bh[200] + Bh[424],
    Qg = Bh[682] + Bh[503],
    ty = Bh[138] + Bh[417],
    iy = Bh[138] + Bh[126],
    ny = Bh[46] + Bh[200] + Bh[683] + Bh[117] + Bh[118],
    ey = Bh[684] + Bh[50] + Bh[587],
    sy = Bh[420] + Bh[262] + Bh[37] + Bh[38],
    hy = Bh[50] + Bh[586] + Bh[80] + Bh[678],
    ry = Bh[685],
    ay = Bh[686],
    oy = Bh[687],
    fy = Bh[688],
    cy = Bh[689],
    uy = Bh[241] + Bh[73] + Bh[296],
    _y = Bh[241],
    dy = Bh[413],
    ly = Bh[690],
    vy = Bh[690] + Bh[73] + Bh[420],
    by = Bh[690] + Bh[73] + Bh[53],
    gy = Bh[691],
    yy = Bh[691] + Bh[73] + Bh[420],
    xy = Bh[691] + Bh[73] + Bh[53],
    my = Bh[691] + Bh[73] + Bh[420] + Bh[73] + Bh[53],
    Ey = Bh[691] + Bh[73] + Bh[53] + Bh[73] + Bh[420],
    py = Bh[692] + Bh[73] + Bh[267],
    wy = Bh[692] + Bh[73] + Bh[205],
    Ty = Bh[692] + Bh[73] + Bh[78],
    Oy = Bh[692] + Bh[73] + Bh[77],
    Iy = Bh[693],
    My = Bh[694],
    Ay = Bh[695],
    jy = Bh[696],
    Sy = Bh[697],
    Cy = Bh[698],
    ky = Bh[699],
    Ly = Bh[700],
    Py = Bh[701],
    Ry = Bh[702],
    Dy = Bh[703],
    Ny = Bh[704],
    By = Bh[705],
    $y = Bh[706],
    Gy = Bh[707],
    Fy = Bh[708],
    zy = Bh[709] + Bh[73] + Bh[710],
    Yy = Bh[709] + Bh[73] + Bh[189],
    Hy = Bh[709] + Bh[73] + Bh[154],
    Uy = Bh[709] + Bh[73] + Bh[289],
    Wy = Bh[709] + Bh[73] + Bh[650],
    qy = Bh[709] + Bh[73] + Bh[327],
    Xy = Bh[709] + Bh[73] + Bh[511],
    Vy = Bh[709] + Bh[73] + Bh[711],
    Ky = Bh[709] + Bh[73] + Bh[328],
    Zy = Bh[709] + Bh[73] + Bh[132],
    Jy = Bh[160] + Bh[20] + Bh[712] + Bh[20] + Bh[338] + Bh[20] + Bh[713],
    Qy = Bh[714],
    tx = Bh[168],
    ix = Bh[160] + Bh[20] + Bh[715] + Bh[20] + Bh[338] + Bh[20] + Bh[360],
    nx = Bh[160] + Bh[20] + Bh[715] + Bh[20] + Bh[338] + Bh[20] + Bh[716],
    ex = Bh[717],
    sx = Bh[718] + Bh[20] + Bh[338],
    hx = Bh[718] + Bh[20] + Bh[338] + Bh[20] + Bh[719],
    rx = Bh[718] + Bh[20] + Bh[383],
    ax = Bh[718] + Bh[20] + Bh[719] + Bh[20] + Bh[720],
    ox = Bh[718] + Bh[20] + Bh[213],
    fx = Bh[721] + Bh[20] + Bh[359],
    cx = Bh[21] + Bh[1] + Bh[291],
    ux = Bh[722] + Bh[222] + Bh[150],
    _x = Bh[22] + Bh[191] + Bh[27] + Bh[141] + Bh[189],
    dx = Bh[22] + Bh[191] + Bh[27] + Bh[141] + Bh[154],
    lx = Bh[483] + Bh[20] + Bh[723] + Bh[20] + Bh[724],
    vx = Bh[156] + Bh[58] + Bh[187] + Bh[88] + Bh[104],
    bx = Bh[20] + Bh[725],
    gx = Bh[297] + Bh[35] + Bh[201],
    yx = Bh[163] + Bh[164] + Bh[42] + Bh[138] + Bh[42] + Bh[125] + Bh[209],
    xx = Bh[20] + Bh[269],
    mx = Bh[20] + Bh[510] + Bh[650],
    Ex = Bh[726],
    px = Bh[373],
    wx = Bh[727],
    Tx = Bh[728],
    Ox = Bh[303] + Bh[1] + Bh[86],
    Ix = Bh[194] + Bh[163] + Bh[164],
    Mx = Bh[729],
    Ax = Bh[196] + Bh[20] + Bh[483] + Bh[20] + Bh[365],
    jx = Bh[20] + Bh[139],
    Sx = Bh[20] + Bh[140],
    Cx = Bh[730],
    kx = Bh[179] + Bh[80] + Bh[340],
    Lx = Bh[69] + Bh[731],
    Px = Bh[732],
    Rx = Bh[733],
    Dx = Bh[466] + Bh[42],
    Nx = Bh[178] + Bh[222] + Bh[734],
    Bx = Bh[69] + Bh[735],
    $x = Bh[179] + Bh[222] + Bh[734],
    Gx = Bh[413] + Bh[13] + Bh[110] + Bh[106],
    Fx = Bh[413] + Bh[13] + Bh[110] + Bh[107],
    zx = Bh[37] + Bh[736] + Bh[737],
    Yx = Bh[24] + Bh[738] + Bh[737],
    Hx = Bh[739] + Bh[1] + Bh[414],
    Ux = Bh[740],
    Wx = Bh[739] + Bh[1] + Bh[414] + Bh[58] + Bh[741] + Bh[200] + Bh[201],
    qx = Bh[20] + Bh[430] + Bh[1] + Bh[742],
    Xx = Bh[743] + Bh[80] + Bh[570],
    Vx = Bh[208],
    Kx = Bh[138],
    Zx = Bh[316] + Bh[163] + Bh[164],
    Jx = Bh[0] + Bh[163] + Bh[164],
    Qx = Bh[3] + Bh[39] + Bh[744] + Bh[163] + Bh[745],
    tm = Bh[746],
    im = Bh[747],
    nm = Bh[748] + Bh[20] + Bh[338] + Bh[20] + Bh[749],
    em = Bh[21] + Bh[88] + Bh[750] + Bh[247] + Bh[248],
    sm = Bh[748] + Bh[20] + Bh[338] + Bh[20] + Bh[215],
    hm = Bh[215] + Bh[20] + Bh[748] + Bh[20] + Bh[346],
    rm = Bh[749] + Bh[20] + Bh[748],
    am = Bh[751] + Bh[20] + Bh[215] + Bh[20] + Bh[748] + Bh[20] + Bh[346],
    om = Bh[751] + Bh[20] + Bh[749] + Bh[20] + Bh[748],
    fm = Bh[655],
    cm = Bh[752],
    um = Bh[652],
    _m = Bh[753] + Bh[20] + Bh[754] + Bh[20] + Bh[376],
    dm = Bh[753] + Bh[20] + Bh[160] + Bh[20] + Bh[376],
    lm = Bh[753] + Bh[20] + Bh[755] + Bh[20] + Bh[376],
    vm = Bh[753] + Bh[20] + Bh[756] + Bh[20] + Bh[376],
    bm = Bh[753] + Bh[20] + Bh[757] + Bh[20] + Bh[376],
    gm = Bh[753] + Bh[20] + Bh[758],
    ym = Bh[27] + Bh[229] + Bh[80] + Bh[759],
    xm = Bh[65] + Bh[126],
    mm = Bh[423] + Bh[1] + Bh[414],
    Em = Bh[423] + Bh[80] + Bh[760] + Bh[58] + Bh[416],
    pm = Bh[423] + Bh[80] + Bh[760] + Bh[13] + Bh[110] + Bh[106],
    wm = Bh[423] + Bh[80] + Bh[760] + Bh[13] + Bh[110] + Bh[107],
    Tm = Bh[718] + Bh[20] + Bh[338] + Bh[20] + Bh[721],
    Om = Bh[423] + Bh[222] + Bh[274],
    Im = Bh[761] + Bh[80] + Bh[340],
    Mm = Bh[761],
    Am = Bh[179] + Bh[1] + Bh[414],
    jm = Bh[20] + Bh[179] + Bh[247] + Bh[248],
    Sm = Bh[179] + Bh[247] + Bh[248],
    Cm = Bh[762] + Bh[27] + Bh[229],
    km = Bh[20] + Bh[763] + Bh[27] + Bh[764] + Bh[243] + Bh[244],
    Lm = Bh[20] + Bh[763] + Bh[27] + Bh[764],
    Pm = Bh[765],
    Rm = Bh[210] + Bh[20] + Bh[211] + Bh[20] + Bh[766],
    Dm = Bh[767],
    Nm = Bh[217] + Bh[73] + Bh[768],
    Bm = Bh[769] + Bh[73] + Bh[768],
    $m = Bh[770],
    Gm = Bh[585],
    Fm = Bh[771],
    zm = Bh[210] + Bh[20] + Bh[211],
    Ym = Bh[62] + Bh[63] + Bh[288] + Bh[64] + Bh[288] + Bh[64] + Bh[288] + Bh[64] + Bh[288] + Bh[68],
    Hm = Bh[717] + Bh[37] + Bh[772],
    Um = Bh[773],
    Wm = Bh[21] + Bh[37] + Bh[774] + Bh[247] + Bh[248],
    qm = Bh[101] + Bh[1] + Bh[414] + Bh[80] + Bh[267],
    Xm = Bh[69] + Bh[189] + Bh[1] + Bh[511] + Bh[58] + Bh[259] + Bh[50],
    Vm = Bh[69] + Bh[775],
    Km = Bh[69] + Bh[776] + Bh[24] + Bh[328] + Bh[58],
    Zm = Bh[69] + Bh[777] + Bh[58] + Bh[778],
    Jm = Bh[69] + Bh[777] + Bh[39] + Bh[779],
    Qm = Bh[69] + Bh[780] + Bh[1] + Bh[781],
    tE = Bh[69] + Bh[782],
    iE = Bh[69] + Bh[189] + Bh[50] + Bh[511] + Bh[1] + Bh[259] + Bh[66],
    nE = Bh[69] + Bh[783] + Bh[58] + Bh[288],
    eE = Bh[69] + Bh[784] + Bh[785],
    sE = Bh[69] + Bh[189] + Bh[66] + Bh[511] + Bh[786] + Bh[154],
    hE = Bh[69] + Bh[777] + Bh[39] + Bh[787],
    rE = Bh[69] + Bh[788],
    aE = Bh[789] + Bh[1] + Bh[790] + Bh[222] + Bh[150],
    oE = Bh[69] + Bh[154] + Bh[639] + Bh[328] + Bh[791],
    fE = Bh[69] + Bh[792],
    cE = Bh[69] + Bh[793] + Bh[50] + Bh[781],
    uE = Bh[69] + Bh[794],
    _E = Bh[69] + Bh[189] + Bh[66] + Bh[795] + Bh[39] + Bh[650],
    dE = Bh[69] + Bh[796] + Bh[797] + Bh[154],
    lE = Bh[69] + Bh[798] + Bh[799],
    vE = Bh[69] + Bh[189] + Bh[24] + Bh[511] + Bh[800] + Bh[288],
    bE = Bh[69] + Bh[801],
    gE = Bh[69] + Bh[14] + Bh[711] + Bh[14] + Bh[328] + Bh[14] + Bh[328],
    yE = Bh[69] + Bh[511] + Bh[39] + Bh[802],
    xE = Bh[69] + Bh[650] + Bh[66] + Bh[650] + Bh[1] + Bh[650] + Bh[58],
    mE = Bh[69] + Bh[803],
    EE = Bh[69] + Bh[804],
    pE = Bh[69] + Bh[511] + Bh[66] + Bh[511] + Bh[24] + Bh[511] + Bh[66],
    wE = Bh[69] + Bh[650] + Bh[1] + Bh[805],
    TE = Bh[69] + Bh[806],
    OE = Bh[69] + Bh[711] + Bh[50] + Bh[711] + Bh[50] + Bh[711] + Bh[50],
    IE = Bh[69] + Bh[807],
    ME = Bh[69] + Bh[808],
    AE = Bh[69] + Bh[809],
    jE = Bh[69] + Bh[259] + Bh[24] + Bh[259] + Bh[50] + Bh[259] + Bh[50],
    SE = Bh[69] + Bh[39] + Bh[711] + Bh[39] + Bh[327] + Bh[39] + Bh[650],
    CE = Bh[69] + Bh[39] + Bh[259] + Bh[39] + Bh[511] + Bh[39] + Bh[327],
    kE = Bh[69] + Bh[39] + Bh[711] + Bh[39] + Bh[650] + Bh[39] + Bh[289],
    LE = Bh[69] + Bh[810],
    PE = Bh[69] + Bh[24] + Bh[259] + Bh[811],
    RE = Bh[69] + Bh[259] + Bh[812] + Bh[288] + Bh[752] + Bh[288],
    DE = Bh[813] + Bh[1] + Bh[790] + Bh[222] + Bh[150],
    NE = Bh[69] + Bh[487] + Bh[259] + Bh[814],
    BE = Bh[69] + Bh[289] + Bh[639] + Bh[289] + Bh[752] + Bh[815],
    $E = Bh[69] + Bh[58] + Bh[154] + Bh[816],
    GE = Bh[69] + Bh[154] + Bh[24] + Bh[328] + Bh[817],
    FE = Bh[818] + Bh[39] + Bh[819],
    zE = Bh[69] + Bh[820],
    YE = Bh[69] + Bh[489] + Bh[327] + Bh[489] + Bh[327] + Bh[489] + Bh[511],
    HE = Bh[389] + Bh[91],
    UE = Bh[20] + Bh[510] + Bh[288],
    WE = Bh[20] + Bh[821],
    qE = Bh[20] + Bh[822],
    XE = Bh[20] + Bh[823],
    VE = Bh[20] + Bh[824] + Bh[163] + Bh[164],
    KE = Bh[825],
    ZE = Bh[31] + Bh[58] + Bh[826],
    JE = Bh[31] + Bh[58] + Bh[827],
    QE = Bh[163] + Bh[305] + Bh[42] + Bh[828] + Bh[42] + Bh[829] + Bh[73],
    tp = Bh[31],
    ip = Bh[830],
    np = Bh[35] + Bh[831] + Bh[42] + Bh[752] + Bh[42] + Bh[830] + Bh[42] + Bh[832] + Bh[73],
    ep = Bh[31] + Bh[282] + Bh[833],
    sp = Bh[834] + Bh[66] + Bh[250],
    hp = Bh[835],
    rp = Bh[217] + Bh[88] + Bh[836],
    ap = Bh[837],
    op = Bh[834] + Bh[80] + Bh[157],
    fp = Bh[838] + Bh[1] + Bh[414],
    cp = Bh[839] + Bh[200] + Bh[840],
    up = Bh[457] + Bh[163] + Bh[841],
    _p = Bh[580] + Bh[222] + Bh[273],
    dp = Bh[842],
    lp = Bh[843] + Bh[420] + Bh[844],
    vp = Bh[845],
    bp = Bh[846],
    gp = Bh[847],
    yp = Bh[848],
    xp = Bh[849],
    mp = Bh[850] + Bh[1] + Bh[201],
    Ep = Bh[851],
    pp = Bh[734] + Bh[222] + Bh[274],
    wp = Bh[852],
    Tp = Bh[853],
    Op = Bh[854],
    Ip = Bh[855],
    Mp = Bh[856],
    Ap = Bh[857],
    jp = Bh[266] + Bh[80] + Bh[157],
    Sp = Bh[858] + Bh[200] + Bh[612] + Bh[1] + Bh[201] + Bh[80] + Bh[157],
    Cp = Bh[859],
    kp = Bh[734],
    Lp = Bh[860],
    Pp = Bh[282] + Bh[861] + Bh[42] + Bh[862] + Bh[495] + Bh[288] + Bh[186],
    Rp = Bh[547],
    Dp = Bh[835] + Bh[117] + Bh[118],
    Np = Bh[863] + Bh[1] + Bh[201],
    Bp = Bh[162] + Bh[53] + Bh[864] + Bh[209],
    $p = Bh[865],
    Gp = Bh[162] + Bh[27] + Bh[866] + Bh[42] + Bh[50] + Bh[867] + Bh[209],
    Fp = Bh[868] + Bh[50] + Bh[867],
    zp = Bh[869],
    Yp = Bh[870],
    Hp = Bh[14] + Bh[871] + Bh[489] + Bh[650] + Bh[639] + Bh[872] + Bh[873] + Bh[711] + Bh[752] + Bh[874] + Bh[639] + Bh[875] + Bh[487] + Bh[289] + Bh[876] + Bh[259] + Bh[877] + Bh[878] + Bh[879] + Bh[880] + Bh[881] + Bh[288] + Bh[489] + Bh[327] + Bh[14] + Bh[882] + Bh[752] + Bh[883] + Bh[884] + Bh[885] + Bh[489] + Bh[711] + Bh[886] + Bh[289] + Bh[752] + Bh[887] + Bh[888] + Bh[889] + Bh[487] + Bh[259] + Bh[489] + Bh[890] + Bh[752] + Bh[154] + Bh[891] + Bh[892] + Bh[893] + Bh[894] + Bh[895] + Bh[154] + Bh[896] + Bh[897] + Bh[64] + Bh[898] + Bh[189] + Bh[752] + Bh[899] + Bh[155] + Bh[900] + Bh[752] + Bh[901] + Bh[14] + Bh[902] + Bh[903] + Bh[904] + Bh[905] + Bh[906] + Bh[907] + Bh[650] + Bh[908] + Bh[909] + Bh[910] + Bh[911] + Bh[752] + Bh[711] + Bh[912] + Bh[289] + Bh[487] + Bh[288] + Bh[913] + Bh[914] + Bh[915] + Bh[916] + Bh[639] + Bh[889] + Bh[917] + Bh[918] + Bh[155] + Bh[919] + Bh[639] + Bh[920] + Bh[903] + Bh[154] + Bh[487] + Bh[921] + Bh[639] + Bh[259] + Bh[922] + Bh[923] + Bh[924] + Bh[925] + Bh[912] + Bh[259] + Bh[752] + Bh[926] + Bh[927] + Bh[779] + Bh[928] + Bh[288] + Bh[929] + Bh[930] + Bh[752] + Bh[931] + Bh[639] + Bh[650],
    Up = Bh[162] + Bh[37] + Bh[932] + Bh[42] + Bh[65] + Bh[495],
    Wp = Bh[406] + Bh[933] + Bh[934] + Bh[406] + Bh[289] + Bh[39] + Bh[406] + Bh[933] + Bh[935] + Bh[73] + Bh[284] + Bh[73] + Bh[853] + Bh[406] + Bh[154] + Bh[1] + Bh[936] + Bh[73] + Bh[284] + Bh[73] + Bh[853],
    qp = Bh[937],
    Xp = Bh[938],
    Vp = Bh[939],
    Kp = Bh[156] + Bh[222],
    Zp = Bh[940],
    Jp = Bh[711] + Bh[73],
    Qp = Bh[941],
    tw = Bh[268],
    iw = Bh[942],
    nw = Bh[1] + Bh[291],
    ew = Bh[88] + Bh[943],
    sw = Bh[1] + Bh[944],
    hw = Bh[945],
    rw = Bh[946],
    aw = Bh[947],
    ow = Bh[948],
    fw = Bh[949],
    cw = Bh[950],
    uw = Bh[951],
    _w = Bh[952],
    dw = Bh[464],
    lw = Bh[953],
    vw = Bh[954],
    bw = Bh[389] + Bh[955],
    gw = Bh[42] + Bh[270] + Bh[42] + Bh[956] + Bh[327],
    yw = Bh[957],
    xw = Bh[958],
    mw = Bh[959] + Bh[243] + Bh[553],
    Ew = Bh[960],
    pw = Bh[961] + Bh[73] + Bh[962] + Bh[73] + Bh[189],
    ww = Bh[80] + Bh[81],
    Tw = Bh[963],
    Ow = Bh[24] + Bh[152],
    Iw = Bh[36],
    Mw = Bh[964],
    Aw = Bh[965] + Bh[243] + Bh[553],
    jw = Bh[50] + Bh[867],
    Sw = Bh[966],
    Cw = Bh[734] + Bh[154] + Bh[50],
    kw = Bh[486] + Bh[222] + Bh[734],
    Lw = Bh[967],
    Pw = Bh[288] + Bh[42] + Bh[288],
    Rw = Bh[389] + Bh[91] + Bh[1] + Bh[291],
    Dw = Bh[389] + Bh[91] + Bh[1] + Bh[291] + Bh[27] + Bh[968],
    Nw = Bh[389] + Bh[91] + Bh[247] + Bh[390],
    Bw = Bh[20] + Bh[258] + Bh[328],
    $w = Bh[20] + Bh[969],
    Gw = Bh[20] + Bh[970] + Bh[37] + Bh[38],
    Fw = Bh[20] + Bh[971],
    zw = Bh[20] + Bh[511] + Bh[972],
    Yw = Bh[239],
    Hw = Bh[20] + Bh[521],
    Uw = Bh[973],
    Ww = Bh[974],
    qw = Bh[20] + Bh[975] + Bh[674],
    Xw = Bh[20] + Bh[976],
    Vw = Bh[20] + Bh[977],
    Kw = Bh[202] + Bh[88] + Bh[978],
    Zw = Bh[979],
    Jw = Bh[20] + Bh[980],
    Qw = Bh[20] + Bh[974],
    tT = Bh[129] + Bh[621] + Bh[327],
    iT = Bh[20] + Bh[981],
    nT = Bh[20] + Bh[190] + Bh[289],
    eT = Bh[485],
    sT = Bh[652] + Bh[163] + Bh[193],
    hT = Bh[982] + Bh[58] + Bh[983],
    rT = Bh[739],
    aT = Bh[20] + Bh[984],
    oT = Bh[20] + Bh[985],
    fT = Bh[20] + Bh[521] + Bh[1] + Bh[291] + Bh[80] + Bh[157] + Bh[66] + Bh[250],
    cT = Bh[986] + Bh[222] + Bh[223],
    uT = Bh[20] + Bh[551] + Bh[200] + Bh[987],
    _T = Bh[988] + Bh[200] + Bh[987],
    dT = Bh[156] + Bh[80] + Bh[340],
    lT = Bh[979] + Bh[63],
    vT = Bh[129] + Bh[989] + Bh[200] + Bh[987],
    bT = Bh[990],
    gT = Bh[20] + Bh[498],
    yT = Bh[991] + Bh[163] + Bh[193],
    xT = Bh[992] + Bh[163] + Bh[155],
    mT = Bh[129] + Bh[993],
    ET = Bh[20] + Bh[994],
    pT = Bh[580],
    wT = Bh[270] + Bh[24] + Bh[271] + Bh[88] + Bh[995],
    TT = Bh[20] + Bh[996] + Bh[1] + Bh[291],
    OT = Bh[3] + Bh[247] + Bh[997] + Bh[58] + Bh[173],
    IT = Bh[20] + Bh[974] + Bh[1] + Bh[998],
    MT = Bh[153] + Bh[58] + Bh[173],
    AT = Bh[20] + Bh[65] + Bh[163] + Bh[999] + Bh[88] + Bh[104],
    jT = Bh[407] + Bh[20] + Bh[1e3],
    ST = Bh[1001] + Bh[73] + Bh[565],
    CT = Bh[407] + Bh[20] + Bh[1002],
    kT = Bh[1001] + Bh[73] + Bh[1003],
    LT = Bh[20] + Bh[1004],
    PT = Bh[20] + Bh[267] + Bh[1] + Bh[291],
    RT = Bh[3] + Bh[24] + Bh[152] + Bh[58] + Bh[187] + Bh[163] + Bh[155],
    DT = Bh[20] + Bh[327] + Bh[628],
    NT = Bh[20] + Bh[621] + Bh[327] + Bh[66] + Bh[1005],
    BT = Bh[46] + Bh[58] + Bh[302] + Bh[24] + Bh[1006],
    $T = Bh[992] + Bh[58] + Bh[173],
    GT = Bh[3] + Bh[1007] + Bh[187] + Bh[200] + Bh[539] + Bh[24] + Bh[25],
    FT = Bh[20] + Bh[511] + Bh[655],
    zT = Bh[20] + Bh[289] + Bh[639],
    YT = Bh[20] + Bh[974] + Bh[1] + Bh[467],
    HT = Bh[740] + Bh[222] + Bh[150],
    UT = Bh[20] + Bh[1008],
    WT = Bh[20] + Bh[639] + Bh[288] + Bh[1] + Bh[467],
    qT = Bh[20] + Bh[328] + Bh[150] + Bh[1] + Bh[467],
    XT = Bh[20] + Bh[199] + Bh[1] + Bh[467],
    VT = Bh[1009] + Bh[73] + Bh[174],
    KT = Bh[129] + Bh[650] + Bh[187],
    ZT = Bh[65] + Bh[1] + Bh[291],
    JT = Bh[239] + Bh[88] + Bh[1010],
    QT = Bh[1011],
    tO = Bh[239] + Bh[53] + Bh[1012],
    iO = Bh[992] + Bh[1] + Bh[1013],
    nO = Bh[1014],
    eO = Bh[85] + Bh[27] + Bh[28] + Bh[1] + Bh[517],
    sO = Bh[20] + Bh[258] + Bh[154],
    hO = Bh[20] + Bh[1015],
    rO = Bh[20] + Bh[372] + Bh[58] + Bh[302] + Bh[163] + Bh[249] + Bh[66] + Bh[250],
    aO = Bh[172] + Bh[24] + Bh[301] + Bh[58] + Bh[302],
    oO = Bh[270] + Bh[24] + Bh[271] + Bh[58] + Bh[187] + Bh[50] + Bh[1016] + Bh[66] + Bh[1017],
    fO = Bh[129] + Bh[1018],
    cO = Bh[20] + Bh[521] + Bh[58] + Bh[173] + Bh[66] + Bh[250],
    uO = Bh[3] + Bh[163] + Bh[193] + Bh[58] + Bh[187] + Bh[163] + Bh[155],
    _O = Bh[371] + Bh[522],
    dO = Bh[123] + Bh[470] + Bh[42] + Bh[1019],
    lO = Bh[156] + Bh[163] + Bh[193] + Bh[39] + Bh[1020],
    vO = Bh[974] + Bh[58] + Bh[173],
    bO = Bh[1021],
    gO = Bh[20] + Bh[996] + Bh[200],
    yO = Bh[20] + Bh[818] + Bh[58] + Bh[173],
    xO = Bh[20] + Bh[1022],
    mO = Bh[0] + Bh[24] + Bh[301],
    EO = Bh[992],
    pO = Bh[20] + Bh[510] + Bh[189],
    wO = Bh[389] + Bh[73] + Bh[24] + Bh[152],
    TO = Bh[1023],
    OO = Bh[221] + Bh[80] + Bh[1024],
    IO = Bh[22] + Bh[29],
    MO = Bh[389] + Bh[73] + Bh[24] + Bh[301],
    AO = Bh[1025],
    jO = Bh[1026] + Bh[24] + Bh[1006],
    SO = Bh[1027] + Bh[73] + Bh[1028],
    CO = Bh[1029] + Bh[27] + Bh[229] + Bh[1] + Bh[517],
    kO = Bh[46] + Bh[35] + Bh[1030],
    LO = Bh[1031],
    PO = Bh[65],
    RO = Bh[389] + Bh[91] + Bh[474],
    DO = Bh[20] + Bh[1032],
    NO = Bh[22] + Bh[1033],
    BO = Bh[1033],
    $O = Bh[65] + Bh[66] + Bh[307],
    GO = Bh[20] + Bh[237],
    FO = Bh[389] + Bh[73] + Bh[35] + Bh[201],
    zO = Bh[237],
    YO = Bh[1034] + Bh[73] + Bh[101],
    HO = Bh[1034] + Bh[73] + Bh[303],
    UO = Bh[245] + Bh[27] + Bh[83],
    WO = Bh[1035] + Bh[20] + Bh[1036],
    qO = Bh[389] + Bh[73] + Bh[80] + Bh[253] + Bh[35] + Bh[201],
    XO = Bh[1027],
    VO = Bh[1037],
    KO = Bh[254],
    ZO = Bh[389] + Bh[73] + Bh[58] + Bh[1038],
    JO = Bh[447] + Bh[80] + Bh[386] + Bh[35] + Bh[387],
    QO = Bh[1039] + Bh[20] + Bh[338],
    tI = Bh[1039] + Bh[20] + Bh[1040],
    iI = Bh[1039] + Bh[20] + Bh[1041],
    nI = Bh[1039] + Bh[20] + Bh[1042] + Bh[20] + Bh[365],
    eI = Bh[22] + Bh[1043] + Bh[222] + Bh[274],
    sI = Bh[1043],
    hI = Bh[389] + Bh[73] + Bh[247] + Bh[1044],
    rI = Bh[451] + Bh[80] + Bh[157],
    aI = Bh[1043] + Bh[222] + Bh[274],
    oI = Bh[1043] + Bh[163] + Bh[164],
    fI = Bh[389] + Bh[73] + Bh[222] + Bh[734],
    cI = Bh[222] + Bh[734],
    uI = Bh[239] + Bh[50] + Bh[165],
    _I = Bh[69] + Bh[1045],
    dI = Bh[22] + Bh[245] + Bh[27] + Bh[141],
    lI = Bh[423] + Bh[58] + Bh[1046] + Bh[1] + Bh[414],
    vI = Bh[178] + Bh[88] + Bh[104],
    bI = Bh[1047] + Bh[80] + Bh[681],
    gI = Bh[1047] + Bh[80] + Bh[681] + Bh[80] + Bh[1024],
    yI = Bh[22] + Bh[1048],
    xI = Bh[234] + Bh[106],
    mI = Bh[234] + Bh[107],
    EI = Bh[718] + Bh[20] + Bh[338] + Bh[20] + Bh[721] + Bh[20] + Bh[317],
    pI = Bh[241] + Bh[1] + Bh[414],
    wI = Bh[241] + Bh[37] + Bh[263] + Bh[50] + Bh[262] + Bh[13] + Bh[110],
    TI = Bh[22] + Bh[239] + Bh[50] + Bh[165],
    OI = Bh[22] + Bh[251] + Bh[247] + Bh[248],
    II = Bh[22] + Bh[251] + Bh[1] + Bh[414],
    MI = Bh[1049],
    AI = Bh[172] + Bh[80] + Bh[157],
    jI = Bh[85] + Bh[58] + Bh[173] + Bh[1] + Bh[467],
    SI = Bh[22] + Bh[239] + Bh[37] + Bh[1050],
    CI = Bh[22] + Bh[239] + Bh[53] + Bh[1012],
    kI = Bh[22] + Bh[990],
    LI = Bh[22] + Bh[1051] + Bh[24] + Bh[261],
    PI = Bh[1052],
    RI = Bh[1053] + Bh[53] + Bh[1054],
    DI = Bh[1053] + Bh[420] + Bh[1055] + Bh[222] + Bh[380],
    NI = Bh[234],
    BI = Bh[85] + Bh[50] + Bh[165] + Bh[1] + Bh[467],
    $I = Bh[20] + Bh[1056],
    GI = Bh[53] + Bh[1012],
    FI = Bh[37] + Bh[1050],
    zI = Bh[39] + Bh[232] + Bh[27] + Bh[141],
    YI = Bh[1057] + Bh[20] + Bh[197],
    HI = Bh[58] + Bh[1046] + Bh[247] + Bh[248],
    UI = Bh[718] + Bh[20] + Bh[721],
    WI = Bh[88] + Bh[238],
    qI = Bh[337] + Bh[20] + Bh[338] + Bh[20] + Bh[468],
    XI = Bh[423] + Bh[73] + Bh[217],
    VI = Bh[423] + Bh[73] + Bh[241],
    KI = Bh[718] + Bh[20] + Bh[719] + Bh[20] + Bh[375] + Bh[20] + Bh[106],
    ZI = Bh[718] + Bh[20] + Bh[719] + Bh[20] + Bh[375] + Bh[20] + Bh[107],
    JI = Bh[423] + Bh[73] + Bh[182],
    QI = Bh[1058] + Bh[20] + Bh[213],
    tM = Bh[739] + Bh[73] + Bh[217],
    iM = Bh[1058] + Bh[20] + Bh[213] + Bh[20] + Bh[210] + Bh[20] + Bh[211],
    nM = Bh[1059],
    eM = Bh[1048],
    sM = Bh[413] + Bh[73] + Bh[1060],
    hM = Bh[719] + Bh[20] + Bh[213],
    rM = Bh[413] + Bh[73] + Bh[217],
    aM = Bh[413] + Bh[73] + Bh[234] + Bh[73] + Bh[186],
    oM = Bh[719] + Bh[20] + Bh[375] + Bh[20] + Bh[107],
    fM = Bh[413] + Bh[73] + Bh[234] + Bh[73] + Bh[187],
    cM = Bh[314] + Bh[20] + Bh[1061],
    uM = Bh[1062] + Bh[73] + Bh[178],
    _M = Bh[314] + Bh[20] + Bh[1061] + Bh[20] + Bh[468],
    dM = Bh[1062] + Bh[73] + Bh[178] + Bh[73] + Bh[96],
    lM = Bh[314] + Bh[20] + Bh[160] + Bh[20] + Bh[1063],
    vM = Bh[1062] + Bh[73] + Bh[260] + Bh[73] + Bh[1064],
    bM = Bh[314] + Bh[20] + Bh[160] + Bh[20] + Bh[1063] + Bh[20] + Bh[375],
    gM = Bh[314] + Bh[20] + Bh[1065] + Bh[20] + Bh[213],
    yM = Bh[1062] + Bh[73] + Bh[179] + Bh[73] + Bh[217],
    xM = Bh[314] + Bh[20] + Bh[1065] + Bh[20] + Bh[748],
    mM = Bh[1062] + Bh[73] + Bh[179] + Bh[73] + Bh[1066],
    EM = Bh[314] + Bh[20] + Bh[1067],
    pM = Bh[1062] + Bh[73] + Bh[761],
    wM = Bh[314] + Bh[20] + Bh[1067] + Bh[20] + Bh[468],
    TM = Bh[1062] + Bh[73] + Bh[761] + Bh[73] + Bh[96],
    OM = Bh[160] + Bh[20] + Bh[712],
    IM = Bh[260] + Bh[73] + Bh[1068],
    MM = Bh[260] + Bh[73] + Bh[277],
    AM = Bh[1069] + Bh[20] + Bh[1070] + Bh[20] + Bh[1071],
    jM = Bh[231] + Bh[73] + Bh[1072] + Bh[73] + Bh[1027],
    SM = Bh[1073] + Bh[20] + Bh[213],
    CM = Bh[251] + Bh[73] + Bh[217],
    kM = Bh[1073] + Bh[20] + Bh[748],
    LM = Bh[251] + Bh[73] + Bh[1066],
    PM = Bh[721],
    RM = Bh[241] + Bh[73] + Bh[139],
    DM = Bh[721] + Bh[20] + Bh[213],
    NM = Bh[241] + Bh[73] + Bh[217],
    BM = Bh[721] + Bh[20] + Bh[160] + Bh[20] + Bh[1063],
    $M = Bh[241] + Bh[73] + Bh[260] + Bh[73] + Bh[1064],
    GM = Bh[721] + Bh[20] + Bh[160] + Bh[20] + Bh[1063] + Bh[20] + Bh[375],
    FM = Bh[241] + Bh[73] + Bh[492],
    zM = Bh[208] + Bh[73] + Bh[241] + Bh[73] + Bh[139],
    YM = Bh[196] + Bh[20] + Bh[721] + Bh[20] + Bh[468],
    HM = Bh[196] + Bh[20] + Bh[721] + Bh[20] + Bh[213],
    UM = Bh[208] + Bh[73] + Bh[241] + Bh[73] + Bh[96],
    WM = Bh[196] + Bh[20] + Bh[721] + Bh[20] + Bh[160] + Bh[20] + Bh[1063],
    qM = Bh[196] + Bh[20] + Bh[721] + Bh[20] + Bh[160] + Bh[20] + Bh[1063] + Bh[20] + Bh[375],
    XM = Bh[196] + Bh[20] + Bh[359],
    VM = Bh[208] + Bh[73] + Bh[492],
    KM = Bh[208] + Bh[73] + Bh[204],
    ZM = Bh[196] + Bh[20] + Bh[631] + Bh[20] + Bh[508],
    JM = Bh[208] + Bh[73] + Bh[652] + Bh[73] + Bh[12],
    QM = Bh[208] + Bh[73] + Bh[1074],
    tA = Bh[196] + Bh[20] + Bh[1059],
    iA = Bh[208] + Bh[73] + Bh[1048],
    nA = Bh[1075] + Bh[20] + Bh[1076],
    eA = Bh[851] + Bh[73] + Bh[184],
    sA = Bh[851] + Bh[73] + Bh[257],
    hA = Bh[1075] + Bh[20] + Bh[1077],
    rA = Bh[851] + Bh[73] + Bh[990],
    aA = Bh[1075] + Bh[20] + Bh[1078] + Bh[20] + Bh[1079],
    oA = Bh[1075] + Bh[20] + Bh[213],
    fA = Bh[851] + Bh[73] + Bh[217],
    cA = Bh[1075] + Bh[20] + Bh[158] + Bh[20] + Bh[365],
    uA = Bh[851] + Bh[73] + Bh[159] + Bh[73] + Bh[973],
    _A = Bh[1075] + Bh[20] + Bh[158] + Bh[20] + Bh[469],
    dA = Bh[851] + Bh[73] + Bh[159] + Bh[73] + Bh[1080],
    lA = Bh[1075] + Bh[20] + Bh[158] + Bh[20] + Bh[468],
    vA = Bh[851] + Bh[73] + Bh[159] + Bh[73] + Bh[96],
    bA = Bh[851] + Bh[73] + Bh[204],
    gA = Bh[851] + Bh[73] + Bh[242] + Bh[73] + Bh[139],
    yA = Bh[1075] + Bh[20] + Bh[1057],
    xA = Bh[851] + Bh[73] + Bh[242],
    mA = Bh[1075] + Bh[20] + Bh[359],
    EA = Bh[851] + Bh[73] + Bh[492],
    pA = Bh[1075] + Bh[20] + Bh[375] + Bh[20] + Bh[106],
    wA = Bh[851] + Bh[73] + Bh[234] + Bh[73] + Bh[186],
    TA = Bh[1075] + Bh[20] + Bh[375] + Bh[20] + Bh[107],
    OA = Bh[851] + Bh[73] + Bh[234] + Bh[73] + Bh[187],
    IA = Bh[1075] + Bh[20] + Bh[365],
    MA = Bh[851] + Bh[73] + Bh[973],
    AA = Bh[851] + Bh[73] + Bh[1081] + Bh[73] + Bh[257],
    jA = Bh[1075] + Bh[20] + Bh[721],
    SA = Bh[851] + Bh[73] + Bh[241],
    CA = Bh[851] + Bh[73] + Bh[241] + Bh[73] + Bh[96],
    kA = Bh[1075] + Bh[20] + Bh[1073] + Bh[20] + Bh[213],
    LA = Bh[1075] + Bh[20] + Bh[1073] + Bh[20] + Bh[748],
    PA = Bh[1075] + Bh[20] + Bh[1082],
    RA = Bh[851] + Bh[73] + Bh[235],
    DA = Bh[1075] + Bh[20] + Bh[719] + Bh[20] + Bh[720],
    NA = Bh[851] + Bh[73] + Bh[413] + Bh[73] + Bh[1060],
    BA = Bh[851] + Bh[73] + Bh[413] + Bh[73] + Bh[217],
    $A = Bh[1075] + Bh[20] + Bh[719] + Bh[20] + Bh[375] + Bh[20] + Bh[106],
    GA = Bh[1075] + Bh[20] + Bh[631] + Bh[20] + Bh[508],
    FA = Bh[851] + Bh[73] + Bh[652] + Bh[73] + Bh[12],
    zA = Bh[1075] + Bh[20] + Bh[1083] + Bh[20] + Bh[350],
    YA = Bh[851] + Bh[73] + Bh[85] + Bh[73] + Bh[267],
    HA = Bh[1039] + Bh[20] + Bh[1061],
    UA = Bh[1043] + Bh[73] + Bh[178],
    WA = Bh[1039] + Bh[20] + Bh[1061] + Bh[20] + Bh[468],
    qA = Bh[1043] + Bh[73] + Bh[178] + Bh[73] + Bh[217],
    XA = Bh[1039] + Bh[20] + Bh[1061] + Bh[20] + Bh[160] + Bh[20] + Bh[1063],
    VA = Bh[1039] + Bh[20] + Bh[1061] + Bh[20] + Bh[160] + Bh[20] + Bh[1063] + Bh[20] + Bh[375],
    KA = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[1076],
    ZA = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[1079],
    JA = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[158] + Bh[20] + Bh[365],
    QA = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[158] + Bh[20] + Bh[469],
    tj = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[1040],
    ij = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[1057] + Bh[20] + Bh[197],
    nj = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[1057],
    ej = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[359],
    sj = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[375] + Bh[20] + Bh[106],
    hj = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[375] + Bh[20] + Bh[107],
    rj = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[721],
    aj = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[721] + Bh[20] + Bh[468],
    oj = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[1073] + Bh[20] + Bh[213],
    fj = Bh[341] + Bh[20] + Bh[197],
    cj = Bh[372] + Bh[73] + Bh[139],
    uj = Bh[372] + Bh[73] + Bh[217],
    _j = Bh[341] + Bh[20] + Bh[1067],
    dj = Bh[372] + Bh[73] + Bh[761],
    lj = Bh[341] + Bh[20] + Bh[1067] + Bh[20] + Bh[468],
    vj = Bh[372] + Bh[73] + Bh[761] + Bh[73] + Bh[96],
    bj = Bh[341] + Bh[20] + Bh[160] + Bh[20] + Bh[1063],
    gj = Bh[372] + Bh[73] + Bh[260] + Bh[73] + Bh[1064],
    yj = Bh[372] + Bh[73] + Bh[79] + Bh[73] + Bh[234],
    xj = Bh[372] + Bh[73] + Bh[65] + Bh[73] + Bh[234],
    mj = Bh[372] + Bh[73] + Bh[1026] + Bh[73] + Bh[1085],
    Ej = Bh[341] + Bh[20] + Bh[1086] + Bh[20] + Bh[1087],
    pj = Bh[372] + Bh[73] + Bh[1088] + Bh[73] + Bh[1089],
    wj = Bh[372] + Bh[73] + Bh[692],
    Tj = Bh[372] + Bh[73] + Bh[1090] + Bh[73] + Bh[1091],
    Oj = Bh[341] + Bh[20] + Bh[342] + Bh[20] + Bh[1070] + Bh[20] + Bh[343],
    Ij = Bh[372] + Bh[73] + Bh[41] + Bh[73] + Bh[1092],
    Mj = Bh[372] + Bh[73] + Bh[41] + Bh[73] + Bh[30],
    Aj = Bh[372] + Bh[73] + Bh[1093],
    jj = Bh[372] + Bh[73] + Bh[1093] + Bh[73] + Bh[492],
    Sj = Bh[341] + Bh[20] + Bh[374] + Bh[20] + Bh[1094] + Bh[20] + Bh[341],
    Cj = Bh[372] + Bh[73] + Bh[79] + Bh[73] + Bh[1095] + Bh[73] + Bh[372],
    kj = Bh[341] + Bh[20] + Bh[376] + Bh[20] + Bh[1094] + Bh[20] + Bh[341],
    Lj = Bh[372] + Bh[73] + Bh[65] + Bh[73] + Bh[1095] + Bh[73] + Bh[372],
    Pj = Bh[325] + Bh[20] + Bh[374],
    Rj = Bh[709] + Bh[73] + Bh[79],
    Dj = Bh[325] + Bh[20] + Bh[374] + Bh[20] + Bh[365],
    Nj = Bh[709] + Bh[73] + Bh[79] + Bh[73] + Bh[973],
    Bj = Bh[325] + Bh[20] + Bh[374] + Bh[20] + Bh[375],
    $j = Bh[709] + Bh[73] + Bh[79] + Bh[73] + Bh[234],
    Gj = Bh[709] + Bh[73] + Bh[79] + Bh[73] + Bh[178],
    Fj = Bh[325] + Bh[20] + Bh[374] + Bh[20] + Bh[1061] + Bh[20] + Bh[468],
    zj = Bh[709] + Bh[73] + Bh[79] + Bh[73] + Bh[761],
    Yj = Bh[325] + Bh[20] + Bh[374] + Bh[20] + Bh[1067] + Bh[20] + Bh[468],
    Hj = Bh[325] + Bh[20] + Bh[374] + Bh[20] + Bh[160] + Bh[20] + Bh[1063],
    Uj = Bh[709] + Bh[73] + Bh[79] + Bh[73] + Bh[260] + Bh[73] + Bh[1064],
    Wj = Bh[325] + Bh[20] + Bh[374] + Bh[20] + Bh[1065] + Bh[20] + Bh[213],
    qj = Bh[709] + Bh[73] + Bh[79] + Bh[73] + Bh[260] + Bh[73] + Bh[1068],
    Xj = Bh[325] + Bh[20] + Bh[374] + Bh[20] + Bh[160] + Bh[20] + Bh[715],
    Vj = Bh[709] + Bh[73] + Bh[79] + Bh[73] + Bh[260] + Bh[73] + Bh[277],
    Kj = Bh[325] + Bh[20] + Bh[376],
    Zj = Bh[709] + Bh[73] + Bh[65],
    Jj = Bh[325] + Bh[20] + Bh[376] + Bh[20] + Bh[365],
    Qj = Bh[709] + Bh[73] + Bh[65] + Bh[73] + Bh[973],
    tS = Bh[325] + Bh[20] + Bh[376] + Bh[20] + Bh[375],
    iS = Bh[709] + Bh[73] + Bh[65] + Bh[73] + Bh[234],
    nS = Bh[325] + Bh[20] + Bh[376] + Bh[20] + Bh[1061],
    eS = Bh[709] + Bh[73] + Bh[65] + Bh[73] + Bh[178],
    sS = Bh[709] + Bh[73] + Bh[65] + Bh[73] + Bh[761],
    hS = Bh[325] + Bh[20] + Bh[376] + Bh[20] + Bh[1067] + Bh[20] + Bh[468],
    rS = Bh[709] + Bh[73] + Bh[65] + Bh[73] + Bh[260] + Bh[73] + Bh[1064],
    aS = Bh[325] + Bh[20] + Bh[376] + Bh[20] + Bh[160] + Bh[20] + Bh[1063] + Bh[20] + Bh[375],
    oS = Bh[325] + Bh[20] + Bh[376] + Bh[20] + Bh[1065] + Bh[20] + Bh[213],
    fS = Bh[709] + Bh[73] + Bh[65] + Bh[73] + Bh[179] + Bh[73] + Bh[217],
    cS = Bh[325] + Bh[20] + Bh[376] + Bh[20] + Bh[1065] + Bh[20] + Bh[748],
    uS = Bh[709] + Bh[73] + Bh[65] + Bh[73] + Bh[260] + Bh[73] + Bh[1068],
    _S = Bh[325] + Bh[20] + Bh[376] + Bh[20] + Bh[160] + Bh[20] + Bh[715],
    dS = Bh[709] + Bh[73] + Bh[65] + Bh[73] + Bh[260] + Bh[73] + Bh[277],
    lS = Bh[423] + Bh[58] + Bh[1096],
    vS = Bh[1075] + Bh[20] + Bh[1079],
    bS = Bh[217],
    gS = Bh[251] + Bh[1] + Bh[414],
    yS = Bh[1051] + Bh[13] + Bh[176] + Bh[222] + Bh[1097],
    xS = Bh[719] + Bh[20] + Bh[720],
    mS = Bh[719] + Bh[20] + Bh[375] + Bh[20] + Bh[106],
    ES = Bh[159] + Bh[80] + Bh[340],
    pS = Bh[1075] + Bh[20] + Bh[1098] + Bh[20] + Bh[1079],
    wS = Bh[1081] + Bh[27] + Bh[83],
    TS = Bh[1075] + Bh[20] + Bh[1040],
    OS = Bh[1075] + Bh[20] + Bh[1057] + Bh[20] + Bh[197],
    IS = Bh[242] + Bh[243] + Bh[244],
    MS = Bh[1051] + Bh[27] + Bh[1099],
    AS = Bh[241] + Bh[88] + Bh[255],
    jS = Bh[235],
    SS = Bh[1075] + Bh[20] + Bh[719] + Bh[20] + Bh[213],
    CS = Bh[1075] + Bh[20] + Bh[719] + Bh[20] + Bh[375] + Bh[20] + Bh[107],
    kS = Bh[20] + Bh[154] + Bh[621],
    LS = Bh[1040],
    PS = Bh[241] + Bh[37] + Bh[263] + Bh[50] + Bh[262],
    RS = Bh[20] + Bh[1100],
    DS = Bh[196] + Bh[20] + Bh[1101],
    NS = Bh[1074] + Bh[222] + Bh[274],
    BS = Bh[160] + Bh[20] + Bh[715],
    $S = Bh[196] + Bh[20] + Bh[1073] + Bh[20] + Bh[748],
    GS = Bh[196] + Bh[20] + Bh[721],
    FS = Bh[196] + Bh[20] + Bh[721] + Bh[20] + Bh[359],
    zS = Bh[1102] + Bh[58] + Bh[1103],
    YS = Bh[20] + Bh[327] + Bh[176],
    HS = Bh[1039] + Bh[20] + Bh[1073] + Bh[20] + Bh[213],
    US = Bh[1062],
    WS = Bh[20] + Bh[650] + Bh[187],
    qS = Bh[79] + Bh[39] + Bh[1104],
    XS = Bh[65] + Bh[39] + Bh[1104],
    VS = Bh[79] + Bh[39] + Bh[279] + Bh[24] + Bh[301],
    KS = Bh[65] + Bh[39] + Bh[279] + Bh[24] + Bh[301],
    ZS = Bh[341] + Bh[20] + Bh[160] + Bh[20] + Bh[1063] + Bh[20] + Bh[375],
    JS = Bh[79] + Bh[39] + Bh[1104] + Bh[80] + Bh[157],
    QS = Bh[79] + Bh[39] + Bh[1104] + Bh[13] + Bh[110],
    tC = Bh[325] + Bh[20] + Bh[374] + Bh[20] + Bh[1061],
    iC = Bh[79] + Bh[39] + Bh[1104] + Bh[80] + Bh[177],
    nC = Bh[79] + Bh[39] + Bh[1104] + Bh[80] + Bh[177] + Bh[80] + Bh[340],
    eC = Bh[325] + Bh[20] + Bh[374] + Bh[20] + Bh[1067],
    sC = Bh[79] + Bh[39] + Bh[1104] + Bh[13] + Bh[1105],
    hC = Bh[79] + Bh[39] + Bh[1104] + Bh[66] + Bh[1106] + Bh[1] + Bh[414],
    rC = Bh[325] + Bh[20] + Bh[374] + Bh[20] + Bh[1065] + Bh[20] + Bh[748],
    aC = Bh[79] + Bh[39] + Bh[1104] + Bh[37] + Bh[263] + Bh[50] + Bh[262],
    oC = Bh[79] + Bh[39] + Bh[1104] + Bh[37] + Bh[263] + Bh[410] + Bh[411],
    fC = Bh[325] + Bh[20] + Bh[374] + Bh[20] + Bh[160] + Bh[20] + Bh[712],
    cC = Bh[79] + Bh[39] + Bh[1104] + Bh[37] + Bh[263] + Bh[1] + Bh[409],
    uC = Bh[65] + Bh[39] + Bh[1104] + Bh[80] + Bh[157],
    _C = Bh[65] + Bh[39] + Bh[1104] + Bh[13] + Bh[110],
    dC = Bh[65] + Bh[39] + Bh[1104] + Bh[80] + Bh[177],
    lC = Bh[325] + Bh[20] + Bh[376] + Bh[20] + Bh[1061] + Bh[20] + Bh[468],
    vC = Bh[65] + Bh[39] + Bh[1104] + Bh[80] + Bh[177] + Bh[80] + Bh[340],
    bC = Bh[65] + Bh[39] + Bh[1104] + Bh[13] + Bh[1105],
    gC = Bh[65] + Bh[39] + Bh[1104] + Bh[13] + Bh[1105] + Bh[80] + Bh[340],
    yC = Bh[65] + Bh[39] + Bh[1104] + Bh[66] + Bh[1106] + Bh[1] + Bh[414],
    xC = Bh[65] + Bh[39] + Bh[1104] + Bh[66] + Bh[1106] + Bh[247] + Bh[248],
    mC = Bh[65] + Bh[39] + Bh[1104] + Bh[37] + Bh[263] + Bh[50] + Bh[262],
    EC = Bh[65] + Bh[39] + Bh[1104] + Bh[37] + Bh[263] + Bh[410] + Bh[411],
    pC = Bh[325] + Bh[20] + Bh[376] + Bh[20] + Bh[160] + Bh[20] + Bh[712],
    wC = Bh[65] + Bh[39] + Bh[1104] + Bh[37] + Bh[263] + Bh[1] + Bh[409],
    TC = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[213],
    OC = Bh[1026] + Bh[37] + Bh[1107],
    IC = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[1078] + Bh[20] + Bh[1079],
    MC = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1075] + Bh[20] + Bh[158] + Bh[20] + Bh[468],
    AC = Bh[239] + Bh[80] + Bh[253],
    jC = Bh[196] + Bh[20] + Bh[1073] + Bh[20] + Bh[213],
    SC = Bh[196] + Bh[20] + Bh[1040],
    CC = Bh[20] + Bh[1108],
    kC = Bh[239] + Bh[1] + Bh[2] + Bh[163] + Bh[193],
    LC = Bh[22] + Bh[239] + Bh[1] + Bh[86],
    PC = Bh[85] + Bh[58] + Bh[1109] + Bh[27] + Bh[28] + Bh[1] + Bh[517],
    RC = Bh[101] + Bh[1] + Bh[86],
    DC = Bh[422] + Bh[37] + Bh[1107],
    NC = Bh[422] + Bh[58] + Bh[1109] + Bh[27] + Bh[72],
    BC = Bh[335] + Bh[27] + Bh[72],
    $C = Bh[101] + Bh[58] + Bh[1109],
    GC = Bh[172] + Bh[1] + Bh[2],
    FC = Bh[22] + Bh[413] + Bh[13] + Bh[110] + Bh[106],
    zC = Bh[22] + Bh[423] + Bh[80] + Bh[760] + Bh[13] + Bh[110] + Bh[106],
    YC = Bh[22] + Bh[413] + Bh[13] + Bh[110] + Bh[107],
    HC = Bh[22] + Bh[423] + Bh[80] + Bh[760] + Bh[13] + Bh[110] + Bh[107],
    UC = Bh[22] + Bh[413] + Bh[58] + Bh[416],
    WC = Bh[22] + Bh[423] + Bh[80] + Bh[760] + Bh[58] + Bh[416],
    qC = Bh[371] + Bh[20] + Bh[1110] + Bh[20] + Bh[1111],
    XC = Bh[22] + Bh[239] + Bh[58] + Bh[173],
    VC = Bh[20] + Bh[1112],
    KC = Bh[373] + Bh[1] + Bh[467],
    ZC = Bh[22] + Bh[739] + Bh[1] + Bh[414],
    JC = Bh[22] + Bh[739] + Bh[1] + Bh[414] + Bh[58] + Bh[741] + Bh[200] + Bh[201],
    QC = Bh[22] + Bh[413] + Bh[1] + Bh[414],
    tk = Bh[379] + Bh[222] + Bh[380] + Bh[1] + Bh[2],
    ik = Bh[239] + Bh[80] + Bh[157],
    nk = Bh[22] + Bh[239] + Bh[80] + Bh[570],
    ek = Bh[20] + Bh[763] + Bh[58] + Bh[173],
    sk = Bh[156] + Bh[200] + Bh[1113] + Bh[58] + Bh[173],
    hk = Bh[22] + Bh[239] + Bh[66] + Bh[1106] + Bh[247] + Bh[248],
    rk = Bh[22] + Bh[179] + Bh[247] + Bh[248],
    ak = Bh[22] + Bh[1074] + Bh[222] + Bh[274],
    ok = Bh[22] + Bh[179] + Bh[1] + Bh[414],
    fk = Bh[80] + Bh[570],
    ck = Bh[66] + Bh[1106] + Bh[247] + Bh[248],
    uk = Bh[1098] + Bh[20] + Bh[1079],
    _k = Bh[22] + Bh[159] + Bh[80] + Bh[157],
    dk = Bh[22] + Bh[159],
    lk = Bh[22] + Bh[973],
    vk = Bh[438] + Bh[39] + Bh[1114],
    bk = Bh[438] + Bh[58] + Bh[1115],
    gk = Bh[66] + Bh[944],
    yk = Bh[22] + Bh[239] + Bh[66] + Bh[944],
    xk = Bh[22] + Bh[159] + Bh[80] + Bh[340],
    mk = Bh[22] + Bh[159] + Bh[66] + Bh[433],
    Ek = Bh[1027] + Bh[58] + Bh[173],
    pk = Bh[22] + Bh[239] + Bh[66] + Bh[1116] + Bh[39] + Bh[1104],
    wk = Bh[22] + Bh[260] + Bh[243] + Bh[244],
    Tk = Bh[22] + Bh[761],
    Ok = Bh[22] + Bh[239] + Bh[222] + Bh[150] + Bh[39] + Bh[1104],
    Ik = Bh[22] + Bh[79] + Bh[39] + Bh[1104],
    Mk = Bh[22] + Bh[79] + Bh[39] + Bh[1104] + Bh[13] + Bh[110],
    Ak = Bh[79] + Bh[39] + Bh[1104] + Bh[37] + Bh[1050],
    jk = Bh[3] + Bh[37] + Bh[1050],
    Sk = Bh[22] + Bh[79] + Bh[39] + Bh[1104] + Bh[80] + Bh[253],
    Ck = Bh[79] + Bh[39] + Bh[1104] + Bh[80] + Bh[1024],
    kk = Bh[79] + Bh[39] + Bh[1104] + Bh[66] + Bh[1106] + Bh[247] + Bh[248],
    Lk = Bh[22] + Bh[65] + Bh[39] + Bh[1104] + Bh[13] + Bh[110],
    Pk = Bh[65] + Bh[39] + Bh[1104] + Bh[37] + Bh[1050],
    Rk = Bh[22] + Bh[65] + Bh[39] + Bh[1104] + Bh[80] + Bh[253],
    Dk = Bh[22] + Bh[65] + Bh[39] + Bh[1104],
    Nk = Bh[22] + Bh[65] + Bh[39] + Bh[1104] + Bh[80] + Bh[157],
    Bk = Bh[65] + Bh[39] + Bh[1104] + Bh[80] + Bh[1024],
    $k = Bh[247] + Bh[248],
    Gk = Bh[39] + Bh[1104] + Bh[80] + Bh[177],
    Fk = Bh[39] + Bh[1104] + Bh[80] + Bh[177] + Bh[80] + Bh[340],
    zk = Bh[39] + Bh[1104] + Bh[80] + Bh[1024],
    Yk = Bh[39] + Bh[1104] + Bh[37] + Bh[263] + Bh[50] + Bh[262],
    Hk = Bh[39] + Bh[1104] + Bh[37] + Bh[263] + Bh[50] + Bh[262] + Bh[13] + Bh[110],
    Uk = Bh[39] + Bh[1104] + Bh[66] + Bh[1106] + Bh[1] + Bh[414],
    Wk = Bh[39] + Bh[1104] + Bh[66] + Bh[1106] + Bh[247] + Bh[248],
    qk = Bh[39] + Bh[1104] + Bh[37] + Bh[263] + Bh[1] + Bh[409],
    Xk = Bh[39] + Bh[1104] + Bh[37] + Bh[263] + Bh[410] + Bh[411],
    Vk = Bh[39] + Bh[1104] + Bh[13] + Bh[1105],
    Kk = Bh[39] + Bh[1104] + Bh[13] + Bh[1105] + Bh[80] + Bh[340],
    Zk = Bh[194] + Bh[39] + Bh[1104],
    Jk = Bh[66] + Bh[1116] + Bh[39] + Bh[1104],
    Qk = Bh[222] + Bh[150] + Bh[39] + Bh[1104],
    tL = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[1117],
    iL = Bh[3] + Bh[432] + Bh[110],
    nL = Bh[21] + Bh[58] + Bh[302] + Bh[37] + Bh[1107],
    eL = Bh[3] + Bh[58] + Bh[302] + Bh[37] + Bh[1107],
    sL = Bh[172] + Bh[27] + Bh[114],
    hL = Bh[1102] + Bh[58] + Bh[302] + Bh[37] + Bh[1107],
    rL = Bh[194] + Bh[88] + Bh[1118] + Bh[37] + Bh[263],
    aL = Bh[341] + Bh[20] + Bh[338] + Bh[20] + Bh[449],
    oL = Bh[341] + Bh[20] + Bh[349],
    fL = Bh[692] + Bh[73],
    cL = Bh[20] + Bh[1119],
    uL = Bh[1075] + Bh[20] + Bh[721] + Bh[20] + Bh[468],
    _L = Bh[341] + Bh[20] + Bh[213],
    dL = Bh[69] + Bh[1120],
    lL = Bh[69] + Bh[1121] + Bh[1122] + Bh[327],
    vL = Bh[69] + Bh[1123] + Bh[24] + Bh[288],
    bL = Bh[505] + Bh[20] + Bh[1124],
    gL = Bh[444],
    yL = Bh[1125],
    xL = Bh[1126],
    mL = Bh[55] + Bh[24] + Bh[25],
    EL = Bh[180] + Bh[222] + Bh[1127],
    pL = Bh[3] + Bh[50] + Bh[1128] + Bh[163] + Bh[450],
    wL = Bh[818] + Bh[222] + Bh[150] + Bh[37] + Bh[1129],
    TL = Bh[1130] + Bh[39] + Bh[1131],
    OL = Bh[35] + Bh[201],
    IL = Bh[80] + Bh[253] + Bh[35] + Bh[201],
    ML = Bh[21] + Bh[80] + Bh[253] + Bh[35] + Bh[201],
    AL = Bh[247] + Bh[1044],
    jL = Bh[20] + Bh[1132] + Bh[200] + Bh[424],
    SL = Bh[21] + Bh[35] + Bh[201],
    CL = Bh[20] + Bh[1133],
    kL = Bh[1134],
    LL = Bh[105] + Bh[27] + Bh[72],
    PL = Bh[529],
    RL = Bh[85] + Bh[24] + Bh[152] + Bh[1] + Bh[1135],
    DL = Bh[1136] + Bh[20] + Bh[1137],
    NL = Bh[1138],
    BL = Bh[1139],
    $L = Bh[1140],
    GL = Bh[101] + Bh[24] + Bh[152],
    FL = Bh[3] + Bh[50] + Bh[51] + Bh[80] + Bh[340],
    zL = Bh[1141] + Bh[58] + Bh[173],
    YL = Bh[20] + Bh[1142] + Bh[58] + Bh[173],
    HL = Bh[611] + Bh[39] + Bh[279],
    UL = Bh[611] + Bh[163] + Bh[176],
    WL = Bh[611] + Bh[13] + Bh[455],
    qL = Bh[451] + Bh[80] + Bh[570],
    XL = Bh[20] + Bh[1143],
    VL = Bh[46] + Bh[163] + Bh[249],
    KL = Bh[378] + Bh[222] + Bh[150],
    ZL = Bh[311] + Bh[222] + Bh[150] + Bh[1] + Bh[1144],
    JL = Bh[5] + Bh[37] + Bh[1145],
    QL = Bh[611] + Bh[222] + Bh[150] + Bh[13] + Bh[1146],
    tP = Bh[611] + Bh[39] + Bh[460],
    iP = Bh[1147] + Bh[20] + Bh[1148],
    nP = Bh[20] + Bh[1149] + Bh[39] + Bh[460],
    eP = Bh[1150],
    sP = Bh[1151],
    hP = Bh[1152] + Bh[80] + Bh[1153] + Bh[39] + Bh[744],
    rP = Bh[156] + Bh[37] + Bh[1050],
    aP = Bh[46] + Bh[200] + Bh[1154],
    oP = Bh[101] + Bh[1] + Bh[1155] + Bh[163] + Bh[604],
    fP = Bh[1156],
    cP = Bh[1157] + Bh[956],
    uP = Bh[50] + Bh[1158] + Bh[42] + Bh[24] + Bh[1159] + Bh[209],
    _P = Bh[303] + Bh[80] + Bh[681],
    dP = Bh[1136] + Bh[20] + Bh[1160],
    lP = Bh[85] + Bh[163] + Bh[604] + Bh[24] + Bh[25],
    vP = Bh[80] + Bh[253],
    bP = Bh[37] + Bh[263],
    gP = Bh[80] + Bh[1024],
    yP = Bh[21] + Bh[24] + Bh[301],
    xP = Bh[24] + Bh[301],
    mP = Bh[446] + Bh[27] + Bh[72],
    EP = Bh[1161] + Bh[24] + Bh[261] + Bh[37] + Bh[1107],
    pP = Bh[239] + Bh[24] + Bh[152],
    wP = Bh[37] + Bh[1107] + Bh[42] + Bh[1] + Bh[1162] + Bh[122] + Bh[279] + Bh[42] + Bh[24] + Bh[261],
    TP = Bh[1163] + Bh[24] + Bh[301],
    OP = Bh[1164],
    IP = Bh[153] + Bh[27] + Bh[968],
    MP = Bh[1165],
    AP = Bh[20] + Bh[551] + Bh[200] + Bh[201],
    jP = Bh[446] + Bh[200] + Bh[201],
    SP = Bh[334] + Bh[1] + Bh[517] + Bh[50] + Bh[518],
    CP = Bh[20] + Bh[974] + Bh[58] + Bh[173],
    kP = Bh[20] + Bh[1141] + Bh[58] + Bh[173],
    LP = Bh[1166] + Bh[88] + Bh[1167],
    PP = Bh[1168] + Bh[88] + Bh[1167],
    RP = Bh[20] + Bh[1169],
    DP = Bh[1039] + Bh[20] + Bh[338] + Bh[20] + Bh[696],
    NP = Bh[1039] + Bh[20] + Bh[1042] + Bh[20] + Bh[197],
    BP = Bh[1039] + Bh[20] + Bh[1042] + Bh[20] + Bh[161],
    $P = Bh[1039] + Bh[20] + Bh[338] + Bh[20] + Bh[315],
    GP = Bh[239] + Bh[66] + Bh[250],
    FP = Bh[1170] + Bh[279],
    zP = Bh[247] + Bh[1044] + Bh[371],
    YP = Bh[1171] + Bh[143],
    HP = Bh[1172] + Bh[42] + Bh[288] + Bh[73] + Bh[154] + Bh[600] + Bh[42] + Bh[1173] + Bh[91] + Bh[612],
    UP = Bh[862],
    WP = Bh[73] + Bh[389] + Bh[91] + Bh[247] + Bh[390] + Bh[91] + Bh[35] + Bh[391] + Bh[42] + Bh[393],
    qP = Bh[1172] + Bh[93] + Bh[189] + Bh[94] + Bh[251] + Bh[91] + Bh[217] + Bh[495] + Bh[62] + Bh[63] + Bh[288] + Bh[401] + Bh[288] + Bh[401] + Bh[288] + Bh[401] + Bh[288] + Bh[73] + Bh[327] + Bh[68],
    XP = Bh[73] + Bh[389] + Bh[91] + Bh[247] + Bh[390] + Bh[91] + Bh[35] + Bh[391],
    VP = Bh[1172] + Bh[93] + Bh[288] + Bh[94],
    KP = Bh[1174],
    ZP = Bh[93] + Bh[1172] + Bh[42] + Bh[289] + Bh[600] + Bh[42] + Bh[1175] + Bh[91] + Bh[789] + Bh[63] + Bh[288] + Bh[73] + Bh[328] + Bh[401] + Bh[288] + Bh[401] + Bh[288] + Bh[73] + Bh[328] + Bh[401] + Bh[189] + Bh[68],
    JP = Bh[73] + Bh[389] + Bh[91] + Bh[247] + Bh[390] + Bh[91] + Bh[35] + Bh[391] + Bh[93] + Bh[419],
    QP = Bh[1172] + Bh[93] + Bh[189] + Bh[94],
    tR = Bh[93] + Bh[1172] + Bh[42] + Bh[288] + Bh[73] + Bh[289] + Bh[600] + Bh[42] + Bh[769],
    iR = Bh[20] + Bh[205],
    nR = Bh[20] + Bh[393],
    eR = Bh[20] + Bh[510] + Bh[328],
    sR = Bh[20] + Bh[190] + Bh[328],
    hR = Bh[73] + Bh[389] + Bh[91] + Bh[247] + Bh[390] + Bh[91] + Bh[80] + Bh[540] + Bh[58] + Bh[1176],
    rR = Bh[1177] + Bh[495] + Bh[154] + Bh[143] + Bh[1178] + Bh[257] + Bh[495] + Bh[967] + Bh[94] + Bh[1179] + Bh[91] + Bh[1180] + Bh[495] + Bh[241] + Bh[91] + Bh[1179] + Bh[94] + Bh[1179] + Bh[91] + Bh[413] + Bh[1181] + Bh[412] + Bh[42] + Bh[288] + Bh[143] + Bh[42] + Bh[288] + Bh[143] + Bh[42] + Bh[189] + Bh[143] + Bh[1178] + Bh[251] + Bh[91] + Bh[217] + Bh[495] + Bh[62] + Bh[63] + Bh[1182] + Bh[64] + Bh[1182] + Bh[64] + Bh[1182] + Bh[64] + Bh[288] + Bh[73] + Bh[289] + Bh[1183] + Bh[241] + Bh[91] + Bh[492] + Bh[495] + Bh[650] + Bh[143] + Bh[94] + Bh[1177] + Bh[495] + Bh[189] + Bh[143] + Bh[94],
    aR = Bh[73] + Bh[389] + Bh[91] + Bh[247] + Bh[390] + Bh[91] + Bh[80] + Bh[540] + Bh[58] + Bh[1176] + Bh[73] + Bh[419] + Bh[1184] + Bh[389] + Bh[91] + Bh[247] + Bh[390] + Bh[91] + Bh[80] + Bh[540] + Bh[58] + Bh[1176] + Bh[93] + Bh[419],
    oR = Bh[1177] + Bh[91] + Bh[78] + Bh[495] + Bh[328] + Bh[143] + Bh[94],
    fR = Bh[1177] + Bh[91] + Bh[77] + Bh[495] + Bh[328] + Bh[143] + Bh[94],
    cR = Bh[73] + Bh[389] + Bh[91] + Bh[247] + Bh[390] + Bh[91] + Bh[80] + Bh[540] + Bh[27] + Bh[400],
    uR = Bh[93] + Bh[1172] + Bh[42] + Bh[289] + Bh[600] + Bh[42] + Bh[1175] + Bh[91] + Bh[789] + Bh[63] + Bh[288] + Bh[73] + Bh[328] + Bh[401] + Bh[288] + Bh[401] + Bh[288] + Bh[73] + Bh[328] + Bh[401] + Bh[189] + Bh[1183],
    _R = Bh[20] + Bh[84] + Bh[50] + Bh[586] + Bh[80] + Bh[678],
    dR = Bh[20] + Bh[82] + Bh[50] + Bh[586] + Bh[80] + Bh[678],
    lR = Bh[389] + Bh[91] + Bh[247] + Bh[390] + Bh[91] + Bh[80] + Bh[540] + Bh[27] + Bh[400],
    vR = Bh[20] + Bh[1185],
    bR = Bh[385] + Bh[163] + Bh[1186],
    gR = Bh[58] + Bh[1187],
    yR = Bh[1027] + Bh[80] + Bh[368],
    xR = Bh[1188] + Bh[20] + Bh[1189],
    mR = Bh[1188] + Bh[20] + Bh[338],
    ER = Bh[20] + Bh[1190],
    pR = Bh[20] + Bh[190] + Bh[106],
    wR = Bh[20] + Bh[190] + Bh[107],
    TR = Bh[129] + Bh[580] + Bh[88] + Bh[1010],
    OR = Bh[85] + Bh[39] + Bh[460] + Bh[80] + Bh[434],
    IR = Bh[85] + Bh[39] + Bh[460] + Bh[24] + Bh[435],
    MR = Bh[20] + Bh[1191] + Bh[106],
    AR = Bh[20] + Bh[1191] + Bh[107],
    jR = Bh[20] + Bh[79] + Bh[1192],
    SR = Bh[20] + Bh[65] + Bh[1192],
    CR = Bh[20] + Bh[79] + Bh[1193],
    kR = Bh[20] + Bh[79] + Bh[80] + Bh[570],
    LR = Bh[743] + Bh[222] + Bh[273],
    PR = Bh[1194] + Bh[222] + Bh[274],
    RR = Bh[20] + Bh[65] + Bh[1193],
    DR = Bh[20] + Bh[65] + Bh[80] + Bh[570],
    NR = Bh[448] + Bh[20] + Bh[1195] + Bh[20] + Bh[365] + Bh[20] + Bh[1196],
    BR = Bh[448] + Bh[20] + Bh[1195] + Bh[20] + Bh[365] + Bh[20] + Bh[1197],
    $R = Bh[448] + Bh[20] + Bh[1076] + Bh[20] + Bh[1195] + Bh[20] + Bh[365] + Bh[20] + Bh[1196],
    GR = Bh[448] + Bh[20] + Bh[1076] + Bh[20] + Bh[1195] + Bh[20] + Bh[365] + Bh[20] + Bh[1197],
    FR = Bh[1009],
    zR = Bh[20] + Bh[628] + Bh[328] + Bh[163] + Bh[155],
    YR = Bh[101] + Bh[50] + Bh[1198],
    HR = Bh[1053] + Bh[50] + Bh[1199],
    UR = Bh[1200],
    WR = Bh[194] + Bh[27] + Bh[141],
    qR = Bh[46] + Bh[1] + Bh[1201] + Bh[27] + Bh[229],
    XR = Bh[96] + Bh[50] + Bh[1199],
    VR = Bh[3] + Bh[50] + Bh[51] + Bh[50] + Bh[1199] + Bh[80] + Bh[1024],
    KR = Bh[447] + Bh[27] + Bh[141],
    ZR = Bh[50] + Bh[1199] + Bh[27] + Bh[229] + Bh[163] + Bh[604],
    JR = Bh[20] + Bh[486] + Bh[327] + Bh[222] + Bh[273],
    QR = Bh[21] + Bh[24] + Bh[301] + Bh[58] + Bh[187] + Bh[163] + Bh[604],
    tD = Bh[607],
    iD = Bh[1202] + Bh[37] + Bh[1203] + Bh[222] + Bh[150],
    nD = Bh[1204],
    eD = Bh[65] + Bh[37] + Bh[1205] + Bh[27] + Bh[141],
    sD = Bh[156] + Bh[1] + Bh[593] + Bh[27] + Bh[141],
    hD = Bh[65] + Bh[37] + Bh[1205],
    rD = Bh[1206],
    aD = Bh[1] + Bh[1207] + Bh[24] + Bh[301] + Bh[163] + Bh[604],
    oD = Bh[21] + Bh[80] + Bh[253] + Bh[58] + Bh[187] + Bh[163] + Bh[604],
    fD = Bh[1] + Bh[1207] + Bh[37] + Bh[263] + Bh[163] + Bh[604],
    cD = Bh[24] + Bh[301] + Bh[371],
    uD = Bh[1202] + Bh[37] + Bh[1203] + Bh[66] + Bh[1116],
    _D = Bh[1] + Bh[1207] + Bh[80] + Bh[1208] + Bh[24] + Bh[301] + Bh[163] + Bh[604],
    dD = Bh[1075] + Bh[20] + Bh[1209] + Bh[20] + Bh[1210] + Bh[20] + Bh[1211] + Bh[20] + Bh[1212] + Bh[20] + Bh[1213],
    lD = Bh[1214],
    vD = Bh[389] + Bh[91] + Bh[37] + Bh[1107] + Bh[24] + Bh[1215],
    bD = Bh[1216] + Bh[1217] + Bh[1218] + Bh[24] + Bh[42] + Bh[189] + Bh[143],
    gD = Bh[327] + Bh[143],
    yD = Bh[85] + Bh[53] + Bh[54] + Bh[1] + Bh[517],
    xD = Bh[1219],
    mD = Bh[1220],
    ED = Bh[1221] + Bh[117] + Bh[118],
    pD = Bh[55] + Bh[24] + Bh[1222],
    wD = Bh[85] + Bh[80] + Bh[157] + Bh[1] + Bh[517],
    TD = Bh[21] + Bh[956],
    OD = Bh[55] + Bh[24] + Bh[1222] + Bh[243] + Bh[1223] + Bh[1] + Bh[564] + Bh[13] + Bh[176] + Bh[243] + Bh[553],
    ID = Bh[85] + Bh[1] + Bh[564] + Bh[13] + Bh[176] + Bh[243] + Bh[553],
    MD = Bh[156] + Bh[222] + Bh[734],
    AD = Bh[851] + Bh[24] + Bh[1215],
    jD = Bh[1224],
    SD = Bh[46] + Bh[24] + Bh[1225],
    CD = Bh[607] + Bh[37] + Bh[1107] + Bh[24] + Bh[1222],
    kD = Bh[0] + Bh[24] + Bh[301] + Bh[58] + Bh[302],
    LD = Bh[986] + Bh[24] + Bh[1226],
    PD = Bh[1227] + Bh[80] + Bh[386] + Bh[35] + Bh[387],
    RD = Bh[385] + Bh[50] + Bh[1228] + Bh[1] + Bh[564] + Bh[222] + Bh[150] + Bh[13] + Bh[1146],
    DD = Bh[1229] + Bh[80] + Bh[570],
    ND = Bh[24] + Bh[1222] + Bh[163] + Bh[604],
    BD = Bh[1230] + Bh[163] + Bh[164],
    $D = Bh[445],
    GD = Bh[1231],
    FD = Bh[1230] + Bh[42] + Bh[208] + Bh[209],
    zD = Bh[42] + Bh[186] + Bh[42],
    YD = Bh[555] + Bh[24] + Bh[1159],
    HD = Bh[447] + Bh[50] + Bh[1232] + Bh[24] + Bh[152],
    UD = Bh[1136] + Bh[20] + Bh[754] + Bh[20] + Bh[1233],
    WD = Bh[23] + Bh[163] + Bh[604] + Bh[24] + Bh[25],
    qD = Bh[1136] + Bh[20] + Bh[1234],
    XD = Bh[299] + Bh[243] + Bh[1235],
    VD = Bh[1236],
    KD = Bh[1136] + Bh[20] + Bh[754] + Bh[20] + Bh[1237],
    ZD = Bh[311] + Bh[24] + Bh[1159],
    JD = Bh[1238] + Bh[20] + Bh[1233],
    QD = Bh[1238] + Bh[20] + Bh[1237],
    tN = Bh[20] + Bh[1239] + Bh[27] + Bh[28] + Bh[1] + Bh[517] + Bh[37] + Bh[1240],
    iN = Bh[180] + Bh[27] + Bh[28] + Bh[1] + Bh[517] + Bh[50] + Bh[518],
    nN = Bh[20] + Bh[1241],
    eN = Bh[20] + Bh[1242] + Bh[24] + Bh[1222],
    sN = Bh[303] + Bh[50] + Bh[1198],
    hN = Bh[194] + Bh[37] + Bh[263] + Bh[163] + Bh[155],
    rN = Bh[194] + Bh[37] + Bh[263],
    aN = Bh[46] + Bh[1] + Bh[1243] + Bh[27] + Bh[141],
    oN = Bh[69] + Bh[1244],
    fN = Bh[20] + Bh[1245],
    cN = Bh[303] + Bh[27] + Bh[229] + Bh[80] + Bh[759] + Bh[58] + Bh[187] + Bh[163] + Bh[193],
    uN = Bh[20] + Bh[1246] + Bh[27] + Bh[1247],
    _N = Bh[46] + Bh[88] + Bh[1248],
    dN = Bh[496] + Bh[27] + Bh[114],
    lN = Bh[571] + Bh[80] + Bh[759],
    vN = Bh[478] + Bh[80] + Bh[759],
    bN = Bh[496] + Bh[35] + Bh[734] + Bh[27] + Bh[114],
    gN = Bh[363] + Bh[20] + Bh[754] + Bh[20] + Bh[1233],
    yN = Bh[1091],
    xN = Bh[1249],
    mN = Bh[46] + Bh[66] + Bh[1116],
    EN = Bh[1091] + Bh[163] + Bh[193],
    pN = Bh[363] + Bh[20] + Bh[1234],
    wN = Bh[608] + Bh[50] + Bh[583] + Bh[106],
    TN = Bh[718] + Bh[20] + Bh[1250] + Bh[20] + Bh[1061],
    ON = Bh[718] + Bh[20] + Bh[1250] + Bh[20] + Bh[1061] + Bh[20] + Bh[213],
    IN = Bh[20] + Bh[943],
    MN = Bh[1251] + Bh[20] + Bh[1233],
    AN = Bh[20] + Bh[1008] + Bh[222] + Bh[561],
    jN = Bh[1251] + Bh[20] + Bh[1237],
    SN = Bh[270] + Bh[24] + Bh[271] + Bh[53] + Bh[425] + Bh[371],
    CN = Bh[385] + Bh[88] + Bh[1252] + Bh[80] + Bh[681] + Bh[58] + Bh[187] + Bh[88] + Bh[1253] + Bh[58] + Bh[392],
    kN = Bh[1254],
    LN = Bh[1255],
    PN = Bh[20] + Bh[184] + Bh[27] + Bh[141],
    RN = Bh[20] + Bh[1256],
    DN = Bh[1257] + Bh[91] + Bh[444],
    NN = Bh[1258] + Bh[91] + Bh[444],
    BN = Bh[1259] + Bh[91] + Bh[444],
    $N = Bh[62] + Bh[63] + Bh[288] + Bh[401] + Bh[1260] + Bh[401] + Bh[288] + Bh[401] + Bh[189] + Bh[68],
    GN = Bh[69] + Bh[1261] + Bh[288],
    FN = Bh[46] + Bh[88] + Bh[1262],
    zN = Bh[20] + Bh[1263],
    YN = Bh[20] + Bh[1264],
    HN = Bh[763] + Bh[58] + Bh[173],
    UN = Bh[1265],
    WN = Bh[1266],
    qN = Bh[1267] + Bh[20] + Bh[1237],
    XN = Bh[88] + Bh[1268] + Bh[163] + Bh[604],
    VN = Bh[986] + Bh[80] + Bh[1153],
    KN = Bh[46] + Bh[80] + Bh[1269],
    ZN = Bh[276] + Bh[222] + Bh[150] + Bh[222] + Bh[1097],
    JN = Bh[156] + Bh[80] + Bh[681],
    QN = Bh[1251],
    tB = Bh[440] + Bh[39] + Bh[744],
    iB = Bh[1270] + Bh[20] + Bh[1271],
    nB = Bh[1270] + Bh[20] + Bh[1272],
    eB = Bh[389] + Bh[91] + Bh[222] + Bh[1273],
    sB = Bh[69] + Bh[1274],
    hB = Bh[189] + Bh[143] + Bh[42] + Bh[1216] + Bh[1217] + Bh[50] + Bh[259] + Bh[50] + Bh[259] + Bh[50] + Bh[259],
    rB = Bh[154] + Bh[143] + Bh[42] + Bh[650] + Bh[143],
    aB = Bh[20] + Bh[422] + Bh[222] + Bh[561],
    oB = Bh[20] + Bh[1275],
    fB = Bh[20] + Bh[1276],
    cB = Bh[1023] + Bh[222] + Bh[274],
    uB = Bh[1277] + Bh[1278] + Bh[1279],
    _B = Bh[438] + Bh[1] + Bh[1280],
    dB = Bh[20] + Bh[1281] + Bh[222] + Bh[561],
    lB = Bh[1023] + Bh[50] + Bh[1282],
    vB = Bh[20] + Bh[1283],
    bB = Bh[3] + Bh[222] + Bh[1273],
    gB = Bh[385] + Bh[243] + Bh[1284] + Bh[631] + Bh[1285],
    yB = Bh[611] + Bh[58] + Bh[187] + Bh[200] + Bh[539] + Bh[24] + Bh[25],
    xB = Bh[1009] + Bh[73] + Bh[311] + Bh[73] + Bh[607],
    mB = Bh[1009] + Bh[73] + Bh[1286],
    EB = Bh[1009] + Bh[73] + Bh[311] + Bh[73] + Bh[943],
    pB = Bh[1009] + Bh[73] + Bh[1287],
    wB = Bh[1009] + Bh[73] + Bh[1288],
    TB = Bh[1091] + Bh[73] + Bh[311] + Bh[73] + Bh[607],
    OB = Bh[1091] + Bh[73] + Bh[1286],
    IB = Bh[1091] + Bh[73] + Bh[311] + Bh[73] + Bh[943],
    MB = Bh[444] + Bh[73] + Bh[607],
    AB = Bh[1289],
    jB = Bh[444] + Bh[73] + Bh[943],
    SB = Bh[1290],
    CB = Bh[1076] + Bh[20] + Bh[1237],
    kB = Bh[184] + Bh[73] + Bh[943],
    LB = Bh[1149] + Bh[73] + Bh[607],
    PB = Bh[1149] + Bh[73] + Bh[943],
    RB = Bh[1043] + Bh[73] + Bh[1014],
    DB = Bh[341] + Bh[20] + Bh[1084],
    NB = Bh[372] + Bh[73] + Bh[1026],
    BB = Bh[440] + Bh[73] + Bh[607],
    $B = Bh[1251] + Bh[20] + Bh[1291],
    GB = Bh[440] + Bh[73] + Bh[1292],
    FB = Bh[440] + Bh[73] + Bh[943],
    zB = Bh[559] + Bh[73] + Bh[544],
    YB = Bh[20] + Bh[446] + Bh[80] + Bh[678],
    HB = Bh[20] + Bh[85] + Bh[24] + Bh[152] + Bh[1] + Bh[598],
    UB = Bh[20] + Bh[1293] + Bh[163] + Bh[604],
    WB = Bh[20] + Bh[176] + Bh[511] + Bh[1] + Bh[1155] + Bh[163] + Bh[604] + Bh[37] + Bh[503],
    qB = Bh[20] + Bh[1294] + Bh[1] + Bh[1155] + Bh[163] + Bh[604] + Bh[37] + Bh[503],
    XB = Bh[447] + Bh[163] + Bh[604] + Bh[200] + Bh[201],
    VB = Bh[3] + Bh[163] + Bh[604] + Bh[163] + Bh[1295],
    KB = Bh[448] + Bh[20] + Bh[211] + Bh[20] + Bh[1296],
    ZB = Bh[1297],
    JB = Bh[448] + Bh[20] + Bh[211] + Bh[20] + Bh[718],
    QB = Bh[448] + Bh[20] + Bh[211] + Bh[20] + Bh[1298],
    t$ = Bh[1299],
    i$ = Bh[1300],
    n$ = Bh[21] + Bh[73] + Bh[1301] + Bh[73] + Bh[372],
    e$ = Bh[21] + Bh[73] + Bh[372],
    s$ = Bh[448] + Bh[20] + Bh[211] + Bh[20] + Bh[1302] + Bh[20] + Bh[314],
    h$ = Bh[21] + Bh[73] + Bh[1062],
    r$ = Bh[448] + Bh[20] + Bh[211] + Bh[20] + Bh[1302] + Bh[20] + Bh[160],
    a$ = Bh[21] + Bh[73] + Bh[260],
    o$ = Bh[316] + Bh[163] + Bh[602],
    f$ = Bh[448] + Bh[20] + Bh[211] + Bh[20] + Bh[1302] + Bh[20] + Bh[1303] + Bh[20] + Bh[341],
    c$ = Bh[448] + Bh[20] + Bh[211] + Bh[20] + Bh[1302] + Bh[20] + Bh[341],
    u$ = Bh[27] + Bh[1162] + Bh[163] + Bh[604],
    _$ = Bh[243] + Bh[1284] + Bh[631] + Bh[1285] + Bh[163] + Bh[604],
    d$ = Bh[88] + Bh[1252] + Bh[80] + Bh[681] + Bh[163] + Bh[604],
    l$ = Bh[27] + Bh[114] + Bh[163] + Bh[604],
    v$ = Bh[37] + Bh[1304],
    b$ = Bh[3] + Bh[1007] + Bh[173],
    g$ = Bh[1305],
    y$ = Bh[1306],
    x$ = Bh[1307],
    m$ = Bh[1308],
    E$ = Bh[474],
    p$ = Bh[1072] + Bh[39] + Bh[1309],
    w$ = Bh[3] + Bh[37] + Bh[331] + Bh[88] + Bh[1310],
    T$ = Bh[1311] + Bh[37] + Bh[1312],
    O$ = Bh[1313] + Bh[20] + Bh[351],
    I$ = Bh[1313] + Bh[20] + Bh[490],
    M$ = Bh[1313] + Bh[20] + Bh[353],
    A$ = Bh[1313] + Bh[20] + Bh[491],
    j$ = Bh[1313] + Bh[20] + Bh[351] + Bh[20] + Bh[350],
    S$ = Bh[1313] + Bh[20] + Bh[351] + Bh[20] + Bh[353],
    C$ = Bh[1313] + Bh[20] + Bh[350] + Bh[20] + Bh[351],
    k$ = Bh[1314],
    L$ = Bh[1315] + Bh[73] + Bh[1316],
    P$ = Bh[1314] + Bh[73] + Bh[520],
    R$ = Bh[1314] + Bh[73] + Bh[1317],
    D$ = Bh[1069] + Bh[20] + Bh[338] + Bh[20] + Bh[1318] + Bh[20] + Bh[345],
    N$ = Bh[1069] + Bh[20] + Bh[338] + Bh[20] + Bh[1318] + Bh[20] + Bh[346],
    B$ = Bh[1069] + Bh[20] + Bh[338] + Bh[20] + Bh[1319] + Bh[20] + Bh[1320],
    $$ = Bh[46] + Bh[420] + Bh[1321] + Bh[50] + Bh[1322],
    G$ = Bh[430] + Bh[80] + Bh[157],
    F$ = Bh[3] + Bh[35] + Bh[201] + Bh[80] + Bh[157],
    z$ = Bh[3] + Bh[1323] + Bh[409],
    Y$ = Bh[3] + Bh[37] + Bh[331] + Bh[222] + Bh[274],
    H$ = Bh[297] + Bh[1] + Bh[2] + Bh[50] + Bh[1322],
    U$ = Bh[520] + Bh[247] + Bh[409],
    W$ = Bh[1317] + Bh[247] + Bh[409],
    q$ = Bh[231] + Bh[222] + Bh[274],
    X$ = Bh[20] + Bh[1324],
    V$ = Bh[1325],
    K$ = Bh[1326],
    Z$ = Bh[1053] + Bh[37] + Bh[331],
    J$ = Bh[297] + Bh[58] + Bh[173],
    Q$ = Bh[20] + Bh[1327] + Bh[37] + Bh[1050],
    tG = Bh[20] + Bh[1328],
    iG = Bh[20] + Bh[1329],
    nG = Bh[237] + Bh[1330],
    eG = Bh[237] + Bh[1331],
    sG = Bh[20] + Bh[1332] + Bh[27] + Bh[1333] + Bh[1] + Bh[2] + Bh[50] + Bh[1322],
    hG = Bh[474] + Bh[106],
    rG = Bh[474] + Bh[107],
    aG = Bh[20] + Bh[1334],
    oG = Bh[231] + Bh[88] + Bh[995],
    fG = Bh[447] + Bh[200] + Bh[1335] + Bh[35] + Bh[300],
    cG = Bh[231] + Bh[50] + Bh[369],
    uG = Bh[239] + Bh[37] + Bh[331] + Bh[50] + Bh[369],
    _G = Bh[1336],
    dG = Bh[55],
    lG = Bh[3] + Bh[200] + Bh[1337] + Bh[163] + Bh[1338],
    vG = Bh[474] + Bh[1] + Bh[308],
    bG = Bh[1339],
    gG = Bh[1340],
    yG = Bh[130] + Bh[80] + Bh[675],
    xG = Bh[1229] + Bh[37] + Bh[331] + Bh[50] + Bh[369],
    mG = Bh[46] + Bh[88] + Bh[1341],
    EG = Bh[20] + Bh[1342],
    pG = Bh[58] + Bh[1343] + Bh[37] + Bh[1304],
    wG = Bh[1344],
    TG = Bh[1345],
    OG = Bh[203],
    IG = Bh[1346],
    MG = Bh[1347] + Bh[20] + Bh[1348] + Bh[20] + Bh[1349],
    AG = Bh[359] + Bh[20] + Bh[211] + Bh[20] + Bh[1350],
    jG = Bh[359] + Bh[20] + Bh[211] + Bh[20] + Bh[1351],
    SG = Bh[607] + Bh[39] + Bh[1352],
    CG = Bh[3] + Bh[247] + Bh[409],
    kG = Bh[1353],
    LG = Bh[3] + Bh[88] + Bh[255],
    PG = Bh[492] + Bh[200] + Bh[201],
    RG = Bh[20] + Bh[1354],
    DG = Bh[474] + Bh[154],
    NG = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1041],
    BG = Bh[474] + Bh[189],
    $G = Bh[341] + Bh[20] + Bh[1084] + Bh[20] + Bh[1355],
    GG = Bh[20] + Bh[1356],
    FG = Bh[20] + Bh[521] + Bh[58] + Bh[1357] + Bh[66] + Bh[250],
    zG = Bh[1202] + Bh[58] + Bh[1358],
    YG = Bh[20] + Bh[621] + Bh[327] + Bh[163] + Bh[176] + Bh[58] + Bh[302],
    HG = Bh[20] + Bh[190] + Bh[327],
    UG = Bh[1359],
    WG = Bh[1360] + Bh[163] + Bh[1361],
    qG = Bh[1362],
    XG = Bh[1363],
    VG = Bh[1363] + Bh[106],
    KG = Bh[46] + Bh[163] + Bh[1364],
    ZG = Bh[1363] + Bh[107],
    JG = Bh[1229],
    QG = Bh[1042] + Bh[20] + Bh[344],
    tF = Bh[1365],
    iF = Bh[1366],
    nF = Bh[231] + Bh[200] + Bh[1367],
    eF = Bh[231] + Bh[24] + Bh[1368],
    sF = Bh[20] + Bh[1369] + Bh[66] + Bh[1370],
    hF = Bh[1339] + Bh[39] + Bh[47],
    rF = Bh[1371],
    aF = Bh[1311],
    oF = Bh[447] + Bh[24] + Bh[452],
    fF = Bh[80] + Bh[1372] + Bh[37] + Bh[1304],
    cF = Bh[496] + Bh[37] + Bh[1312],
    uF = Bh[20] + Bh[1373],
    _F = Bh[20] + Bh[1374] + Bh[222] + Bh[274],
    dF = Bh[20] + Bh[1375],
    lF = Bh[0] + Bh[13] + Bh[455] + Bh[24] + Bh[301],
    vF = Bh[270] + Bh[24] + Bh[271] + Bh[58] + Bh[187] + Bh[222] + Bh[1376] + Bh[58] + Bh[1377] + Bh[66] + Bh[1017] + Bh[80] + Bh[1378],
    bF = Bh[20] + Bh[79],
    gF = Bh[65] + Bh[1] + Bh[414],
    yF = Bh[46] + Bh[1379],
    xF = Bh[46] + Bh[13] + Bh[1380],
    mF = Bh[46] + Bh[243] + Bh[1381],
    EF = Bh[46] + Bh[247] + Bh[1382],
    pF = Bh[46] + Bh[80] + Bh[1383],
    wF = Bh[46] + Bh[1] + Bh[1384],
    TF = Bh[46] + Bh[200] + Bh[1385],
    OF = Bh[50] + Bh[51] + Bh[80] + Bh[1024],
    IF = Bh[247] + Bh[1386],
    MF = Bh[247] + Bh[390],
    AF = Bh[24] + Bh[152] + Bh[371],
    jF = Bh[35] + Bh[201] + Bh[371],
    SF = Bh[37] + Bh[1107] + Bh[371],
    CF = Bh[163] + Bh[164] + Bh[371],
    kF = Bh[80] + Bh[1387],
    LF = Bh[27] + Bh[229],
    PF = Bh[24] + Bh[301] + Bh[58] + Bh[302],
    RF = Bh[222] + Bh[1388] + Bh[37] + Bh[1304],
    DF = Bh[389] + Bh[1389] + Bh[42] + Bh[270] + Bh[42] + Bh[956] + Bh[327],
    NF = Bh[154] + Bh[73] + Bh[288],
    BF = Bh[154] + Bh[73] + Bh[327] + Bh[73] + Bh[328] + Bh[42] + Bh[1390] + Bh[511],
    $F = Bh[389] + Bh[1389] + Bh[209] + Bh[50] + Bh[1391] + Bh[42] + Bh[1] + Bh[1392] + Bh[42] + Bh[270] + Bh[42] + Bh[956] + Bh[327] + Bh[427] + Bh[1] + Bh[291],
    GF = Bh[1393] + Bh[427] + Bh[1171] + Bh[427] + Bh[1394],
    FF = 0;
    if (t[Ed]) {
        var zF = navigator[pd],
        YF = /opera/i[To](zF),
        HF = !YF && /msie/i.test(zF),
        UF = /rv:11.0/i[To](zF),
        WF = /MSIE 10./i[To](zF);
        if (UF && (HF = !0), /msie\s[6,7,8]/i.test(zF)) throw new Error("your browser is not supported");
        var qF = /webkit|khtml/i[To](zF),
        XF = !qF && /gecko/i[To](zF),
        VF = /firefox\//i[To](zF),
        KF = /Chrome\//i[To](zF),
        ZF = !KF && /Safari\//i.test(zF),
        JF = /Macintosh;/i[To](zF),
        QF = /(iPad|iPhone|iPod)/g[To](zF),
        tz = /Android/g[To](zF),
        iz = /Windows Phone/g[To](zF),
        nz = (QF || tz || iz) && s_ in t,
        ez = zF[wd](/AppleWebKit\/([0-9\.]*)/);
        if (ez && ez[Fh] > 1) {
            parseFloat(ez[1])
        }
        tz && parseFloat(zF[wd](/Android\s([0-9\.]*)/)[1])
    }
    t[Td] || (t.requestAnimationFrame = t[Od] || t[Id] || t[Md] || t[Ad] ||
    function(i) {
        return t.setTimeout(function() {
            i()
        },
        1e3 / 60)
    }),
    t[jd] || (t[jd] = t[Sd] || t[Cd] || t[kd] || t[Ld] ||
    function(i) {
        return t[Pd](i)
    });
    var sz = {
        SELECTION_TOLERANCE: nz ? 5 : 2,
        LABEL_COLOR: Rd
    };
    Z(sz, {
        FONT_STYLE: {
            get: function() {
                return this._fontStyle || (this._fontStyle = Dd)
            },
            set: function(t) {
                this._fontStyle != t && (this._fontStyle = t, this._fontChanged = !0)
            }
        },
        FONT_SIZE: {
            get: function() {
                return this._fontSize || (this[Nd] = 12)
            },
            set: function(t) {
                this[Nd] != t && (this[Nd] = t, this._fontChanged = !0)
            }
        },
        FONT_FAMILY: {
            get: function() {
                return this[Bd] || (this[Bd] = "Verdana,helvetica,arial,sans-serif")
            },
            set: function(t) {
                this._fontFamily != t && (this._fontFamily = t, this[$d] = !0)
            }
        },
        FONT: {
            get: function() {
                return (this[$d] || this[$d] === n) && (this._fontChanged = !1, this._font = this[Gd] + vr + this[Fd] + zd + this[Yd]),
                this._font
            }
        }
    });
    var hz = function(t) {
        this._jg = [],
        this._lu = {},
        t && this.add(t)
    };
    hz.prototype = {
        _jg: null,
        _lu: null,
        get: function(t) {
            return this[Hd](t)
        },
        getById: function(t) {
            return this._lu[t]
        },
        getByIndex: function(t) {
            return this._jg[t]
        },
        forEach: function(t, i, n) {
            return l(this._jg, t, i, n)
        },
        forEachReverse: function(t, i, n) {
            return b(this._jg, t, i, n)
        },
        size: function() {
            return this._jg.length
        },
        contains: function(t) {
            return this[uc](t.id)
        },
        containsById: function(t) {
            return this._lu.hasOwnProperty(t)
        },
        setIndex: function(t, i) {
            var n = this._jg[Vh](t);
            if (0 > n) throw new Error(ya + t.id + Ud);
            return n == i ? !1 : (this._jg[Uh](n, 1), this._jg.splice(i, 0, t), !0)
        },
        setIndexAfter: function(t, i) {
            var n = this._jg[Vh](t);
            if (0 > n) throw new Error(ya + t.id + Ud);
            return n == i ? i: n == i + 1 ? i + 1 : (n > i && (i += 1), this._jg[Uh](n, 1), this._jg[Uh](i, 0, t), i)
        },
        setIndexBefore: function(t, i) {
            var n = this._jg[Vh](t);
            if (0 > n) throw new Error(ya + t.id + Ud);
            return n == i ? i: n == i - 1 ? i - 1 : (i > n && (i -= 1), this._jg.splice(n, 1), this._jg[Uh](i, 0, t), i)
        },
        indexOf: function(t) {
            return this._jg.indexOf(t)
        },
        getIndexById: function(t) {
            var i = this.getById(t);
            return i ? this._jg.indexOf(i) : -1
        },
        add: function(t, i) {
            return $(t) ? this._gx(t, i) : this._kr(t, i)
        },
        addFirst: function(t) {
            return this.add(t, 0)
        },
        _gx: function(t, i) {
            if (0 == t[Fh]) return ! 1;
            var e = !1,
            s = i >= 0;
            t = t._jg || t;
            for (var h = 0,
            r = t[Fh]; r > h; h++) {
                var a = t[h];
                null !== a && a !== n && this._kr(a, i, !0) && (e = !0, s && i++)
            }
            return e
        },
        _kr: function(t, i) {
            var e = t.id;
            return e === n || this[uc](e) ? !1 : (y(this._jg, t, i), this._lu[e] = t, t)
        },
        remove: function(t) {
            return $(t) ? this[Wd](t) : t.id ? this._gt(t.id, t) : this.removeById(t)
        },
        _neo: function(t) {
            if (0 == t[Fh]) return ! 1;
            var i = !1;
            t = t._jg || t;
            for (var e = 0,
            s = t.length; s > e; e++) {
                var h = t[e];
                if (null !== h && h !== n) {
                    h.id === n && (h = this._lu[h]);
                    var r = h.id;
                    this._gt(r, h, !0) && (i = !0)
                }
            }
            return i
        },
        _gt: function(t, i) {
            return t !== n && this.containsById(t) ? ((null === i || i === n) && (i = this[qd](t)), delete this._lu[t], x(this._jg, i), !0) : !1
        },
        removeById: function(t) {
            var i = this._lu[t];
            return i ? this._gt(t, i) : !1
        },
        set: function(t) {
            if (!t || 0 == t) return void this.clear();
            if (this.isEmpty() || !$(t)) return this.clear(),
            this.add(t);
            var i = [],
            n = {},
            e = 0;
            if (l(t,
            function(t) {
                this._lu[t.id] ? (n[t.id] = t, e++) : i[Xh](t)
            },
            this), e != this[Fh]) {
                var s = [];
                this[Wf](function(t) {
                    n[t.id] || s[Xh](t)
                },
                this),
                s[Fh] && this._neo(s)
            }
            return i[Fh] && this._gx(i),
            !0
        },
        clear: function() {
            return this[Sf]() ? !1 : (this._jg.length = 0, this._lu = {},
            !0)
        },
        toDatas: function() {
            return this._jg[Hh](0)
        },
        isEmpty: function() {
            return 0 == this._jg.length
        },
        valueOf: function() {
            return this._jg[Fh]
        },
        clone: function(t) {
            var i = new hz;
            return i.add(t ? g(this._jg) : this[$u]()),
            i
        }
    },
    Z(hz.prototype, {
        datas: {
            get: function() {
                return this._jg
            }
        },
        random: {
            get: function() {
                return this._jg && this._jg[Fh] ? this._jg[Y(this._jg[Fh])] : null
            }
        },
        length: {
            get: function() {
                return this._jg ? this._jg[Fh] : 0
            }
        }
    });
    var rz = (2 * Math.PI, .5 * Math.PI),
    az = function(t, i) {
        i = i.toUpperCase();
        for (var n = HF ? t[Xd] : t[Vd]; n && (1 != n[Kd] || n[Zd] && n[Zd][Jd]() != i);) n = HF ? n[Qd] : n.nextElementSibling;
        return n && 1 == n[Kd] && n.tagName && n[Zd][Jd]() == i ? n: null
    },
    oz = function(t, i, n) {
        t instanceof oz && (i = t.y, t = t.x, n = t[uo]),
        this.set(t, i, n)
    },
    fz = function(t, i, n, e) {
        var s = t - n,
        h = i - e;
        return Math[Ka](s * s + h * h)
    };
    oz.prototype = {
        x: 0,
        y: 0,
        rotate: n,
        set: function(t, i, n) {
            this.x = t || 0,
            this.y = i || 0,
            this.rotate = n || 0
        },
        negate: function() {
            this.x = -this.x,
            this.y = -this.y
        },
        offset: function(t, i) {
            this.x += t,
            this.y += i
        },
        equals: function(t) {
            return this.x == t.x && this.y == t.y
        },
        distanceTo: function(t) {
            return fz(this.x, this.y, t.x, t.y)
        },
        toString: function() {
            return tl + this.x + il + this.y + Sr
        },
        clone: function() {
            return new oz(this.x, this.y)
        }
    },
    Object[hr](oz.prototype, nl, {
        get: function() {
            return Math[Ka](this.x * this.x + this.y * this.y)
        }
    });
    var cz = function(t, i, e, s) {
        t !== n && this._mz(t, i, e, s)
    };
    cz[Jh] = {
        _nc: null,
        _nb: null,
        _n9: null,
        _nd: null,
        _ne: null,
        _ng: null,
        _nh: 1,
        _mz: function(t, i, n, e) {
            this._nc = t,
            this._nb = i,
            this._n9 = n,
            this._nd = e,
            t == n ? (this._ne = -1, this._nh = 0, this._ng = t) : (this._ne = (i - e) / (t - n), this._ng = i - this._ne * t, this._nh = 1),
            this._l0 = Math[Va](this._nd - this._nb, this._n9 - this._nc),
            this._nhos = Math.cos(this._l0),
            this[el] = Math.sin(this._l0)
        },
        _dm: function(t) {
            return 0 == this._nh ? Number.NaN: this._ne * t + this._ng
        },
        _dg: function(t) {
            return 0 == this._ne ? Number.NaN: (t - this._ng) / this._ne
        },
        _$e: function(t) {
            var i, n, e, s, h, r = t[0],
            a = t[2],
            o = t[4],
            f = t[1],
            c = t[3],
            u = t[5],
            _ = this._ne,
            d = this._ng,
            l = this._nh;
            if (0 == l ? (e = Math.sqrt(( - _ * _ * r - _ * d) * o + _ * _ * a * a + 2 * _ * d * a - _ * d * r), s = -_ * a + _ * r, h = _ * o - 2 * _ * a + _ * r) : (e = Math[Ka](( - f + _ * r + d) * u + c * c + ( - 2 * _ * a - 2 * d) * c + (_ * o + d) * f + ( - _ * _ * r - _ * d) * o + _ * _ * a * a + 2 * _ * d * a - _ * d * r), s = -c + f + _ * a - _ * r, h = u - 2 * c + f - _ * o + 2 * _ * a - _ * r), 0 != h) {
                i = (e + s) / h,
                n = ( - e + s) / h;
                var v, b;
                return i >= 0 && 1 >= i && (v = Bi(i, t)),
                n >= 0 && 1 >= n && (b = Bi(n, t)),
                v && b ? [v, b] : v ? v: b ? b: void 0
            }
        },
        _3s: function(t, i, n) {
            if (this._ne == t._ne || 0 == this._nh && 0 == t._nh) return null;
            var e, s;
            if (e = 0 == this._nh ? this._ng: 0 == t._nh ? t._ng: (t._ng - this._ng) / (this._ne - t._ne), s = 0 == this._ne ? this._ng: 0 == t._ne ? t._ng: this._nh ? this._ne * e + this._ng: t._ne * e + t._ng, !i) return {
                x: e,
                y: s
            };
            var h, r, a;
            if (n) h = -i / 2,
            r = -h;
            else {
                h = -fz(this._nc, this._nb, e, s),
                r = fz(this._n9, this._nd, e, s);
                var o = -h + r;
                if (o > i) {
                    var f = i / o;
                    h *= f,
                    r *= f
                } else a = (i - o) / 2
            }
            var c = this._7l(e, s, h),
            u = this._7l(e, s, r);
            return a && (c[Ko] = a, u[Ko] = a),
            [c, u]
        },
        _7l: function(t, i, n) {
            return 0 == this._nh ? {
                x: t,
                y: i + n
            }: {
                x: t + n * this[sl],
                y: i + n * this._sin
            }
        }
    };
    var uz = function(t, i) {
        this[Sa] = t,
        this[Ca] = i
    };
    uz[Jh] = {
        width: 0,
        height: 0,
        isEmpty: function() {
            return this[Sa] <= 0 || this[Ca] <= 0
        },
        clone: function() {
            return new uz(this[Sa], this[Ca])
        },
        toString: function() {
            return hl + this[Sa] + il + this[Ca] + Sr
        }
    };
    var _z = function(t, i, e, s) {
        t instanceof Object && !D(t) && (i = t.y, e = t.width, s = t[Ca], t = t.x),
        e === n && (e = -1),
        s === n && (s = -1),
        this.x = t || 0,
        this.y = i || 0,
        this[Sa] = e,
        this[Ca] = s
    };
    _z.prototype = {
        x: 0,
        y: 0,
        width: -1,
        height: -1,
        setByRect: function(t) {
            this.x = t.x || 0,
            this.y = t.y || 0,
            this[Sa] = t[Sa] || 0,
            this.height = t.height || 0
        },
        set: function(t, i, n, e) {
            this.x = t || 0,
            this.y = i || 0,
            this.width = n || 0,
            this.height = e || 0
        },
        offset: function(t, i) {
            return this.x += t,
            this.y += i,
            this
        },
        contains: function(t, i) {
            return t instanceof _z ? ai(this.x, this.y, this.width, this[Ca], t.x, t.y, t[Sa], t[Ca], i) : t >= this.x && t <= this.x + this[Sa] && i >= this.y && i <= this.y + this[Ca]
        },
        intersectsPoint: function(t, i, n) {
            return this.width <= 0 && this[Ca] <= 0 ? !1 : n ? this.intersectsRect(t - n, i - n, 2 * n, 2 * n) : t >= this.x && t <= this.x + this[Sa] && i >= this.y && i <= this.y + this[Ca]
        },
        intersectsRect: function(t, i, n, e) {
            return hi(this.x, this.y, this.width, this[Ca], t, i, n, e)
        },
        intersects: function(t, i) {
            return D(t[Sa]) ? this.intersectsRect(t.x, t.y, t[Sa], t[Ca]) : this.intersectsPoint(t, i)
        },
        intersection: function(t, i, n, e) {
            var s = this.x,
            h = this.y,
            r = s;
            r += this[Sa];
            var a = h;
            a += this.height;
            var o = t;
            o += n;
            var f = i;
            return f += e,
            t > s && (s = t),
            i > h && (h = i),
            r > o && (r = o),
            a > f && (a = f),
            r -= s,
            a -= h,
            0 > r || 0 > a ? null: new _z(s, h, r, a)
        },
        addPoint: function(t) {
            this.add(t.x, t.y)
        },
        add: function(t, i) {
            if (D(t[Sa])) return this[rl](t.x, t.y, t[Sa], t[Ca]);
            if (D(t.x) && (i = t.y, t = t.x), this[Sa] < 0 || this.height < 0) return this.x = t,
            this.y = i,
            void(this.width = this[Ca] = 0);
            var n = this.x,
            e = this.y,
            s = this[Sa],
            h = this.height;
            s += n,
            h += e,
            n > t && (n = t),
            e > i && (e = i),
            t > s && (s = t),
            i > h && (h = i),
            s -= n,
            h -= e,
            s > Number[al] && (s = Number[al]),
            h > Number[al] && (h = Number.MAX_VALUE),
            this.set(n, e, s, h)
        },
        addRect: function(t, i, n, e) {
            var s = this[Sa],
            h = this[Ca]; (0 > s || 0 > h) && this.set(t, i, n, e);
            var r = n,
            a = e;
            if (! (0 > r || 0 > a)) {
                var o = this.x,
                f = this.y;
                s += o,
                h += f;
                var c = t,
                u = i;
                r += c,
                a += u,
                o > c && (o = c),
                f > u && (f = u),
                r > s && (s = r),
                a > h && (h = a),
                s -= o,
                h -= f,
                s > Number.MAX_VALUE && (s = Number.MAX_VALUE),
                h > Number.MAX_VALUE && (h = Number[al]),
                this.set(o, f, s, h)
            }
        },
        shrink: function(t, i, n, e) {
            return D(t) ? 1 == arguments[Fh] ? e = i = n = t || 0 : 2 == arguments[Fh] ? (n = t || 0, e = i || 0) : (t = t || 0, i = i || 0, n = n || 0, e = e || 0) : (i = t[Co] || 0, n = t[Fr] || 0, e = t[Gr] || 0, t = t.top || 0),
            this.x += i,
            this.y += t,
            this[Sa] -= i + e,
            this[Ca] -= t + n,
            this
        },
        grow: function(t, i, n, e) {
            return D(t) ? 1 == arguments.length ? e = i = n = t || 0 : 2 == arguments[Fh] ? (n = t || 0, e = i || 0) : (t = t || 0, i = i || 0, n = n || 0, e = e || 0) : (i = t[Co] || 0, n = t.bottom || 0, e = t[Gr] || 0, t = t.top || 0),
            this.x -= i,
            this.y -= t,
            this[Sa] += i + e,
            this[Ca] += t + n,
            this
        },
        scale: function(t) {
            return this.x *= t,
            this.y *= t,
            this[Sa] *= t,
            this.height *= t,
            this
        },
        isEmpty: function() {
            return this[Sa] <= 0 && this[Ca] <= 0
        },
        toString: function() {
            return this.x + ol + this.y + ol + this[Sa] + ol + this.height
        },
        union: function(t) {
            var i = this[Sa],
            n = this[Ca];
            if (0 > i || 0 > n) return new _z(t.x, t.y, t[Sa], t[Ca]);
            var e = t[Sa],
            s = t[Ca];
            if (0 > e || 0 > s) return new _z(this.x, this.y, this.width, this.height);
            var h = this.x,
            r = this.y;
            i += h,
            n += r;
            var a = t.x,
            o = t.y;
            return e += a,
            s += o,
            h > a && (h = a),
            r > o && (r = o),
            e > i && (i = e),
            s > n && (n = s),
            i -= h,
            n -= r,
            i > Number.MAX_VALUE && (i = Number[al]),
            n > Number[al] && (n = Number[al]),
            new _z(h, r, i, n)
        },
        clear: function() {
            this.set(0, 0, -1, -1)
        },
        equals: function(t) {
            return t && this.x == t.x && this.y == t.y && this[Sa] == t[Sa] && this.height == t[Ca]
        },
        clone: function(t, i) {
            return new _z(this.x + (t || 0), this.y + (i || 0), this[Sa], this.height)
        },
        toArray: function() {
            return [this.x, this.y, this[Sa], this.height]
        },
        getIntersectionPoint: function(t, i, n, e) {
            return si(this, t, i, n, e)
        }
    },
    p(_z, uz),
    _z[_c] = function(t, i) {
        return t == i || t && i && t.x == i.x && t.y == i.y && t.width == i[Sa] && t[Ca] == i[Ca]
    },
    Z(_z[Jh], {
        left: {
            get: function() {
                return this.x
            }
        },
        top: {
            get: function() {
                return this.y
            }
        },
        bottom: {
            get: function() {
                return this.y + this.height
            }
        },
        right: {
            get: function() {
                return this.x + this[Sa]
            }
        },
        cx: {
            get: function() {
                return this.x + this[Sa] / 2
            }
        },
        cy: {
            get: function() {
                return this.y + this.height / 2
            }
        },
        center: {
            get: function() {
                return new oz(this.cx, this.cy)
            }
        }
    }),
    _z[ku] = hi,
    _z[Wo] = oi,
    _z[mf] = ri;
    var dz = function(t, i, n, e) {
        1 == arguments[Fh] ? i = n = e = t: 2 == arguments.length && (n = t, e = i),
        this.set(t, i, n, e)
    };
    dz.prototype = {
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
        set: function(t, i, n, e) {
            this.top = t || 0,
            this.left = i || 0,
            this.bottom = n || 0,
            this[Gr] = e || 0
        },
        clone: function() {
            return new dz(this.top, this[Co], this[Fr], this[Gr])
        },
        equals: function(t) {
            return t && this.top == t.top && this[Fr] == t[Fr] && this.left == t[Co] && this[Gr] == t.right
        }
    };
    var lz = function(t, i) {
        this[Yr] = t,
        this[Hr] = i
    };
    lz[Jh] = {
        verticalPosition: !1,
        horizontalPosition: !1,
        toString: function() {
            return (this[Yr] || "") + (this[Hr] || "")
        }
    },
    K(lz[Jh], fl, {
        get: function() {
            return (this[Yr] || "") + (this[Hr] || "")
        }
    });
    var vz = cl,
    bz = ul,
    gz = _l,
    yz = hc,
    xz = dl,
    mz = ll;
    lz[vl] = new lz(vz, yz),
    lz.LEFT_MIDDLE = new lz(vz, xz),
    lz[bl] = new lz(vz, mz),
    lz[gl] = new lz(bz, yz),
    lz[yl] = new lz(bz, xz),
    lz[xl] = new lz(bz, mz),
    lz[ml] = new lz(gz, yz),
    lz[El] = new lz(gz, xz),
    lz[pl] = new lz(gz, mz);
    var Ez = [lz[vl], lz[wl], lz[bl], lz.CENTER_TOP, lz.CENTER_MIDDLE, lz[xl], lz[ml], lz[El], lz[pl]];
    K(lz, Ir, {
        get: function() {
            return Ez[Y(Ez[Fh])]
        }
    }),
    lz.fromString = function(t) {
        for (var i in lz) {
            var n = lz[i];
            if (n && Ir != i && n instanceof lz && n.toString() == t) return n
        }
    };
    var pz = function(t, i, n, e, s) {
        this.set(t, i, n, e),
        this[Tl] = s
    };
    pz[Jh] = {
        radius: 0,
        classify: function(t, i, n, e) {
            return i > t ? 0 : i + e > t ? 1 : n - e > t ? 2 : n > t ? 3 : 4
        },
        intersectsRect: function(t, i, n, e) {
            if (T(this, pz, Ol, arguments) === !1) return ! 1;
            var s = this.x,
            h = this.y,
            r = s + this[Sa],
            a = h + this[Ca],
            o = 2 * radius,
            f = 2 * radius,
            c = Math.min(this[Sa], Math.abs(o)) / 2,
            u = Math.min(this[Ca], Math.abs(f)) / 2,
            _ = this[Il](t, s, r, c),
            d = this[Il](t + n, s, r, c),
            l = this[Il](i, h, a, u),
            v = this[Il](i + e, h, a, u);
            return 2 == _ || 2 == d || 2 == l || 2 == v ? !0 : 2 > _ && d > 2 || 2 > l && v > 2 ? !0 : (t = 1 == d ? t = t + n - (s + c) : t -= r - c, i = 1 == v ? i = i + e - (h + u) : i -= a - u, t /= c, i /= u, 1 >= t * t + i * i)
        },
        intersectsPoint: function(t, i) {
            if (T(this, pz, mf, arguments) === !1) return ! 1;
            var n = this.x,
            e = this.y,
            s = n + this.width,
            h = e + this.height;
            if (n > t || e > i || t >= s || i >= h) return ! 1;
            var r = 2 * radius,
            a = 2 * radius,
            o = Math.min(this.width, Math.abs(r)) / 2,
            f = Math.min(this[Ca], Math.abs(a)) / 2;
            return t >= (n += o) && t < (n = s - o) ? !0 : i >= (e += f) && i < (e = h - f) ? !0 : (t = (t - n) / o, i = (i - e) / f, 1 >= t * t + i * i)
        },
        clone: function() {
            return new pz(this.x, this.y, this.width, this[Ca], this[Tl])
        }
    },
    p(pz, _z);
    var wz = function(t, i, n, e) {
        this[Lo] = t,
        this[fo] = i,
        this[Ml] = n,
        this.value = e
    };
    wz[Jh] = {
        source: null,
        type: null,
        kind: null,
        value: null,
        toString: function() {
            return Al + this[Lo] + jl + this.type + Sl + this[Ml]
        }
    };
    var Tz = function(t, i, n, e, s) {
        this.source = t,
        this[Ml] = i,
        this[Cl] = e,
        this[ar] = n,
        this[kl] = s
    };
    Tz[Jh] = {
        type: Ll,
        propertyType: null,
        toString: function() {
            return Al + this.source + jl + this.type + Pl + this.kind + Rl + this.oldValue + Dl + this[ar]
        }
    },
    p(Tz, wz),
    K(Tz.prototype, Nl, {
        get: function() {
            return this[Ml]
        },
        set: function(t) {
            this[Ml] = t
        }
    });
    var Oz = function(t, i, n) {
        this.source = t,
        this.oldValue = t.parent,
        this.value = i,
        this[Bl] = n,
        this[Cl] && (this[$l] = this[Cl].getChildIndex(t))
    };
    Oz[Jh] = {
        kind: bc
    },
    p(Oz, Tz);
    var Iz = function(t, i) {
        this[Lo] = t,
        this[ar] = i
    };
    Iz[Jh][Ml] = Gl,
    p(Iz, Tz);
    var Mz = function(t, i) {
        this[Lo] = t,
        this.value = i
    };
    Mz[Jh][Ml] = Fl,
    p(Mz, Tz);
    var Az = function(t, i, n, e) {
        this[Lo] = i,
        this[Cl] = n,
        this.value = e,
        this[bc] = t,
        this.child = i,
        this[$l] = n,
        this.newIndex = e
    };
    Az[Jh][Ml] = zl,
    p(Az, Tz);
    var jz = function() {};
    jz.prototype = {
        listener: null,
        beforeEvent: function(t) {
            return null != this[Yl] && this[Yl][sr] ? this.listener[sr](t) : !0
        },
        onEvent: function(t) {
            null != this[Yl] && this[Yl].onEvent && this.listener[Hl](t)
        }
    };
    var Sz = function() {
        w(this, Sz, arguments),
        this[Ul] = {},
        this.listeners = []
    },
    Cz = function(t, i) {
        this[Yl] = t,
        this[Wl] = i,
        t instanceof Function ? this.onEvent = t: (this[Hl] = t[Hl], this[sr] = t.beforeEvent),
        this[_c] = function(t) {
            return t && this.listener == t[Yl] && this[Wl] == t[Wl]
        }
    };
    Cz[Jh] = {
        equals: function(t) {
            return t && this[Yl] == t[Yl] && this[Wl] == t[Wl]
        },
        destroy: function() {
            delete this[Wl],
            delete this.listener
        }
    },
    Sz[Jh] = {
        listeners: null,
        _ngm: function() {
            return this.listeners && this[ql].length > 0
        },
        _7r: function(t, i) {
            return t instanceof Sz ? t: new Cz(t, i)
        },
        _9h: function(t, i) {
            if (t instanceof Sz) return this[ql][Vh](t);
            for (var n = this[ql], e = 0, s = n.length; s > e; e++) {
                var h = n[e];
                if (h[Yl] == t && h[Wl] == i) return e
            }
            return - 1
        },
        contains: function(t, i) {
            return this._9h(t, i) >= 0
        },
        addListener: function(t, i) {
            return this[Ku](t, i) ? !1 : void this[ql].push(this._7r(t, i))
        },
        removeListener: function(t, i) {
            var n = this._9h(t, i);
            n >= 0 && this.listeners[Uh](n, 1)
        },
        on: function(t, i) {
            this.addListener(t, i)
        },
        un: function(t, i, n) {
            this[Xl](t, i, n)
        },
        onEvent: function(t) {
            return this[ql] ? void l(this.listeners,
            function(i) {
                i[Hl] && (i.scope ? i[Hl][zh](i[Wl], t) : i.onEvent(t))
            },
            this) : !1
        },
        beforeEvent: function(t) {
            return this[ql] ? l(this[ql],
            function(i) {
                return i.beforeEvent ? i[Wl] ? i[sr].call(i[Wl], t) : i.beforeEvent(t) : !0
            },
            this) : !0
        },
        _dt: function(t) {
            return this[sr](t) === !1 ? !1 : (this[Hl](t), !0)
        },
        clear: function() {
            this[ql] = []
        },
        destroy: function() {
            this[wf]()
        }
    },
    p(Sz, jz);
    var kz = {
        onEvent: function() {},
        beforeEvent: function() {}
    },
    Lz = function(t, i, n, e, s) {
        this.source = t,
        this[fo] = Vl,
        this[Ml] = i,
        this[ao] = n,
        this[Kl] = e,
        this[$l] = s
    };
    Lz[Jh] = {
        index: -1,
        oldIndex: -1,
        toString: function() {
            return Al + this[Lo] + jl + this[fo] + Sl + this[Ml] + Zl + this.data + Jl + this[Kl] + Ql + this[$l]
        }
    },
    p(Lz, wz),
    Lz[tv] = iv,
    Lz[nv] = mc,
    Lz.KIND_CLEAR = wf,
    Lz[ev] = sv;
    var Pz = function() {
        this.id = ++FF,
        this._nh6 = {}
    };
    Pz[Jh] = {
        _nh6: null,
        id: null,
        get: function(t) {
            return this[hv][t]
        },
        set: function(t, i) {
            var n = this.get(t);
            if (n === i) return ! 1;
            var e = new Tz(this, t, i, n);
            return e[kl] = mY[rv],
            this._neq(t, i, e, this._nh6)
        },
        _neq: function(t, i, e, s) {
            return this[sr](e) === !1 ? !1 : (s || (s = this[hv]), i === n ? delete s[t] : s[t] = i, this.onEvent(e), !0)
        },
        remove: function(t) {
            this.set(t, null)
        },
        valueOf: function() {
            return this.id
        },
        toString: function() {
            return this.id
        },
        _dz: function(t, i) {
            if (i === n && (i = -1), this == t || t == this._jy) return ! 1;
            if (t && this == t._jy && !t._dz(null)) return ! 1;
            var e = new Oz(this, t, i);
            if (!this[sr](e)) return ! 1;
            var s, h, r = this._jy;
            return t && (s = new Iz(t, this), !t[sr](s)) ? !1 : null == r || (h = new Mz(r, this), r[sr](h)) ? (this._jy = t, null != t && ci(t, this, i), null != r && ui(r, this), this.onEvent(e), null != t && t[Hl](s), null != r && r[Hl](h), this.onParentChanged(r, t), !0) : !1
        },
        addChild: function(t, i) {
            var n = t._dz(this, i);
            return n && this.onChildAdd(t, i),
            n
        },
        onChildAdd: function() {},
        removeChild: function(t) {
            if (!this._g2 || !this._g2[Ku](t)) return ! 1;
            var i = t._dz(null);
            return this[Wr](t),
            i
        },
        onChildRemove: function() {},
        toChildren: function() {
            return this._g2 ? this._g2[$u]() : null
        },
        clearChildren: function() {
            if (this._g2 && this._g2.length) {
                var t = this[av]();
                l(t,
                function(t) {
                    t._dz(null)
                },
                this),
                this.onChildrenClear(t)
            }
        },
        forEachChild: function(t, i) {
            return this[$h]() ? this._g2[Wf](t, i) : !1
        },
        onChildrenClear: function() {},
        getChildIndex: function(t) {
            return this._g2 && this._g2[Fh] ? this._g2[Vh](t) : -1
        },
        setChildIndex: function(t, i) {
            if (!this._g2 || !this._g2[Fh]) return ! 1;
            var n = this._g2[Vh](t);
            if (0 > n || n == i) return ! 1;
            var e = new Az(this, t, n, i);
            return this.beforeEvent(e) === !1 ? !1 : (this._g2.remove(t) && this._g2.add(t, i), this[Hl](e), !0)
        },
        hasChildren: function() {
            return this._g2 && this._g2[Fh] > 0
        },
        getChildAt: function(t) {
            return null == this._g2 ? null: this._g2._jg[t]
        },
        isDescendantOf: function(t) {
            if (!t[$h]()) return ! 1;
            for (var i = this[bc]; null != i;) {
                if (t == i) return ! 0;
                i = i[bc]
            }
            return ! 1
        },
        onParentChanged: function() {},
        firePropertyChangeEvent: function(t, i, n, e) {
            this.onEvent(new Tz(this, t, i, n, e))
        }
    },
    p(Pz, jz),
    Z(Pz.prototype, {
        childrenCount: {
            get: function() {
                return this._g2 ? this._g2[Fh] : 0
            }
        },
        children: {
            get: function() {
                return this._g2 || (this._g2 = new hz),
                this._g2
            }
        },
        parent: {
            get: function() {
                return this._jy
            },
            set: function(t) {
                this._dz(t, -1)
            }
        },
        properties: {
            get: function() {
                return this[hv]
            },
            set: function(t) {
                this._nh6 != t && (this[hv] = t)
            }
        }
    });
    var Rz = function() {
        this._jg = [],
        this._lu = {},
        this._1d = new Sz
    };
    Rz[Jh] = {
        beforeEvent: function(t) {
            return null != this._1d && this._1d[sr] ? this._1d[sr](t) : !0
        },
        onEvent: function(t) {
            return this._1d instanceof Function ? void this._1d(t) : void(null != this._1d && this._1d[Hl] && this._1d[Hl](t))
        },
        _1d: null,
        setIndex: function(t, i) {
            if (!this[Ku](t)) throw new Error(ya + t[ov]() + Ud);
            var n = this[Vh](t);
            if (n == i) return ! 1;
            var e = new Lz(this, Lz[ev], t, i, n);
            return this[sr](e) === !1 ? !1 : (this._jg[mc](t) >= 0 && this._jg.add(i, t), this[Hl](e), !0)
        },
        _gx: function(t, i) {
            if (0 == t.length) return ! 1;
            var e = !1,
            s = i >= 0,
            h = new Lz(this, Lz[tv], t, i);
            if (this[sr](h) === !1) return ! 1;
            var r = [];
            t = t._jg || t;
            for (var a = 0,
            o = t[Fh]; o > a; a++) {
                var f = t[a];
                null !== f && f !== n && this._kr(f, i, !0) && (r.push(f), e = !0, s && i++)
            }
            return h[ao] = r,
            this[Hl](h),
            e
        },
        _kr: function(t, i, n) {
            if (this[fv](t) === !1) return ! 1;
            if (n) return T(this, Rz, cv, arguments);
            var e = new Lz(this, Lz[tv], t, i);
            return this[sr](e) === !1 ? !1 : T(this, Rz, cv, arguments) ? (this._kq(t, e), t) : !1
        },
        _kq: function(t, i) {
            this[Hl](i)
        },
        _neo: function(t) {
            if (0 == t.length) return ! 1;
            var i = new Lz(this, Lz[nv], t);
            if (this[sr](i) === !1) return ! 1;
            var e = [],
            s = !1;
            t = t._jg || t;
            for (var h = 0,
            r = t[Fh]; r > h; h++) {
                var a = t[h];
                if (null !== a && a !== n) {
                    var o = a.id || a;
                    a.id === n && (a = null),
                    this._gt(o, a, !0) && (e[Xh](a), s = !0)
                }
            }
            return i[ao] = e,
            this[Hl](i),
            s
        },
        _gt: function(t, i, n) {
            if (n) return T(this, Rz, uv, arguments);
            var e = new Lz(this, Lz[nv], i);
            return this.beforeEvent(e) === !1 ? !1 : T(this, Rz, uv, arguments) ? (this[Hl](e), !0) : !1
        },
        clear: function() {
            if (this[Sf]()) return ! 1;
            var t = new Lz(this, Lz.KIND_CLEAR, this[$u]());
            return this[sr](t) === !1 ? !1 : T(this, Rz, wf) ? (this.onEvent(t), !0) : !1
        },
        accept: function(t) {
            return this.filter && this[_v](t) === !1 ? !1 : !0
        }
    },
    p(Rz, hz),
    K(Rz[Jh], dv, {
        get: function() {
            return this._1d
        }
    });
    var Dz = function() {
        w(this, Dz, arguments),
        this.selectionChangeDispatcher = new Sz,
        this._selectionModel = new Nz(this),
        this[lv]._1d = this[vv],
        this[bv] = new Sz,
        this[bv][gv]({
            beforeEvent: this[yv],
            onEvent: this.onDataPropertyChanged
        },
        this),
        this[xv] = new Sz,
        this[mv] = new Sz,
        this[Ev] = new hz;
        var t = this;
        this[Ev].setIndex = function(i, n) {
            if (!t[Ev][Ku](i)) throw new Error(ya + i.id + Ud);
            var e = t.$roots._jg[Vh](i);
            if (e == n) return ! 1;
            t.$roots._jg[Uh](e, 1),
            t[Ev]._jg[Uh](n, 0, i),
            t._nhfIndexFlag = !0;
            var s = new Az(t, i, e, n);
            return t._24(s),
            !0
        }
    };
    Dz[Jh] = {
        selectionModel: null,
        selectionChangeDispatcher: null,
        dataChangeDispatcher: null,
        parentChangeDispatcher: null,
        roots: null,
        _kq: function(t, i) {
            t[Yl] = this[bv],
            t.parent || this[Ev].add(t),
            this[Hl](i)
        },
        _gt: function(t, i) {
            if (T(this, Dz, uv, arguments)) {
                if (i instanceof TU) i[pv]();
                else if (i instanceof OU) {
                    var n = i.getEdges();
                    this[mc](n)
                }
                var e = i[bc];
                return null == e ? this[Ev][mc](i) : (e.removeChild(i), e[wv] = !0),
                i[$h]() && this.remove(i[av]()),
                i[Yl] = null,
                !0
            }
            return ! 1
        },
        _5w: function(t) {
            var i = t[Lo];
            this[Ku](i) && (null == i[bc] ? this[Ev].add(i) : null == t[Cl] && this.$roots[mc](i), this.parentChangeDispatcher.onEvent(t))
        },
        _24: function(t) {
            this[mv][Hl](t)
        },
        beforeDataPropertyChange: function(t) {
            return t instanceof Oz ? this[xv][sr](t) : !0
        },
        onDataPropertyChanged: function(t) {
            return t instanceof Oz ? (this._nhfIndexFlag = !0, t[Lo][Tv] = !0, void this._5w(t)) : void(t instanceof Az && (this[Tv] = !0, t[Lo]._nhfIndexFlag = !0, this._24(t)))
        },
        toRoots: function() {
            return this[Ev].toDatas()
        },
        _go: function(t) {
            var i, n = t._jy;
            i = n ? n._g2: this[Ev];
            var e = i.indexOf(t);
            if (0 > e) throw new Error(Ov + t + "' not exist in the box");
            return 0 == e ? n: i[Hd](e - 1)
        },
        _gn: function(t) {
            var i, n = t._jy;
            i = n ? n._g2: this[Ev];
            var e = i[Vh](t);
            if (0 > e) throw new Error(Ov + t + "' not exist in the box");
            return e == i[Fh] - 1 ? n ? this._gn(n) : null: i.getByIndex(e + 1)
        },
        forEachByDepthFirst: function(t, i, n) {
            return this[Ev].length ? h(this[Ev], t, i, n) : !1
        },
        forEachByDepthFirstReverse: function(t, i, n) {
            return this[Ev][Fh] ? o(this.$roots, t, i, n) : !1
        },
        forEachByBreadthFirst: function(t, i) {
            return this[Ev].length ? u(this[Ev], t, i) : !1
        },
        forEachByBreadthFirstReverse: function(t, i) {
            return this[Ev][Fh] ? _(this[Ev], t, i) : !1
        },
        clear: function() {
            return T(this, Dz, wf) ? (this[Ev][wf](), this.selectionModel.clear(), !0) : !1
        }
    },
    p(Dz, Rz),
    Z(Dz[Jh], {
        selectionModel: {
            get: function() {
                return this[lv]
            }
        },
        roots: {
            get: function() {
                return this[Ev]
            }
        }
    });
    var Nz = function(t) {
        w(this, Nz),
        this.box = t,
        this[Iv] = {
            onEvent: function(t) {
                Lz.KIND_REMOVE == t[Ml] ? null != t[ao] ? this[mc](t.data) : null != t.datas && this[mc](t[Mv]) : Lz.KIND_CLEAR == t[Ml] && this[wf]()
            }
        },
        this.box[dv][gv](this[Iv], this)
    };
    Nz[Jh] = {
        box: null,
        isSelected: function(t) {
            return this[uc](t.id || t)
        },
        select: function(t) {
            return this.add(t)
        },
        unselect: function(t) {
            return this[mc](t)
        },
        reverseSelect: function(t) {
            return this.contains(t) ? this[mc](t) : this.add(t)
        },
        accept: function(t) {
            return this.box[Ku](t)
        }
    },
    p(Nz, Rz);
    var Bz = null,
    $z = null,
    Gz = function() {
        if (!i.createElement) return function(t) {
            return t
        };
        var t = i.createElement(i_),
        e = t[ta],
        s = {};
        return function(t) {
            if (s[t]) return s[t];
            var i = _i(t);
            return e[i] !== n || $z && e[i = _i($z + i)] !== n ? (s[t] = i, i) : t
        }
    } (),
    Fz = {}; !
    function() {
        if (!i[Av]) return ! 1;
        for (var e = i[Av], s = "Webkit Moz O ms Khtml" [lr](vr), h = 0; h < s[Fh]; h++) if (e.style[s[h] + jv] !== n) {
            $z = Vr + s[h][Sv]() + Vr;
            break
        }
        var r = i[Ga](ta);
        t[Cv] || r[lc](i.createTextNode("")),
        r[fo] = kv,
        r.id = Lv,
        e[lc](r),
        Bz = r[Pv];
        var a, o;
        for (var f in Fz) {
            var c = Fz[f];
            a = f,
            o = "";
            for (var u in c) o += Gz(u) + Zr + c[u] + Rv;
            gi(a, o)
        }
    } ();
    var zz = function(t, i, n, e, s) {
        if (s) {
            var h = function(t) {
                h[Dv][zh](h[Wl], t)
            };
            return h[Wl] = s,
            h[Dv] = n,
            t[Nv](i, h, e),
            h
        }
        return t[Nv](i, n, e),
        n
    },
    Yz = function(t, i, n) {
        t[Bv](i, n)
    },
    G = function(t) {
        t.preventDefault ? t[Er]() : t[pr] = !1
    },
    F = function(t) {
        t[wr] ? t[wr]() : t.cancelBubble || (t.cancelBubble = !0)
    },
    z = function(t) {
        G(t),
        F(t)
    };
    if (sz.DOUBLE_CLICK_INTERVAL_TIME = 200, sz.LONG_PRESS_INTERVAL = 800, t[Ed] && navigator.userAgent) {
        var Hz, Uz = /mobile|tablet|ip(ad|hone|od)|android/i,
        Wz = s_ in t,
        qz = Wz && Uz[To](navigator.userAgent);
        if (qz) Hz = $v;
        else {
            var Xz = Gv in t ? "mousewheel": Fv;
            Hz = zv + Xz,
            Wz && (Hz += Yv)
        }
        Hz = Hz[lr](/[\s,]+/);
        var Vz = function(i) {
            return t.TouchEvent && i instanceof t[Hv]
        },
        Kz = function() {
            return sz.DOUBLE_CLICK_INTERVAL_TIME
        },
        Zz = function() {
            return sz.LONG_PRESS_INTERVAL
        },
        G = function(t) {
            t[Er] ? t.preventDefault() : t[pr] = !1
        },
        F = function(t) {
            t[wr] && t[wr](),
            t[Tr] = !0
        },
        z = function(t) {
            G(t),
            F(t)
        },
        Jz = function(t) {
            return t[Uv] || t[pr] === !1
        },
        Qz = function(t) {
            hY[Wv] && hY._nhurrentItem[qv](t)
        },
        tY = function(t) {
            if (hY[Wv]) {
                var i = hY[Wv];
                i[Xv](t),
                iY(null)
            }
        },
        iY = function(t) {
            hY[Wv] != t && (hY[Wv] && (hY[Wv][Vv] = !1), hY._nhurrentItem = t)
        },
        nY = function(i, n) {
            Hz[Wf](function(t) {
                i[Nv](t, n, !1)
            }),
            nz || hY[nu] || (hY._nek = !0, t[Nv](Kv, Qz, !0), t.addEventListener(Zv, tY, !0))
        },
        eY = function(t, i) {
            Hz[Wf](function(n) {
                t.removeEventListener(n, i, !1)
            })
        },
        sY = function(t) {
            return t[Nr] ? {
                timeStamp: t[Jv],
                x: t.cx,
                y: t.cy
            }: {
                timeStamp: t[Jv],
                x: t.clientX,
                y: t.clientY
            }
        };
        xi[Jh] = {
            _install: function() {
                this.__nection || (this[Qv] = function(t) {
                    this[tb](t)
                } [fr](this), nY(this._mk, this[Qv]))
            },
            _uninstall: function() {
                this[Qv] && eY(this._mk, this[Qv])
            },
            _nection: function(t) {
                t = this[ib](t);
                var i = t.type;
                this._handleEvent(t, i) === !1 && this[nb](t, eb + i)
            },
            _nhancelLongPressTimer: function() {
                this[sb] && (clearTimeout(this[sb]), this[sb] = null)
            },
            __l5LongPress: function(t) {
                this[hb] || (this.__onLongPressFunction = function() {
                    this[rb] && (this[ab] = !0, this._l5Event[ob] ? this[nb](this._l5Event, fb) : this[nb](this[rb], cb))
                } [fr](this)),
                this._nhancelLongPressTimer(),
                this[sb] = setTimeout(this[hb], Zz(t))
            },
            __fixTouchEvent: function(t) {
                for (var i, n, e = 0,
                s = 0,
                h = t[Nr][Fh], r = 0; h > r;) {
                    var a = t[Nr][r++],
                    o = a[ra],
                    f = a[aa];
                    if (2 == r) {
                        var c = n[0] - o,
                        u = n[1] - f;
                        i = Math[Ka](c * c + u * u)
                    }
                    n = [o, f],
                    e += o,
                    s += f
                }
                t.cx = e / h,
                t.cy = s / h,
                t[Vu] = {
                    x: t.cx,
                    y: t.cy,
                    clientX: t.cx,
                    clientY: t.cy
                },
                t[nl] = i
            },
            __touchCountChange: function(t) {
                this[da].clear(),
                this._9j = sY(t)
            },
            _handleTouchEvent: function(t, i) {
                switch (i) {
                case "touchstart":
                    z(t),
                    this.__fixTouchEvent(t),
                    this[ub](t);
                    var n = t[Nr].length;
                    this[rb] || (this[rb] = t, this._onstart(t), this.__nhancelClick = !1, this[_b](t)),
                    1 == n && (this[db] = null),
                    n >= 2 && !this[db] && (this[db] = {
                        cx: t.cx,
                        cy: t.cy,
                        distance: t[nl]
                    });
                    break;
                case "touchmove":
                    z(t),
                    this[lb](t);
                    var n = t[Nr][Fh];
                    if (n >= 2 && this.__l5MulTouchEvent) {
                        var e = this[db][nl];
                        t[vb] = t[nl] / e,
                        t[bb] = this.__l5MulTouchEvent.prevScale ? t[vb] / this[db][gb] : t._scale,
                        this[db][gb] = t[vb],
                        this[yb] || (this.__pinching = !0, this[nb](t, xb))
                    }
                    this[Vv] || (this[Vv] = !0, this._l5drag(t)),
                    this[mb](t),
                    this[yb] && this._onEvent(t, Eb);
                    break;
                case "touchend":
                    z(t);
                    var n = t[Nr][Fh];
                    n && (this[lb](t), this[ub](t)),
                    1 >= n && (this[yb] && (this.__pinching = !1, this._onEvent(t, pb)), this.__l5MulTouchEvent = null),
                    0 == n && (this[Vv] ? (this[wb](t), this[Vv] = !1) : t.timeStamp - this[rb].timeStamp < .8 * Kz(t) && this[Tb](this[rb]), this[Ob](t));
                    break;
                case "touchcancel":
                    this[Vv] = !1,
                    this[yb] = !1,
                    this.__l5MulTouchEvent = null
                }
                return ! 1
            },
            _handleEvent: function(t, i) {
                if (Vz(t)) return this._handleTouchEvent(t, i);
                if (Ib == i) z(t),
                iY(this),
                this._9j = sY(t),
                this[rb] || (this._l5Event = t, this[Mb](t)),
                this[ab] = !1,
                this[_b](t);
                else if (Zv == i) iY(),
                this[Ob](t);
                else if (Ab == i) {
                    if (this[jb]) return this[Tb](t),
                    !0
                } else if (Sb == i) {
                    if (this._delayClickEvent) return ! 0
                } else {
                    if (Cb == i) return this[nb](t, kb),
                    this[rb] && Jz(t) && iY(this),
                    !0;
                    if (i == Xz) {
                        var e = t[Lb];
                        if (e !== n ? e % 120 ? e % 12 || (e /= 12) : e /= 120 : e === n && (e = -t.detail), !e) return;
                        return t.delta = e,
                        this[nb](t, Gv)
                    }
                }
                return ! 1
            },
            _onEvent: function(t, i) {
                if (this._handler) {
                    var n = this[_a];
                    return i = i || t[fo],
                    n instanceof Function ? n(t, i) : n[i] instanceof Function ? n[i][zh](n, t, this._scope || this._mk) : void 0
                }
            },
            _toQEvent: function(t) {
                return t
            },
            _onWindowMouseUp: function(t) {
                this[Vv] && (z(t), this[Vv] = !1, t = this[ib](t), this[wb](t), this[Ob](t), this._onEvent(t, Pb))
            },
            _l5DragDistance: 4,
            _onWindowMouseMove: function(t) {
                if (this[rb]) {
                    if (z(t), !this.__dragging) {
                        var i = this[rb].screenX - t[Rb],
                        n = this._l5Event[Db] - t[Db];
                        if (i * i + n * n < this[Nb]) return;
                        this[Vv] = !0,
                        this[Bb](t)
                    }
                    this[mb](this[ib](t))
                }
            },
            _delayClickEvent: !0,
            __onclick: function(t) {
                if (!this[ab]) {
                    var i = Kz(t);
                    this[$b] ? this.__dblclicked || (clearTimeout(this[$b]), this.__nhlickTimer = null, this._onEvent(t, Gb), this.__dblclicked = !0) : (this[Fb] = !1, this[$b] = setTimeout(function(t) {
                        this[$b] = null,
                        this.__dblclicked || this[nb](t, h_)
                    }.bind(this, t, i), i))
                }
            },
            _onstart: function(t) {
                t[ob] ? this[nb](t, zb) : this[nb](t, Yb)
            },
            _onrelease: function(t) {
                this[rb] && (this._nhancelLongPressTimer(), t[ob] ? this[nb](t, Hb) : this[nb](t, Ub), this[rb] = null, this._9j = null)
            },
            _neppendDragInfo: function(t) {
                var i = this._9j;
                this._9j = sY(t),
                this[da].add(i, this._9j, t)
            },
            _l5drag: function() {
                this.__nhancelClick = !0,
                this[Wb](),
                this[rb][ob] ? this._onEvent(this[rb], qb) : this[nb](this[rb], Xb)
            },
            _ondrag: function(t) {
                this[Vb](t),
                this[rb][ob] ? this._onEvent(t, Kb) : this[nb](t, Zb)
            },
            _enddrag: function(t) {
                if (t[Jv] - this._9j[Jv] < 100) {
                    var i = this[da][Jb]();
                    i && (t.vx = i.x, t.vy = i.y)
                }
                this[rb][ob] ? this[nb](t, Qb) : this._onEvent(t, tg),
                this[da][wf]()
            },
            _ii: function() {
                this[ig]()
            },
            _l3Status: function() {
                hY[Wv] == this && delete hY._nhurrentItem,
                this[Wb](),
                delete this._9j,
                this._l5Event && (delete this._l5Event.getData, delete this[rb][Yu], delete this[rb])
            }
        };
        var hY = A(function(t) {
            this._kt = t,
            xi[Zh](this, [t.canvasPanel, null, t])
        },
        {
            "super": xi,
            _n8Data: function(t) {
                return this._kt[ng](t)
            },
            _lp: function(t) {
                return this._kt.getUIByMouseEvent(t)
            },
            _toQEvent: function(i) {
                return (i instanceof MouseEvent || t[Hv] && i instanceof t[Hv]) && (i[eg] = this[sg].bind(this, i), i[Yu] = this._lp.bind(this, i)),
                i
            },
            _onElementRemoved: function(t) {
                this._j3Listeners(function(i) {
                    i.onElementRemoved instanceof Function && i.onElementRemoved(t, this._kt)
                })
            },
            _onElementClear: function() {
                this[hg](function(t) {
                    t[rg] instanceof Function && t[rg](this._kt)
                })
            },
            _ii: function(t) {
                this[ag] && this[og](this._21s, t),
                this[fg] && this[og](this[fg], t),
                this[ig]()
            },
            _kt: null,
            _21s: null,
            _nhustomInteractionListeners: null,
            _mzInteraction: function(t) {
                return this._21s == t ? !1 : (this[ag] && this[ag][Fh] && this[og](this._21s), void(this[ag] = t))
            },
            _n6CustomInteractionListener: function(t) {
                this[fg] || (this[fg] = []),
                this._nhustomInteractionListeners.push(t)
            },
            _kmCustomInteractionListener: function(t) {
                this._nhustomInteractionListeners && 0 != this[fg][Fh] && x(this._nhustomInteractionListeners, t)
            },
            _onEvent: function(t, i, n) {
                this._kt[i] instanceof Function && this._kt[i][zh](this._kt, t, n),
                this[ag] && this[cg](t, i, this._21s, n),
                this[fg] && this[cg](t, i, this[fg], n)
            },
            _j3Listeners: function(t) {
                this._21s && l(this[ag], t, this),
                this[fg] && l(this._nhustomInteractionListeners, t, this)
            },
            __onEvent: function(t, i, n, e) {
                if (!$(n)) return void this.__handleEvent(t, i, n, e);
                for (var s = 0; s < n[Fh]; s++) {
                    var h = n[s];
                    this[ug](t, i, h, e)
                }
            },
            __handleEvent: function(t, i, n, e) {
                if (! (n[fv] instanceof Function && n[fv](i, t, this._kt, e) === !1)) {
                    n[_g] instanceof Function && n.onevent(i, t, this._kt, e);
                    var s = n[i];
                    s instanceof Function && s[zh](n, t, this._kt, e)
                }
            },
            _iiInteraction: function(t) {
                t[dg] instanceof Function && t[dg][zh](t, this._kt)
            },
            _iiInteractions: function(t, i) {
                if (!$(t)) return void this._iiInteraction(t, i);
                for (var n = 0; n < t.length; n++) {
                    var e = t[n];
                    e && this[lg](e, i)
                }
            }
        })
    }
    Ei[Jh] = {
        limitCount: 10,
        points: null,
        add: function(t, i, n) {
            0 == this.points.length && (this[vg] = t.x, this._l5Y = t.y);
            var e = i[Jv] - t[Jv] || 1;
            n.interval = e;
            var s = i.x - t.x,
            h = i.y - t.y;
            n.dx = s,
            n.dy = h,
            n[bg] = this._l5X,
            n[gg] = this._l5Y,
            n.totalDeltaX = i.x - this._l5X,
            n[yg] = i.y - this._l5Y,
            this[ba][Uh](0, 0, {
                interval: e,
                dx: s,
                dy: h
            }),
            this[ba][Fh] > this[xg] && this[ba].pop()
        },
        getCurrentSpeed: function() {
            if (!this[ba].length) return null;
            for (var t = 0,
            i = 0,
            n = 0,
            e = 0,
            s = this.points[Fh]; s > e; e++) {
                var h = this[ba][e],
                r = h[mg];
                if (r > 150) {
                    t = 0;
                    break
                }
                if (t += r, i += h.dx, n += h.dy, t > 300) break
            }
            return 0 == t || 0 == i && 0 == n ? null: {
                x: i / t,
                y: n / t
            }
        },
        clear: function() {
            this[ba] = []
        }
    };
    var rY, aY, oY, fY;
    qF ? (rY = Eg, aY = pg, oY = wg, fY = Tg) : XF ? (rY = Og, aY = Ig, oY = Mg, fY = Ag) : (rY = jg, aY = jg, oY = U_, fY = Sg);
    var cY = Cg,
    uY = Math.PI,
    _Y = Math.pow,
    dY = Math.sin,
    lY = 1.70158,
    vY = {
        swing: function(t) {
            return - Math.cos(t * uY) / 2 + .5
        },
        easeNone: function(t) {
            return t
        },
        easeIn: function(t) {
            return t * t
        },
        easeOut: function(t) {
            return (2 - t) * t
        },
        easeBoth: function(t) {
            return (t *= 2) < 1 ? .5 * t * t: .5 * (1 - --t * (t - 2))
        },
        easeInStrong: function(t) {
            return t * t * t * t
        },
        easeOutStrong: function(t) {
            return 1 - --t * t * t * t
        },
        easeBothStrong: function(t) {
            return (t *= 2) < 1 ? .5 * t * t * t * t: .5 * (2 - (t -= 2) * t * t * t)
        },
        elasticIn: function(t) {
            var i = .3,
            n = i / 4;
            return 0 === t || 1 === t ? t: -(_Y(2, 10 * (t -= 1)) * dY(2 * (t - n) * uY / i))
        },
        elasticOut: function(t) {
            var i = .3,
            n = i / 4;
            return 0 === t || 1 === t ? t: _Y(2, -10 * t) * dY(2 * (t - n) * uY / i) + 1
        },
        elasticBoth: function(t) {
            var i = .45,
            n = i / 4;
            return 0 === t || 2 === (t *= 2) ? t: 1 > t ? -.5 * _Y(2, 10 * (t -= 1)) * dY(2 * (t - n) * uY / i) : _Y(2, -10 * (t -= 1)) * dY(2 * (t - n) * uY / i) * .5 + 1
        },
        backIn: function(t) {
            return 1 === t && (t -= .001),
            t * t * ((lY + 1) * t - lY)
        },
        backOut: function(t) {
            return (t -= 1) * t * ((lY + 1) * t + lY) + 1
        },
        backBoth: function(t) {
            return (t *= 2) < 1 ? .5 * t * t * (((lY *= 1.525) + 1) * t - lY) : .5 * ((t -= 2) * t * (((lY *= 1.525) + 1) * t + lY) + 2)
        },
        bounceIn: function(t) {
            return 1 - vY[kg](1 - t)
        },
        bounceOut: function(t) {
            var i, n = 7.5625;
            return i = 1 / 2.75 > t ? n * t * t: 2 / 2.75 > t ? n * (t -= 1.5 / 2.75) * t + .75 : 2.5 / 2.75 > t ? n * (t -= 2.25 / 2.75) * t + .9375 : n * (t -= 2.625 / 2.75) * t + .984375
        },
        bounceBoth: function(t) {
            return.5 > t ? .5 * vY[Lg](2 * t) : .5 * vY[kg](2 * t - 1) + .5
        }
    },
    bY = function(t) {
        this._jv = t
    };
    bY.prototype = {
        _jv: null,
        _82: function() {
            this[Pg] instanceof Function && (this[Pg](), this[Pg] = null)
        },
        _l5: function(t) {
            var i = Date.now();
            this._mj(),
            this[Pg] = t,
            this[Rg] = requestAnimationFrame(function n() {
                var t = Date.now(),
                e = t - i;
                return ! e || this._jv && this._jv(e) !== !1 ? (i = t, void(this[Rg] = requestAnimationFrame(n[fr](this)))) : void this._mj()
            } [fr](this))
        },
        _6r: function() {},
        _mj: function() {
            return this[Rg] ? (this._6r(), this._82(), t[jd](this._requestID), void delete this[Rg]) : !1
        },
        _e9: function() {
            return null != this[Rg]
        }
    };
    var gY = function(t, i, n, e) {
        this[Dg] = t,
        this[ua] = i || this,
        this._39 = e,
        n && n > 0 && (this._ib = n)
    };
    gY[Jh] = {
        _ib: 1e3,
        _39: null,
        _et: 0,
        _mj: function() {
            return this._et = 0,
            this[Ng] = 0,
            T(this, gY, Bg)
        },
        _nht: 0,
        _jv: function(t) {
            if (this._et += t, this._et >= this._ib) return this[Dg][zh](this._scope, 1, (1 - this[Ng]) * this._ib, t, this._ib),
            !1;
            var i = this._et / this._ib;
            return this._39 && (i = this._39(i)),
            this[Dg][zh](this[ua], i, (i - this[Ng]) * this._ib, t, this._ib) === !1 ? !1 : void(this._nht = i)
        }
    },
    p(gY, bY);
    var yY = function(t) {
        ni(t)
    },
    xY = {
        version: $g,
        extend: p,
        doSuperConstructor: w,
        doSuper: T,
        createFunction: function(t, i) {
            return i.bind(t)
        },
        setClass: L,
        appendClass: P,
        removeClass: R,
        forEach: l,
        forEachReverse: b,
        isNumber: D,
        isString: N,
        isBoolean: B,
        isArray: $,
        eventPreventDefault: G,
        eventStopPropagation: F,
        stopEvent: z,
        callLater: C,
        nextFrame: k,
        forEachChild: e,
        forEachByDepthFirst: h,
        forEachByDepthFirstReverse: o,
        forEachByBreadthFirst: u,
        randomInt: Y,
        randomBool: H,
        randomColor: W,
        addEventListener: zz,
        getFirstElementChildByTagName: az
    };
    xY[Gg] = nz,
    xY.isIOS = QF,
    xY.intersectsPoint = ri,
    xY[Fg] = ai,
    xY.Rect = _z,
    xY[zg] = uz,
    xY.Point = oz,
    xY[Yg] = dz,
    xY[Hg] = wz,
    xY[Ug] = Tz,
    xY[Wg] = Lz,
    xY[qg] = jz,
    xY[Xg] = Sz,
    xY[Vg] = lz,
    xY[Kg] = Pz,
    xY[Zg] = Nz,
    xY[Jg] = Dz,
    xY[Qg] = kz,
    xY[ty] = Ti,
    xY.loadXML = pi,
    xY[iy] = wi,
    xY[ny] = mi,
    xY[ey] = fz,
    xY[sy] = hz,
    xY[hy] = xi,
    xY[ry] = function(t) {
        alert(t)
    },
    xY[ay] = function(t, i, n, e) {
        var s = prompt(t, i);
        return s != i && n ? n[zh](e, s) : s
    },
    xY[oy] = function(t, i, n) {
        var e = confirm(t);
        return e && i ? i.call(n) : e
    },
    xY.addCSSRule = gi;
    var mY = {
        IMAGE_ADJUST_FLIP: fy,
        IMAGE_ADJUST_MIRROR: cy,
        SELECTION_TYPE_BORDER_RECT: uy,
        SELECTION_TYPE_BORDER: _y,
        SELECTION_TYPE_SHADOW: dy,
        NS_SVG: "http://www.w3.org/2000/svg",
        PROPERTY_TYPE_ACCESSOR: 0,
        PROPERTY_TYPE_STYLE: 1,
        PROPERTY_TYPE_CLIENT: 2,
        EDGE_TYPE_DEFAULT: null,
        EDGE_TYPE_ELBOW: ly,
        EDGE_TYPE_ELBOW_HORIZONTAL: vy,
        EDGE_TYPE_ELBOW_VERTICAL: by,
        EDGE_TYPE_ORTHOGONAL: gy,
        EDGE_TYPE_ORTHOGONAL_HORIZONTAL: yy,
        EDGE_TYPE_ORTHOGONAL_VERTICAL: xy,
        EDGE_TYPE_HORIZONTAL_VERTICAL: my,
        EDGE_TYPE_VERTICAL_HORIZONTAL: Ey,
        EDGE_TYPE_EXTEND_TOP: py,
        EDGE_TYPE_EXTEND_LEFT: wy,
        EDGE_TYPE_EXTEND_BOTTOM: Ty,
        EDGE_TYPE_EXTEND_RIGHT: Oy,
        EDGE_TYPE_ZIGZAG: Iy,
        EDGE_CORNER_NONE: __,
        EDGE_CORNER_ROUND: eo,
        EDGE_CORNER_BEVEL: My,
        GROUP_TYPE_RECT: vc,
        GROUP_TYPE_CIRCLE: Ay,
        GROUP_TYPE_ELLIPSE: jy,
        SHAPE_CIRCLE: Sy,
        SHAPE_RECT: vc,
        SHAPE_ROUNDRECT: Cy,
        SHAPE_STAR: ky,
        SHAPE_TRIANGLE: Ly,
        SHAPE_HEXAGON: Py,
        SHAPE_PENTAGON: Ry,
        SHAPE_TRAPEZIUM: Dy,
        SHAPE_RHOMBUS: Ny,
        SHAPE_PARALLELOGRAM: By,
        SHAPE_HEART: $y,
        SHAPE_DIAMOND: Gy,
        SHAPE_CROSS: Fy,
        SHAPE_ARROW_STANDARD: zy,
        SHAPE_ARROW_1: Yy,
        SHAPE_ARROW_2: Hy,
        SHAPE_ARROW_3: Uy,
        SHAPE_ARROW_4: Wy,
        SHAPE_ARROW_5: qy,
        SHAPE_ARROW_6: Xy,
        SHAPE_ARROW_7: Vy,
        SHAPE_ARROW_8: Ky,
        SHAPE_ARROW_OPEN: Zy
    };
    mY[Jy] = Qy,
    mY.LINE_CAP_TYPE_ROUND = eo,
    mY.LINE_CAP_TYPE_SQUARE = tx,
    mY[ix] = My,
    mY.LINE_JOIN_TYPE_ROUND = eo,
    mY[nx] = ex,
    sz[sx] = mY[hx],
    sz[rx] = qz ? 8 : 3,
    sz.SELECTION_BORDER = 2,
    sz[ax] = 7,
    sz[ox] = V(3422561023),
    sz[sx] = mY.SELECTION_TYPE_SHADOW,
    sz[fx] = 10,
    sz.POINTER_WIDTH = 10,
    sz[Ru] = 10,
    sz.IMAGE_MAX_SIZE = 200,
    sz.LINE_HEIGHT = 1.2;
    var EY = t.devicePixelRatio || 1;
    1 > EY && (EY = 1);
    var pY;
    xY[cx] = ki;
    var wY = function(t, i, n, e) {
        var s = t - n,
        h = i - e;
        return s * s + h * h
    };
    Zi[Jh] = {
        equals: function(t) {
            return this.cx == t.cx && this.cy == t.cy && this.r == t.r
        }
    },
    Zi[Qa] = function(t, i, n) {
        if (!n) return Vi(t, i);
        var e = wY(t.x, t.y, i.x, i.y),
        s = wY(t.x, t.y, n.x, n.y),
        h = wY(n.x, n.y, i.x, i.y);
        if (e + TY >= s + h) return Vi(t, i, 0, n);
        if (s + TY >= e + h) return Vi(t, n, 0, i);
        if (h + TY >= e + s) return Vi(i, n, 0, t);
        var r;
        Math.abs(n.y - i.y) < 1e-4 && (r = t, t = i, i = r),
        r = n.x * (t.y - i.y) + t.x * (i.y - n.y) + i.x * ( - t.y + n.y);
        var a = (n.x * n.x * (t.y - i.y) + (t.x * t.x + (t.y - i.y) * (t.y - n.y)) * (i.y - n.y) + i.x * i.x * ( - t.y + n.y)) / (2 * r),
        o = (i.y + n.y) / 2 - (n.x - i.x) / (n.y - i.y) * (a - (i.x + n.x) / 2);
        return new Zi(a, o, fz(a, o, t.x, t.y), t, i, n)
    };
    var TY = .01,
    OY = {
        _ng9: function(t, i, e, s, h) {
            if (N(t) && (t = lz.fromString(t)), !t) return {
                x: 0,
                y: 0
            };
            var r = 0,
            a = 0,
            o = i._jb;
            if (e = e || 0, t.x === n) {
                var f = t[Yr],
                c = t[Hr],
                u = !0;
                switch (f) {
                case gz:
                    u = !1;
                    break;
                case bz:
                    r += o / 2
                }
                switch (c) {
                case yz:
                    a -= e / 2;
                    break;
                case mz:
                    a += e / 2
                }
            } else r = t.x,
            a = t.y,
            Math.abs(r) > 0 && Math.abs(r) < 1 && (r *= o);
            h && null != s && (a += s.y, r += Math.abs(s.x) < 1 ? s.x * o: s.x);
            var _ = rn[zh](i, r, a, u);
            return _ ? (h || null == s || _.offset(s), _) : {
                x: 0,
                y: 0
            }
        },
        _lt: function(t, i) {
            var n = i.type,
            e = i[ba];
            switch (n) {
            case ZY:
                t[ux](e[0], e[1], e[2], e[3], i._r);
                break;
            case qY:
                t.moveTo(e[0], e[1]);
                break;
            case XY:
                t.lineTo(e[0], e[1]);
                break;
            case VY:
                t.quadraticCurveTo(e[0], e[1], e[2], e[3]);
                break;
            case KY:
                t.bezierCurveTo(e[0], e[1], e[2], e[3], e[4], e[5]);
                break;
            case JY:
                t.closePath()
            }
        },
        _5a: function(t, i, n, e) {
            var s = i.type;
            if (s != qY && s != JY) {
                var h = n[oo],
                r = i[ba];
                switch (n[fo] == qY && t.add(h.x, h.y), s) {
                case ZY:
                    fn(i, h.x, h.y, r[0], r[1], r[2], r[3], r[4]),
                    t.add(r[0], r[1]),
                    t.add(i[bo], i[go]),
                    t.add(i._p2x, i._p2y),
                    i[_x] && t.add(i[_x].x, i[_x].y),
                    i[dx] && t.add(i.$boundaryPoint2.x, i[dx].y);
                    break;
                case XY:
                    t.add(r[0], r[1]);
                    break;
                case VY:
                    Gi([h.x, h.y][co](r), t);
                    break;
                case KY:
                    Ui([h.x, h.y][co](r), t);
                    break;
                case JY:
                    e && t.add(e[ba][0], e[ba][1])
                }
            }
        },
        _58: function(t, i, n) {
            var e = t[fo];
            if (e == qY) return 0;
            var s = i[oo],
            h = t[ba];
            switch (e == KY && 4 == h.length && (e = VY), e) {
            case XY:
                return fz(h[0], h[1], s.x, s.y);
            case ZY:
                return t._jb;
            case VY:
                var r = zi([s.x, s.y].concat(h));
                return t._lf = r,
                r(1);
            case KY:
                var r = qi([s.x, s.y][co](h));
                return t._lf = r,
                r(1) || Wi([s.x, s.y][co](h));
            case JY:
                if (s && n) return t[ba] = n[ba],
                fz(n.points[0], n[ba][1], s.x, s.y)
            }
            return 0
        }
    },
    IY = /^data:image\/(\w+);base64,/i,
    MY = /^gif/i,
    AY = /^svg/i,
    jY = 10,
    SY = 11,
    CY = 12,
    kY = 20,
    LY = 30;
    sz[Oo] = 50,
    sz[Io] = 30,
    sz[lx] = 1e6;
    var PY = 1,
    RY = 2,
    DY = 3;
    ln.prototype = {
        _jm: 0,
        _6h: !0,
        _l7: null,
        _j8: null,
        _mn: null,
        _lr: null,
        _neu: n,
        _8z: n,
        _6j: function() {
            return this._jm == PY
        },
        getBounds: function(t) {
            return this._lr == LY ? this._mn[io](t) : (this._6h && this._fv(), this)
        },
        validate: function() {
            this._6h && this._fv()
        },
        _fv: function() {
            if (this._6h = !1, this._lr == LY) return this._mn.validate(),
            void this[vx](this._mn.bounds);
            if (this._lr == kY) return void this._94();
            if (this._jm != PY) try {
                this._e4()
            } catch(t) {
                this._jm = DY,
                xY.error(t)
            }
        },
        _51: function() {
            this._dt(),
            this[bx].clear(),
            delete this[bx]
        },
        _iy: function(t) {
            this._l7 && this._l7.parentNode && this._l7[gx].removeChild(this._l7),
            this._jm = DY,
            xY[Po](yx + this._mn),
            this[xx] = null,
            this._j8 = null,
            this._l7 = null,
            t !== !1 && this._51()
        },
        _e4: function() {
            var t = this._mn;
            if (this._jm = PY, this[bx] = new Sz, this._lr == CY) {
                for (var n in oH) this[n] = oH[n];
                return void Wn(this._mn, this, this[mx], this._iy, this._fh)
            }
            this._l7 || (this._l7 = i[Ga](e_), HF && (this._l7[ta][Ex] = u_, i[px].appendChild(this._l7))),
            this._l7.src = t,
            this._l7[Sa] && (this[Sa] = this._l7.width, this[Ca] = this._l7.height),
            this._l7[wx] = HF ?
            function(t) {
                setTimeout(this._89[fr](this, t), 100)
            } [fr](this) : this._89.bind(this),
            this._l7[Tx] = this._iy.bind(this)
        },
        _89: function() {
            this._jm = RY;
            var t = this._l7[Sa],
            i = this._l7[Ca];
            if (this._l7[gx] && this._l7[gx][Ox](this._l7), !t || !i) return void this._iy();
            this[Sa] = t,
            this[Ca] = i;
            var n = this._dq();
            n.width = t,
            n[Ca] = i,
            n.g[Ix](this._l7, 0, 0, t, i),
            this[xx] = HF && this._lr == SY ? null: En(n),
            this._51()
        },
        _94: function() {
            var t = this._mn;
            if (! (t.draw instanceof Function)) return void this._iy(!1);
            if (t[Mx] === !1 && t[Sa] && t[Ca]) return this.width = t[Sa],
            void(this[Ca] = t.height);
            var i = t[Sa] || sz[Ax],
            n = t[Ca] || sz.IMAGE_MAX_SIZE,
            e = this._dq();
            e[Sa] = i,
            e.height = n;
            var s = e.g;
            t.draw(s);
            var h = Ri(s, 0, 0, i, n);
            if (h) {
                var r = wn(h[ao], i, n);
                this.x = r._x,
                this.y = r._y,
                this[Sa] = r[jx],
                this[Ca] = r[Sx],
                e[Sa] = this[Sa],
                e[Ca] = this[Ca],
                s[Ho](h, -this.x, -this.y),
                this[xx] = r
            }
        },
        _dq: function() {
            return this._j8 || (this._j8 = ki())
        },
        _6o: function(t, i, n, e, s, h) {
            i[Cx](),
            i[vc](0, 0, e, s),
            i[kx] = h || Lx,
            i.fill(),
            i[Px](),
            i.textAlign = Vu,
            i.textBaseline = Rx,
            i[kx] = A_;
            var r = 6 * (i.canvas.ratio || 1);
            i.font = Dx + r + "px Verdana,helvetica,arial,sans-serif",
            i[O_] = I_,
            i.lineWidth = 1,
            i[Nx](t, e / 2 + .5, s / 2 + .5),
            i[O_] = Bx,
            i.strokeText(t, e / 2 - .5, s / 2 - .5),
            i[$x](t, e / 2, s / 2),
            i.restore()
        },
        draw: function(t, i, n, e, s, h) {
            if (this[Sa] && this.height) {
                i = i || 1,
                e = e || 1,
                s = s || 1;
                var r = this[Sa] * e,
                a = this[Ca] * s;
                if (h && n[M_] && (t[M_] = n[M_], t.shadowBlur = (n[j_] || 0) * i, t[Gx] = (n.shadowOffsetX || 0) * i, t[Fx] = (n[Fx] || 0) * i), this._jm == PY) return this._6o(zx, t, i, r, a, n.renderColor);
                if (this._jm == DY) return this._6o(Yx, t, i, r, a, n[Hx]);
                if (this._lr == LY) return t[p_](e, s),
                void this._mn[wo](t, i, n);
                var o = this._g3(i, e, s);
                return o ? ((this.x || this.y) && t[Ux](this.x * e, this.y * s), t[p_](e / o[p_], s / o.scale), void o._lt(t, n[Hx], n[Wx])) : void this._j9(t, i, e, s, this[Sa] * e, this[Ca] * s, n)
            }
        },
        _j9: function(t, i, n, e, s, h, r) {
            if (this._lr == kY) return 1 != n && 1 != e && t[p_](n, e),
            void this._mn[wo](t, r);
            if (this._l7) {
                if (!VF) return void t.drawImage(this._l7, 0, 0, s, h);
                var n = i * s / this.width,
                e = i * h / this[Ca];
                t.scale(1 / n, 1 / e),
                t[Ix](this._l7, 0, 0, s * n, h * e)
            }
        },
        _jn: null,
        _g3: function(t, i, n) {
            if (this._lr == kY && this._mn[Mx] === !1) return null;
            if (this._lr == jY || (t *= Math.max(i, n)) <= 1) return this[qx] || (this[qx] = this._g4(this._j8 || this._l7, 1)),
            this[qx];
            var e = this._jn[Xx] || 0;
            if (t = Math.ceil(t), e >= t) {
                for (var s = t,
                h = this._jn[s]; ! h && ++s <= e;) h = this._jn[s];
                if (h) return h
            }
            t % 2 && t++;
            var r = this[Sa] * t,
            a = this.height * t;
            if (r * a > sz[lx]) return null;
            var o = ki(r, a);
            return (this.x || this.y) && o.g[Ux]( - this.x * t, -this.y * t),
            this._j9(o.g, 1, t, t, r, a),
            this._g4(o, t)
        },
        _g4: function(t, i) {
            var n = new nH(t, i);
            return this._jn[i] = n,
            this._jn[Xx] = i,
            n
        },
        hitTest: function(t, i, n) {
            if (this._lr == LY) return this._mn[Zu][Zh](this._mn, arguments);
            if (! (this[xx] || this._l7 && this._l7[xx])) return ! 0;
            var e = this._pixels || this._l7._pixels;
            return e._ik(t, i, n)
        },
        _dt: function() {
            this._dispatcher && this._dispatcher.onEvent(new wz(this, Vx, Kx, this._l7))
        },
        _neh: function(t, i) {
            this._dispatcher && this[bx][gv](t, i)
        },
        _6z: function(t, i) {
            this._dispatcher && this[bx].removeListener(t, i)
        },
        _ngz: function(t) {
            this._jn = {},
            (t || this[Sa] * this[Ca] > 1e5) && (this._l7 = null, this._j8 = null)
        }
    },
    p(ln, _z);
    var NY = {};
    xY.drawImage = xn,
    xY[Zx] = vn,
    xY[Jx] = gn,
    xY[Qx] = function() {
        var t = [];
        for (var i in NY) t[Xh](i);
        return t
    };
    var BY = function(t, i, n, e, s, h) {
        this.type = t,
        this[tm] = i,
        this[im] = n,
        this[Xu] = e || 0,
        this.tx = s || 0,
        this.ty = h || 0
    };
    mY[nm] = _l,
    mY.GRADIENT_TYPE_LINEAR = cl,
    BY[Jh] = {
        type: null,
        colors: null,
        positions: null,
        angle: null,
        tx: 0,
        ty: 0,
        position: lz[yl],
        isEmpty: function() {
            return null == this[tm] || 0 == this[tm][Fh]
        },
        _79: function() {
            var t = this[tm][Fh];
            if (1 == t) return [0];
            for (var i = [], n = 1 / (t - 1), e = 0; t > e; e++) i[Xh](n * e);
            return this.positions || (this[im] = i),
            i
        },
        generatorGradient: function(t) {
            if (null == this[tm] || 0 == this.colors[Fh]) return null;
            var i, n = Pi();
            if (this.type == mY.GRADIENT_TYPE_LINEAR) {
                var e = this.angle;
                e > Math.PI && (e -= Math.PI);
                var s;
                if (e <= Math.PI / 2) {
                    var h = Math.atan2(t[Ca], t[Sa]),
                    r = Math[Ka](t.width * t[Sa] + t[Ca] * t.height),
                    a = h - e;
                    s = Math.cos(a) * r
                } else {
                    var h = Math[Va](t.width, t[Ca]),
                    r = Math.sqrt(t[Sa] * t.width + t[Ca] * t[Ca]),
                    a = h - (e - Math.PI / 2);
                    s = Math.cos(a) * r
                }
                var o = s / 2,
                f = o * Math.cos(e),
                c = o * Math.sin(e),
                u = t.x + t.width / 2 - f,
                _ = t.y + t[Ca] / 2 - c,
                d = t.x + t[Sa] / 2 + f,
                l = t.y + t[Ca] / 2 + c;
                i = n.createLinearGradient(u, _, d, l)
            } else {
                if (! (this[fo] = mY[nm])) return null;
                var v = fi(this[Of], t[Sa], t.height);
                v.x += t.x,
                v.y += t.y,
                this.tx && (v.x += Math.abs(this.tx) < 1 ? t.width * this.tx: this.tx),
                this.ty && (v.y += Math.abs(this.ty) < 1 ? t.height * this.ty: this.ty);
                var b = fz(v.x, v.y, t.x, t.y);
                b = Math.max(b, fz(v.x, v.y, t.x, t.y + t[Ca])),
                b = Math.max(b, fz(v.x, v.y, t.x + t[Sa], t.y + t[Ca])),
                b = Math.max(b, fz(v.x, v.y, t.x + t.width, t.y)),
                i = n[em](v.x, v.y, 0, v.x, v.y, b)
            }
            var g = this[tm],
            y = this.positions;
            y && y.length == g[Fh] || (y = this._79());
            for (var x = 0,
            m = g[Fh]; m > x; x++) i.addColorStop(y[x], g[x]);
            return i
        }
    };
    var $Y = new BY(mY[sm], [V(2332033023), V(1154272460), V(1154272460), V(1442840575)], [.1, .3, .7, .9], Math.PI / 2),
    GY = new BY(mY[sm], [V(2332033023), V(1154272460), V(1154272460), V(1442840575)], [.1, .3, .7, .9], 0),
    FY = (new BY(mY[sm], [V(1154272460), V(1442840575)], [.1, .9], 0), new BY(mY[nm], [V(2298478591), V(1156509422), V(1720223880), V(1147561574)], [.1, .3, .7, .9], 0, -.3, -.3)),
    zY = [V(0), V(4294901760), V(4294967040), V(4278255360), V(4278250239), V(4278190992), V(4294901958), V(0)],
    YY = [0, .12, .28, .45, .6, .75, .8, 1],
    HY = new BY(mY[sm], zY, YY),
    UY = new BY(mY[sm], zY, YY, Math.PI / 2),
    WY = new BY(mY[nm], zY, YY);
    BY[hm] = $Y,
    BY.LINEAR_GRADIENT_HORIZONTAL = GY,
    BY[rm] = FY,
    BY.RAINBOW_LINEAR_GRADIENT = HY,
    BY[am] = UY,
    BY[om] = WY;
    var qY = dl,
    XY = cl,
    VY = fm,
    KY = ul,
    ZY = cm,
    JY = um;
    mY[_m] = qY,
    mY[dm] = XY,
    mY[lm] = VY,
    mY[vm] = KY,
    mY[bm] = ZY,
    mY[gm] = JY;
    var QY = function(t, i) {
        this.id = ++FF,
        $(t) ? this.points = t: (this.type = t, this.points = i)
    };
    QY[Jh] = {
        toJSON: function() {
            var t = {
                type: this[fo],
                points: this[ba]
            };
            return this[Nu] && (t.invalidTerminal = !0),
            t
        },
        parseJSON: function(t) {
            this[fo] = t[fo],
            this.points = t.points,
            this.invalidTerminal = t.invalidTerminal
        },
        points: null,
        type: XY,
        clone: function() {
            return new QY(this[fo], this[ba] ? g(this[ba]) : null)
        },
        move: function(t, i) {
            if (this.points) for (var n = 0,
            e = this.points[Fh]; e > n; n++) {
                var s = this.points[n];
                xY.isNumber(s) && (this.points[n] += n % 2 == 0 ? t: i)
            }
        }
    },
    Z(QY[Jh], {
        lastPoint: {
            get: function() {
                return this[fo] == ZY ? {
                    x: this[_o],
                    y: this[lo]
                }: {
                    x: this[ba][this[ba][Fh] - 2],
                    y: this[ba][this[ba].length - 1]
                }
            }
        },
        firstPoint: {
            get: function() {
                return {
                    x: this[ba][0],
                    y: this[ba][1]
                }
            }
        }
    }),
    xY[ym] = QY;
    var tH = 0,
    iH = function(t) {
        this.bounds = new _z,
        this._fx = t || []
    };
    iH[Jh] = {
        toJSON: function() {
            var t = [];
            return this._fx[Wf](function(i) {
                t[Xh](i[xm]())
            }),
            t
        },
        parseJSON: function(t) {
            var i = this._fx;
            t[Wf](function(t) {
                i[Xh](new QY(t.type, t[ba]))
            })
        },
        clear: function() {
            this._fx[Fh] = 0,
            this[no][wf](),
            this._jb = 0,
            this._6h = !0
        },
        _dv: !0,
        _7f: function(t, i) {
            this._dv && 0 === this._fx.length && t != qY && this._fx.push(new QY(qY, [0, 0])),
            this._fx[Xh](new QY(t, i)),
            this._6h = !0
        },
        add: function(t) {
            this._fx[Xh](t),
            this._6h = !0
        },
        removePathSegment: function(t) {
            return t >= this._fx[Fh] ? !1 : (this._fx[Uh](t, 1), void(this._6h = !0))
        },
        moveTo: function(t, i) {
            this._7f(qY, [t, i])
        },
        lineTo: function(t, i) {
            this._7f(XY, [t, i])
        },
        quadTo: function(t, i, n, e) {
            this._7f(VY, [t, i, n, e])
        },
        curveTo: function(t, i, n, e, s, h) {
            this._7f(KY, [t, i, n, e, s, h])
        },
        arcTo: function(t, i, n, e, s) {
            this._7f(ZY, [t, i, n, e, s])
        },
        closePath: function() {
            this._7f(JY)
        },
        _7t: function(t, i, n, e, s) {
            if (e[mm]) {
                if (n == mY[hx]) {
                    if (!e[Em]) return;
                    return t[M_] = e[mm],
                    t.shadowBlur = e[Em] * i,
                    t[Gx] = (e[pm] || 0) * i,
                    void(t.shadowOffsetY = (e[wm] || 0) * i)
                }
                if (n == mY[Tm]) {
                    if (!e.selectionBorder) return;
                    t.strokeStyle = e[mm],
                    t.lineWidth = e.selectionBorder + (s.lineWidth || 0),
                    this._lt(t),
                    t.stroke()
                }
            }
        },
        _6h: !0,
        _fx: null,
        _jb: 0,
        lineCap: Qy,
        lineJoin: eo,
        draw: function(t, i, n, e, s) {
            t.lineCap = n[w_] || this[w_],
            t[T_] = n.lineJoin || this[T_],
            e && (s || (s = n), this._7t(t, i, s[Om], s, n)),
            n[Im] && (this._lt(t), t[jf] = n[jf] + 2 * (n[Mm] || 0), t[O_] = n[Im], t[ho]()),
            t[jf] = 0,
            this._lt(t),
            n.fillColor && (t[kx] = n.renderColor || n[Am], t[ro]()),
            n.fillGradient && (t[kx] = n[jm] || n[Sm], t[ro]()),
            n.lineWidth && (t[jf] = n.lineWidth, n[Lf] && (t.lineDash = n.lineDash, t[Bf] = n[Bf]), t[O_] = n[Hx] || n.strokeStyle, t[ho](), t[Lf] = [])
        },
        _lt: function(t) {
            t[Cm]();
            for (var i, n, e = 0,
            s = this._fx[Fh]; s > e; e++) i = this._fx[e],
            OY._lt(t, i, n),
            n = i
        },
        invalidate: function() {
            this._6h = !0
        },
        validate: function() {
            if (this._6h = !1, this[no][wf](), this._jb = 0, 0 != this._fx.length) for (var t, i, n = this._fx,
            e = 1,
            s = n[0], h = s, r = n.length; r > e; e++) t = n[e],
            t.type == qY ? h = t: (OY._5a(this.bounds, t, s, h), i = OY._58(t, s, h), t._jb = i, this._jb += i),
            s = t
        },
        getBounds: function(t, i) {
            if (this._6h && this[to](), i = i || new _z, t) {
                var n = t / 2;
                i.set(this.bounds.x - n, this[no].y - n, this[no].width + t, this[no][Ca] + t)
            } else i.set(this[no].x, this[no].y, this[no].width, this[no][Ca]);
            return i
        },
        hitTest: function(t, i, n, e, s, h) {
            return hn.call(this, t, i, n, e, s, h)
        },
        toSegments: function() {
            return [][co](this._fx)
        },
        generator: function(t, i, n, e, s) {
            return sn[zh](this, t, i, n, e, s)
        },
        getLocation: function(t, i) {
            return rn[zh](this, t, i || 0)
        }
    },
    Z(iH[Jh], {
        segments: {
            get: function() {
                return this._fx
            },
            set: function(t) {
                this[wf](),
                this._fx = t
            }
        },
        length: {
            get: function() {
                return this._6h && this.validate(),
                this._jb
            }
        },
        _empty: {
            get: function() {
                return 0 == this._fx[Fh]
            }
        }
    }),
    pn.prototype = {
        _12: function(t, i) {
            var n, e, s, h, r, a = t[Fh],
            o = 0,
            f = 0;
            for (r = 0; a > r; r += 4) if (t[r + 3] > 0) {
                n = (r + 4) / i / 4 | 0;
                break
            }
            for (r = a - 4; r >= 0; r -= 4) if (t[r + 3] > 0) {
                e = (r + 4) / i / 4 | 0;
                break
            }
            for (o = 0; i > o; o++) {
                for (f = n; e > f; f++) if (t[f * i * 4 + 4 * o + 3] > 0) {
                    s = o;
                    break
                }
                if (s >= 0) break
            }
            for (o = i - 1; o >= 0; o--) {
                for (f = n; e > f; f++) if (t[f * i * 4 + 4 * o + 3] > 0) {
                    h = o;
                    break
                }
                if (h >= 0) break
            }
            this._x = s,
            this._y = n,
            this._width = h - s + 1,
            this[Sx] = e - n + 1,
            this._ji = new _z(s, n, this[jx], this[Sx]),
            this._pixelSize = this._width * this[Sx],
            this[km] = i,
            this[Lm] = t
        },
        _fd: function(t, i) {
            return this._originalPixels[4 * (t + this._x + (this._y + i) * this[km]) + 3]
        },
        _ik: function(t, i, n) { (!n || 1 >= n) && (n = 1),
            n = 0 | n,
            t = Math[eo](t - this._x) - n,
            i = Math[eo](i - this._y) - n,
            n += n;
            for (var e = t,
            s = i; i + n > s;) {
                for (var e = t; t + n > e;) {
                    if (this._fd(e, s)) return ! 0; ++e
                }++s
            }
            return ! 1
        }
    },
    mY[No] = Pm,
    mY[Rm] = Dm,
    mY[Bo] = Nm,
    mY.BLEND_MODE_LINEAR_BURN = Bm,
    mY.BLEND_MODE_LIGHTEN = $m,
    mY[Go] = Gm,
    mY[Yo] = Fm,
    sz[zm] = mY[$o];
    var nH = function(t, i, n) {
        this._j8 = t,
        this[p_] = i || 1,
        t instanceof Image && (n = !1),
        this._ix = n
    };
    nH.prototype = {
        scale: 1,
        _j8: null,
        _jn: null,
        _ix: !0,
        _lt: function(t, i, n) {
            if (!i || this._ix === !1) return void t.drawImage(this._j8, 0, 0);
            this._jn || (this._jn = {});
            var e = i + n,
            s = this._jn[e];
            if (s || (s = In(this._j8, i, n), s || (this._ix = !1), this._jn[e] = s || this._j8), s) if (HF) try {
                t[Ix](s, 0, 0)
            } catch(h) {} else t.drawImage(s, 0, 0)
        }
    };
    var eH = function(t, i, n, e, s, h, r, a, o) {
        this._mm = Sn(t, i, n, e, s, h, r, a, o)
    },
    sH = {
        server: {
            draw: function(t) {
                t[Cx](),
                t[Ux](0, 0),
                t[Cm](),
                t[Pc](0, 0),
                t.lineTo(40, 0),
                t[Rc](40, 40),
                t[Rc](0, 40),
                t.closePath(),
                t[Px](),
                t[Ux](0, 0),
                t[Ux](0, 0),
                t[p_](1, 1),
                t[Ux](0, 0),
                t.strokeStyle = Ym,
                t[w_] = Qy,
                t[T_] = ex,
                t[Hm] = 4,
                t.save(),
                t[Cx](),
                t.restore(),
                t.save(),
                t.restore(),
                t[Cx](),
                t[Um](),
                t[Cx](),
                t.restore(),
                t[Cx](),
                t[Um](),
                t[Cx](),
                t[Um](),
                t.save(),
                t[Um](),
                t[Cx](),
                t[Um](),
                t.save(),
                t[Um](),
                t.save(),
                t[Um](),
                t.save(),
                t[Um](),
                t[Cx](),
                t.restore(),
                t.save(),
                t[Um](),
                t[Um](),
                t[Cx]();
                var i = t[Wm](6.75, 3.9033, 30.5914, 27.7447);
                i[qm](.0493, Xm),
                i[qm](.0689, Vm),
                i[qm](.0939, Km),
                i.addColorStop(.129, Zm),
                i[qm](.2266, Jm),
                i.addColorStop(.2556, Qm),
                i[qm](.2869, tE),
                i.addColorStop(.3194, iE),
                i[qm](.3525, nE),
                i[qm](.3695, eE),
                i.addColorStop(.5025, sE),
                i[qm](.9212, hE),
                i.addColorStop(1, rE),
                t[kx] = i,
                t[Cm](),
                t[Pc](25.677, 4.113),
                t[aE](25.361, 2.4410000000000007, 23.364, 2.7940000000000005, 22.14, 2.7990000000000004),
                t[aE](19.261, 2.813, 16.381, 2.8260000000000005, 13.502, 2.8400000000000003),
                t[aE](12.185, 2.846, 10.699000000000002, 2.652, 9.393, 2.8790000000000004),
                t[aE](9.19, 2.897, 8.977, 2.989, 8.805, 3.094),
                t.bezierCurveTo(8.084999999999999, 3.5109999999999997, 7.436999999999999, 4.1259999999999994, 6.776, 4.63),
                t.bezierCurveTo(5.718999999999999, 5.436, 4.641, 6.22, 3.6029999999999998, 7.05),
                t[aE](4.207, 6.5889999999999995, 21.601999999999997, 36.579, 21.028, 37.307),
                t[aE](22.019, 36.063, 23.009999999999998, 34.819, 24.000999999999998, 33.575),
                t.bezierCurveTo(24.587999999999997, 32.84, 25.589999999999996, 31.995000000000005, 25.593999999999998, 30.983000000000004),
                t[aE](25.595999999999997, 30.489000000000004, 25.598, 29.994000000000003, 25.601, 29.500000000000004),
                t.bezierCurveTo(25.612, 26.950000000000003, 25.622, 24.400000000000006, 25.633, 21.85),
                t[aE](25.657, 16.318, 25.680999999999997, 10.786000000000001, 25.704, 5.253),
                t[aE](25.706, 4.885, 25.749, 4.478, 25.677, 4.113),
                t.bezierCurveTo(25.67, 4.077, 25.697, 4.217, 25.677, 4.113),
                t.closePath(),
                t[ro](),
                t.stroke(),
                t[Um](),
                t.save(),
                t[Cx](),
                t[kx] = oE,
                t.beginPath(),
                t[Pc](19.763, 6.645),
                t[aE](20.002000000000002, 6.643999999999999, 20.23, 6.691999999999999, 20.437, 6.778),
                t[aE](20.644000000000002, 6.864999999999999, 20.830000000000002, 6.991, 20.985, 7.146999999999999),
                t[aE](21.14, 7.302999999999999, 21.266, 7.488999999999999, 21.352999999999998, 7.696999999999999),
                t[aE](21.438999999999997, 7.903999999999999, 21.487, 8.133, 21.487, 8.372),
                t.lineTo(21.398, 36.253),
                t.bezierCurveTo(21.397, 36.489, 21.349, 36.713, 21.262, 36.917),
                t[aE](21.174, 37.121, 21.048000000000002, 37.305, 20.893, 37.458),
                t[aE](20.738, 37.611, 20.553, 37.734, 20.348, 37.818999999999996),
                t[aE](20.141, 37.903999999999996, 19.916, 37.95099999999999, 19.679, 37.949),
                t[Rc](4.675, 37.877),
                t[aE](4.4399999999999995, 37.876000000000005, 4.216, 37.827000000000005, 4.012, 37.741),
                t[aE](3.8089999999999997, 37.653999999999996, 3.6249999999999996, 37.528999999999996, 3.4719999999999995, 37.376),
                t.bezierCurveTo(3.3179999999999996, 37.221, 3.1939999999999995, 37.037, 3.1079999999999997, 36.833999999999996),
                t.bezierCurveTo(3.022, 36.629999999999995, 2.9739999999999998, 36.406, 2.9739999999999998, 36.172),
                t[Rc](2.924, 8.431),
                t[aE](2.923, 8.192, 2.971, 7.964, 3.057, 7.758),
                t[aE](3.143, 7.552, 3.267, 7.365, 3.4219999999999997, 7.209),
                t[aE](3.5769999999999995, 7.052999999999999, 3.76, 6.925, 3.965, 6.837),
                t[aE](4.17, 6.749, 4.396, 6.701, 4.633, 6.7),
                t.lineTo(19.763, 6.645),
                t[Vo](),
                t[ro](),
                t.stroke(),
                t[Um](),
                t.restore(),
                t.save(),
                t[kx] = fE,
                t.beginPath(),
                t.arc(12.208, 26.543, 2.208, 0, 6.283185307179586, !0),
                t.closePath(),
                t.fill(),
                t.stroke(),
                t[Um](),
                t[Cx](),
                t[kx] = oE,
                t[Cm](),
                t.arc(12.208, 26.543, 1.876, 0, 6.283185307179586, !0),
                t.closePath(),
                t[ro](),
                t[ho](),
                t[Um](),
                t[Cx](),
                t[kx] = fE,
                t[Cm](),
                t[Pc](19.377, 17.247),
                t[aE](19.377, 17.724, 18.991999999999997, 18.108999999999998, 18.516, 18.108999999999998),
                t[Rc](5.882, 18.108999999999998),
                t[aE](5.404999999999999, 18.108999999999998, 5.02, 17.723, 5.02, 17.247),
                t[Rc](5.02, 11.144),
                t[aE](5.02, 10.666, 5.406, 10.281, 5.882, 10.281),
                t[Rc](18.516, 10.281),
                t[aE](18.993, 10.281, 19.377, 10.666, 19.377, 11.144),
                t[Rc](19.377, 17.247),
                t[Vo](),
                t.fill(),
                t[ho](),
                t[Um](),
                t[Cx](),
                t[Cx](),
                t[kx] = oE,
                t.beginPath(),
                t[Pc](18.536, 13.176),
                t[aE](18.536, 13.518, 18.261000000000003, 13.794, 17.919, 13.794),
                t.lineTo(6.479, 13.794),
                t[aE](6.1370000000000005, 13.794, 5.861, 13.518, 5.861, 13.176),
                t[Rc](5.861, 11.84),
                t[aE](5.861, 11.498, 6.137, 11.221, 6.479, 11.221),
                t.lineTo(17.918, 11.221),
                t[aE](18.259999999999998, 11.221, 18.535, 11.497, 18.535, 11.84),
                t[Rc](18.535, 13.176),
                t.closePath(),
                t[ro](),
                t[ho](),
                t[Um](),
                t[Cx](),
                t[kx] = oE,
                t.beginPath(),
                t[Pc](18.536, 16.551),
                t[aE](18.536, 16.892999999999997, 18.261000000000003, 17.168999999999997, 17.919, 17.168999999999997),
                t.lineTo(6.479, 17.168999999999997),
                t[aE](6.1370000000000005, 17.168999999999997, 5.861, 16.892999999999997, 5.861, 16.551),
                t[Rc](5.861, 15.215999999999998),
                t[aE](5.861, 14.872999999999998, 6.137, 14.596999999999998, 6.479, 14.596999999999998),
                t[Rc](17.918, 14.596999999999998),
                t[aE](18.259999999999998, 14.596999999999998, 18.535, 14.872999999999998, 18.535, 15.215999999999998),
                t[Rc](18.535, 16.551),
                t[Vo](),
                t[ro](),
                t.stroke(),
                t[Um](),
                t.restore(),
                t.restore()
            }
        },
        exchanger2: {
            draw: function(t) {
                t[Cx](),
                t[Ux](0, 0),
                t[Cm](),
                t.moveTo(0, 0),
                t[Rc](40, 0),
                t[Rc](40, 40),
                t.lineTo(0, 40),
                t[Vo](),
                t.clip(),
                t[Ux](0, 0),
                t[Ux](0, 0),
                t[p_](1, 1),
                t.translate(0, 0),
                t[O_] = Ym,
                t[w_] = Qy,
                t[T_] = ex,
                t[Hm] = 4,
                t[Cx](),
                t.save(),
                t[Um](),
                t[Cx](),
                t[Um](),
                t[Cx](),
                t[Um](),
                t[Cx](),
                t[Um](),
                t.save(),
                t.restore(),
                t[Cx](),
                t.restore(),
                t[Cx](),
                t[Um](),
                t[Cx](),
                t.restore(),
                t[Cx](),
                t.restore(),
                t[Cx](),
                t.restore(),
                t.restore(),
                t[Cx]();
                var i = t[Wm](.4102, 24.3613, 39.5898, 24.3613);
                i[qm](0, Xm),
                i[qm](.0788, Jm),
                i[qm](.2046, cE),
                i[qm](.3649, uE),
                i[qm](.5432, _E),
                i.addColorStop(.6798, dE),
                i.addColorStop(.7462, lE),
                i[qm](.8508, vE),
                i[qm](.98, Qm),
                i[qm](1, bE),
                t[kx] = i,
                t.beginPath(),
                t[Pc](.41, 16.649),
                t[aE](.633, 19.767, .871, 20.689, 1.094, 23.807000000000002),
                t.bezierCurveTo(1.29, 26.548000000000002, 3.324, 28.415000000000003, 5.807, 29.711000000000002),
                t[aE](10.582, 32.202000000000005, 16.477, 32.806000000000004, 21.875999999999998, 32.523),
                t[aE](26.929, 32.258, 32.806, 31.197000000000003, 36.709999999999994, 27.992000000000004),
                t[aE](38.30499999999999, 26.728000000000005, 38.83599999999999, 25.103000000000005, 38.998999999999995, 23.161000000000005),
                t[aE](39.589, 16.135000000000005, 39.589, 16.135000000000005, 39.589, 16.135000000000005),
                t[aE](39.589, 16.135000000000005, 3.26, 16.647, .41, 16.649),
                t[Vo](),
                t[ro](),
                t[ho](),
                t.restore(),
                t[Cx](),
                t.save(),
                t[kx] = oE,
                t[Cm](),
                t.moveTo(16.4, 25.185),
                t[aE](12.807999999999998, 24.924999999999997, 9.139, 24.238, 5.857999999999999, 22.705),
                t[aE](3.175999999999999, 21.450999999999997, -.32200000000000095, 18.971999999999998, .544999999999999, 15.533999999999999),
                t.bezierCurveTo(1.3499999999999992, 12.335999999999999, 4.987999999999999, 10.495999999999999, 7.807999999999999, 9.428999999999998),
                t[aE](11.230999999999998, 8.133999999999999, 14.911999999999999, 7.519999999999999, 18.558, 7.345999999999998),
                t[aE](22.233, 7.169999999999998, 25.966, 7.437999999999998, 29.548000000000002, 8.300999999999998),
                t[aE](32.673, 9.052999999999999, 36.192, 10.296, 38.343, 12.814999999999998),
                t.bezierCurveTo(40.86600000000001, 15.768999999999998, 39.208000000000006, 19.066999999999997, 36.406000000000006, 21.043999999999997),
                t.bezierCurveTo(33.566, 23.046999999999997, 30.055000000000007, 24.071999999999996, 26.670000000000005, 24.676999999999996),
                t.bezierCurveTo(23.289, 25.28, 19.824, 25.436, 16.4, 25.185),
                t.bezierCurveTo(13.529, 24.977, 19.286, 25.396, 16.4, 25.185),
                t[Vo](),
                t.fill(),
                t[ho](),
                t[Um](),
                t[Um](),
                t[Cx](),
                t.save(),
                t.save(),
                t[Cx](),
                t[Cx](),
                t[kx] = gE,
                t[Cm](),
                t.moveTo(5.21, 21.754),
                t[Rc](8.188, 17.922),
                t[Rc](9.53, 18.75),
                t.lineTo(15.956, 16.004),
                t[Rc](18.547, 17.523),
                t[Rc](12.074, 20.334),
                t[Rc](13.464, 21.204),
                t[Rc](5.21, 21.754),
                t.closePath(),
                t.fill(),
                t[ho](),
                t[Um](),
                t[Um](),
                t.restore(),
                t.save(),
                t[Cx](),
                t[Cx](),
                t.fillStyle = gE,
                t.beginPath(),
                t[Pc](17.88, 14.61),
                t.lineTo(9.85, 13.522),
                t[Rc](11.703, 12.757),
                t[Rc](7.436, 10.285),
                t[Rc](10.783, 8.942),
                t.lineTo(15.091, 11.357),
                t[Rc](16.88, 10.614),
                t.lineTo(17.88, 14.61),
                t[Vo](),
                t.fill(),
                t[ho](),
                t[Um](),
                t[Um](),
                t[Cx](),
                t.save(),
                t[kx] = gE,
                t[Cm](),
                t[Pc](17.88, 14.61),
                t[Rc](9.85, 13.522),
                t[Rc](11.703, 12.757),
                t[Rc](7.436, 10.285),
                t[Rc](10.783, 8.942),
                t.lineTo(15.091, 11.357),
                t.lineTo(16.88, 10.614),
                t.lineTo(17.88, 14.61),
                t.closePath(),
                t[ro](),
                t.stroke(),
                t[Um](),
                t[Um](),
                t.restore(),
                t.save(),
                t[Cx](),
                t.save(),
                t.fillStyle = gE,
                t[Cm](),
                t[Pc](23.556, 15.339),
                t[Rc](20.93, 13.879),
                t[Rc](26.953, 11.304),
                t.lineTo(25.559, 10.567),
                t[Rc](33.251, 9.909),
                t[Rc](31.087, 13.467),
                t[Rc](29.619, 12.703),
                t.lineTo(23.556, 15.339),
                t[Vo](),
                t[ro](),
                t[ho](),
                t.restore(),
                t[Um](),
                t[Um](),
                t.save(),
                t[Cx](),
                t[Cx](),
                t.fillStyle = gE,
                t[Cm](),
                t[Pc](30.028, 23.383),
                t[Rc](24.821, 20.366),
                t[Rc](22.915, 21.227),
                t[Rc](21.669, 16.762),
                t.lineTo(30.189, 17.942),
                t[Rc](28.33, 18.782),
                t[Rc](33.579, 21.725),
                t[Rc](30.028, 23.383),
                t[Vo](),
                t[ro](),
                t.stroke(),
                t.restore(),
                t[Um](),
                t[Cx](),
                t.save(),
                t[kx] = gE,
                t[Cm](),
                t[Pc](30.028, 23.383),
                t[Rc](24.821, 20.366),
                t[Rc](22.915, 21.227),
                t[Rc](21.669, 16.762),
                t.lineTo(30.189, 17.942),
                t[Rc](28.33, 18.782),
                t[Rc](33.579, 21.725),
                t.lineTo(30.028, 23.383),
                t[Vo](),
                t[ro](),
                t[ho](),
                t.restore(),
                t.restore(),
                t[Um](),
                t[Um](),
                t.restore(),
                t.restore()
            }
        },
        exchanger: {
            draw: function(t) {
                t.save(),
                t.translate(0, 0),
                t[Cm](),
                t[Pc](0, 0),
                t[Rc](40, 0),
                t[Rc](40, 40),
                t[Rc](0, 40),
                t[Vo](),
                t[Px](),
                t[Ux](0, 0),
                t.translate(0, 0),
                t[p_](1, 1),
                t[Ux](0, 0),
                t[O_] = Ym,
                t[w_] = Qy,
                t[T_] = ex,
                t.miterLimit = 4,
                t[Cx](),
                t[Cx](),
                t.restore(),
                t.save(),
                t[Um](),
                t[Cx](),
                t[Um](),
                t[Cx](),
                t.restore(),
                t[Cx](),
                t[Um](),
                t[Cx](),
                t[Um](),
                t[Cx](),
                t[Um](),
                t[Um](),
                t[Cx]();
                var i = t[Wm](.2095, 20.7588, 39.4941, 20.7588);
                i.addColorStop(0, yE),
                i[qm](.0788, xE),
                i[qm](.352, mE),
                i[qm](.6967, EE),
                i.addColorStop(.8916, pE),
                i.addColorStop(.9557, wE),
                i[qm](1, TE),
                t.fillStyle = i,
                t[Cm](),
                t[Pc](39.449, 12.417),
                t.lineTo(39.384, 9.424),
                t[aE](39.384, 9.424, .7980000000000018, 22.264, .3710000000000022, 23.024),
                t[aE]( - .026999999999997804, 23.733, .4240000000000022, 24.903000000000002, .5190000000000022, 25.647000000000002),
                t[aE](.7240000000000022, 27.244000000000003, .9240000000000023, 28.841, 1.1350000000000022, 30.437),
                t[aE](1.3220000000000023, 31.843, 2.7530000000000023, 32.094, 3.9620000000000024, 32.094),
                t[aE](8.799000000000003, 32.092, 13.636000000000003, 32.091, 18.473000000000003, 32.089),
                t[aE](23.515, 32.086999999999996, 28.556000000000004, 32.086, 33.598, 32.083999999999996),
                t.bezierCurveTo(34.859, 32.083999999999996, 36.286, 31.979999999999997, 37.266, 31.081999999999997),
                t.bezierCurveTo(37.537, 30.820999999999998, 37.655, 30.535999999999998, 37.699999999999996, 30.229999999999997),
                t[Rc](37.711, 30.316999999999997),
                t.lineTo(39.281, 16.498999999999995),
                t[aE](39.281, 16.498999999999995, 39.467999999999996, 15.126999999999995, 39.489, 14.666999999999994),
                t[aE](39.515, 14.105, 39.449, 12.417, 39.449, 12.417),
                t[Vo](),
                t.fill(),
                t.stroke(),
                t.restore(),
                t[Cx](),
                t[Cx](),
                t[Cx](),
                t.save(),
                t.restore(),
                t[Cx](),
                t.restore(),
                t[Cx](),
                t[Um](),
                t[Cx](),
                t.restore(),
                t[Cx](),
                t[Um](),
                t.save(),
                t[Um](),
                t[Cx](),
                t[Um](),
                t[Cx](),
                t[Um](),
                t[Cx](),
                t[Um](),
                t.restore(),
                t[Cx]();
                var i = t[Wm](19.8052, 7.7949, 19.8052, 24.7632);
                i[qm](0, OE),
                i[qm](.1455, IE),
                i[qm](.2975, ME),
                i.addColorStop(.4527, AE),
                i.addColorStop(.6099, jE),
                i.addColorStop(.7687, SE),
                i[qm](.9268, CE),
                i[qm](.9754, kE),
                i[qm](1, LE),
                t.fillStyle = i,
                t[Cm](),
                t[Pc](33.591, 24.763),
                t[aE](23.868000000000002, 24.754, 14.145, 24.746000000000002, 4.423000000000002, 24.738000000000003),
                t.bezierCurveTo(3.140000000000002, 24.737000000000002, -.48799999999999777, 24.838000000000005, .3520000000000021, 22.837000000000003),
                t.bezierCurveTo(1.292000000000002, 20.594000000000005, 2.2330000000000023, 18.351000000000003, 3.1730000000000023, 16.108000000000004),
                t.bezierCurveTo(4.113000000000002, 13.865000000000006, 5.054000000000002, 11.623000000000005, 5.994000000000002, 9.380000000000004),
                t[aE](6.728000000000002, 7.629000000000005, 9.521000000000003, 7.885000000000004, 11.156000000000002, 7.880000000000004),
                t[aE](16.974000000000004, 7.861000000000004, 22.793000000000003, 7.843000000000004, 28.612000000000002, 7.825000000000005),
                t[aE](30.976000000000003, 7.818000000000005, 33.341, 7.810000000000005, 35.707, 7.803000000000004),
                t[aE](36.157000000000004, 7.802000000000004, 36.609, 7.787000000000004, 37.06, 7.804000000000005),
                t[aE](37.793, 7.833000000000005, 39.389, 7.875000000000004, 39.385000000000005, 9.424000000000005),
                t[aE](39.38400000000001, 9.647000000000006, 39.31, 10.138000000000005, 39.27700000000001, 10.359000000000005),
                t.bezierCurveTo(38.81900000000001, 13.361000000000004, 38.452000000000005, 15.764000000000006, 37.99400000000001, 18.766000000000005),
                t.bezierCurveTo(37.806000000000004, 19.998000000000005, 37.61800000000001, 21.230000000000004, 37.43000000000001, 22.462000000000007),
                t.bezierCurveTo(37.151, 24.271, 35.264, 24.77, 33.591, 24.763),
                t[Vo](),
                t[ro](),
                t[ho](),
                t[Um](),
                t.restore(),
                t[Um](),
                t.save(),
                t[Cx](),
                t[Cx](),
                t[kx] = gE,
                t[Cm](),
                t.moveTo(10.427, 19.292),
                t[Rc](5.735, 16.452),
                t[Rc](12.58, 13.8),
                t[Rc](12.045, 15.07),
                t[Rc](20.482, 15.072),
                t[Rc](19.667, 17.887),
                t[Rc](11.029, 17.851),
                t[Rc](10.427, 19.292),
                t[Vo](),
                t[ro](),
                t[ho](),
                t[Um](),
                t[Um](),
                t.save(),
                t[Cx](),
                t[kx] = gE,
                t[Cm](),
                t[Pc](13.041, 13.042),
                t.lineTo(8.641, 10.73),
                t[Rc](14.82, 8.474),
                t[Rc](14.373, 9.537),
                t.lineTo(22.102, 9.479),
                t[Rc](21.425, 11.816),
                t.lineTo(13.54, 11.85),
                t[Rc](13.041, 13.042),
                t.closePath(),
                t[ro](),
                t.stroke(),
                t[Um](),
                t[Um](),
                t.save(),
                t[Cx](),
                t[kx] = gE,
                t.beginPath(),
                t.moveTo(29.787, 16.049),
                t[Rc](29.979, 14.704),
                t.lineTo(21.51, 14.706),
                t[Rc](22.214, 12.147),
                t.lineTo(30.486, 12.116),
                t[Rc](30.653, 10.926),
                t[Rc](36.141, 13.4),
                t[Rc](29.787, 16.049),
                t[Vo](),
                t.fill(),
                t[ho](),
                t[Um](),
                t[Um](),
                t.save(),
                t[Cx](),
                t.fillStyle = gE,
                t.beginPath(),
                t[Pc](28.775, 23.14),
                t[Rc](29.011, 21.49),
                t.lineTo(19.668, 21.405),
                t[Rc](20.523, 18.295),
                t[Rc](29.613, 18.338),
                t.lineTo(29.815, 16.898),
                t[Rc](35.832, 19.964),
                t[Rc](28.775, 23.14),
                t.closePath(),
                t[ro](),
                t.stroke(),
                t[Um](),
                t[Um](),
                t[Um](),
                t[Um]()
            }
        },
        cloud: {
            draw: function(t) {
                t[Cx](),
                t.beginPath(),
                t[Pc](0, 0),
                t[Rc](90.75, 0),
                t.lineTo(90.75, 62.125),
                t[Rc](0, 62.125),
                t.closePath(),
                t[Px](),
                t.strokeStyle = Ym,
                t.lineCap = Qy,
                t[T_] = ex,
                t[Hm] = 4,
                t[Cx]();
                var i = t[Wm](44.0054, 6.4116, 44.0054, 51.3674);
                i[qm](0, "rgba(159, 160, 160, 0.7)"),
                i[qm](.9726, PE),
                t.fillStyle = i,
                t[Cm](),
                t.moveTo(57.07, 20.354),
                t.bezierCurveTo(57.037, 20.354, 57.006, 20.358, 56.974000000000004, 20.358),
                t.bezierCurveTo(54.461000000000006, 14.308, 48.499, 10.049000000000001, 41.538000000000004, 10.049000000000001),
                t[aE](33.801, 10.049000000000001, 27.309000000000005, 15.316000000000003, 25.408000000000005, 22.456000000000003),
                t[aE](18.988000000000007, 23.289, 14.025000000000006, 28.765000000000004, 14.025000000000006, 35.413000000000004),
                t[aE](14.025000000000006, 42.635000000000005, 19.880000000000006, 48.49, 27.102000000000004, 48.49),
                t[aE](29.321000000000005, 48.49, 31.407000000000004, 47.933, 33.237, 46.961),
                t[aE](34.980000000000004, 49.327, 37.78, 50.867999999999995, 40.945, 50.867999999999995),
                t.bezierCurveTo(43.197, 50.867999999999995, 45.261, 50.086, 46.896, 48.785999999999994),
                t[aE](49.729, 50.78699999999999, 53.244, 51.98799999999999, 57.07, 51.98799999999999),
                t.bezierCurveTo(66.412, 51.98799999999999, 73.986, 44.90699999999999, 73.986, 36.17099999999999),
                t[aE](73.986, 27.436, 66.413, 20.354, 57.07, 20.354),
                t[Vo](),
                t[ro](),
                t.stroke(),
                t[Um](),
                t[Um]()
            }
        },
        node: {
            width: 60,
            height: 100,
            draw: function(t) {
                t[Cx](),
                t.translate(0, 0),
                t[Cm](),
                t[Pc](0, 0),
                t[Rc](40, 0),
                t[Rc](40, 40),
                t.lineTo(0, 40),
                t[Vo](),
                t.clip(),
                t[Ux](0, 0),
                t[Ux](0, 0),
                t.scale(1, 1),
                t[Ux](0, 0),
                t.strokeStyle = Ym,
                t[w_] = Qy,
                t.lineJoin = ex,
                t.miterLimit = 4,
                t.save(),
                t[kx] = RE,
                t[Cm](),
                t.moveTo(13.948, 31.075),
                t[Rc](25.914, 31.075),
                t.quadraticCurveTo(25.914, 31.075, 25.914, 31.075),
                t[Rc](25.914, 34.862),
                t.quadraticCurveTo(25.914, 34.862, 25.914, 34.862),
                t[Rc](13.948, 34.862),
                t.quadraticCurveTo(13.948, 34.862, 13.948, 34.862),
                t.lineTo(13.948, 31.075),
                t[DE](13.948, 31.075, 13.948, 31.075),
                t[Vo](),
                t[ro](),
                t[ho](),
                t[Um](),
                t[Cx](),
                t[kx] = NE,
                t[Cm](),
                t[Pc](29.679, 35.972),
                t[aE](29.679, 36.675000000000004, 29.110999999999997, 37.244, 28.407999999999998, 37.244),
                t[Rc](11.456, 37.244),
                t[aE](10.751999999999999, 37.244, 10.183, 36.675, 10.183, 35.972),
                t.lineTo(10.183, 36.136),
                t[aE](10.183, 35.431000000000004, 10.751999999999999, 34.863, 11.456, 34.863),
                t[Rc](28.407, 34.863),
                t.bezierCurveTo(29.11, 34.863, 29.678, 35.431, 29.678, 36.136),
                t[Rc](29.678, 35.972),
                t[Vo](),
                t[ro](),
                t.stroke(),
                t[Um](),
                t[Cx](),
                t[kx] = NE,
                t.beginPath(),
                t.moveTo(.196, 29.346),
                t.bezierCurveTo(.196, 30.301, .9690000000000001, 31.075, 1.925, 31.075),
                t[Rc](37.936, 31.075),
                t.bezierCurveTo(38.891, 31.075, 39.665, 30.301, 39.665, 29.346),
                t[Rc](39.665, 27.174),
                t[Rc](.196, 27.174),
                t[Rc](.196, 29.346),
                t[Vo](),
                t[ro](),
                t.stroke(),
                t[Um](),
                t[Cx](),
                t[kx] = BE,
                t[Cm](),
                t[Pc](37.937, 3.884),
                t[Rc](1.926, 3.884),
                t[aE](.97, 3.884, .19699999999999984, 4.657, .19699999999999984, 5.614),
                t[Rc](.19699999999999984, 27.12),
                t.lineTo(39.666000000000004, 27.12),
                t[Rc](39.666000000000004, 5.615),
                t[aE](39.665, 4.657, 38.892, 3.884, 37.937, 3.884),
                t[Vo](),
                t.fill(),
                t[ho](),
                t[Um](),
                t[Cx](),
                t.save(),
                t[Um](),
                t.save(),
                t[Um](),
                t.restore(),
                t[Cx]();
                var i = t.createLinearGradient(6.9609, 2.9341, 32.9008, 28.874);
                i[qm](0, $E),
                i[qm](1, GE),
                t[kx] = i,
                t.beginPath(),
                t.moveTo(35.788, 6.39),
                t[Rc](4.074, 6.39),
                t[aE](3.315, 6.39, 2.702, 7.003, 2.702, 7.763),
                t.lineTo(2.702, 24.616),
                t[Rc](37.159, 24.616),
                t.lineTo(37.159, 7.763),
                t[aE](37.159, 7.003, 36.546, 6.39, 35.788, 6.39),
                t.closePath(),
                t[ro](),
                t[ho](),
                t.restore(),
                t[Um]()
            }
        },
        group: {
            draw: function(t) {
                t[Cx](),
                t.translate(0, 0),
                t.beginPath(),
                t[Pc](0, 0),
                t.lineTo(47.75, 0),
                t.lineTo(47.75, 40),
                t[Rc](0, 40),
                t[Vo](),
                t[Px](),
                t[Ux](0, 0),
                t[Ux](0, 0),
                t.scale(1, 1),
                t.translate(0, 0),
                t[O_] = Ym,
                t[w_] = Qy,
                t[T_] = ex,
                t.miterLimit = 4,
                t[Cx](),
                t[Cx](),
                t[kx] = RE,
                t[Cm](),
                t.moveTo(10.447, 26.005),
                t[Rc](18.847, 26.005),
                t[DE](18.847, 26.005, 18.847, 26.005),
                t[Rc](18.847, 28.663),
                t[DE](18.847, 28.663, 18.847, 28.663),
                t[Rc](10.447, 28.663),
                t[DE](10.447, 28.663, 10.447, 28.663),
                t[Rc](10.447, 26.005),
                t[DE](10.447, 26.005, 10.447, 26.005),
                t[Vo](),
                t[ro](),
                t.stroke(),
                t.restore(),
                t[Cx](),
                t[kx] = NE,
                t[Cm](),
                t[Pc](21.491, 29.443),
                t[aE](21.491, 29.935000000000002, 21.094, 30.338, 20.597, 30.338),
                t[Rc](8.698, 30.338),
                t.bezierCurveTo(8.201, 30.338, 7.8020000000000005, 29.936, 7.8020000000000005, 29.443),
                t[Rc](7.8020000000000005, 29.557000000000002),
                t[aE](7.8020000000000005, 29.063000000000002, 8.201, 28.662000000000003, 8.698, 28.662000000000003),
                t[Rc](20.597, 28.662000000000003),
                t[aE](21.093, 28.662000000000003, 21.491, 29.062, 21.491, 29.557000000000002),
                t[Rc](21.491, 29.443),
                t[Vo](),
                t[ro](),
                t[ho](),
                t[Um](),
                t.save(),
                t.fillStyle = NE,
                t[Cm](),
                t.moveTo(.789, 24.79),
                t.bezierCurveTo(.789, 25.461, 1.334, 26.005, 2.0060000000000002, 26.005),
                t[Rc](27.289, 26.005),
                t[aE](27.961000000000002, 26.005, 28.504, 25.461, 28.504, 24.79),
                t.lineTo(28.504, 23.267),
                t[Rc](.789, 23.267),
                t[Rc](.789, 24.79),
                t[Vo](),
                t[ro](),
                t.stroke(),
                t[Um](),
                t.save(),
                t[kx] = BE,
                t[Cm](),
                t[Pc](27.289, 6.912),
                t[Rc](2.006, 6.912),
                t.bezierCurveTo(1.3339999999999996, 6.912, .7889999999999997, 7.455, .7889999999999997, 8.126),
                t[Rc](.7889999999999997, 23.227),
                t[Rc](28.503999999999998, 23.227),
                t[Rc](28.503999999999998, 8.126),
                t.bezierCurveTo(28.504, 7.455, 27.961, 6.912, 27.289, 6.912),
                t[Vo](),
                t[ro](),
                t[ho](),
                t[Um](),
                t[Cx](),
                t[Cx](),
                t.restore(),
                t[Cx](),
                t[Um](),
                t[Um](),
                t[Cx]();
                var i = t[Wm](5.54, 6.2451, 23.7529, 24.458);
                i[qm](0, $E),
                i[qm](1, GE),
                t.fillStyle = i,
                t.beginPath(),
                t[Pc](25.78, 8.671),
                t[Rc](3.514, 8.671),
                t.bezierCurveTo(2.9819999999999998, 8.671, 2.549, 9.101999999999999, 2.549, 9.635),
                t.lineTo(2.549, 21.466),
                t[Rc](26.743, 21.466),
                t.lineTo(26.743, 9.636),
                t.bezierCurveTo(26.743, 9.102, 26.312, 8.671, 25.78, 8.671),
                t[Vo](),
                t.fill(),
                t.stroke(),
                t[Um](),
                t[Um](),
                t.save(),
                t[Cx](),
                t[kx] = RE,
                t[Cm](),
                t.moveTo(27.053, 33.602),
                t.lineTo(36.22, 33.602),
                t[DE](36.22, 33.602, 36.22, 33.602),
                t[Rc](36.22, 36.501),
                t[DE](36.22, 36.501, 36.22, 36.501),
                t[Rc](27.053, 36.501),
                t[DE](27.053, 36.501, 27.053, 36.501),
                t[Rc](27.053, 33.602),
                t[DE](27.053, 33.602, 27.053, 33.602),
                t.closePath(),
                t[ro](),
                t[ho](),
                t.restore(),
                t[Cx](),
                t.fillStyle = NE,
                t[Cm](),
                t[Pc](39.104, 37.352),
                t[aE](39.104, 37.891, 38.67, 38.327, 38.13, 38.327),
                t.lineTo(25.143, 38.327),
                t[aE](24.602, 38.327, 24.166, 37.891, 24.166, 37.352),
                t[Rc](24.166, 37.477999999999994),
                t[aE](24.166, 36.937, 24.602, 36.501, 25.143, 36.501),
                t.lineTo(38.131, 36.501),
                t[aE](38.671, 36.501, 39.105, 36.937, 39.105, 37.477999999999994),
                t.lineTo(39.105, 37.352),
                t.closePath(),
                t.fill(),
                t[ho](),
                t[Um](),
                t[Cx](),
                t[kx] = NE,
                t[Cm](),
                t[Pc](16.514, 32.275),
                t[aE](16.514, 33.004999999999995, 17.107, 33.601, 17.839, 33.601),
                t.lineTo(45.433, 33.601),
                t.bezierCurveTo(46.166, 33.601, 46.758, 33.005, 46.758, 32.275),
                t.lineTo(46.758, 30.607999999999997),
                t.lineTo(16.514, 30.607999999999997),
                t[Rc](16.514, 32.275),
                t[Vo](),
                t.fill(),
                t[ho](),
                t[Um](),
                t[Cx](),
                t.fillStyle = BE,
                t[Cm](),
                t[Pc](45.433, 12.763),
                t.lineTo(17.839, 12.763),
                t.bezierCurveTo(17.107, 12.763, 16.514, 13.356, 16.514, 14.089),
                t.lineTo(16.514, 30.57),
                t[Rc](46.757999999999996, 30.57),
                t[Rc](46.757999999999996, 14.088),
                t[aE](46.758, 13.356, 46.166, 12.763, 45.433, 12.763),
                t[Vo](),
                t[ro](),
                t[ho](),
                t[Um](),
                t[Cx](),
                t[Cx](),
                t[Um](),
                t.save(),
                t[Um](),
                t[Um](),
                t.save(),
                i = t[Wm](21.6973, 12.0352, 41.5743, 31.9122),
                i[qm](0, $E),
                i[qm](1, GE),
                t[kx] = i,
                t[Cm](),
                t[Pc](43.785, 14.683),
                t[Rc](19.486, 14.683),
                t.bezierCurveTo(18.903000000000002, 14.683, 18.433, 15.153, 18.433, 15.735),
                t.lineTo(18.433, 28.649),
                t[Rc](44.837, 28.649),
                t[Rc](44.837, 15.734),
                t.bezierCurveTo(44.838, 15.153, 44.367, 14.683, 43.785, 14.683),
                t[Vo](),
                t[ro](),
                t[ho](),
                t[Um](),
                t.restore(),
                t[Cx](),
                t[FE] = .5,
                t[Cm](),
                t[Pc](23.709, 36.33),
                t.lineTo(4.232, 36.33),
                t[Rc](4.232, 27.199),
                t[Rc](5.304, 27.199),
                t[Rc](5.304, 35.259),
                t[Rc](23.709, 35.259),
                t[Rc](23.709, 36.33),
                t.closePath(),
                t.fill(),
                t[ho](),
                t[Um](),
                t[Um]()
            }
        },
        subnetwork: {
            draw: function(t) {
                t.save(),
                t.translate(0, 0),
                t.beginPath(),
                t.moveTo(0, 0),
                t.lineTo(60.75, 0),
                t[Rc](60.75, 42.125),
                t.lineTo(0, 42.125),
                t[Vo](),
                t.clip(),
                t[Ux](0, .26859504132231393),
                t[p_](.6694214876033058, .6694214876033058),
                t[Ux](0, 0),
                t.strokeStyle = Ym,
                t[w_] = Qy,
                t[T_] = ex,
                t[Hm] = 4,
                t.save(),
                t[Cx](),
                t.restore(),
                t.save(),
                t[Um](),
                t.restore(),
                t[Cx]();
                var i = t[Wm](43.6724, -2.7627, 43.6724, 59.3806);
                i.addColorStop(0, "rgba(159, 160, 160, 0.7)"),
                i.addColorStop(.9726, PE),
                t.fillStyle = i,
                t.beginPath(),
                t[Pc](61.732, 16.509),
                t[aE](61.686, 16.509, 61.644, 16.515, 61.599, 16.515),
                t[aE](58.126, 8.152000000000001, 49.884, 2.2650000000000006, 40.262, 2.2650000000000006),
                t[aE](29.567, 2.2650000000000006, 20.594, 9.545000000000002, 17.966, 19.415),
                t.bezierCurveTo(9.09, 20.566, 2.229, 28.136, 2.229, 37.326),
                t[aE](2.229, 47.309, 10.322, 55.403000000000006, 20.306, 55.403000000000006),
                t.bezierCurveTo(23.374000000000002, 55.403000000000006, 26.257, 54.633, 28.787, 53.28900000000001),
                t[aE](31.197, 56.56000000000001, 35.067, 58.69000000000001, 39.442, 58.69000000000001),
                t[aE](42.555, 58.69000000000001, 45.408, 57.60900000000001, 47.669, 55.81200000000001),
                t[aE](51.586, 58.57800000000001, 56.443999999999996, 60.238000000000014, 61.732, 60.238000000000014),
                t.bezierCurveTo(74.64699999999999, 60.238000000000014, 85.116, 50.45000000000002, 85.116, 38.37400000000001),
                t[aE](85.116, 26.298, 74.646, 16.509, 61.732, 16.509),
                t[Vo](),
                t[ro](),
                t[ho](),
                t[Um](),
                t[Cx](),
                t[Cx](),
                t[kx] = RE,
                t[Cm](),
                t[Pc](34.966, 44.287),
                t[Rc](45.112, 44.287),
                t[DE](45.112, 44.287, 45.112, 44.287),
                t[Rc](45.112, 47.497),
                t[DE](45.112, 47.497, 45.112, 47.497),
                t.lineTo(34.966, 47.497),
                t[DE](34.966, 47.497, 34.966, 47.497),
                t[Rc](34.966, 44.287),
                t[DE](34.966, 44.287, 34.966, 44.287),
                t[Vo](),
                t[ro](),
                t[ho](),
                t[Um](),
                t.save(),
                t[kx] = zE,
                t.beginPath(),
                t.moveTo(48.306, 48.439),
                t[aE](48.306, 49.034, 47.824999999999996, 49.52, 47.226, 49.52),
                t.lineTo(32.854, 49.52),
                t[aE](32.253, 49.52, 31.771, 49.034000000000006, 31.771, 48.439),
                t[Rc](31.771, 48.578),
                t[aE](31.771, 47.981, 32.253, 47.497, 32.854, 47.497),
                t[Rc](47.226, 47.497),
                t.bezierCurveTo(47.824999999999996, 47.497, 48.306, 47.98, 48.306, 48.578),
                t.lineTo(48.306, 48.439),
                t[Vo](),
                t.fill(),
                t.stroke(),
                t.restore(),
                t[Cx](),
                t[kx] = YE,
                t.beginPath(),
                t[Pc](23.302, 42.82),
                t.bezierCurveTo(23.302, 43.63, 23.96, 44.287, 24.772, 44.287),
                t.lineTo(55.308, 44.287),
                t.bezierCurveTo(56.12, 44.287, 56.775, 43.629999999999995, 56.775, 42.82),
                t[Rc](56.775, 40.98),
                t[Rc](23.302, 40.98),
                t[Rc](23.302, 42.82),
                t.closePath(),
                t[ro](),
                t.stroke(),
                t[Um](),
                t[Cx](),
                t.fillStyle = BE,
                t[Cm](),
                t.moveTo(55.307, 21.229),
                t[Rc](24.771, 21.229),
                t.bezierCurveTo(23.959, 21.229, 23.301000000000002, 21.884, 23.301000000000002, 22.695),
                t[Rc](23.301000000000002, 40.933),
                t[Rc](56.774, 40.933),
                t.lineTo(56.774, 22.695),
                t[aE](56.774, 21.884, 56.119, 21.229, 55.307, 21.229),
                t.closePath(),
                t[ro](),
                t[ho](),
                t.restore(),
                t[Cx](),
                t[Cx](),
                t.restore(),
                t[Cx](),
                t[Um](),
                t[Um](),
                t.save(),
                i = t[Wm](29.04, 20.4219, 51.0363, 42.4181),
                i[qm](0, $E),
                i[qm](1, GE),
                t[kx] = i,
                t[Cm](),
                t[Pc](53.485, 23.353),
                t.lineTo(26.592, 23.353),
                t[aE](25.948999999999998, 23.353, 25.427, 23.873, 25.427, 24.517000000000003),
                t[Rc](25.427, 38.807),
                t[Rc](54.647, 38.807),
                t.lineTo(54.647, 24.517000000000003),
                t.bezierCurveTo(54.648, 23.873, 54.127, 23.353, 53.485, 23.353),
                t[Vo](),
                t[ro](),
                t[ho](),
                t.restore(),
                t.restore(),
                t[Um]()
            }
        }
    };
    for (var hH in sH) vn(HE + hH, sH[hH]);
    var rH = function() {
        this[kf] = !1;
        var t = this._fr;
        t[wf]();
        var i = this.$border || 0,
        n = this._7w.x + i / 2,
        e = this._7w.y + i / 2,
        s = this._7w[Sa] - i,
        h = this._7w[Ca] - i,
        r = Bn[zh](this, {
            x: n,
            y: e
        });
        zn(t, r.x, r.y, !0),
        r = Bn.call(this, {
            x: n + s,
            y: e
        }),
        zn(t, r.x, r.y),
        r = Bn.call(this, {
            x: n + s,
            y: e + h
        }),
        zn(t, r.x, r.y),
        r = Bn[zh](this, {
            x: n,
            y: e + h
        }),
        zn(t, r.x, r.y),
        this.__mvPointer && (r = Bn[zh](this, {
            x: this._pointerX,
            y: this._pointerY
        }), zn(t, r.x, r.y)),
        i && t.grow(i / 2)
    },
    aH = 20,
    oH = {
        _gv: !1,
        _kn: null,
        _nh0: 0,
        _lc: -1,
        _ld: null,
        _fh: function(t) {
            this._kn || (this._kn = [], this._jm = RY),
            this._kn[Xh](t),
            this._f3(),
            this._l5()
        },
        _l5: function() {
            if (!this._ld) {
                var t = this;
                this._ld = setTimeout(function i() {
                    return t._f3() !== !1 ? void(t._ld = setTimeout(i, t._gz())) : void delete t._ld
                },
                this._gz())
            }
        },
        _gz: function() {
            return Math.max(aH, this._kn[this._lc].delay)
        },
        _f3: function() {
            return this._h0(this._lc + 1)
        },
        _h0: function(t) {
            if (this._gv) t %= this[UE];
            else if (t >= this._kn[Fh]) return ! 1;
            if (this._lc == t) return ! 1;
            this._lc = t;
            var i = this._kn[this._lc],
            n = i._nhache;
            return n || (i[WE] = n = ki(this.width, this[Ca]), n.g.putImageData(i[ao], 0, 0), n[xx] = i[xx]),
            this._l7 = n,
            this[hf] = !0,
            this._dt()
        },
        _nh4: function() {
            return this._kn ? (this._gv = !0, this[UE] = this._kn.length, 1 == this[UE] ? this._dt() : void this._l5()) : void this._iy()
        },
        _mj: function() {
            this._ld && (clearTimeout(this._ld), delete this._ld)
        },
        _dt: function() {
            var t = this[bx][ql];
            if (!t || !t[Fh]) return ! 1;
            for (var i = new wz(this, Vx, Kx, this._l7), n = 0, e = t[Fh]; e > n; n++) {
                var s = t[n];
                s[Wl]._jy && s[Wl]._jy[qE] ? (t[Uh](n, 1), n--, e--) : s[Hl][zh](s[Wl], i)
            }
            return t.length > 0
        },
        _neh: function(t, i) {
            this[bx].addListener(t, i),
            this._gv && !this._ld && this._l5()
        },
        _6z: function(t, i) {
            this[bx][Xl](t, i),
            this[bx][XE]() || this._mj()
        },
        _ii: function() {
            this._mj(),
            this[bx].clear()
        },
        _g3: function() {
            var t = this._l7._ngufferedImage;
            return t || (this._l7[VE] = t = new nH(this._l7, 1)),
            t
        }
    },
    fH = function(t) {
        return t[KE](function(t, i) {
            return 2 * t + i
        },
        0)
    },
    cH = function(t) {
        for (var i = [], n = 7; n >= 0; n--) i.push( !! (t & 1 << n));
        return i
    },
    uH = function(t) {
        this[ao] = t,
        this.len = this[ao][Fh],
        this.pos = 0,
        this[ZE] = function() {
            if (this.pos >= this.data.length) throw new Error("Attempted to read past end of stream.");
            return 255 & t.charCodeAt(this.pos++)
        },
        this.readBytes = function(t) {
            for (var i = [], n = 0; t > n; n++) i[Xh](this.readByte());
            return i
        },
        this.read = function(t) {
            for (var i = "",
            n = 0; t > n; n++) i += String[Qf](this[ZE]());
            return i
        },
        this.readUnsigned = function() {
            var t = this[JE](2);
            return (t[1] << 8) + t[0]
        }
    },
    _H = function(t, i) {
        for (var n, e, s = 0,
        h = function(t) {
            for (var n = 0,
            e = 0; t > e; e++) i.charCodeAt(s >> 3) & 1 << (7 & s) && (n |= 1 << e),
            s++;
            return n
        },
        r = [], a = 1 << t, o = a + 1, f = t + 1, c = [], u = function() {
            c = [],
            f = t + 1;
            for (var i = 0; a > i; i++) c[i] = [i];
            c[a] = [],
            c[o] = null
        };;) if (e = n, n = h(f), n !== a) {
            if (n === o) break;
            if (n < c[Fh]) e !== a && c[Xh](c[e][co](c[n][0]));
            else {
                if (n !== c[Fh]) throw new Error(QE);
                c[Xh](c[e][co](c[e][0]))
            }
            r.push[Zh](r, c[n]),
            c[Fh] === 1 << f && 12 > f && f++
        } else u();
        return r
    },
    dH = function(t, i) {
        i || (i = {});
        var n = function(i) {
            for (var n = [], e = 0; i > e; e++) n[Xh](t.readBytes(3));
            return n
        },
        e = function() {
            var i, n;
            n = "";
            do i = t[ZE](),
            n += t[tp](i);
            while (0 !== i);
            return n
        },
        s = function() {
            var e = {};
            if (e.sig = t.read(3), e.ver = t[tp](3), ip !== e.sig) throw new Error(np);
            e[Sa] = t[ep](),
            e.height = t[ep]();
            var s = cH(t[ZE]());
            e[sp] = s[hp](),
            e[rp] = fH(s.splice(0, 3)),
            e[ap] = s[hp](),
            e[op] = fH(s[Uh](0, 3)),
            e[fp] = t.readByte(),
            e.pixelAspectRatio = t[ZE](),
            e.gctFlag && (e.gct = n(1 << e[op] + 1)),
            i.hdr && i.hdr(e)
        },
        h = function(n) {
            var s = function(n) {
                var e = (t[ZE](), cH(t.readByte()));
                n.reserved = e.splice(0, 3),
                n[cp] = fH(e[Uh](0, 3)),
                n[up] = e.shift(),
                n.transparencyGiven = e.shift(),
                n[_p] = t[ep](),
                n.transparencyIndex = t.readByte(),
                n.terminator = t[ZE](),
                i.gce && i.gce(n)
            },
            h = function(t) {
                t[dp] = e(),
                i.com && i.com(t)
            },
            r = function(n) {
                t[ZE](),
                n[lp] = t.readBytes(12),
                n.ptData = e(),
                i.pte && i.pte(n)
            },
            a = function(n) {
                var s = function(n) {
                    t[ZE](),
                    n[vp] = t[ZE](),
                    n[bp] = t[ep](),
                    n[gp] = t[ZE](),
                    i.app && i.app.NETSCAPE && i.app[yp](n)
                },
                h = function(t) {
                    t.appData = e(),
                    i.app && i.app[t[xp]] && i.app[t[xp]](t)
                };
                switch (t[ZE](), n.identifier = t[tp](8), n[mp] = t[tp](3), n[xp]) {
                case "NETSCAPE":
                    s(n);
                    break;
                default:
                    h(n)
                }
            },
            o = function(t) {
                t[ao] = e(),
                i.unknown && i[vp](t)
            };
            switch (n[Ep] = t[ZE](), n[Ep]) {
            case 249:
                n[pp] = wp,
                s(n);
                break;
            case 254:
                n.extType = Tp,
                h(n);
                break;
            case 1:
                n[pp] = Op,
                r(n);
                break;
            case 255:
                n.extType = Ip,
                a(n);
                break;
            default:
                n[pp] = vp,
                o(n)
            }
        },
        r = function(s) {
            var h = function(t, i) {
                for (var n = new Array(t[Fh]), e = t.length / i, s = function(e, s) {
                    var h = t[Hh](s * i, (s + 1) * i);
                    n.splice[Zh](n, [e * i, i][co](h))
                },
                h = [0, 4, 2, 1], r = [8, 8, 4, 2], a = 0, o = 0; 4 > o; o++) for (var f = h[o]; e > f; f += r[o]) s(f, a),
                a++;
                return n
            };
            s.leftPos = t.readUnsigned(),
            s[Hf] = t[ep](),
            s.width = t[ep](),
            s[Ca] = t.readUnsigned();
            var r = cH(t.readByte());
            s[Yf] = r.shift(),
            s[Mp] = r[hp](),
            s[ap] = r[hp](),
            s[Ap] = r[Uh](0, 2),
            s[jp] = fH(r[Uh](0, 3)),
            s.lctFlag && (s.lct = n(1 << s.lctSize + 1)),
            s[Sp] = t.readByte();
            var a = e();
            s[Uf] = _H(s[Sp], a),
            s[Mp] && (s[Uf] = h(s[Uf], s[Sa])),
            i.img && i.img(s)
        },
        a = function() {
            var n = {};
            switch (n[Cp] = t[ZE](), String[Qf](n[Cp])) {
            case "!":
                n[fo] = kp,
                h(n);
                break;
            case ",":
                n[fo] = e_,
                r(n);
                break;
            case ";":
                n.type = Lp,
                i.eof && i.eof(n);
                break;
            default:
                throw new Error(Pp + n[Cp].toString(16))
            }
            Lp !== n.type && setTimeout(a, 0)
        },
        o = function() {
            s(),
            setTimeout(a, 0)
        };
        o()
    },
    lH = "";
    i[Nv] && i[Nv](Rp,
    function(t) {
        if (t.ctrlKey && t[Dp] && t.altKey && 73 == t[Np]) {
            var i = xY.name + Bp + xY[$p] + Gp + xY[Fp] + qa + xY[zp] + qa + xY[Yp] + lH;
            xY.alert(i)
        }
    },
    !1);
    var vH = Hp;
    lH = Up + decodeURIComponent(Wp);
    var bH, gH, yH, xH = t,
    mH = qp,
    EH = Xp,
    pH = Vp,
    wH = Kp,
    TH = Zp,
    OH = Jp,
    IH = Qp,
    MH = tw,
    AH = iw,
    jH = nw,
    SH = ew,
    CH = sw,
    kH = hw,
    LH = rw,
    PH = ir,
    RH = aw,
    DH = ow,
    NH = fw,
    BH = cw,
    $H = uw,
    GH = _w,
    FH = xH[wH + dw];
    FH && (gH = xH[LH + lw][TH + vw], FH.call(xH, Vn, RH), FH.call(xH, Kn, BH), FH.call(xH,
    function() {
        YH && YH == vH && (QH = !1)
    },
    DH));
    var zH, YH, HH, UH = 111,
    WH = function(t, i) {
        i || (i = bw + EH + gw);
        try {
            yH[zh](t, i, 6 * UH, 1 * UH)
        } catch(n) {}
    },
    qH = !0,
    XH = !0,
    VH = !0,
    KH = !0,
    ZH = !0,
    JH = !0,
    QH = !0,
    tU = nz ? 200 : 1024,
    iU = function(t, i) {
        return Xn ? Xn(t, i) || "": void 0
    };
    if (i.createElement) {
        var nU = i[Ga](yw);
        nU[ta][xw] = __,
        nU.onload = function(t) {
            var i = t[C_][mw],
            n = gH;
            if ("" === n || Ew == n || pw == n) return void this[gx][gx].removeChild(this[gx]);
            var e = i[ww].fromCharCode;
            i[wH + dw](function() {
                qn(e) != zH && (jU[Jh]._jz = null)
            },
            BH),
            this[gx][gx][Ox](this[gx])
        };
        var eU = i[Ga](i_);
        eU[ta][Sa] = x_,
        eU[ta][Ca] = x_,
        eU[ta][Tw] = u_,
        eU[lc](nU),
        i[od][lc](eU)
    }
    if (i[PH + Ow]) {
        var sU = i[PH + Ow](AH + Iw);
        sU.style[xw] = __,
        sU[wx] = function(t) {
            var i = Mw,
            n = t.target[i + Aw];
            bH = n[jw].now();
            var e = n[jH + SH + Sw + CH + Cw][kH + fo];
            yH = e[mH + kw],
            KF && (n = xH);
            var s = n[wH + dw];
            s[zh](xH, te, BH),
            s.call(xH, ie, $H),
            s[zh](xH, ee, GH),
            s[zh](xH, se, DH),
            s[zh](xH, Zn, NH),
            s[zh](xH, Qn, GH),
            s.call(xH, ne, BH),
            s.call(xH, Jn, BH),
            this[gx][gx][Ox](this[gx])
        };
        var eU = i[Ga](i_);
        eU[ta][Sa] = x_,
        eU.style.height = x_,
        eU.style[Tw] = u_,
        eU[lc](sU),
        i[od].appendChild(eU)
    }
    var hU = {
        position: Lw,
        userSelect: __,
        outline: __,
        transformOrigin: Pw,
        "-webkit-tap-highlight-color": Ym
    },
    rU = Rw;
    gi(Dr + rU, hU);
    var aU = {
        width: v_,
        height: v_,
        position: d_,
        overflow: u_,
        textAlign: Co,
        outline: __,
        tapHighlightColor: Ym,
        userSelect: __
    },
    oU = Dw;
    gi(Dr + oU, aU);
    var fU = Nw,
    cU = {
        overflow: u_,
        "text-align": Co,
        "-webkit-tap-highlight-color": Ym,
        outline: __
    };
    gi(Dr + fU, cU);
    var uU = A(function(t) {
        this[Bw] = new dU,
        this._n5 = new hz,
        this._8k = [],
        this[$w] = [],
        this[Gw] = [],
        this._8j = {},
        this[no] = new _z,
        this._je = new xU,
        this._viewport = new mU,
        this._je.listener = function(t) {
            this._6t(t)
        }.bind(this),
        this[Fw](),
        this.setParent(t)
    },
    {
        _new: null,
        _j8: null,
        _n5: null,
        _nhd: null,
        _je: null,
        _nhf: function(t) {
            return t ? (this[zw] || (this._6hs = {}), this[zw][t] ? !1 : (this[zw][t] = !0, void this[Yw]())) : this[Yw]()
        },
        _9x: function(t) {
            return this[zw] && this[zw][t]
        },
        isInvalidate: function() {
            return this._6h
        },
        clear: function() {
            this._n5[wf](),
            this._nhd[Fh] = 0,
            this._8j = {},
            this[nu] = !1,
            this.invalidate()
        },
        _6e: function() {
            this[Hw](Uw),
            this._2k()
        },
        _2k: function() {
            this[Hw](Ww)
        },
        invalidate: function(t) { (t || !this._6h) && (this._6h = !0, this._mj || (this._jzingID = requestAnimationFrame(this._fv[fr](this))))
        },
        _6f: function(t) {
            return this._mj = t,
            t ? void(this[qw] && (cancelAnimationFrame(this._jzingID), this[qw] = null)) : void(this._6h && this[Yw](!0))
        },
        _fv: function() {
            this[qw] = null,
            this._6h = !1;
            var t = this[nu];
            this[nu] || (this[Xw](), this[nu] = !0),
            this._nhj(!t),
            this._37(),
            this._jz(),
            this._22()
        },
        _nhj: function(t) {
            this[Vw] = t || this[Kw],
            (t || this[zw][Uw]) && this._9v(),
            (t || this[zw][Zw]) && this._6u(),
            this[Jw](t),
            this._45(t),
            this[zw] = {}
        },
        _37: function() {
            this[$w][Fh] = 0;
            var t = this[Qw];
            if (this._n5[Wf](function(i) {
                if (i[tT] !== !1) {
                    var n = this[iT](i);
                    t[ku](n.x, n.y, n[Sa], n.height) && this._nhd[Xh](i)
                }
            },
            this), this._nhd = this._ie(this[$w]), !this[Vw]) {
                var i = this[Bw];
                this[Gw][Fh] = 0,
                i._nge(this[Qw]),
                i._ip() || this[$w][Wf](function(t) {
                    var n = this[iT](t);
                    i._fo(n.x, n.y, n[Sa], n[Ca]) && this._ltingList[Xh](t)
                },
                this)
            }
        },
        _ie: function(t) {
            return KF ? t = d(t, this[nT]) : t[eT](this[nT]),
            t
        },
        _ne3: function(t, i) {
            return t = t.zIndex || 0,
            i = i[sT] || 0,
            t - i
        },
        _ngb: function(t) {
            return t[hT]
        },
        _jz: function() {
            if (this[Vw]) return this._e2(),
            this._6q(!0),
            void this[rT](this[aT], this[$w]);
            this._6q(this[oT]);
            var t = this[Bw],
            i = this[aT];
            i.save(),
            this[oT] && (ae(i), i[Ix](this._nguffer.canvas, this[oT].x, this[oT].y)),
            t._ki(i, this._e0[fr](this)),
            this._e2(),
            this[rT](i, this[Gw]),
            i[Um]()
        },
        _6q: function(t) {
            this._nhfCanvasSizeFlag ? (this._nhfCanvasSizeFlag = !1, this._j8[Ya](this[jx], this[Sx])) : t && re(this._j8)
        },
        _9v: function() {
            var t = this.width,
            i = this[Ca];
            return this._width == t && this[Sx] == i ? !1 : (this[jx] = t, this._height = i, void(this[fT] = !0))
        },
        _45: function(t) {
            if (!t && !this[zw].viewport) return ! 1;
            var i = this._je[cT]([0, 0]),
            n = this[p_],
            e = this[jx] / n,
            s = this[Sx] / n,
            h = this.rotate,
            r = this[Qw];
            if (r.x == i[0] && r.y == i[1] && r[Sa] == e && r[Ca] == s && r.rotate == h) return ! 1;
            var a = r.toJSON();
            return this[Qw].set(i[0], i[1], e, s, h, n),
            this._3e(this[Qw], a, t),
            !0
        },
        _3e: function(t, i, n) {
            this._nen || n || (this[oT] = this._hd(i, t))
        },
        _6t: function() {
            if (this[nu]) {
                if (this._mj) {
                    var t;
                    this._nhurrentMatrix ? this[uT][_T] = t = bU.mul([], this._je.m, bU.invert([], this[uT].m)) : t = this._je.m,
                    this._5g(t)
                }
                this._nhf(Zw),
                this._2k()
            }
        },
        _5g: function(t) {
            this.__nhssMatrix = t,
            EU[dT](this._j8, r_, t ? lT + t.join(Ar) + ")": "")
        },
        _6u: function() {
            var t = this[uT];
            if (this._nhurrentMatrix = {
                tx: this._je.m[4],
                ty: this._je.m[5],
                m: this._je.m[Hh](),
                scale: this._je._hw(),
                rotate: this._je._fm()
            },
            this[vT] && this._5g(null), !this[Vw]) {
                if (this._2v(this[uT], t), !t || t[p_] != this[uT].scale) return this._71(this._nhurrentMatrix[p_], t ? t[p_] : null),
                void(this[Vw] = !0);
                if (!t || t[uo] != this[uT][uo]) return this._56(this[uT][uo], t ? t[uo] : null),
                void(this[Vw] = !0);
                var i = t.m[4] - this._nhurrentMatrix.m[4],
                n = t.m[5] - this[uT].m[5],
                e = this.ratio;
                i *= e,
                n *= e;
                var s = 1e-4; (Math.abs(i - Math.round(i)) > s || Math.abs(n - Math.round(n)) > s) && (this._nen = !0)
            }
        },
        _6v: function() {
            var t = this[no],
            i = t[qh]();
            t[wf](),
            this._n5.forEach(function(i) {
                i.__i5 !== !1 && t.add(this[iT](i))
            },
            this),
            t.equals(i) || this._3g(t, i)
        },
        _3g: function() {},
        _nek: !1,
        _nhl: function() {},
        _9u: function(t) {
            var i = t[La];
            t.scale(i, i),
            t[r_][Zh](t, this._je.m)
        },
        render: function(t, i) {
            i && i[Fh] && (t[Cx](), this._9u(t), i[Wf](function(i) {
                if (t[Cx](), i[bT] !== !1) try {
                    i[rT](t)
                } catch(n) {
                    console[Po](n)
                }
                t[Um]()
            },
            this), t.restore())
        },
        setParent: function(t) {
            N(t) && (t = i.getElementById(t)),
            this._n4 != t && (this._n4 && this._new && (R(this._n4, fU), this._n4[Ox](this[gT])), this._n4 = t, this._n4 && (P(this._n4, fU), this._n4[lc](this._74()), this._6e()))
        },
        _74: function() {
            return this[gT] || this._nhn(),
            this._new
        },
        _nhn: function() {
            var t = ki(!0);
            Un(t.g),
            t.className = rU;
            var n = i[Ga](i_);
            return n.className = oU,
            n[lc](t),
            n[yT] = 0,
            this._j8 = t,
            this[gT] = n,
            this[aT] = this._j8[Mo](za),
            t
        },
        toLogical: function(t, i) {
            return t instanceof Object && (Q(t) && (t = this._8h(t)), Array.isArray(t) ? (i = t[1] || 0, t = t[0] || 0) : (i = t.y || 0, t = t.x || 0)),
            this._je.reverseTransform([t, i])
        },
        toCanvas: function(t, i) {
            return this._je[r_]([t, i])
        },
        _8h: function(t) {
            return yi(t, this[gT])
        },
        _el: function(t, i, n) {
            if (t.hitTest instanceof Function) return t[Zu](i, n);
            var e = this[iT](t);
            return e ? n ? _z[ku](e.x, e.y, e[Sa], e[Ca], i[0] - n, i[1] - n, n + n, n + n) : _z.intersects(e.x, e.y, e[Sa], e[Ca], i[0], i[1]) : t
        },
        hitTest: function(t, i) {
            return this._8i(t, i)
        },
        _8i: function(t, i) {
            i = this._9s(i),
            t = this.toLogical(t);
            for (var n, e = this[$w].length; --e >= 0;) if (n = this[$w][e], this._el(n, t, i)) return n
        },
        _9s: function(t) {
            return (t === n || null === t) && (t = sz[rx]),
            t ? t / this[p_] : 0
        },
        getUIByMouseEvent: function(t, i) {
            if (t.uiId) return this._n5[qd](t[xT]);
            var n = this._8i(t, i);
            return t[xT] = n ? n.id: -1,
            n
        },
        _8j: null,
        invalidateUI: function(t) {
            this._8j[t.id] = t,
            this[Yw]()
        },
        _9z: function(t) {
            t[to] instanceof Function && t[to](this)
        },
        _nhp: function(t) {
            t.__ji && this._he(t[mT]);
            var i = t[tT];
            if (t.__i5 = this._ej(t), !t[tT]) return i;
            var n = t[mT];
            this._9z(t);
            var e = this._ngb(t);
            t[mT] = {
                x: e.x,
                y: e.y,
                width: e[Sa],
                height: e[Ca]
            };
            var s = t.__i5 !== i || !_z[_c](n, e);
            return s && t[mT] && this._he(t[mT]),
            s
        },
        _ej: function(t) {
            return t.visible !== !1
        },
        _$p: function() {
            this._n5[Wf](function(t) {
                this[ET](t)
            },
            this),
            this._8j = {},
            this._6v()
        },
        _nex: function(t) {
            if (t) return this._$p();
            var i = this._nhfBoundsFlag;
            this._nhfBoundsFlag = !1;
            for (var n in this._8j) {
                var e = this._8j[n];
                i ? this._nhp(e) : i = this[ET](e)
            }
            this._8j = {},
            i && this._6v()
        },
        _8k: null,
        _22: function() {
            if (!this._8k[Fh]) return ! 1;
            var t = this._8k;
            this._8k = [],
            t[Wf](function(t) {
                try {
                    var i = t.call,
                    n = t.scope,
                    e = t[pT];
                    n instanceof Object ? i = i.bind(n) : n && !e && (e = parseInt(n)),
                    e ? setTimeout(i, e) : i()
                } catch(s) {}
            },
            this),
            this._6h && this._fv()
        },
        _ef: function(t, i, n) {
            this._8k[Xh]({
                call: t,
                scope: i,
                delay: n
            }),
            this._6h || this._22()
        },
        _44: function(t, i) {
            for (var n = this[$w], e = 0, s = n[Fh]; s > e; e++) if (t[zh](i, n[e]) === !1) return ! 1
        },
        _ee: function(t, i) {
            this._n5[Wf](t, i)
        },
        _$v: function(t, i) {
            for (var n = this[$w], e = n[Fh] - 1; e >= 0; e--) if (t[zh](i, n[e]) === !1) return ! 1
        },
        _42: function(t, i) {
            this._n5[wT](t, i)
        },
        _40: function() {
            return this.bounds
        },
        _h7: function(t, i, n) {
            t /= this[p_] || 1,
            this._k5(t, i, n)
        },
        _k5: function(t, i, e) {
            if (this[nu] && (i === n || null === i)) {
                var s = this.toLogical(this[Sa] / 2, this[Ca] / 2);
                i = s[0] || 0,
                e = s[1] || 0
            }
            return this._je.scale(t, [i || 0, e || 0])
        },
        _ec: function(t, i) {
            this._je[Ux]([t, i], !0)
        },
        _nep: function(t, i, n, e) {
            if (n == this[p_] && e !== !1) {
                var s = this.ratio;
                s != (0 | s) && (t = Math.round(t * s) / s, i = Math.round(i * s) / s)
            }
            this._je.translateTo([t, i], n)
        },
        _k6: function(t, i) {
            return this._k5(this._ea, t, i)
        },
        _ic: function(t, i) {
            return this._k5(1 / this._ea, t, i)
        },
        _1b: function() {
            var t = this._40();
            if (!t[Sf]()) {
                var i = this[Sa] / t.width,
                n = this[Ca] / t.height,
                e = Math.min(i, n);
                return e = Math.max(this._hb, Math.min(this._h9, e)),
                {
                    scale: e,
                    cx: t.cx,
                    cy: t.cy
                }
            }
        },
        _ea: 1.3,
        _h9: 10,
        _hb: .1,
        _nen: !1,
        _71: function() {},
        _56: function() {},
        _2v: function() {},
        _e2: function() {
            this._nguffer = null,
            this[Bw]._l3()
        },
        _e0: function(t) {
            var i = this._je,
            n = this._j8.ratio,
            e = this.scale,
            s = i._fm();
            if (!s) {
                var h = i[r_]([t[0], t[1]]);
                return h[0] *= n,
                h[1] *= n,
                n *= e,
                h[2] = t[2] * n,
                h[3] = t[3] * n,
                h
            }
            var r = new _z,
            a = i[r_]([t[0], t[1]]);
            return r.add(a[0], a[1]),
            a = i[r_]([t[0] + t[2], t[1]]),
            r.add(a[0], a[1]),
            a = i[r_]([t[0], t[1] + t[3]]),
            r.add(a[0], a[1]),
            a = i.transform([t[0] + t[2], t[1] + t[3]]),
            r.add(a[0], a[1]),
            [r.x * n, r.y * n, r[Sa] * n, r[Ca] * n]
        },
        _hd: function(t, n) {
            var e = n._3m(t.x, t.y, t.width, t[Ca]);
            if (e) {
                var s = this._j8,
                h = this[p_] * this[La],
                r = this[Bw],
                a = {},
                o = 1e-6;
                e.x > o && (a.left = n._4u(0, 0, e.x, n[Ca], h)),
                n[Sa] - e.right > o && (a[Gr] = n._4u(e[Gr], 0, n[Sa] - e.right, n[Ca], h)),
                e.y > o && (a.top = n._4u(e.x, 0, e.width, e.y, h)),
                n[Ca] - e.bottom > o && (a.bottom = n._4u(e.x, e.bottom, e.width, n.height - e.bottom, h)),
                U(a) || r._4p(a);
                var f = n._i3(t.x, t.y),
                c = (f[0] - e.x) * h,
                u = (f[1] - e.y) * h,
                _ = e[Sa] * h,
                d = e.height * h;
                c = Math[eo](c),
                u = Math[eo](u),
                _ = Math[eo](_),
                d = Math[eo](d);
                var l = this[TT];
                return l || (l = this[TT] = i.createElement(Fa), l.g = l.getContext(za)),
                l[Sa] = _,
                l[Ca] = d,
                ae(l.g),
                l.g.drawImage(s, c, u),
                c = f[0] * h - c,
                u = f[1] * h - u,
                {
                    x: c,
                    y: u,
                    canvas: l
                }
            }
        },
        _m1: function(t, i, n, e) {
            this._ng8._n6(t, i, n, e)
        },
        _he: function(t) {
            this._ng8._io(t)
        }
    });
    Object.defineProperties(uU.prototype, {
        width: {
            get: function() {
                return this[gT][P_]
            }
        },
        height: {
            get: function() {
                return this[gT][R_]
            }
        },
        rotate: {
            get: function() {
                return this._je._fm()
            }
        },
        tx: {
            get: function() {
                return this._je._8s()[0]
            }
        },
        ty: {
            get: function() {
                return this._je._8s()[1]
            }
        },
        ratio: {
            get: function() {
                return this._j8 ? this._j8[La] : void 0
            }
        },
        scale: {
            get: function() {
                return this._je._hw()
            },
            set: function(t) {
                this._h7(t)
            }
        },
        renderScale: {
            get: function() {
                return this[p_] * this[La]
            }
        },
        uis: {
            get: function() {
                return this._n5
            }
        },
        length: {
            get: function() {
                return this._n5[Fh]
            }
        },
        viewportBounds: {
            get: function() {
                return this._viewport[OT]()
            }
        }
    });
    var _U, dU = A({
        constructor: function() {
            this._hi = [],
            this._ji = new _z,
            this._hg = HF ? 20 : 50
        },
        _hg: 20,
        _hi: null,
        _lz: !1,
        _ji: null,
        _l3: function() {
            this._lz = !1,
            this._hi[Fh] = 0,
            this[IT] = null,
            this._ji[wf]()
        },
        _ip: function() {
            return 0 == this._hi[Fh] && !this[IT]
        },
        _n6: function(t, i, n, e) {
            0 >= n || 0 >= e || this._hi[Xh]([t, i, n, e])
        },
        _io: function(t) {
            this._n6(t.x, t.y, t.width, t[Ca])
        },
        _4p: function(t) {
            var i = this._ji;
            for (var n in t) {
                var e = t[n],
                s = e[OT]();
                i.add(s)
            }
            this[IT] = t
        },
        _nge: function(t, i) {
            for (var n = [], e = this._hi, s = 0, h = e.length; h > s; s++) {
                var r = e[s];
                t[ku](r[0], r[1], r[2], r[3]) && (n[Xh](r), this._ji[rl](r[0], r[1], r[2], r[3]))
            }
            this._hi = n,
            this._lz = i || n.length >= this._hg
        },
        _fo: function(t, i, n, e) {
            if (!this._ji[Ol](t, i, n, e)) return ! 1;
            if (this._lz) return ! 0;
            if (this[IT]) {
                var s = this._viewportClips;
                for (var h in s) if (s[h].intersects(t, i, n, e)) return ! 0
            }
            for (var r, a = 0,
            o = this._hi[Fh]; o > a; a++) if (r = this._hi[a], _z[ku](t, i, n, e, r[0], r[1], r[2], r[3])) return ! 0;
            return ! 1
        },
        _ki: function(t, i) {
            if (this._ip()) return ! 1;
            if (t.beginPath(), this._lz) {
                var n = i([this._ji.x, this._ji.y, this._ji[Sa], this._ji[Ca]]);
                return oe(t, n[0], n[1], n[2], n[3]),
                void t[Px]()
            }
            if (this[IT]) for (var e in this[IT]) {
                var n = this._viewportClips[e][MT];
                oe(t, n[0], n[1], n[2], n[3])
            }
            for (var s = this._hi,
            h = 0,
            r = s[Fh]; r > h; h++) {
                var n = i(s[h]);
                oe(t, n[0], n[1], n[2], n[3])
            }
            t[Px]()
        }
    });
    dU[AT] = function(t, i, n, e) {
        return t instanceof Object && (i = t.y, n = t[Sa], e = t[Ca], t = t.x),
        n = X(t + n) - (t = q(t)),
        e = X(i + e) - (i = q(i)),
        [t, i, n, e]
    },
    dU._de = q,
    dU._h6 = X,
    mY[jT] = ST,
    mY[CT] = kT,
    sz.NAVIGATION_TYPE = mY[CT];
    var lU = A({
        _jz: function() {
            O(this, lU, LT, arguments),
            this[PT]._jz()
        },
        _ne3: function(t, i) {
            return t = t[Mf][sT] || 0,
            i = i[Mf].zIndex || 0,
            t - i
        },
        "super": uU,
        constructor: function(t, n) {
            this._kt = t,
            N(n) && (n = i[RT](n)),
            n && n.tagName || (n = i[Ga](i_)),
            I(this, lU, [n]),
            this[PT] = new rh(this, this[gT]),
            this._hm = [],
            this._kt._6.addListener(this._1g, this),
            this._kt._1d.addListener(this._97, this),
            this._kt._$y[gv](this._6l, this),
            this._kt._$h[gv](this._33, this),
            this._kt._$k[gv](this._3b, this),
            this._ng2 = {},
            this._3w(sz.NAVIGATION_TYPE, !0)
        },
        _5g: function(t) {
            O(this, lU, DT, arguments),
            this[PT]._5g(t)
        },
        _hj: function(t) {
            return t.id || (t = this._n5[qd](t)),
            t ? (this._n5.remove(t), t.destroy(), t[mT] && this._he(t[mT]), void(this._nhfBoundsFlag = !0)) : !1
        },
        _fp: function() {
            this._n5.forEach(function(t) {
                t[dg]()
            }),
            this._n5.clear()
        },
        _ej: function(t) {
            var i = t.data || t;
            return i._$l && (i._$l = !1, i._i5 = this._53(i)),
            i._i5 !== !1
        },
        _53: function(t) {
            return this._3p(t) ? !this._kt[NT] || this._kt[NT](t) !== !1 : !1
        },
        _ne1: function(t) {
            return this._kt._3i == Qs(t)
        },
        _3p: function(t) {
            if (t[bT] === !1) return ! 1;
            if (! (t instanceof TU)) return this._kt._3i != Qs(t) ? !1 : !t._e8;
            var i = t.fromAgent,
            n = t[gc];
            if (!i || !n) return ! 1;
            if (i == n && !t.isLooped()) return ! 1;
            if (t[BT]()) {
                var e = t[xc](!0);
                if (e && !e._ej(t)) return ! 1
            }
            var s = this._ej(i),
            h = this._ej(n);
            return s && h ? !0 : !1
        },
        _ngb: function(t) {
            return t._nek ? {
                x: t.$x + t[$T].x,
                y: t.$y + t.uiBounds.y,
                width: t[$T][Sa],
                height: t[$T][Ca]
            }: void 0
        },
        _2o: function(t) {
            var i = this._lp(t);
            if (i) {
                var n = this[iT](i);
                if (n) return new _z(n)
            }
        },
        _el: function(t, i, n) {
            return t.hitTest(i[0], i[1], n)
        },
        hitTest: function(t, i) {
            var n = O(this, lU, Zu, arguments);
            if (n) {
                t = this.toLogical(t),
                i = this._9s(i);
                var e = n.hitTest(t[0], t[1], i, !0);
                if (e instanceof jU) return e
            }
            return n
        },
        _3f: function(t) {
            return this[GT](t)
        },
        _6q: function() {
            O(this, lU, FT, arguments),
            this._topCanvas._ir(this[Sa], this[Ca])
        },
        _ll: 1,
        _nhd: null,
        _8m: null,
        _8o: null,
        _n5: null,
        _n4: null,
        _j8: null,
        _ng8: null,
        _6h: !1,
        _nek: !1,
        _je: null,
        _44: function(t, i) {
            for (var n = this._nhd,
            e = 0,
            s = n[Fh]; s > e; e++) if (t[zh](i, n[e]) === !1) return ! 1
        },
        _ee: function(t, i) {
            this._n5.forEach(t, i)
        },
        _$v: function(t, i) {
            for (var n = this[$w], e = n[Fh] - 1; e >= 0; e--) if (t[zh](i, n[e]) === !1) return ! 1
        },
        _42: function(t, i) {
            this._n5[wT](t, i)
        },
        _3e: function(t) {
            O(this, lU, zT, arguments),
            this[YT] = {
                value: t
            }
        },
        _nhl: function() {
            this._45(!0),
            this._originAdjusted || (this._originAdjusted = !0, this._kt && this._kt.originAtCenter && this._je[HT]([this[Sa] / 2, this.height / 2]))
        },
        _fv: function() {
            if (!this[qE] && this._6h) {
                if (this[qw] = null, this._6h = !1, this[nu] && this._kt && this._kt._$l && (this._kt._$l = !1, this._kt.forEach(function(t) {
                    t.invalidateVisibility(!0)
                })), O(this, lU, UT, arguments), this._6x && (this[WT] || this[qT]) && this._6x._jc(), this[WT]) {
                    var t = this[WT][ar],
                    i = this[WT].old;
                    this[WT] = null,
                    this._kt._4b(new Tz(this._kt, r_, t, i))
                }
                if (this._scaleChanged) {
                    var t = this[XT].value,
                    i = this._scaleChanged.old;
                    this[XT] = null,
                    this._kt._4b(new Tz(this._kt, p_, t, i))
                }
                if (this[qT]) {
                    var t = this[qT].value,
                    i = this[qT].old;
                    this[qT] = null,
                    this._kt._4b(new Tz(this._kt, VT, t, i))
                }
                this._viewportChanged && (this._viewportChanged = !1, this._6x && this._6x._3e && this._6x._3e(this[Qw][Sa] * this[Qw][p_], this[Qw][Ca] * this[Qw][p_]), this._kt._4b(new Tz(this._kt, Ww, this[Qw])))
            }
        },
        _hm: null,
        _nhp: function(t) {
            var i = t[Mf];
            if (!t._1a && !i._6h && !i._$l) return ! 1;
            var n = t.$invalidateSize;
            return n = O(this, lU, ET, arguments) || n
        },
        _9z: function(t) {
            var i = t[Mf];
            i[KT] && (i.__4y = !1, t._4y()),
            i[wv] && i._i0() && (t._5n(), i[wv] = !1),
            (t._1a || i._6h) && (i._6h = !1, t[to]())
        },
        _ho: function(t, i) {
            var n = t.ratio;
            t[p_](n, n),
            t.transform.apply(t, this._je.m);
            for (var e = this[p_], s = [], h = 0, r = i[Fh]; r > h; h++) {
                var a = i[h];
                a._jz(t, e),
                a._k1 && a._k1.length && s.push(a)
            }
            if (s[Fh]) for (h = 0, r = s[Fh]; r > h; h++) s[h]._96(t, e)
        },
        render: function(t, i) {
            if (i.length) {
                if (t.save(), HF) try {
                    this._ho(t, i)
                } catch(n) {} else this._ho(t, i);
                t[Um]()
            }
        },
        _hp: function(t, i, n) {
            t[Cx](),
            t.translate( - n.x * i, -n.y * i),
            t[p_](i, i);
            var e, s, h = this._n5._jg[Hh]();
            h = this._ie(h);
            for (var r = [], a = 0, o = h[Fh]; o > a; a++) e = h[a],
            e[tT] && (s = this._ngb(e), n.intersectsRect(s.x, s.y, s.width, s[Ca]) && (e._jz(t, i), e._k1 && e._k1[Fh] && r[Xh](e)));
            if (r[Fh]) for (a = 0, o = r[Fh]; o > a; a++) r[a]._96(t, i);
            t[Um]()
        },
        _13: function() {},
        _1k: function() {
            for (var t, i, n = this._n5._jg,
            e = new _z,
            s = n.length - 1; s >= 0; s--) t = n[s],
            t._i5 && (i = t[$T], e[rl](t.$x + i.x, t.$y + i.y, i[Sa], i[Ca]));
            var h = this._8o;
            this._8o = e,
            e[_c](h) || this._13(h, e)
        },
        _8w: function() {},
        _55: function() {
            this[$w][Fh] = 0,
            this._8m = {}
        },
        _ln: function() {
            this._l3()
        },
        _ii: function() {
            this._l3(),
            this[qE] = !0,
            this._6h = !1,
            this._topCanvas[wf](),
            this._8k.length = 0,
            this._6x && (this._6x._ii(), delete this._6x)
        },
        _lp: function(t) {
            return this._n5.getById(t.id || t)
        },
        _$c: function(t) {
            return this._f8(t)
        },
        _hq: function(t, i) {
            var n = this[ZT](t, i);
            return {
                x: n[0],
                y: n[1]
            }
        },
        _f8: function(t, i) {
            var n = this.toLogical(t, i);
            return {
                x: n[0],
                y: n[1]
            }
        },
        _$a: null,
        _3b: function(t) {
            var i = t.source,
            n = t.data;
            if (n) if (this._nek) {
                var e, s;
                if ($(n)) for (var h = 0,
                r = n[Fh]; r > h; h++) s = n[h].id,
                e = this._n5[qd](s),
                e && (e.selected = i.containsById(s), e[JT]());
                else {
                    if (s = n.id, e = this._n5[qd](s), !e) return;
                    e[QT] = i[uc](s),
                    e[JT]()
                }
                this[Hw]()
            } else {
                this._$a || (this._$a = {});
                var e, s;
                if ($(n)) for (var h = 0,
                r = n[Fh]; r > h; h++) s = n[h].id,
                this._$a[s] = !0;
                else s = n.id,
                this._$a[s] = !0
            }
        },
        _kt: null,
        _nhw: function(t) {
            var i = t.uiClass;
            return i ? new i(t, this._kt) : void 0
        },
        _1g: function(t) {
            if (!this._nek) return ! 1;
            var i = t[Lo],
            n = t[Ml];
            t_ == n && this._kt[tO](),
            iO == n ? (this._hj(i.id), this._kq(i)) : nO == n && i._i0() && t[ar] && this._5z(i);
            var e = this._n5[qd](i.id);
            e && e._nek && e[eO](t) && this[Hw]()
        },
        _3x: function(t) {
            var i = this._lp(t);
            i && (i.invalidateData(), this[Hw]())
        },
        _97: function(t) {
            if (!this[nu]) return ! 1;
            switch (t[Ml]) {
            case Lz.KIND_ADD:
                this._kq(t.data);
                break;
            case Lz[nv]:
                this._hr(t[ao]);
                break;
            case Lz.KIND_CLEAR:
                this._ig(t[ao])
            }
        },
        _l3: function() {
            this[sO] = {},
            this._fp(),
            this[wf]()
        },
        _ng2: null,
        _kq: function(t) {
            var i = this[hO](t);
            i && (this._n5.add(i), this[nu] && (this[sO][t.id] = t), this[Hw]())
        },
        _hr: function(t) {
            if (Array[xr](t)) {
                for (var i, n = [], e = 0, s = t[Fh]; s > e; e++) i = t[e].id,
                n[Xh](i),
                delete this[sO][i];
                t = n
            } else t = t.id,
            delete this[sO][t],
            t = [t];
            t[Wf](function(t) {
                this._hj(t)
            },
            this),
            this[Hw]()
        },
        _ig: function() {
            this._l3()
        },
        _6l: function(t) {
            return this[nu] ? void(t[Lo] instanceof OU && !this[sO][t[Lo].id] && (t[Cl] && (this._3x(t[Cl]), t[Cl].__6h = !0), t[ar] && (this._3x(t[ar]), t[ar].__6h = !0), this._5z(t.source))) : !1
        },
        _33: function(t) {
            return this._nek ? void(t[Lo] instanceof OU && !this[sO][t[Lo].id] && this._5z(t.source)) : !1
        },
        _2q: function(t) {
            if (t[rO]) {
                var i = t[xc](!0);
                if (!i) return t[rO] = !1,
                void t[aO]();
                i._fv(this._kt),
                i._ng4(function(t) {
                    t.validateEdgeBundle()
                })
            }
        },
        _$p: function() {
            var t, i = (this._kt, this._kt.graphModel),
            n = this._n5,
            e = [],
            s = 1;
            if (i[oO](function(i) {
                return i instanceof TU ? (this._2q(i), void e[Xh](i)) : (t = this[hO](i), void(t && (n.add(t), i[fO] = s++)))
            },
            this), n[Fh]) for (var h = n._jg,
            s = h[Fh] - 1; s >= 0; s--) t = h[s],
            this._3c(t, t[Mf]);
            for (var r, s = 0,
            a = e.length; a > s; s++) if (r = e[s], t = this._nhw(r)) {
                this._3c(t, r),
                n.add(t);
                var o = r[Ec],
                f = r.toAgent,
                c = o[fO] || 0;
                o != f && (c = Math.max(c, f[fO] || 0)),
                r[fO] = c
            }
            if (e[Fh] && n._jg[eT](function(t, i) {
                return t.$data[fO] - i[Mf].__lc
            }), this._$a) {
                var u = i.selectionModel;
                for (var _ in this._$a) if (u.containsById(_)) {
                    var t = n[qd](_);
                    t && (t[QT] = !0)
                }
                this._$a = null
            }
            this._6v()
        },
        _nex: function(t) {
            if (t) return this._$p();
            var i = this[cO];
            this[cO] = !1;
            for (var n in this[sO]) {
                var e = this[sO][n];
                e instanceof OU ? this._5z(e) : this._61(e)
            }
            this._ng2 = {};
            for (var s, h, r = this._n5._jg,
            a = [], o = r.length - 1; o >= 0; o--) s = r[o],
            h = s[Mf],
            h instanceof TU ? (this._2q(h), a.push(s)) : this._3c(s, h) && !i && (i = !0);
            if (a.length) for (var o = 0,
            f = a[Fh]; f > o; o++) s = a[o],
            this._3c(s, s[Mf]) && !i && (i = !0);
            i && this._6v()
        },
        _3c: function(t, i) {
            if (i instanceof TU) return i[KT] && (i[KT] = !1, t._4y()),
            this[ET](t);
            if (i[wv] && i._i0() && (t._5n(), i.__6h = !1), this[ET](t)) {
                var n = this._4m(i);
                return n && (n[wv] = !0),
                i.hasEdge() && i[Cc](function(t) {
                    t[KT] = !0
                },
                this),
                !0
            }
        },
        _2r: function(t, i) {
            var n = t.fromAgent,
            e = t[gc],
            s = i[uO](n.id);
            if (n == e) return s;
            var h = i[uO](e.id);
            return Math.max(s, h)
        },
        _2t: function(t, i) {
            var n = this[B_]._gu(t);
            return n ? i[uO](n.id) : 0
        },
        _5z: function(t) {
            var i = this._n5,
            n = i[qd](t.id);
            if (!n) throw new Error(_O + t[rr] + dO);
            var s = this._2t(t, i),
            h = [n];
            t[$h]() && e(t,
            function(t) {
                t instanceof OU && (n = i.getById(t.id), n && h[Xh](n))
            },
            this),
            this._4k(i, s, h)
        },
        _61: function(t) {
            var i = this._n5.getById(t.id);
            if (i) {
                var n = this._2r(t, this._n5);
                this._n5.setIndexBefore(i, n)
            }
        },
        _4k: function(t, i, n) {
            function e(t) {
                s.add(t)
            }
            var s = new hz;
            l(n,
            function(n) {
                i = t[lO](n, i),
                n[Mf][Cc](e)
            },
            this),
            0 != s[Fh] && s[Wf](this._61, this)
        },
        _87: function(t) {
            return t[xc](!0)
        },
        _4m: function(t) {
            var i = Ee(t);
            return i && i[nO] ? i: null
        },
        _6w: null,
        _6x: null,
        _3w: function(t, i) {
            return i || t != this._6w ? (this._6w = t, this._6x && (this._6x._ii(), delete this._6x), t == mY.NAVIGATION_SCROLLBAR ? void(this._6x = new sh(this, this[gT])) : t == mY.NAVIGATION_BUTTON ? void(this._6x = new eh(this, this[gT])) : void 0) : !1
        },
        _2v: function(t, i) {
            this[WT] = {
                value: t,
                old: i
            }
        },
        _71: function(t, i) {
            this[XT] = {
                value: t,
                old: i
            }
        },
        _3g: function(t, i) {
            this._8oChanged = {
                value: t,
                old: i
            }
        },
        _72: function() {
            this._6e()
        }
    });
    Object[Rr](lU[Jh], {
        _viewportBounds: {
            get: function() {
                return this[vO]
            }
        },
        _scale: {
            get: function() {
                return this[p_]
            },
            set: function(t) {
                this._h7(t)
            }
        },
        _tx: {
            get: function() {
                return this.tx
            }
        },
        _ty: {
            get: function() {
                return this.ty
            }
        },
        graphModel: {
            get: function() {
                return this._kt._ktModel
            }
        }
    });
    var vU = uU,
    bU = {};
    bU[ir] = function() {
        return [1, 0, 0, 1, 0, 0]
    },
    bU[bO] = function(t, i) {
        var n = i[0],
        e = i[1],
        s = i[2],
        h = i[3],
        r = i[4],
        a = i[5],
        o = n * h - e * s;
        return o ? (o = 1 / o, t[0] = h * o, t[1] = -e * o, t[2] = -s * o, t[3] = n * o, t[4] = (s * a - h * r) * o, t[5] = (e * r - n * a) * o, t) : null
    },
    bU[Dm] = function(t, i, n) {
        var e = i[0],
        s = i[1],
        h = i[2],
        r = i[3],
        a = i[4],
        o = i[5],
        f = n[0],
        c = n[1],
        u = n[2],
        _ = n[3],
        d = n[4],
        l = n[5];
        return t[0] = e * f + h * c,
        t[1] = s * f + r * c,
        t[2] = e * u + h * _,
        t[3] = s * u + r * _,
        t[4] = e * d + h * l + a,
        t[5] = s * d + r * l + o,
        t
    },
    bU.mul = bU.multiply,
    bU[uo] = function(t, i, n) {
        var e = i[0],
        s = i[1],
        h = i[2],
        r = i[3],
        a = i[4],
        o = i[5],
        f = Math.sin(n),
        c = Math.cos(n);
        return t[0] = e * c + h * f,
        t[1] = s * c + r * f,
        t[2] = e * -f + h * c,
        t[3] = s * -f + r * c,
        t[4] = a,
        t[5] = o,
        t
    },
    bU.scale = function(t, i, n) {
        var e = i[0],
        s = i[1],
        h = i[2],
        r = i[3],
        a = i[4],
        o = i[5],
        f = n[0],
        c = n[1];
        return t[0] = e * f,
        t[1] = s * f,
        t[2] = h * c,
        t[3] = r * c,
        t[4] = a,
        t[5] = o,
        t
    },
    bU[Ux] = function(t, i, n) {
        var e = i[0],
        s = i[1],
        h = i[2],
        r = i[3],
        a = i[4],
        o = i[5],
        f = n[0],
        c = n[1];
        return t[0] = e,
        t[1] = s,
        t[2] = h,
        t[3] = r,
        t[4] = e * f + h * c + a,
        t[5] = s * f + r * c + o,
        t
    },
    bU[r_] = function(t, i) {
        var n = i[0],
        e = i[1];
        return [n * t[0] + e * t[2] + t[4], n * t[1] + e * t[3] + t[5]]
    },
    bU.reverseTransform = function(t, i) {
        return bU.transform(bU[bO]([], t), i)
    };
    var gU = Math.PI + Math.PI,
    yU = D,
    xU = A({
        equals: function(t) {
            if (!t || !Array[xr](t)) return ! 1;
            for (var i = this.m,
            n = 0; n < i[Fh];) {
                if (i[n] != t[n]) return ! 1; ++n
            }
            return ! 0
        },
        constructor: function(t) {
            this.m = t || bU.create(),
            this.im = []
        },
        listener: null,
        _6h: !0,
        invalidate: function() {
            return this._6h = !0,
            this[gO] && this[_c](this[gO]) ? !1 : (this.listener && this.listener({
                target: this,
                kind: Yw
            }), this[gO] = this.m[Hh](), this)
        },
        validate: function() {
            return this._6h = !1,
            bU.invert(this.im, this.m),
            this
        },
        translate: function(t, i) {
            return yU(t) && (t = [arguments[0], arguments[1]], i = arguments[2]),
            i !== !1 ? (this.m[4] += t[0], this.m[5] += t[1], this[Yw]()) : (bU.translate(this.m, this.m, t), this.invalidate())
        },
        translateTo: function(t, i) {
            return yU(t) && (t = [arguments[0], arguments[1]], i = arguments[2]),
            i && (i /= this._hw(), bU.scale(this.m, this.m, [i, i])),
            this.m[4] = t[0],
            this.m[5] = t[1],
            this.invalidate()
        },
        scale: function(t, i) {
            return br == typeof t && (t = [t, t]),
            i ? (bU[Ux](this.m, this.m, i), bU[p_](this.m, this.m, t), bU.translate(this.m, this.m, fe(i))) : bU[p_](this.m, this.m, t),
            this.invalidate()
        },
        rotate: function(t, i) {
            return i ? (bU.translate(this.m, this.m, i), bU[uo](this.m, this.m, t), bU[Ux](this.m, this.m, fe(i))) : bU.rotate(this.m, this.m, t),
            this[Yw]()
        },
        transform: function(t) {
            return bU[r_](this.m, t)
        },
        reverseTransform: function(t) {
            return bU.transform(this._4t(), t)
        },
        toString: function() {
            return lT + this.m[Zf](Ar) + Sr
        },
        _4t: function() {
            return this._6h && this[to](),
            this.im
        },
        _ds: function() {
            var t = this.m[0],
            i = this.m[1],
            n = this.m[2],
            e = this.m[3];
            return [Math[Ka](t * t + n * n), Math[Ka](i * i + e * e)]
        },
        _hw: function() {
            var t = this.m[0],
            i = this.m[2];
            return Math[Ka](t * t + i * i)
        },
        _8s: function() {
            return [this.m[4], this.m[5]]
        },
        _d1: function() {
            var t = this.m[0],
            i = this.m[1],
            n = this.m[2],
            e = this.m[3];
            return [ce(Math.atan2(i, e)), ce(Math.atan2( - n, t))]
        },
        _fm: function() {
            return ce(Math[Va](this.m[1], this.m[3]))
        }
    }),
    mU = A({
        constructor: function() {},
        x: 0,
        y: 0,
        width: 0,
        height: 0,
        rotate: 0,
        set: function(t, i, n, e, s, h) {
            return this.x = t,
            this.y = i,
            this[Sa] = n,
            this[Ca] = e,
            this[uo] = s,
            this._nhos = Math.cos(s),
            this._sin = Math.sin(s),
            this[p_] = h,
            this._globalBounds = null,
            this
        },
        _i3: function(t, i) {
            return t -= this.x,
            i -= this.y,
            this[uo] ? de(t, i, this[el], this[sl]) : [t, i]
        },
        _8u: function(t) {
            var i = new _z;
            return i.add(this._i3(t.x, t.y)),
            i.add(this._i3(t.x + t[Sa], t.y)),
            i.add(this._i3(t.x, t.y + t[Ca])),
            i.add(this._i3(t.x + t[Sa], t.y + t[Ca])),
            i
        },
        _hx: function(t, i) {
            if (this[uo]) {
                var n = de(t, i, Math.sin( - this.rotate), Math.cos( - this[uo]));
                t = n[0],
                i = n[1]
            }
            return [this.x + t, this.y + i]
        },
        _5k: function(t, i) {
            var n = this._i3(t, i);
            return t = n[0],
            i = n[1],
            t >= 0 && i >= 0 && t <= this[Sa] && i <= this[Ca]
        },
        intersects: function(t, i, n, e) {
            if (!this[uo]) return _z[ku](this.x, this.y, this[Sa], this[Ca], t, i, n, e);
            if (!n || !e) return this._5k(t, i);
            var s = this.getGlobalBounds();
            if (!s[ku](t, i, n, e)) return ! 1;
            for (var h = s.points,
            r = 0; r < h.length;) {
                var a = h[r];
                if (_z[mf](t, i, n, e, a[0], a[1])) return ! 0;
                r++
            }
            var o = [[t, i], [t + n, i], [t, i + e], [t + n, i + e]];
            for (r = 0; r < o.length;) {
                var a = o[r];
                if (this._5k(a[0], a[1])) return ! 0;
                r++
            }
            return _e(h, o)
        },
        getGlobalBounds: function() {
            return this[yO] || (this[yO] = this._7d(0, 0, this[Sa], this.height)),
            this[yO]
        },
        _7d: function(t, i, n, e) {
            if (!this.rotate) return new _z(this.x + t, this.y + i, n, e);
            var s = [],
            h = new _z,
            r = this._hx(t, i);
            return s.push(r),
            h.add(r[0], r[1]),
            r = this._hx(t + n, i),
            s[Xh](r),
            h.add(r[0], r[1]),
            r = this._hx(t, i + e),
            s[Xh](r),
            h.add(r[0], r[1]),
            r = this._hx(t + n, i + e),
            s[Xh](r),
            h.add(r[0], r[1]),
            h[ba] = s,
            h
        },
        _4u: function(t, i, n, e, s) {
            var h;
            if (this.rotate) {
                var r = this._hx(t, i);
                h = (new mU).set(r[0], r[1], n, e, this.rotate, this[p_])
            } else h = (new mU).set(this.x + t, this.y + i, n, e, 0, this.scale);
            return h[MT] = [Math[eo](s * t), Math.round(s * i), Math[eo](s * n), Math[eo](s * e)],
            h
        },
        _3m: function(t, i, n, e) {
            if (!this[uo]) {
                var s = _z[Wo](this.x, this.y, this[Sa], this.height, t, i, n, e);
                return s && s.offset( - this.x, -this.y),
                s
            }
            var h = this._i3(t, i);
            return t = h[0],
            i = h[1],
            _z.intersection(0, 0, this[Sa], this[Ca], h[0], h[1], n, e)
        },
        equals: function(t) {
            return this.x == t.x && this.y == t.y && this[Sa] == t.width && this[Ca] == t[Ca] && this[uo] == t[uo]
        },
        toString: function() {
            return this.x + Ar + this.y + Ar + this[Sa] + Ar + this[Ca] + Ar + this.rotate
        },
        toJSON: function() {
            return {
                x: this.x,
                y: this.y,
                width: this.width,
                height: this[Ca],
                rotate: this[uo],
                scale: this.scale
            }
        }
    }),
    EU = {
        setStyle: bi,
        setStyles: li,
        addRule: gi,
        pre: Gz
    },
    pU = function(t, i, n, e) {
        this[Lo] = t,
        this[Ml] = i,
        this[Cl] = e,
        this.value = n,
        this[kl] = mY.PROPERTY_TYPE_STYLE
    };
    p(pU, Tz);
    var wU = function(t) {
        this.id = ++FF,
        this._nh6 = {},
        this._jk = {},
        t && (this.$name = t)
    };
    wU.prototype = {
        _jk: null,
        getStyle: function(t) {
            return this._jk[t]
        },
        setStyle: function(t, i) {
            var n = this._jk[t];
            return n === i || n && i && n[_c] && n[_c](i) ? !1 : this[xO](t, i, new pU(this, t, i, n), this._jk)
        },
        putStyles: function(t, i) {
            for (var n in t) {
                var e = t[n];
                i ? this._jk[n] = e: this[dT](n, e)
            }
        },
        _$l: !0,
        invalidateVisibility: function(t) {
            this._$l = !0,
            t || (this instanceof OU && this[mO]() && this[Cc](function(t) {
                t._$l = !0
            }), this._i0() && this[$h]() && this.forEachChild(function(t) {
                t.invalidateVisibility()
            }))
        },
        onParentChanged: function() {
            this.invalidateVisibility()
        },
        _i0: function() {
            return ! this._4r && this instanceof AU
        },
        invalidate: function() {
            this[Hl](new wz(this, EO, Yw))
        },
        _nh1: null,
        addUI: function(t, i) {
            if (this._nh1 || (this._nh1 = new hz), t.id || (t.id = ++FF), this[pO].containsById(t.id)) return ! 1;
            var n = {
                id: t.id,
                ui: t,
                bindingProperties: i
            };
            this[pO].add(n);
            var e = new wz(this, EO, iv, n);
            return this[Hl](e)
        },
        removeUI: function(t) {
            if (!this[pO]) return ! 1;
            var i = this[pO][qd](t.id);
            return i ? (this._nh1[mc](i), void this[Hl](new wz(this, EO, mc, i))) : !1
        },
        toString: function() {
            return this.$name || this.id
        },
        type: wO,
        _4r: !1,
        _i5: !0
    },
    p(wU, Pz),
    S(wU[Jh], [iO, rr, sT, TO]),
    Z(wU[Jh], {
        enableSubNetwork: {
            get: function() {
                return this._4r
            },
            set: function(t) {
                if (this._4r != t) {
                    var i = this._4r;
                    this._4r = t,
                    this instanceof OU && this._$w(),
                    this[Hl](new Tz(this, t_, t, i))
                }
            }
        },
        bindingUIs: {
            get: function() {
                return this[pO]
            }
        },
        styles: {
            get: function() {
                return this._jk
            },
            set: function(t) {
                if (this._jk != t) {
                    for (var i in this._jk) i in t || (t[i] = n);
                    this[OO](t),
                    this._jk = t
                }
            }
        }
    });
    var TU = function(t, i, n) {
        this.id = ++FF,
        this[hv] = {},
        this._jk = {},
        n && (this[IO] = n),
        this[kc] = t,
        this.$to = i,
        this.connect()
    };
    TU[Jh] = {
        $uiClass: us,
        _kd: null,
        _i7: null,
        _kg: null,
        _hz: null,
        _ey: !1,
        type: MO,
        otherNode: function(t) {
            return t == this[Tc] ? this.to: t == this.to ? this.from: void 0
        },
        connect: function() {
            if (this._ey) return ! 1;
            if (!this.$from || !this.$to) return ! 1;
            if (this._ey = !0, this[kc] == this.$to) return void this[kc]._ia(this);
            je(this.$to, this),
            Me(this[kc], this),
            ve(this[kc], this, this.$to);
            var t = this[Ec],
            i = this[gc];
            if (t != i) {
                var n;
                this[kc]._e8 && (ge(t, this, i), n = !0),
                this.$to._e8 && (xe(i, this, t), n = !0),
                n && ve(t, this, i)
            }
        },
        disconnect: function() {
            if (!this._ey) return ! 1;
            if (this._ey = !1, this[kc] == this.$to) return void this[kc]._nh2(this);
            Ae(this[kc], this),
            Se(this.$to, this),
            be(this[kc], this, this.$to);
            var t = this[Ec],
            i = this[gc];
            if (t != i) {
                var n;
                this[kc]._e8 && (ye(t, this, i), n = !0),
                this.$to._e8 && (me(i, this, t), n = !0),
                n && be(t, this, i)
            }
        },
        isConnected: function() {
            return this._ey
        },
        isInvalid: function() {
            return ! this[kc] || !this.$to
        },
        isLooped: function() {
            return this[kc] == this.$to
        },
        getEdgeBundle: function(t) {
            return t ? this._2g() : this[Sc]() ? this[kc]._4o: this.$from[xc](this.$to)
        },
        hasEdgeBundle: function() {
            var t = this[xc](!0);
            return t && t[AO].length > 1
        },
        _2g: function() {
            var t = this.fromAgent,
            i = this[gc];
            return t == i ? this.$from._e8 || this.$to._e8 ? null: this[kc]._4o: this[Ec][xc](this.toAgent)
        },
        _9m: null,
        hasPathSegments: function() {
            return this._9m && !this._9m[Sf]()
        },
        isBundleEnabled: function() {
            return this[jO] && !this[Bu]()
        },
        firePathChange: function(t) {
            this[Hl](new Tz(this, SO, t))
        },
        addPathSegment: function(t, i, n) {
            var e = new QY(i || XY, t);
            this._9m || (this._9m = new hz),
            this._9m.add(e, n),
            this.firePathChange(e)
        },
        addPathSegement: function() {
            return xY.log('change "edge.addPathSegement(...)" to "edge.addPathSegment(...)"'),
            this.addPathSegment[Zh](this, arguments)
        },
        removePathSegmentByIndex: function(t) {
            if (!this._9m) return ! 1;
            var i = this._9m[Hd](t);
            i && (this._9m[mc](i), this.firePathChange(i))
        },
        removePathSegment: function(t) {
            return this._9m ? (this._9m.remove(t), void this[CO](t)) : !1
        },
        movePathSegment: function(t, i, n) {
            if (!this._9m) return ! 1;
            if (t = t || 0, i = i || 0, xY[kO](n)) {
                var e = this._9m[Hd](n);
                return e ? (e[Sg](t, i), void this.firePathChange()) : !1
            }
            l(function(n) {
                n[Sg](t, i)
            }),
            this.firePathChange()
        },
        move: function(t, i) {
            return this._9m ? (this._9m[Wf](function(n) {
                n[Sg](t, i)
            },
            this), void this[CO]()) : !1
        },
        validateEdgeBundle: function() {}
    },
    p(TU, wU),
    Z(TU[Jh], {
        pathSegments: {
            get: function() {
                return this._9m
            },
            set: function(t) {
                xY[xr](t) && (t = new hz(t)),
                this._9m = t,
                this.firePathChange()
            }
        },
        from: {
            get: function() {
                return this[kc]
            },
            set: function(t) {
                if (this[kc] != t) {
                    var i = new Tz(this, Tc, t, this[kc]);
                    this[sr](i) !== !1 && (this.disconnect(), this[kc] = t, this[LO](), this.onEvent(i))
                }
            }
        },
        to: {
            get: function() {
                return this.$to
            },
            set: function(t) {
                if (this.$to != t) {
                    var i = new Tz(this, PO, t, this.$to);
                    this[sr](i) !== !1 && (this[pv](), this.$to = t, this.connect(), this[Hl](i))
                }
            }
        },
        fromAgent: {
            get: function() {
                return this[kc] ? this[kc]._e8 || this[kc] : null
            }
        },
        toAgent: {
            get: function() {
                return this.$to ? this.$to._e8 || this.$to: null
            }
        }
    }),
    S(TU[Jh], [Hu, {
        name: jO,
        value: !0
    },
    Xu]);
    var OU = function(t, i, n) {
        2 == arguments[Fh] && D(t) && (n = i, i = t, t = null),
        this.id = ++FF,
        this._nh6 = {},
        this._jk = {},
        t && (this[IO] = t),
        this[iu] = RO,
        this[uf] = lz[yl],
        this.$location = {
            x: i || 0,
            y: n || 0
        },
        this[yc] = {}
    };
    OU[Jh] = {
        $uiClass: _s,
        _e8: null,
        forEachEdge: function(t, i, n) {
            return ! n && this._kw && this._kw.forEach(t, i) === !1 ? !1 : ke(this, t, i)
        },
        forEachOutEdge: function(t, i) {
            return Le(this, t, i)
        },
        forEachInEdge: function(t, i) {
            return Pe(this, t, i)
        },
        getEdges: function() {
            var t = [];
            return this.forEachEdge(function(i) {
                t[Xh](i)
            }),
            t
        },
        _i8: null,
        _gr: null,
        _jp: null,
        _i9: null,
        _ngq: 0,
        _9i: 0,
        hasInEdge: function() {
            return null != this._i8
        },
        hasOutEdge: function() {
            return null != this._gr
        },
        hasEdge: function() {
            return null != this._i8 || null != this._gr || this.hasLoops()
        },
        linkedWith: function(t) {
            return t.from == this || t.to == this || t.fromAgent == this || t[gc] == this
        },
        hasEdgeWith: function(t) {
            var i = this[xc](t);
            return i && i[AO][Fh] > 0
        },
        _kw: null,
        _4o: null,
        hasLoops: function() {
            return this._kw && this._kw[Fh] > 0
        },
        _ia: function(t) {
            return this._kw || (this._kw = new hz, this._4o = new qW(this, this, this._kw)),
            this._4o._j0(t)
        },
        _nh2: function(t) {
            return this._4o ? this._4o[DO](t) : void 0
        },
        getEdgeBundle: function(t) {
            return t == this ? this._4o: this[yc][t.id] || t[yc][this.id]
        },
        _6g: function() {
            return this._9d && this._9d.length
        },
        _5c: function() {
            return this._8b && this._8b[Fh]
        },
        _9f: function() {
            return this._6g() || this._5c()
        },
        _8b: null,
        _9d: null,
        _nhq: function() {
            var t = this._e8,
            i = le(this);
            if (t != i) {
                var n = Ce(this);
                this._98(i),
                n[Wf](function(t) {
                    var i = t[Ec],
                    n = t.toAgent,
                    t = t[vd],
                    e = t[kc]._e8,
                    s = t.$to._e8;
                    i != n && (i && ye(i, t, n || t.$to), n && me(n, t, i || t.$from)),
                    e != s && (e && ge(e, t, s || t.$to), s && xe(s, t, e || t.$from), ve(e || t.$from, t, s || t.$to))
                },
                this)
            }
        },
        onParentChanged: function() {
            this[tO](),
            this._nhq()
        },
        _8e: null,
        _$w: function() {
            var t;
            if (this._4r ? t = null: (t = this._e8, t || this._gf !== !1 || (t = this)), this._8e == t) return ! 1;
            if (this._8e = t, this._g2 && this._g2._jg[Fh]) for (var i, n = this._g2._jg,
            e = 0,
            s = n[Fh]; s > e; e++) i = n[e],
            i instanceof OU && i._98(t)
        },
        setLocation: function(t, i) {
            if (this[NO] && this[NO].x == t && this[NO].y == i) return ! 1;
            var n;
            n = this[NO] ? {
                x: this.$location.x,
                y: this.$location.y
            }: this.$location;
            var e = new Tz(this, BO, n, {
                x: t,
                y: i
            });
            return this[sr](e) === !1 ? !1 : (this[NO] ? (this[NO].x = t, this[NO].y = i) : this[NO] = new oz(t, i), this[Hl](e), !0)
        },
        _e6: null,
        addFollower: function(t) {
            return null == t ? !1 : t.host = this
        },
        removeFollower: function(t) {
            return this._e6 && this._e6[Ku](t) ? t.host = null: !1
        },
        hasFollowers: function() {
            return this._e6 && !this._e6.isEmpty()
        },
        toFollowers: function() {
            return this[Ic]() ? this._e6[$u]() : null
        },
        clearFollowers: function() {
            this[Ic]() && (this[$O](), l(this[$O](),
            function(t) {
                t.host = null
            }))
        },
        getFollowerIndex: function(t) {
            return this._e6 && this._e6[Ku](t) ? this._e6.indexOf(t) : -1
        },
        setFollowerIndex: function(t, i) {
            return this._e6 && this._e6.contains(t) ? void this._e6[jc](t, i) : -1
        },
        getFollowerCount: function() {
            return this._e6 ? this._e6[Fh] : 0
        },
        _9c: function() {
            return this._e6 ? this._e6: (this._e6 = new hz, this._e6)
        },
        isFollow: function(t) {
            if (!t || !this[GO]) return ! 1;
            for (var i = this._host; i;) {
                if (i == t) return ! 0;
                i = i._host
            }
            return ! 1
        },
        _98: function(t) {
            return t == this._e8 ? !1 : (this._e8 = t, this[tO](), void this._$w())
        },
        type: FO
    },
    p(OU, wU),
    Z(OU[Jh], {
        loops: {
            get: function() {
                return this._kw
            }
        },
        edgeCount: {
            get: function() {
                return this[pc] + this._9i
            }
        },
        agentNode: {
            get: function() {
                return this._e8 || this
            }
        },
        host: {
            set: function(t) {
                if (this == t || t == this._host) return ! 1;
                var i = new Tz(this, zO, this[GO], t);
                if (!1 === this[sr](i)) return ! 1;
                var n = null,
                e = null,
                s = this[GO];
                if (null != t && (n = new Tz(t, YO, null, this), !1 === t[sr](n))) return ! 1;
                if (null != s && (e = new Tz(s, HO, null, this), !1 === s.beforeEvent(e))) return ! 1;
                if (this._host = t, null != t) {
                    var h = t._9c();
                    h.add(this)
                }
                if (null != s) {
                    var h = s._9c();
                    h[mc](this)
                }
                return this[Hl](i),
                null != t && t[Hl](n),
                null != s && s.onEvent(e),
                !0
            },
            get: function() {
                return this[GO]
            }
        }
    }),
    S(OU[Jh], [BO, Uw, Vx, uo, UO]),
    Z(OU[Jh], {
        x: {
            get: function() {
                return this[BO].x
            },
            set: function(t) {
                t != this.location.x && (this[BO] = new oz(t, this[BO].y))
            }
        },
        y: {
            get: function() {
                return this[BO].y
            },
            set: function(t) {
                t != this[BO].y && (this[BO] = new oz(this.location.x, t))
            }
        }
    });
    var IU = function(t, i) {
        t instanceof iH && (i = t, t = n),
        w(this, IU, [t]),
        this.path = i || new iH,
        this.anchorPosition = null,
        this.uiClass = hh,
        sz.SHAPENODE_STYLES || (sz.SHAPENODE_STYLES = {},
        sz[WO][CU.ARROW_TO] = !1),
        this[OO](sz.SHAPENODE_STYLES)
    };
    IU[Jh] = {
        $uiClass: hh,
        type: qO,
        moveTo: function(t, i) {
            this[XO][Pc](t, i),
            this.firePathChange()
        },
        lineTo: function(t, i) {
            this[XO].lineTo(t, i),
            this.firePathChange()
        },
        quadTo: function(t, i, n, e) {
            this.path[Dc](t, i, n, e),
            this.firePathChange()
        },
        curveTo: function(t, i, n, e, s, h) {
            this[XO][Nc](t, i, n, e, s, h),
            this[CO]()
        },
        arcTo: function(t, i, n, e, s) {
            this.path[ux](t, i, n, e, s),
            this[CO]()
        },
        closePath: function() {
            this[XO].closePath(),
            this.firePathChange()
        },
        clear: function() {
            this.path.clear(),
            this[CO]()
        },
        removePathSegmentByIndex: function(t) {
            this[XO].removePathSegment(t) !== !1 && this.firePathChange()
        },
        firePathChange: function() {
            this[XO]._6h = !0,
            this.onEvent(new Tz(this, SO))
        }
    },
    p(IU, OU),
    Z(IU.prototype, {
        path: {
            get: function() {
                return this.image
            },
            set: function(t) {
                this[Vx] = t
            }
        },
        pathSegments: {
            get: function() {
                return this[XO][VO]
            },
            set: function(t) {
                this[XO].segments = t || [],
                this[CO]()
            }
        },
        length: {
            get: function() {
                return this[XO][Fh]
            }
        }
    }),
    xY.ShapeNode = IU;
    var MU = {
        _jt: {},
        register: function(t, i) {
            MU._jt[t] = i
        },
        getShape: function(t, i, e, s, h, r) {
            s === n && (s = i, h = e, i = 0, e = 0),
            s || (s = 50),
            h || (h = 50);
            var a = MU._jt[t];
            return a ? a[KO] instanceof Function ? a.generator(i, e, s, h, r) : a: void 0
        },
        getRect: function(t, i, n, e, s, h, r) {
            return t instanceof Object && Sa in t && (i = t.y, n = t[Sa], e = t[Ca], s = t.rx, h = t.ry, r = t.path, t = t.x),
            Re(r || new iH, t, i, n, e, s, h)
        },
        getAllShapes: function(t, i, n, e, s) {
            var h = {};
            for (var r in MU._jt) {
                var a = MU.getShape(r, t, i, n, e, s);
                a && (h[r] = a)
            }
            return h
        },
        createRegularShape: function(t, i, n, e, s) {
            return ze(t, i, n, e, s)
        }
    };
    is(),
    ns[Jh] = {
        type: ZO
    },
    p(ns, IU),
    xY.Bus = ns,
    es.prototype = {
        _gu: function(t) {
            var i, n = t._jy;
            i = n ? n._g2: this[Ev];
            var e = i[Vh](t);
            if (0 > e) throw new Error(Ov + t + "' not exist in the box");
            for (; e >= 0;) {
                if (0 == e) return n instanceof OU ? n: null;
                e -= 1;
                var h = i[Hd](e);
                if (h = s(h)) return h
            }
            return null
        },
        forEachNode: function(t, i) {
            this[Wf](function(n) {
                return n instanceof OU && t[zh](i, n) === !1 ? !1 : void 0
            })
        },
        _3i: null
    },
    p(es, Dz),
    Z(es[Jh], {
        propertyChangeDispatcher: {
            get: function() {
                return this._$r
            }
        },
        currentSubNetwork: {
            get: function() {
                return this._3i
            },
            set: function(t) {
                if (t && !t[t_] && (t = null), this._3i != t) {
                    var i = this._3i;
                    this._3i = t,
                    this._$r[Hl](new Tz(this, JO, t, i))
                }
            }
        }
    }),
    sz[QO] = mY.GROUP_TYPE_RECT,
    sz[tI] = 5,
    sz[iI] = !0,
    sz[nI] = {
        width: 60,
        height: 60
    };
    var AU = function(t, i, e) {
        w(this, AU, arguments),
        (i === n || e === n) && (this[NO].invalidateFlag = !0),
        this[eI] = sz.GROUP_TYPE,
        this.$padding = sz[tI],
        this[iu] = sH[sI],
        this.$minSize = sz[nI],
        this[nO] = sz[iI]
    };
    AU[Jh] = {
        type: hI,
        $uiClass: th,
        _9k: function() {
            return ! this._gf && !this._e8
        },
        forEachOutEdge: function(t, i, n) {
            return Le(this, t, i) === !1 ? !1 : !n && this._9k() && this._8b ? this._8b[Wf](t, i) : void 0
        },
        forEachInEdge: function(t, i, n) {
            return Pe(this, t, i) === !1 ? !1 : !n && this._9k() && this._9d ? this._9d[Wf](t, i) : void 0
        },
        forEachEdge: function(t, i, n) {
            return T(this, AU, Cc, arguments) === !1 ? !1 : n || n || !this._9k() ? void 0 : this._9d && this._9d[Wf](t, i) === !1 ? !1 : this._8b ? this._8b.forEach(t, i) : void 0
        },
        hasInEdge: function(t) {
            return t ? null != this._i8: null != this._i8 || this._6g()
        },
        hasOutEdge: function(t) {
            return t ? null != this._gr: null != this._gr || this._5c()
        },
        hasEdge: function(t) {
            return t ? null != this._i8 || null != this._gr: null != this._i8 || null != this._gr || this._9f()
        }
    },
    p(AU, OU),
    Z(AU[Jh], {
        expanded: {
            get: function() {
                return this._gf
            },
            set: function(t) {
                if (this._gf != t) {
                    var i = new Tz(this, nO, t, this._gf);
                    this.beforeEvent(i) !== !1 && (this._gf = t, this._$w(), this[Hl](i), this._e8 || ss[zh](this))
                }
            }
        }
    }),
    S(AU[Jh], [rI, aI, So, oI]),
    xY.Group = AU,
    hs[Jh].type = fI,
    p(hs, OU),
    xY[cI] = hs;
    var jU = function(t) {
        this._ji = new _z,
        this._7w = new _z,
        this._fr = new _z,
        this.id = ++FF,
        t && (this.data = t)
    };
    jU.prototype = {
        invalidate: function() {
            this[uI]()
        },
        _1a: !0,
        _ji: null,
        _7w: null,
        _fr: null,
        _nek: !1,
        _jw: 1,
        _jr: 1,
        _i5: !0,
        _7u: 0,
        _6a: 0,
        _jy: null,
        _ner: null,
        borderColor: _I,
        borderLineDash: null,
        borderLineDashOffset: null,
        syncSelection: !0,
        syncSelectionStyles: !0,
        _15: function() {
            this[dI] = fi(this.anchorPosition, this._7u, this._6a)
        },
        setMeasuredBounds: function(t, i, n, e) {
            return t instanceof Object && (n = t.x, e = t.y, i = t[Ca], t = t[Sa]),
            this._ji[Sa] == t && this._ji[Ca] == i && this._ji.x == n && this._ji.y == e ? !1 : void this._ji.set(n || 0, e || 0, t || 0, i || 0)
        },
        initialize: function() {},
        measure: function() {},
        draw: function() {},
        _7t: function(t, i, n) {
            n[Om] == mY.SELECTION_TYPE_SHADOW ? (t[M_] = n.selectionColor, t[j_] = n[Em] * i, t.shadowOffsetX = (n[pm] || 0) * i, t[Fx] = (n[wm] || 0) * i) : this._1r(t, i, n)
        },
        _1r: function(t, i, n) {
            var e = n.selectionBorder || 0;
            n.selectionBackgroundColor && (t[kx] = n[lI], t.fillRect(this._7w.x - e / 2, this._7w.y - e / 2, this._7w[Sa] + e, this._7w[Ca] + e)),
            t[O_] = n[mm],
            t[jf] = e,
            t[vI](this._7w.x - e / 2, this._7w.y - e / 2, this._7w.width + e, this._7w[Ca] + e)
        },
        _jz: function(t, i, n, e) {
            if (!this._i5) return ! 1;
            if (this[bI] || (n = this[QT]), (n && !this[gI] || !e) && (e = this), t[Cx](), 1 != this.$alpha && (t[FE] = this[yI]), t[Ux](this.$x, this.$y), this[ef] && this[sf] && t[uo](this[sf]), (this[xI] || this[mI]) && t[Ux](this[xI], this[mI]), this.$rotate && t[uo](this.$rotate), this[Zo] && this[Jo] && t.translate( - this[Jo].x, -this._ner.y), this[M_] && (t[M_] = this[M_], t[j_] = this[j_] * i, t[Gx] = this[Gx] * i, t[Fx] = this[Fx] * i), n && e[Om] == mY[EI] && (this._1r(t, i, e), n = !1), this._$n() && this._m1Shape && !this[vf]._empty) {
                this[vf].validate();
                var s = {
                    lineWidth: this[ff],
                    strokeStyle: this[pI],
                    lineDash: this.borderLineDash,
                    lineDashOffset: this[wI],
                    fillColor: this.$backgroundColor,
                    fillGradient: this[df],
                    lineCap: Qy,
                    lineJoin: eo
                };
                this[vf][wo](t, i, s, n, e),
                n = !1,
                t[M_] = Ym
            }
            t[Cm](),
            this[wo](t, i, n, e),
            t[Um]()
        },
        invalidateData: function() {
            this[TI] = !0,
            this[hf] = !0,
            this._1a = !0
        },
        invalidateSize: function() {
            this[hf] = !0,
            this._1a = !0
        },
        invalidateRender: function() {
            this._1a = !0
        },
        _53: function() {},
        _$n: function() {
            return this.$backgroundColor || this[OI] || this.$border
        },
        _46: function() {
            return this[II] || this[OI]
        },
        doValidate: function() {
            return this.$invalidateData && (this.$invalidateData = !1, this[MI]() !== !1 && (this.$invalidateSize = !0)),
            this[hf] && this[AI] && this.validateSize(),
            Gn[zh](this) ? (this.$invalidateRotate = !0, this.onBoundsChanged && this[jI](), !0) : this[SI] ? (this[kf] = !0, this[SI] = !1, !0) : void 0
        },
        validate: function() {
            var t = this._i5;
            return this.$invalidateVisibility && (this[CI] = !1, this._i5 = this[kI], !this._i5 || (this[Mf] || this[LI]) && this._53() !== !1 || (this._i5 = !1)),
            this._i5 ? (this._1a = !1, this[nu] || (this[PI](), this[nu] = !0), this[RI]()) : t != this._i5
        },
        _i3: function(t, i) {
            return t -= this.$x,
            i -= this.$y,
            $n[zh](this, {
                x: t,
                y: i
            })
        },
        hitTest: function(t, i, n, e) {
            if (t -= this.$x, i -= this.$y, !this._fr[mf](t, i, n)) return ! 1;
            var s = $n[zh](this, {
                x: t,
                y: i
            });
            return t = s.x,
            i = s.y,
            !e && this._$n() && this[vf] && this[vf][Zu](t, i, n, !1, this[ff], this[II] || this[OI]) ? !0 : this[DI](t, i, n)
        },
        doHitTest: function(t, i, n) {
            return this._ji[mf](t, i, n)
        },
        hitTestByBounds: function(t, i, n, e) {
            var s = this._i3(t, i);
            return ! e && this._$n() && this._m1Shape && this._m1Shape.hitTest(t, i, n, !1, this[ff], this[II] || this.$backgroundGradient) ? !0 : this._ji[mf](s.x, s.y, n)
        },
        onDataChanged: function() {
            this.$invalidateData = !0,
            this._1a = !0,
            this[CI] = !0
        },
        getBounds: function() {
            var t = this._fr[qh]();
            return t[NI](this.x, this.y),
            this.parent && (this.parent[uo] && Ai(t, this[bc].rotate, t), t[NI](this[bc].x || 0, this.parent.y || 0)),
            t
        },
        destroy: function() {
            this[qE] = !0
        },
        _dx: !1
    },
    Z(jU[Jh], {
        originalBounds: {
            get: function() {
                return this._ji
            }
        },
        data: {
            get: function() {
                return this[Mf]
            },
            set: function(t) {
                if (this[Mf] != t) {
                    var i = this[Mf];
                    this.$data = t,
                    this[BI](t, i)
                }
            }
        },
        parent: {
            get: function() {
                return this._jy
            }
        },
        showOnTop: {
            get: function() {
                return this._dx
            },
            set: function(t) {
                t != this._dx && (this._dx = t, this._1a = !0, this._jy && this._jy[$I] && this._jy._nec(this))
            }
        }
    }),
    as(jU.prototype, {
        visible: {
            value: !0,
            validateFlags: [GI, FI]
        },
        showEmpty: {
            validateFlags: [GI]
        },
        anchorPosition: {
            value: lz[yl],
            validateFlags: [zI, FI]
        },
        position: {
            value: lz[yl],
            validateFlags: [FI]
        },
        offsetX: {
            value: 0,
            validateFlags: [FI]
        },
        offsetY: {
            value: 0,
            validateFlags: [FI]
        },
        layoutByAnchorPoint: {
            value: !0,
            validateFlags: [zg, zI, FI]
        },
        padding: {
            value: 0,
            validateFlags: [zg]
        },
        border: {
            value: 0,
            validateFlags: [zg]
        },
        borderRadius: {
            value: sz[fx]
        },
        showPointer: {
            value: !1,
            validateFlags: [zg]
        },
        pointerX: {
            value: 0,
            validateFlags: [zg]
        },
        pointerY: {
            value: 0,
            validateFlags: [zg]
        },
        pointerWidth: {
            value: sz[YI]
        },
        backgroundColor: {
            validateFlags: [zg]
        },
        backgroundGradient: {
            validateFlags: [zg, HI]
        },
        selected: {
            value: !1,
            validateFlags: [zg]
        },
        selectionBorder: {
            value: sz[UI],
            validateFlags: [zg]
        },
        selectionShadowBlur: {
            value: sz[ax],
            validateFlags: [zg]
        },
        selectionColor: {
            value: sz[ox],
            validateFlags: [zg]
        },
        selectionType: {
            value: sz.SELECTION_TYPE,
            validateFlags: [zg]
        },
        selectionShadowOffsetX: {
            value: 0,
            validateFlags: [zg]
        },
        selectionShadowOffsetY: {
            value: 0,
            validateFlags: [zg]
        },
        shadowBlur: {
            value: 0,
            validateFlags: [zg]
        },
        shadowColor: {
            validateFlags: [zg]
        },
        shadowOffsetX: {
            value: 0,
            validateFlags: [zg]
        },
        shadowOffsetY: {
            value: 0,
            validateFlags: [zg]
        },
        renderColorBlendMode: {},
        renderColor: {},
        x: {
            value: 0,
            validateFlags: [FI]
        },
        y: {
            value: 0,
            validateFlags: [FI]
        },
        rotatable: {
            value: !0,
            validateFlags: [WI, zg]
        },
        rotate: {
            value: 0,
            validateFlags: [WI, zg]
        },
        _hostRotate: {
            validateFlags: [WI]
        },
        lineWidth: {
            value: 0,
            validateFlags: [Kg]
        },
        alpha: {
            value: 1
        }
    });
    var SU = [mY[fu], mY.PROPERTY_TYPE_STYLE, mY[rv]];
    fs.prototype = {
        removeBinding: function(t) {
            for (var i = SU.length; --i >= 0;) {
                var n = SU[i],
                e = this[n];
                for (var s in e) {
                    var h = e[s];
                    Array[xr](h) ? (v(h,
                    function(i) {
                        return i[C_] == t
                    },
                    this), h[Fh] || delete e[s]) : h[C_] == t && delete e[s]
                }
            }
        },
        _1q: function(t, i, n) {
            if (!n && (n = this[i[kl] || mY.PROPERTY_TYPE_ACCESSOR], !n)) return ! 1;
            var e = n[t];
            e ? (Array[xr](e) || (n[t] = e = [e]), e[Xh](i)) : n[t] = i
        },
        _2d: function(t, i, n, e, s, h) {
            t = t || mY[fu];
            var r = this[t];
            if (!r) return ! 1;
            var a = {
                property: i,
                propertyType: t,
                bindingProperty: e,
                target: n,
                callback: s,
                invalidateSize: h
            };
            this._1q(i, a, r)
        },
        onBindingPropertyChange: function(t, i, n, e) {
            var s = this[n || mY[fu]];
            if (!s) return ! 1;
            var h = s[i];
            return h ? (t._1a = !0, os(t, h, n, e), !0) : !1
        },
        initBindingProperties: function(t, i) {
            for (var e = SU[Fh]; --e >= 0;) {
                var s = SU[e],
                h = this[s];
                for (var r in h) {
                    var a = h[r];
                    if (a.bindingProperty) {
                        var o = a.target;
                        if (o) {
                            if (! (o instanceof jU || (o = t[o]))) continue
                        } else o = t;
                        var f;
                        f = i === !1 ? t.getProperty(a[ru], s) : s == mY[qI] ? t[zu].getStyle(t[Mf], a.property) : t[Mf][a.property],
                        f !== n && (o[a[au]] = f)
                    }
                }
            }
        }
    };
    var CU = {};
    CU.SELECTION_COLOR = XI,
    CU.SELECTION_BORDER = VI,
    CU.SELECTION_SHADOW_BLUR = "selection.shadow.blur",
    CU[KI] = "selection.shadow.offset.x",
    CU[ZI] = "selection.shadow.offset.y",
    CU[sx] = JI,
    CU[QI] = tM,
    CU[iM] = "render.color.blend.mode",
    CU[nM] = eM,
    CU.SHADOW_BLUR = sM,
    CU[hM] = rM,
    CU.SHADOW_OFFSET_X = aM,
    CU[oM] = fM,
    CU[cM] = uM,
    CU[_M] = dM,
    CU[lM] = vM,
    CU[bM] = "shape.line.dash.offset",
    CU[gM] = yM,
    CU[xM] = mM,
    CU[EM] = pM,
    CU[wM] = TM,
    CU[OM] = IM,
    CU.LINE_JOIN = MM,
    CU[AM] = jM,
    CU[SM] = CM,
    CU[kM] = LM,
    CU[PM] = RM,
    CU[DM] = NM,
    CU[BM] = $M,
    CU[GM] = "border.line.dash.offset",
    CU.BORDER_RADIUS = FM,
    CU.PADDING = So,
    CU.IMAGE_BACKGROUND_COLOR = "image.background.color",
    CU.IMAGE_BACKGROUND_GRADIENT = "image.background.gradient",
    CU.IMAGE_BORDER = zM,
    CU[YM] = CU[HM] = UM,
    CU[WM] = "image.border.line.dash",
    CU[qM] = "image.border.line.dash.offset",
    CU[XM] = CU.IMAGE_BORDER_RADIUS = VM,
    CU.IMAGE_PADDING = KM,
    CU[ZM] = JM,
    CU.IMAGE_ADJUST = QM,
    CU[tA] = iA,
    CU[nA] = eA,
    CU.LABEL_POSITION = sA,
    CU[hA] = rA,
    CU[aA] = "label.anchor.position",
    CU[oA] = fA,
    CU[cA] = uA,
    CU[_A] = dA,
    CU[lA] = vA,
    CU.LABEL_PADDING = bA,
    CU.LABEL_POINTER_WIDTH = gA,
    CU[yA] = xA,
    CU[mA] = EA,
    CU[pA] = wA,
    CU[TA] = OA,
    CU[IA] = MA,
    CU.LABEL_ALIGN_POSITION = AA,
    CU[jA] = SA,
    CU.LABEL_BORDER_STYLE = CA,
    CU[kA] = "label.background.color",
    CU[LA] = "label.background.gradient",
    CU[PA] = RA,
    CU[DA] = NA,
    CU.LABEL_SHADOW_COLOR = BA,
    CU[$A] = "label.shadow.offset.x",
    CU.LABEL_SHADOW_OFFSET_Y = "label.shadow.offset.y",
    CU[GA] = FA,
    CU[zA] = YA,
    CU.GROUP_BACKGROUND_COLOR = "group.background.color",
    CU.GROUP_BACKGROUND_GRADIENT = "group.background.gradient",
    CU[HA] = UA,
    CU[WA] = qA,
    CU[XA] = "group.stroke.line.dash",
    CU[VA] = "group.stroke.line.dash.offset",
    CU[KA] = "edge.bundle.label.rotate",
    CU[ZA] = "edge.bundle.label.position",
    CU.EDGE_BUNDLE_LABEL_ANCHOR_POSITION = "edge.bundle.label.anchor.position",
    CU.EDGE_BUNDLE_LABEL_COLOR = "edge.bundle.label.color",
    CU[JA] = "edge.bundle.label.font.size",
    CU[QA] = "edge.bundle.label.font.family",
    CU.EDGE_BUNDLE_LABEL_FONT_STYLE = "edge.bundle.label.font.style",
    CU[tj] = "edge.bundle.label.padding",
    CU[ij] = "edge.bundle.label.pointer.width",
    CU[nj] = "edge.bundle.label.pointer",
    CU[ej] = "edge.bundle.label.radius",
    CU[sj] = "edge.bundle.label.offset.x",
    CU[hj] = "edge.bundle.label.offset.y",
    CU[rj] = "edge.bundle.label.border",
    CU[aj] = "edge.bundle.label.border.color",
    CU[oj] = "edge.bundle.label.background.color",
    CU.EDGE_BUNDLE_LABEL_BACKGROUND_GRADIENT = "edge.bundle.label.background.gradient",
    CU.EDGE_BUNDLE_LABEL_ROTATABLE = "edge.bundle.label.rotatable",
    CU[fj] = cj,
    CU.EDGE_COLOR = uj,
    CU[_j] = dj,
    CU[lj] = vj,
    CU[bj] = gj,
    CU.EDGE_LINE_DASH_OFFSET = "edge.line.dash.offset",
    CU[Wu] = yj,
    CU[qu] = xj,
    CU.EDGE_BUNDLE_GAP = mj,
    CU[Ej] = pj,
    CU.EDGE_EXTEND = wj,
    CU[Su] = Tj,
    CU[Oj] = "edge.split.by.percent",
    CU[uu] = Ij,
    CU[_u] = Mj,
    CU[Ou] = Aj,
    CU[Mu] = jj,
    CU[Sj] = Cj,
    CU[kj] = Lj,
    CU[Pj] = Rj,
    CU[Dj] = Nj,
    CU[Bj] = $j,
    CU.ARROW_FROM_STROKE = Gj,
    CU[Fj] = "arrow.from.stroke.style",
    CU.ARROW_FROM_OUTLINE = zj,
    CU[Yj] = "arrow.from.outline.style",
    CU[Hj] = Uj,
    CU.ARROW_FROM_LINE_DASH_OFFSET = "arrow.from.line.dash.offset",
    CU[Wj] = "arrow.from.fill.color",
    CU.ARROW_FROM_FILL_GRADIENT = "arrow.from.fill.gradient",
    CU.ARROW_FROM_LINE_CAP = qj,
    CU[Xj] = Vj,
    CU[Kj] = Zj,
    CU[Jj] = Qj,
    CU[tS] = iS,
    CU[nS] = eS,
    CU.ARROW_TO_STROKE_STYLE = "arrow.to.stroke.style",
    CU.ARROW_TO_OUTLINE = sS,
    CU[hS] = "arrow.to.outline.style",
    CU.ARROW_TO_LINE_DASH = rS,
    CU[aS] = "arrow.to.line.dash.offset",
    CU[oS] = fS,
    CU[cS] = "arrow.to.fill.gradient",
    CU.ARROW_TO_LINE_CAP = uS,
    CU[_S] = dS;
    var kU = new fs,
    LU = mY.PROPERTY_TYPE_ACCESSOR,
    PU = mY[qI],
    RU = !1;
    kU._2d(PU, CU[sx], null, Om),
    kU._2d(PU, CU.SELECTION_BORDER, null, lS),
    kU._2d(PU, CU[ax], null, Em),
    kU._2d(PU, CU.SELECTION_COLOR, null, mm),
    kU._2d(PU, CU[KI], null, "selectionShadowOffsetX"),
    kU._2d(PU, CU[ZI], null, "selectionShadowOffsetY"),
    kU._2d(LU, rr, Ep, ao),
    kU._2d(PU, CU[hA], Ep, bT),
    kU._2d(PU, CU[vS], Ep, Of),
    kU._2d(PU, CU[aA], Ep, UO),
    kU._2d(PU, CU[oA], Ep, bS),
    kU._2d(PU, CU[cA], Ep, X_),
    kU._2d(PU, CU[jA], Ep, _y),
    kU._2d(PU, CU.LABEL_BORDER_STYLE, Ep, pI),
    kU._2d(PU, CU.LABEL_BACKGROUND_COLOR, Ep, gS),
    kU._2d(PU, CU.LABEL_ON_TOP, Ep, yS),
    RU || (kU._2d(PU, CU[xS], null, j_), kU._2d(PU, CU.SHADOW_COLOR, null, M_), kU._2d(PU, CU[mS], null, Gx), kU._2d(PU, CU.SHADOW_OFFSET_Y, null, Fx), kU._2d(PU, CU[_A], Ep, V_), kU._2d(PU, CU[lA], Ep, ES), kU._2d(PU, CU[pS], Ep, wS), kU._2d(PU, CU.LABEL_ROTATE, Ep, uo), kU._2d(PU, CU[TS], Ep, So), kU._2d(PU, CU[OS], Ep, IS), kU._2d(PU, CU.LABEL_POINTER, Ep, MS), kU._2d(PU, CU.LABEL_RADIUS, Ep, AS), kU._2d(PU, CU[pA], Ep, xI), kU._2d(PU, CU[TA], Ep, mI), kU._2d(PU, CU[PA], Ep, jS), kU._2d(PU, CU.LABEL_BACKGROUND_GRADIENT, Ep, lf), kU._2d(PU, CU[IA], Ep, Uw), kU._2d(PU, CU[DA], Ep, j_), kU._2d(PU, CU[SS], Ep, M_), kU._2d(PU, CU[$A], Ep, Gx), kU._2d(PU, CU[CS], Ep, Fx), kU._2d(PU, CU[GA], Ep, sT), kU._2d(PU, CU[QI], null, Hx), kU._2d(PU, CU[iM], null, Wx), kU._2d(PU, CU.ALPHA, null, eM));
    var DU = new fs;
    DU._2d(LU, BO),
    DU._2d(LU, UO, null, kS),
    DU._2d(LU, uo, null, uo),
    RU || (DU._2d(PU, CU[SM], null, gS), DU._2d(PU, CU.BACKGROUND_GRADIENT, null, lf), DU._2d(PU, CU[LS], null, So), DU._2d(PU, CU[PM], null, _y), DU._2d(PU, CU[fx], null, AS), DU._2d(PU, CU[DM], null, pI), DU._2d(PU, CU[BM], null, PS), DU._2d(PU, CU[GM], null, wI)),
    DU._2d(LU, Vx, Vx, ao, RS),
    DU._2d(LU, Uw, Vx, Uw),
    DU._2d(PU, CU[cM], Vx, jf),
    DU._2d(PU, CU[_M], Vx, O_),
    DU._2d(PU, CU[gM], Vx, Am),
    DU._2d(PU, CU[AM], Vx, If),
    RU || (DU._2d(PU, CU[DS], Vx, NS), DU._2d(PU, CU[EM], Vx, Mm), DU._2d(PU, CU[wM], Vx, Im), DU._2d(PU, CU[xM], Vx, Sm), DU._2d(PU, CU[lM], Vx, Lf), DU._2d(PU, CU[bM], Vx, Bf), DU._2d(PU, CU[OM], Vx, w_), DU._2d(PU, CU[BS], Vx, T_), DU._2d(PU, CU.IMAGE_BACKGROUND_COLOR, Vx, gS), DU._2d(PU, CU[$S], Vx, lf), DU._2d(PU, CU.IMAGE_PADDING, Vx, So), DU._2d(PU, CU[GS], Vx, _y), DU._2d(PU, CU[FS], Vx, AS), DU._2d(PU, CU.IMAGE_BORDER_COLOR, Vx, pI), DU._2d(PU, CU[WM], Vx, PS), DU._2d(PU, CU.IMAGE_BORDER_LINE_DASH_OFFSET, Vx, wI), DU._2d(PU, CU.IMAGE_Z_INDEX, Vx, sT), DU._2d(PU, CU[tA], Vx, eM)),
    DU._2d(LU, nO, null, null, zS),
    DU._2d(LU, t_, null, null, zS);
    var NU = new fs;
    NU._2d(LU, aI, null, null, YS),
    NU._2d(LU, oI, null, null, YS),
    NU._2d(LU, rI, null, null, YS),
    NU._2d(LU, So, null, null, YS),
    NU._2d(PU, CU[HS], US, Am),
    NU._2d(PU, CU.GROUP_BACKGROUND_GRADIENT, US, Sm),
    NU._2d(PU, CU[HA], US, jf),
    NU._2d(PU, CU.GROUP_STROKE_STYLE, US, O_),
    NU._2d(PU, CU[XA], US, Lf),
    NU._2d(PU, CU[VA], US, Bf);
    var BU = new fs;
    BU._2d(LU, Tc, US, null, WS),
    BU._2d(LU, PO, US, null, WS),
    BU._2d(LU, Hu, US, null, WS),
    BU._2d(PU, CU[fj], US, jf),
    BU._2d(PU, CU.EDGE_COLOR, US, O_),
    BU._2d(PU, CU.ARROW_FROM, US, qS),
    BU._2d(PU, CU[Kj], US, XS),
    RU || (BU._2d(PU, CU[Sj], null, VS, WS), BU._2d(PU, CU[kj], null, KS, WS), BU._2d(PU, CU.EDGE_OUTLINE, US, Mm), BU._2d(PU, CU[lj], US, Im), BU._2d(PU, CU[bj], US, Lf), BU._2d(PU, CU[ZS], US, Bf), BU._2d(PU, CU[Su], US, null, WS), BU._2d(PU, CU[Wu], US, null, WS), BU._2d(PU, CU[qu], US, null, WS), BU._2d(PU, CU[OM], US, w_), BU._2d(PU, CU[BS], US, T_), BU._2d(LU, SO, null, null, WS, !0), BU._2d(LU, Xu, null, null, WS, !0), BU._2d(PU, CU.ARROW_FROM_SIZE, US, JS), BU._2d(PU, CU.ARROW_FROM_OFFSET, US, QS), BU._2d(PU, CU[tC], US, iC), BU._2d(PU, CU[Fj], US, nC), BU._2d(PU, CU[eC], US, sC), BU._2d(PU, CU[Yj], US, "fromArrowOutlineStyle"), BU._2d(PU, CU.ARROW_FROM_FILL_COLOR, US, hC), BU._2d(PU, CU[rC], US, "fromArrowFillGradient"), BU._2d(PU, CU[Hj], US, aC), BU._2d(PU, CU.ARROW_FROM_LINE_DASH_OFFSET, US, "fromArrowLineDashOffset"), BU._2d(PU, CU[Xj], US, oC), BU._2d(PU, CU[fC], US, cC), BU._2d(PU, CU[Jj], US, uC), BU._2d(PU, CU[tS], US, _C), BU._2d(PU, CU[nS], US, dC), BU._2d(PU, CU[lC], US, vC), BU._2d(PU, CU.ARROW_TO_OUTLINE, US, bC), BU._2d(PU, CU.ARROW_TO_OUTLINE_STYLE, US, gC), BU._2d(PU, CU[oS], US, yC), BU._2d(PU, CU[cS], US, xC), BU._2d(PU, CU.ARROW_TO_LINE_DASH, US, mC), BU._2d(PU, CU.ARROW_TO_LINE_DASH_OFFSET, US, "toArrowLineDashOffset"), BU._2d(PU, CU[_S], US, EC), BU._2d(PU, CU[pC], US, wC));
    var $U = new fs;
    $U._2d(PU, CU[TC], OC, bS),
    $U._2d(PU, CU[ZA], OC, Of),
    $U._2d(PU, CU[IC], OC, UO),
    $U._2d(PU, CU.EDGE_BUNDLE_LABEL_FONT_SIZE, OC, X_),
    $U._2d(PU, CU.EDGE_BUNDLE_LABEL_ROTATABLE, OC, jS),
    RU || ($U._2d(PU, CU.EDGE_BUNDLE_LABEL_ROTATE, OC, uo), $U._2d(PU, CU[QA], OC, V_), $U._2d(PU, CU[MC], OC, ES), $U._2d(PU, CU.EDGE_BUNDLE_LABEL_PADDING, OC, So), $U._2d(PU, CU[ij], OC, IS), $U._2d(PU, CU[nj], OC, MS), $U._2d(PU, CU.EDGE_BUNDLE_LABEL_RADIUS, OC, AS), $U._2d(PU, CU[sj], OC, xI), $U._2d(PU, CU[hj], OC, mI), $U._2d(PU, CU.EDGE_BUNDLE_LABEL_BORDER, OC, _y), $U._2d(PU, CU.EDGE_BUNDLE_LABEL_BORDER_STYLE, OC, pI), $U._2d(PU, CU[oj], OC, gS), $U._2d(PU, CU.EDGE_BUNDLE_LABEL_BACKGROUND_GRADIENT, OC, lf));
    var GU = new fs;
    GU._2d(LU, BO),
    GU._2d(PU, CU[SM], null, gS),
    GU._2d(PU, CU[kM], null, lf),
    GU._2d(PU, CU.PADDING, null, So),
    GU._2d(PU, CU[PM], null, _y),
    GU._2d(PU, CU[fx], null, AS),
    GU._2d(PU, CU[DM], null, pI),
    GU._2d(PU, CU[BM], null, PS),
    GU._2d(PU, CU[GM], null, wI),
    GU._2d(LU, uo, null, uo),
    GU._2d(LU, SO, null, null, AC),
    GU._2d(LU, XO, Vx, ao),
    GU._2d(LU, Uw, Vx, Uw),
    GU._2d(PU, CU[cM], Vx, jf),
    GU._2d(PU, CU[_M], Vx, O_),
    GU._2d(PU, CU[gM], Vx, Am),
    GU._2d(PU, CU.SHAPE_FILL_GRADIENT, Vx, Sm),
    RU || (GU._2d(PU, CU[EM], Vx, Mm), GU._2d(PU, CU.SHAPE_OUTLINE_STYLE, Vx, Im), GU._2d(PU, CU[lM], Vx, Lf), GU._2d(PU, CU.SHAPE_LINE_DASH_OFFSET, Vx, Bf), GU._2d(PU, CU.LINE_CAP, Vx, w_), GU._2d(PU, CU.LINE_JOIN, Vx, T_), GU._2d(PU, CU.LAYOUT_BY_PATH, Vx, If), GU._2d(PU, CU[jC], Vx, gS), GU._2d(PU, CU[$S], Vx, lf), GU._2d(PU, CU[SC], Vx, So), GU._2d(PU, CU.IMAGE_BORDER, Vx, _y), GU._2d(PU, CU[FS], Vx, AS), GU._2d(PU, CU[HM], Vx, pI), GU._2d(PU, CU.IMAGE_BORDER_LINE_DASH, Vx, PS), GU._2d(PU, CU[qM], Vx, wI), GU._2d(PU, CU.ARROW_FROM, Vx, qS), GU._2d(PU, CU[Dj], Vx, JS), GU._2d(PU, CU[Bj], Vx, QS), GU._2d(PU, CU[tC], Vx, iC), GU._2d(PU, CU.ARROW_FROM_STROKE_STYLE, Vx, nC), GU._2d(PU, CU[Wj], Vx, hC), GU._2d(PU, CU[rC], Vx, "fromArrowFillGradient"), GU._2d(PU, CU.ARROW_FROM_LINE_DASH, Vx, aC), GU._2d(PU, CU.ARROW_FROM_LINE_DASH_OFFSET, Vx, "fromArrowLineDashOffset"), GU._2d(PU, CU[Xj], Vx, oC), GU._2d(PU, CU.ARROW_FROM_LINE_CAP, Vx, cC), GU._2d(PU, CU.ARROW_TO_SIZE, Vx, uC), GU._2d(PU, CU[tS], Vx, _C), GU._2d(PU, CU.ARROW_TO, Vx, XS), GU._2d(PU, CU.ARROW_TO_STROKE, Vx, dC), GU._2d(PU, CU[lC], Vx, vC), GU._2d(PU, CU[oS], Vx, yC), GU._2d(PU, CU.ARROW_TO_FILL_GRADIENT, Vx, xC), GU._2d(PU, CU.ARROW_TO_LINE_DASH, Vx, mC), GU._2d(PU, CU[aS], Vx, "toArrowLineDashOffset"), GU._2d(PU, CU[_S], Vx, EC), GU._2d(PU, CU[pC], Vx, wC));
    var FU = function(t, i) {
        return t = t[sT],
        i = i.zIndex,
        t == i ? 0 : (t = t || 0, i = i || 0, t > i ? 1 : i > t ? -1 : void 0)
    },
    zU = function(t, i) {
        this[$T] = new _z,
        w(this, zU, arguments),
        this.id = this[Mf].id,
        this[zu] = i,
        this._g2 = [],
        this[CC] = new fs
    };
    zU.prototype = {
        syncSelection: !1,
        graph: null,
        layoutByAnchorPoint: !1,
        _nhh: null,
        _g2: null,
        addChild: function(t, i) {
            t._jy = this,
            i !== n ? y(this._g2, t, i) : this._g2.push(t),
            t._dx && this[$I](t),
            this[kC](),
            this.invalidateSize(),
            this[LC] = !0
        },
        removeChild: function(t) {
            this[CC].removeBinding(t),
            t._jy = null,
            x(this._g2, t),
            this._k1 && this._k1[mc](t),
            this.invalidateSize(),
            this.$invalidateChild = !0
        },
        getProperty: function(t, i) {
            return i == mY[qI] ? this[zu].getStyle(this[Mf], t) : i == mY[rv] ? this[Mf].get(t) : this[Mf][t]
        },
        getStyle: function(t) {
            return this[zu][cu](this[Mf], t)
        },
        _$t: function(t, i, n) {
            var e = this._nhh[PC](this, t, i, n);
            return kU[PC](this, t, i, n) || e
        },
        onPropertyChange: function(t) {
            if (sT == t.kind) return this[JT](),
            !0;
            if (EO == t.type) {
                if (Yw == t[Ml]) return this[Yw](),
                !0;
                var i = t[ar];
                return i && i.ui ? (iv == t.kind ? this._9a(i) : mc == t.kind && this[Ox](i.ui), !0) : !1
            }
            return this._$t(t[Ml], t[kl] || LU, t.value)
        },
        label: null,
        initLabel: function() {
            var t = new HU;
            t.name = Ep,
            this[RC](t),
            this.label = t
        },
        initialize: function() {
            this[DC](),
            this[Mf][pO] && this.$data[pO][Wf](this._9a, this),
            kU.initBindingProperties(this),
            this[CC][NC](this, !1)
        },
        addBinding: function(t, i) {
            return i[ru] ? (i[C_] = t, void this._nhh._1q(i[ru], i)) : !1
        },
        _ga: function(t, i) {
            var n = this[Mf];
            if (!n[pO]) return ! 1;
            var e = n[pO].getById(t.id);
            if (!e || !e[BC]) return ! 1;
            var s = e[BC];
            if ($(s)) {
                var h = !1;
                return l(s,
                function(t) {
                    return ao == t[au] ? (h = cs(n, i, t.property, t[kl]), !1) : void 0
                },
                this),
                h
            }
            return ao == s[au] ? cs(n, i, s[ru], s.propertyType) : !1
        },
        _9a: function(t) {
            var i = t.ui;
            if (i) {
                var n = t[BC];
                n && (Array[xr](n) ? n[Wf](function(t) {
                    this[$C](i, t)
                },
                this) : this.addBinding(i, n)),
                this.addChild(i)
            }
        },
        validate: function() {
            return this[nu] || (this.initialize(), this[nu] = !0),
            this.doValidate()
        },
        _$b: !0,
        invalidateChildrenIndex: function() {
            this._$b = !0
        },
        doValidate: function() {
            if (this._1a && (this._1a = !1, this[GC]() && (this.measure(), this[hf] = !0), this._$b && (this._$b = !1, KF ? this._g2 = d(this._g2, FU) : this._g2[eT](FU))), Gn[zh](this) && (this[kf] = !0), this[kf]) {
                rH[zh](this),
                this.uiBounds[vx](this._fr);
                var t = this.$selectionBorder || 0,
                i = Math.max(this.$selectionBorder || 0, this[FC] || 0, this[zC] || 0),
                n = Math.max(this[YC] || 0, this[HC] || 0),
                e = Math.max(2 * t, this[UC], this[WC]);
                e += sz[qC] || 0;
                var s = e - i,
                h = e + i,
                r = e - n,
                a = e + n;
                return 0 > s && (s = 0),
                0 > h && (h = 0),
                0 > r && (r = 0),
                0 > a && (a = 0),
                this[$T].grow(r, s, a, h),
                this[jI] && this.onBoundsChanged(),
                this[XC] = !0,
                !0
            }
        },
        validateChildren: function() {
            var t = this[LC];
            this.$invalidateChild = !1;
            var i = this[VC],
            n = this[KC];
            i && (i[ZC] = this[ZC], i[JC] = this[JC], i.$shadowColor = this[QC], i[UC] = this[UC], i.$shadowOffsetX = this.$shadowOffsetX, i.$shadowOffsetY = this.$shadowOffsetY),
            this[KC] = !1,
            i && i._1a && (n = i[to]() || n, i.$x = 0, i.$y = 0, i.$invalidateRotate && rH.call(i), t = !0);
            for (var e = 0,
            s = this._g2[Fh]; s > e; e++) {
                var h = this._g2[e];
                if (h != i) {
                    var r = h._1a && h[to](); (r || n) && h._i5 && Hn(h, i, this),
                    !t && r && (t = !0)
                }
            }
            return t
        },
        measure: function() {
            this._ji[wf]();
            for (var t, i, n = 0,
            e = this._g2[Fh]; e > n; n++) t = this._g2[n],
            t._i5 && (i = t._fr, i[Sa] <= 0 || i.height <= 0 || this._ji[rl](t.$x + i.x, t.$y + i.y, i.width, i[Ca]))
        },
        _k1: null,
        _nec: function(t) {
            if (!this._k1) {
                if (!t[yS]) return;
                return this._k1 = new hz,
                this._k1.add(t)
            }
            return t.showOnTop ? this._k1.add(t) : this._k1[mc](t)
        },
        draw: function(t, i, n) {
            for (var e, s = 0,
            h = this._g2.length; h > s; s++) e = this._g2[s],
            e._i5 && !e[yS] && e._jz(t, i, n, this)
        },
        _96: function(t, i) {
            if (!this._i5 || !this._k1 || !this._k1[Fh]) return ! 1;
            t.save(),
            t[Ux](this.$x, this.$y),
            this[ef] && this[sf] && t.rotate(this[sf]),
            (this[xI] || this.offsetY) && t[Ux](this.offsetX, this[mI]),
            this[Qo] && t.rotate(this[Qo]),
            this[Zo] && this[Jo] && t[Ux]( - this[Jo].x, -this._ner.y),
            this[M_] && (t.shadowColor = this.shadowColor, t[j_] = this[j_] * i, t.shadowOffsetX = this[Gx] * i, t[Fx] = this[Fx] * i),
            t[Cm]();
            for (var n, e = 0,
            s = this._g2[Fh]; s > e; e++) n = this._g2[e],
            n._i5 && n[yS] && n._jz(t, i, this[QT], this);
            t[Um]()
        },
        doHitTest: function(t, i, n) {
            if (n) {
                if (!this._ji[Ol](t - n, i - n, 2 * n, 2 * n)) return ! 1
            } else if (!this._ji[mf](t, i)) return ! 1;
            return this[tk](t, i, n)
        },
        hitTestChildren: function(t, i, n) {
            for (var e, s = this._g2[Fh] - 1; s >= 0; s--) if (e = this._g2[s], e._i5 && e[Zu](t, i, n)) return e;
            return ! 1
        },
        destroy: function() {
            this[qE] = !0;
            for (var t, i = this._g2[Fh] - 1; i >= 0; i--) t = this._g2[i],
            t.destroy()
        }
    },
    p(zU, jU),
    Z(zU.prototype, {
        renderColorBlendMode: {
            get: function() {
                return this[JC]
            },
            set: function(t) {
                this[JC] = t,
                this._1a = !0,
                this.body && (this.body.renderColorBlendMode = this[JC])
            }
        },
        renderColor: {
            get: function() {
                return this[ZC]
            },
            set: function(t) {
                this[ZC] = t,
                this._1a = !0,
                this[px] && (this[px][Hx] = this[ZC])
            }
        },
        bodyBounds: {
            get: function() {
                if (this.$invalidateBounds) {
                    this[XC] = !1;
                    var t, i = this[px];
                    t = i && i._i5 && !this._$n() ? i._fr.clone() : this._fr[qh](),
                    this.rotate && Ai(t, this.rotate, t),
                    t.x += this.$x,
                    t.y += this.$y,
                    this._d6 = t
                }
                return this._d6
            }
        },
        bounds: {
            get: function() {
                return new _z((this.$x || 0) + this.uiBounds.x, (this.$y || 0) + this.uiBounds.y, this.uiBounds[Sa], this.uiBounds[Ca])
            }
        },
        body: {
            get: function() {
                return this._ngody
            },
            set: function(t) {
                t && this[VC] != t && (this[VC] = t, this.bodyChanged = !0, this[ik]())
            }
        }
    }),
    sz[qC] = 1;
    var YU = function() {
        w(this, YU, arguments)
    };
    YU[Jh] = {
        strokeStyle: Bx,
        lineWidth: 0,
        fillColor: null,
        fillGradient: null,
        _jw: 1,
        _jr: 1,
        outline: 0,
        onDataChanged: function(t) {
            T(this, YU, BI, arguments),
            this._l7 && this._89 && this._l7._6z(this._89, this),
            t && this[RS](t)
        },
        _nha: function(t) {
            this._l7 = bn(t),
            this._l7.validate(),
            (this._l7._lr == CY || this._l7._6j()) && (this._89 || (this._89 = function() {
                this[uI](),
                this._jy && this._jy.graph && (this._jy[ik](), this._jy[zu][Yw]())
            }), this._l7[ko](this._89, this))
        },
        _l7: null,
        initialize: function() {
            this[RS](this.$data)
        },
        _53: function() {
            return this._l7 && this._l7[wo]
        },
        _9v: function(t) {
            if (!t || t[Sa] <= 0 || t[Ca] <= 0 || !this.$size || !(this[Uw] instanceof Object)) return this._jw = 1,
            void(this._jr = 1);
            var i = this[Uw][Sa],
            e = this[Uw][Ca];
            if ((i === n || null === i) && (i = -1), (e === n || null === e) && (e = -1), 0 > i && 0 > e) return this._jw = 1,
            void(this._jr = 1);
            var s, h, r = t.width,
            a = t.height;
            i >= 0 && (s = i / r),
            e >= 0 && (h = e / a),
            0 > i ? s = h: 0 > e && (h = s),
            this._jw = s,
            this._jr = h
        },
        validateSize: function() {
            if (this.$invalidateScale) {
                this[nk] = !1;
                var t = this[ek];
                this._jw,
                this._jr,
                this._9v(t),
                this[sk](t[Sa] * this._jw, t[Ca] * this._jr, t.x * this._jw, t.y * this._jr)
            }
        },
        measure: function() {
            var t = this._l7.getBounds(this[jf] + this[Mm]);
            return t ? (this.$invalidateScale = !0, void(this[ek] = t[qh]())) : void this._ji.set(0, 0, 0, 0)
        },
        onBoundsChanged: function() {
            this[hk] = !0
        },
        _1o: function() {
            this[hk] = !1,
            this[jm] = this.fillGradient ? BY.prototype[bf].call(this[rk], this._7w) : null
        },
        _k3: function(t) {
            var i, n;
            if (fy == this[ak]) i = 1,
            n = -1;
            else {
                if (cy != this.$adjustType) return;
                i = -1,
                n = 1
            }
            var e = this._ji.cx,
            s = this._ji.cy;
            t[Ux](e, s),
            t[p_](i, n),
            t[Ux]( - e, -s)
        },
        draw: function(t, i, n, e) {
            if (this._jw && this._jr) {
                if (this.$invalidateFillGradient && this._1o(), t.save(), this[ak] && this._k3(t), this._l7._lr == LY) return t[p_](this._jw, this._jr),
                this._l7._mn.draw(t, i, this, n, e || this),
                void t[Um]();
                n && this._7t(t, i, e),
                this._l7[wo](t, i, this, this._jw, this._jr),
                t[Um]()
            }
        },
        doHitTest: function(t, i, n) {
            if (this._l7[Zu]) {
                if (fy == this[ak]) {
                    var e = this._ji.cy;
                    i = 2 * e - i
                } else if (cy == this[ak]) {
                    var s = this._ji.cx;
                    t = 2 * s - t
                }
                t /= this._jw,
                i /= this._jr;
                var h = (this._jw + this._jr) / 2;
                return h > 1 && (n /= h, n = 0 | n),
                this._l7._mn instanceof iH ? this._l7._mn[Zu](t, i, n, !0, this.$lineWidth, this[ok] || this[rk]) : this._l7.hitTest(t, i, n)
            }
            return ! 0
        },
        $invalidateScale: !0,
        $invalidateFillGradient: !0
    },
    p(YU, jU),
    as(YU.prototype, {
        adjustType: {},
        fillColor: {},
        size: {
            validateFlags: [zg, fk]
        },
        fillGradient: {
            validateFlags: [ck]
        }
    }),
    Z(YU.prototype, {
        originalBounds: {
            get: function() {
                return this[ek]
            }
        }
    }),
    sz[uk] = lz[yl];
    var HU = function() {
        w(this, HU, arguments),
        this[bS] = sz[oA]
    };
    HU.prototype = {
        color: sz.LABEL_COLOR,
        showPointer: !0,
        fontSize: null,
        fontFamily: null,
        fontStyle: null,
        _gy: null,
        alignPosition: null,
        measure: function() {
            this.font;
            var t = Li(this[Mf], this[_k] || sz[Fd], this[dk]);
            if (this._gy = t, this.$size) {
                var i = this[lk][Sa] || 0,
                n = this[lk][Ca] || 0;
                return this[sk](i > t[Sa] ? i: t.width, n > t[Ca] ? n: t[Ca])
            }
            return this.setMeasuredBounds(t.width, t[Ca])
        },
        doHitTest: function(t, i, n) {
            return this.$data ? Mn(t, i, n, this) : !1
        },
        draw: function(t, i, n, e) {
            n && this._7t(t, i, e);
            var s = this.$fontSize || sz[Fd];
            if (this.$rotatable && this[sf]) {
                var h = on(this[sf]);
                h > rz && 3 * rz > h && (t.translate(this._ji.width / 2, this._ji[Ca] / 2), t[uo](Math.PI), t.translate( - this._ji[Sa] / 2, -this._ji[Ca] / 2))
            }
            var r = this.alignPosition || sz[uk],
            a = r[Yr],
            o = r[Hr],
            f = s * sz.LINE_HEIGHT,
            c = f / 2;
            if (o != yz && this._gy.height < this._ji[Ca]) {
                var u = this._ji.height - this._gy.height;
                c += o == xz ? u / 2 : u
            }
            t.translate(0, c),
            t.font != this[dk] && (t[Ua] = this[dk]),
            a == bz ? (t.textAlign = Vu, t[Ux](this._ji[Sa] / 2, 0)) : a == gz ? (t[vk] = Gr, t[Ux](this._ji[Sa], 0)) : t.textAlign = Co,
            t[bk] = Rx,
            t[kx] = this[bS];
            for (var _ = 0,
            d = this[Mf][lr](qa), l = 0, v = d[Fh]; v > l; l++) {
                var b = d[l];
                if (HF) try {
                    t[$x](b, 0, _)
                } catch(g) {} else t[$x](b, 0, _);
                _ += f
            }
        },
        _53: function() {
            return null != this[Mf] || this[lk]
        },
        $invalidateFont: !0
    },
    p(HU, jU),
    as(HU.prototype, {
        size: {
            validateFlags: [Kg]
        },
        fontStyle: {
            validateFlags: [Kg, gk]
        },
        fontSize: {
            validateFlags: [Kg, gk]
        },
        fontFamily: {
            validateFlags: [Kg, gk]
        }
    }),
    Z(HU.prototype, {
        font: {
            get: function() {
                return this[yk] && (this[yk] = !1, this.$font = (this[xk] || sz[Gd]) + vr + (this[_k] || sz[Fd]) + zd + (this[mk] || sz[Yd])),
                this[dk]
            }
        }
    });
    var UU = function(t) {
        t = t || new iH,
        this[Ek] = new _z,
        w(this, UU, [t])
    };
    UU[Jh] = {
        layoutByPath: !0,
        layoutByAnchorPoint: !1,
        measure: function() {
            this[pk] = !0,
            this.$invalidateToArrow = !0,
            this.$data[io](this[wk] + this[Tk], this[Ek]),
            this[sk](this.pathBounds)
        },
        validateSize: function() {
            if (this[pk] || this[Ok]) {
                var t = this[Ek].clone();
                if (this[pk]) {
                    this.$invalidateFromArrow = !1;
                    var i = this.validateFromArrow();
                    i && t.add(i)
                }
                if (this.$invalidateToArrow) {
                    this[Ok] = !1;
                    var i = this.validateToArrow();
                    i && t.add(i)
                }
                this[sk](t)
            }
        },
        validateFromArrow: function() {
            if (!this[Mf]._jb || !this[Ik]) return void(this.$fromArrowShape = null);
            var t = this[Mf],
            i = 0,
            n = 0,
            e = this[Mk];
            e && (isNaN(e) && (e.x || e.y) ? (i += e.x || 0, n += e.y || 0) : i += e || 0, i > 0 && 1 > i && (i *= t._jb)),
            this[Ak] = t[jk](i, n),
            this[Ak][uo] = Math.PI + this[Ak][uo] || 0,
            this[Sk] = Ds(this[Ik], this.$fromArrowSize);
            var s = this.$fromArrowShape[io](this[Ck][jf] + this[Ck][Mm]);
            return this[kk] instanceof xY.Gradient ? this[Ck]._fillGradient = BY[Jh][bf][zh](this[kk], s) : this[Ck] && (this.fromArrowStyles[jm] = null),
            s.offset(this[Ak].x, this.fromArrowLocation.y),
            ji(s, this[Ak].rotate, s, this[Ak].x, this[Ak].y),
            s
        },
        validateToArrow: function() {
            if (!this[Mf]._jb || !this.$toArrow) return void(this.$toArrowShape = null);
            var t = this[Mf],
            i = 0,
            n = 0,
            e = this[Lk];
            e && (isNaN(e) && (e.x || e.y) ? (i += e.x || 0, n += e.y || 0) : i += e || 0),
            0 > i && i > -1 && (i *= t._jb),
            i += t._jb,
            this[Pk] = t[jk](i, n),
            this[Rk] = Ds(this[Dk], this[Nk]);
            var s = this[Rk][io](this[Bk][jf] + this.toArrowStyles[Mm]);
            return this[xC] instanceof xY[$k] ? this[Bk][jm] = BY[Jh][bf].call(this[xC], s) : this[Bk] && (this.toArrowStyles[jm] = null),
            s.offset(this[Pk].x, this[Pk].y),
            ji(s, this.toArrowLocation[uo], s, this[Pk].x, this.toArrowLocation.y),
            s
        },
        _27: function(t) {
            var i = t ? "from": PO,
            e = this[i + Gk];
            e === n && (e = this[wk]);
            var s = this[i + Fk];
            s === n && (s = this[O_]);
            var h = this[i + zk];
            h || (this[i + zk] = h = {}),
            h[jf] = e,
            h.strokeStyle = s,
            h[Lf] = this[i + Yk],
            h[Bf] = this[i + Hk],
            h[Am] = this[i + Uk],
            h[Sm] = this[i + Wk],
            h[w_] = this[i + qk],
            h[T_] = this[i + Xk],
            h[Mm] = this[i + Vk] || 0,
            h[Im] = this[i + Kk]
        },
        doValidate: function() {
            return this.$fromArrow && this._27(!0),
            this[Dk] && this._27(!1),
            T(this, UU, RI)
        },
        drawArrow: function(t, i, n, e) {
            if (this.$fromArrow && this[Sk]) {
                t[Cx]();
                var s = this[Ak],
                h = s.x,
                r = s.y,
                a = s[uo];
                t[Ux](h, r),
                a && t.rotate(a),
                this[Sk][wo](t, i, this[Ck], n, e),
                t[Um]()
            }
            if (this.$toArrow && this.$toArrowShape) {
                t.save();
                var s = this.toArrowLocation,
                h = s.x,
                r = s.y,
                a = s[uo];
                t[Ux](h, r),
                a && t[uo](a),
                this[Rk][wo](t, i, this[Bk], n, e),
                t.restore()
            }
        },
        outlineStyle: null,
        outline: 0,
        onBoundsChanged: function() {
            this[hk] = !0
        },
        _1o: function() {
            this.$invalidateFillGradient = !1,
            this[jm] = this[rk] ? BY[Jh][bf][zh](this[rk], this._7w) : null
        },
        draw: function(t, i, n, e) {
            this[hk] && this._1o(),
            this.$data[wo](t, i, this, n, e),
            this[Zk](t, i, n, e)
        },
        doHitTest: function(t, i, n) {
            if (this.$data.hitTest(t, i, n, !0, this.$lineWidth + this.$outline, this[ok] || this[rk])) return ! 0;
            if (this[Dk] && this[Rk]) {
                var e = t - this.toArrowLocation.x,
                s = i - this.toArrowLocation.y;
                if (this[Pk][uo]) {
                    var h = Oi(e, s, -this[Pk][uo]);
                    e = h.x,
                    s = h.y
                }
                var r = this[Bk][Am] || this[Bk][Sm];
                if (this.$toArrowShape[Zu](e, s, n, !0, this[Bk][jf], r)) return ! 0
            }
            if (this[Ik] && this[Sk]) {
                var e = t - this[Ak].x,
                s = i - this[Ak].y;
                if (this[Ak].rotate) {
                    var h = Oi(e, s, -this[Ak][uo]);
                    e = h.x,
                    s = h.y
                }
                var r = this.fromArrowStyles[Am] || this.fromArrowStyles[Sm];
                if (this.$fromArrowShape[Zu](e, s, n, !0, this.fromArrowStyles.lineWidth, r)) return ! 0
            }
            return ! 1
        },
        $fromArrowOutline: 0,
        $toArrowOutline: 0,
        $invalidateFillGradient: !0,
        $invalidateFromArrow: !0,
        $invalidateToArrow: !0
    },
    p(UU, jU),
    as(UU.prototype, {
        fillColor: {},
        fillGradient: {
            validateFlags: [ck]
        },
        fromArrowOffset: {
            validateFlags: [Jk, zg]
        },
        fromArrowSize: {
            validateFlags: [Jk, zg]
        },
        fromArrow: {
            validateFlags: [Jk, zg]
        },
        fromArrowOutline: {
            validateFlags: [Jk, zg]
        },
        fromArrowStroke: {
            validateFlags: [Jk, zg]
        },
        toArrowOffset: {
            validateFlags: [Qk, zg]
        },
        toArrowSize: {
            validateFlags: [Qk, zg]
        },
        toArrow: {
            validateFlags: [Qk, zg]
        },
        toArrowOutline: {
            validateFlags: [Qk, zg]
        },
        toArrowStroke: {
            validateFlags: [Qk, zg]
        },
        outline: {
            value: 0,
            validateFlags: [Kg]
        }
    }),
    Z(UU[Jh], {
        length: {
            get: function() {
                return this[ao][Fh]
            }
        }
    }),
    us[Jh] = {
        shape: null,
        path: null,
        initialize: function() {
            T(this, us, PI),
            this[XO] = new iH,
            this[XO]._dv = !1,
            this[US] = new UU(this.path),
            this[RC](this[US], 0),
            this._ngody = this[US],
            BU[NC](this)
        },
        _1p: !0,
        _5x: null,
        _$n: function() {
            return ! 1
        },
        _46: function() {
            return ! 1
        },
        validatePoints: function() {
            this[US][uI]();
            var t = this[Mf],
            i = this.path;
            i[wf]();
            var n = t[Ec],
            e = t[gc];
            n && e && zs(this, t, i, n, e)
        },
        drawLoopedEdge: function(t, i, n, e) {
            Ws(this, e, t)
        },
        drawEdge: function(t, i, n, e, s, h) {
            var r = s.center,
            a = h[Vu];
            if (e == mY[tL]) {
                var o = (r.x + a.x) / 2,
                f = (r.y + a.y) / 2,
                c = r.x - a.x,
                u = r.y - a.y,
                _ = Math.sqrt(c * c + u * u),
                d = Math[Va](u, c);
                d += Math.PI / 6,
                _ *= .04,
                _ > 30 && (_ = 30);
                var l = Math.cos(d) * _,
                v = Math.sin(d) * _;
                return t[Rc](o - v, f + l),
                void t[Rc](o + v, f - l)
            }
            var b = Us(this, this.data, s, h, i, n, r, a);
            b && (t._fx = b)
        },
        _25: function() {
            if (!this[Mf][BT]()) return null;
            var t = this[zu]._84._87(this[Mf]);
            if (!t || !t.canBind(this.graph) || !t._gf) return null;
            var i = t[iL](this);
            return t.isPositiveOrder(this[Mf]) || (i = -i),
            i
        },
        checkBundleLabel: function() {
            var t = this.getBundleLabel();
            return t ? (this[OC] || this[nL](), this[OC]._i5 = !0, void(this[OC][ao] = t)) : void(this[OC] && (this[OC]._i5 = !1, this[OC][ao] = null))
        },
        createBundleLabel: function() {
            var t = new HU;
            t.editable = !1,
            this[OC] = t,
            this[RC](this.bundleLabel),
            $U.initBindingProperties(this)
        },
        getBundleLabel: function() {
            return this[zu][eL](this.data)
        },
        doValidate: function() {
            return this._1p && (this._1p = !1, this[sL]()),
            this[hL](),
            T(this, us, RI)
        },
        _4y: function() {
            this._1p = !0,
            this.invalidateSize()
        },
        _$t: function(t, i, n) {
            var e = this._nhh.onBindingPropertyChange(this, t, i, n);
            return e = kU[PC](this, t, i, n) || e,
            this.bundleLabel && this[OC][Mf] && (e = $U[PC](this, t, i, n) || e),
            BU[PC](this, t, i, n) || e
        }
    },
    p(us, zU),
    us[rL] = function(t, i, n, e) {
        if (t.moveTo(i.x, i.y), !e || e == mY[aL]) return void t[Rc](n.x, n.y);
        if (e == mY[bu]) t[Rc](i.x, n.y);
        else if (e == mY[du]) t[Rc](n.x, i.y);
        else if (0 == e.indexOf(mY[Lu])) {
            var s;
            s = e == mY.EDGE_TYPE_ORTHOGONAL_HORIZONTAL ? !0 : e == mY[vu] ? !1 : Math.abs(i.x - n.x) > Math.abs(i.y - n.y);
            var h = (i.x + n.x) / 2,
            r = (i.y + n.y) / 2;
            s ? (t.lineTo(h, i.y), t[Rc](h, n.y)) : (t[Rc](i.x, r), t[Rc](n.x, r))
        } else if (0 == e.indexOf(mY[xu])) {
            var s, a = WU[CU[oL]] || 0;
            s = e == mY.EDGE_TYPE_ELBOW_HORIZONTAL ? !0 : e == mY[lu] ? !1 : Math.abs(i.x - n.x) > Math.abs(i.y - n.y),
            s ? (t[Rc](i.x + a, i.y), t[Rc](n.x - a, n.y)) : (t[Rc](i.x, i.y + a), t[Rc](n.x, n.y - a))
        } else if (0 == e[Vh](fL)) {
            var a = WU[CU[oL]] || 0;
            if (e == mY[gu]) {
                var o = Math.min(i.y, n.y) - a;
                t[Rc](i.x, o),
                t[Rc](n.x, o)
            } else if (e == mY[pu]) {
                var o = Math.max(i.y, n.y) + a;
                t.lineTo(i.x, o),
                t.lineTo(n.x, o)
            } else if (e == mY[Eu]) {
                var f = Math.min(i.x, n.x) - a;
                t[Rc](f, i.y),
                t[Rc](f, n.y)
            } else if (e == mY.EDGE_TYPE_EXTEND_RIGHT) {
                var f = Math.max(i.x, n.x) + a;
                t.lineTo(f, i.y),
                t[Rc](f, n.y)
            }
        } else if (e == mY.EDGE_TYPE_ZIGZAG) {
            var h = (i.x + n.x) / 2,
            r = (i.y + n.y) / 2,
            c = i.x - n.x,
            u = i.y - n.y,
            _ = Math[Ka](c * c + u * u),
            d = Math.atan2(u, c);
            d += Math.PI / 6,
            _ *= .04,
            _ > 30 && (_ = 30);
            var l = Math.cos(d) * _,
            v = Math.sin(d) * _;
            t[Rc](h - v, r + l),
            t[Rc](h + v, r - l)
        }
        t[Rc](n.x, n.y)
    },
    Z(us[Jh], {
        length: {
            get: function() {
                return this[XO] ? this[XO].length: 0
            }
        }
    }),
    us[Jh][ka] = function(t, i, n) {
        var e = mn(this[XO], t, i, n);
        if (e && e[Fh] > 2) {
            var s = this.data,
            h = e[e.length - 1];
            s.pathSegments = h[fo] == XY ? e.splice(1, e[Fh] - 2) : e.splice(1, e[Fh] - 1)
        }
    },
    _s.prototype = {
        _2i: null,
        image: null,
        initialize: function() {
            T(this, _s, PI),
            this[cL](),
            DU[NC](this)
        },
        _nha: function() {
            this[ao].image ? this[Vx] && (this[px] = this[Vx]) : this[Ep] && (this.body = this.label)
        },
        _nez: function() {
            this[Vx] = new YU,
            this[RC](this[Vx], 0),
            this._nha()
        },
        doValidate: function() {
            this.body && (this instanceof th && !this[Mf][oI] && this._5m() ? this[px].$layoutByAnchorPoint = !1 : (this[px][Zo] = null != this._2i, this[px][UO] = this._2i));
            var t = this[Mf].$location,
            i = 0,
            n = 0;
            t && (i = t.x, n = t.y);
            var e = this.$x != i || this.$y != n;
            return e && (this.$invalidateBounds = !0),
            this.$x = i,
            this.$y = n,
            zU[Jh][RI][zh](this) || e
        },
        _$t: function(t, i, n) {
            var e = this[CC][PC](this, t, i, n);
            return e = kU.onBindingPropertyChange(this, t, i, n) || e,
            DU.onBindingPropertyChange(this, t, i, n) || e
        }
    },
    p(_s, zU);
    var WU = {};
    WU[CU.SELECTION_COLOR] = sz.SELECTION_COLOR,
    WU[CU[UI]] = sz[UI],
    WU[CU[ax]] = sz[ax],
    WU[CU[sx]] = mY.SELECTION_TYPE_SHADOW,
    WU[CU[KI]] = 2,
    WU[CU[ZI]] = 2,
    WU[CU.LABEL_COLOR] = sz.LABEL_COLOR,
    WU[CU[vS]] = lz[xl],
    WU[CU[aA]] = lz[gl],
    WU[CU[TS]] = new dz(0, 2),
    WU[CU[OS]] = 8,
    WU[CU.LABEL_RADIUS] = 8,
    WU[CU.LABEL_POINTER] = !0,
    WU[CU[jA]] = 0,
    WU[CU[uL]] = Bx,
    WU[CU[PA]] = !0,
    WU[CU[kA]] = null,
    WU[CU[LA]] = null,
    WU[CU[_L]] = dL,
    WU[CU.EDGE_WIDTH] = 1.5,
    WU[CU.EDGE_FROM_AT_EDGE] = !0,
    WU[CU[kj]] = !0,
    WU[CU[HS]] = V(3438210798),
    WU[CU[HA]] = 1,
    WU[CU[WA]] = Bx,
    WU[CU[Kj]] = !0,
    WU[CU[Dj]] = sz.ARROW_SIZE,
    WU[CU.ARROW_TO_SIZE] = sz[Ru],
    WU[CU[Ej]] = 10,
    WU[CU.EDGE_CORNER_RADIUS] = 8,
    WU[CU[Ou]] = mY.EDGE_CORNER_ROUND,
    WU[CU[Oj]] = !0,
    WU[CU[oL]] = 20,
    WU[CU[uu]] = .5,
    WU[CU.EDGE_SPLIT_VALUE] = 20,
    WU[CU.EDGE_BUNDLE_GAP] = 20,
    WU[CU.EDGE_BUNDLE_LABEL_ANCHOR_POSITION] = lz[xl],
    WU[CU.EDGE_BUNDLE_LABEL_POSITION] = lz[gl],
    WU[CU[TC]] = lL,
    WU[CU.SHAPE_STROKE] = 1,
    WU[CU[_M]] = vL,
    WU[CU[iM]] = sz.BLEND_MODE,
    WU[CU[nM]] = 1,
    sz.LOOKING_EDGE_ENDPOINT_TOLERANCE = 2;
    var qU = function(i, n) {
        this._$r = new Sz,
        this._$r.on(function(t) {
            JO == t[Ml] && this[tO]()
        },
        this),
        this._1d = new Sz,
        this._1d[gv](function(t) { ! this.currentSubNetwork || t[Ml] != Lz[bL] && t[Ml] != Lz.KIND_REMOVE || this[B_][Ku](this.currentSubNetwork) || (this[JO] = null)
        },
        this),
        this._6 = new Sz,
        this._$y = new Sz,
        this._$h = new Sz,
        this._$k = new Sz,
        this.graphModel = n || new es,
        this._84 = new lU(this, i),
        this._2m = new Sh(this),
        this._17 = new Sz,
        this._onresize = zz(t, gL,
        function() {
            this.updateViewport()
        },
        !1, this),
        this._84[gT].ondrop = function(t) {
            this[yL](t)
        } [fr](this),
        this._84[gT][xL] = function(t) {
            this[xL](t)
        } [fr](this)
    };
    qU[Jh] = {
        originAtCenter: !0,
        editable: !1,
        ondragover: function(t) {
            xY[mL](t)
        },
        getDropInfo: function(t, i) {
            var n = null;
            if (i) try {
                n = JSON[Ea](i)
            } catch(e) {}
            return n
        },
        ondrop: function(t) {
            var i = t[EL];
            if (i) {
                var n = i.getData(id),
                e = this[pL](t, n);
                e || (e = {},
                e[Vx] = i[eg](Vx), e[fo] = i[eg](fo), e[Ep] = i[eg](Ep), e[oI] = i.getData(oI));
                var s = this[wL](t);
                if (s = this.toLogical(s.x, s.y), !(this[TL] instanceof Function && this.dropAction[zh](this, t, s, e) === !1) && (e[Vx] || e[Ep] || e[fo])) {
                    var h = e[Vx],
                    r = e[fo],
                    a = e[Ep],
                    o = e[oI];
                    xY[mL](t);
                    var f;
                    if (r && OL != r ? cI == r ? f = this.createText(a, s.x, s.y) : IL == r ? f = this[ML](a, s.x, s.y) : AL == r ? (f = this.createGroup(a, s.x, s.y), o && (o = Js(o), o && (f[oI] = o))) : (r = J(r), r instanceof Function && r[Jh] instanceof OU && (f = new r, f[rr] = a, f[BO] = new oz(s.x, s.y), this[jL].add(f))) : f = this[SL](a, s.x, s.y), f) {
                        if (h && (h = Js(h), h && (f[Vx] = h)), t[Dp]) {
                            var c = this.getElementByMouseEvent(t);
                            c && this[CL](c) && (f.parent = c)
                        }
                        if (e[kL]) for (var u in e[kL]) f[u] = e[kL][u];
                        if (e[LL]) for (var u in e[LL]) f.set(u, e.clientProperties[u]);
                        if (e[PL] && f[OO](e[PL]), this[RL](f, t, e) === !1) return ! 1;
                        var _ = new jh(this, jh[DL], t, f);
                        return this.onInteractionEvent(_),
                        f
                    }
                }
            }
        },
        _ngr: function(t) {
            return t.enableSubNetwork || t instanceof AU || t[NL]
        },
        enableDoubleClickToOverview: !0,
        _84: null,
        _$r: null,
        _1d: null,
        _6: null,
        _$k: null,
        _$y: null,
        _$h: null,
        _1h: function(t) {
            return this._$r[sr](t)
        },
        _4b: function(t) {
            this._$r[Hl](t),
            Ww == t[Ml] && this.checkLimitedBounds()
        },
        isVisible: function(t) {
            return this._84._ej(t)
        },
        isMovable: function(t) {
            return (t instanceof OU || t instanceof TU && t[Bu]()) && t.movable !== !1
        },
        isSelectable: function(t) {
            return t[BL] !== !1
        },
        isEditable: function(t) {
            return t.editable !== !1
        },
        isRotatable: function(t) {
            return t[jS] !== !1
        },
        isResizable: function(t) {
            return t.resizable !== !1
        },
        canLinkFrom: function(t) {
            return t[$L] !== !1 && t.canLinkFrom !== !1
        },
        canLinkTo: function(t) {
            return t[$L] !== !1 && t.canLinkTo !== !1
        },
        createNode: function(t, i, n) {
            var e = new OU(t, i, n);
            return this[jL].add(e),
            e
        },
        createText: function(t, i, n) {
            var e = new hs(t, i, n);
            return this._ktModel.add(e),
            e
        },
        createShapeNode: function(t, i, n, e) {
            D(i) && (e = n, n = i, i = null);
            var s = new IU(t, i);
            return s.$location = new oz(n, e),
            this._ktModel.add(s),
            s
        },
        createGroup: function(t, i, n) {
            var e = new AU(t, i, n);
            return this[jL].add(e),
            e
        },
        createEdge: function(t, i, n) {
            if (t instanceof OU) {
                var e = n;
                n = i,
                i = t,
                t = e
            }
            var s = new TU(i, n);
            return t && (s[IO] = t),
            this[jL].add(s),
            s
        },
        addElement: function(t, i) {
            this[jL].add(t),
            i && t[$h]() && t.forEachChild(function(t) {
                this[GL](t, i)
            },
            this)
        },
        removeElement: function(t) {
            this[jL].remove(t)
        },
        clear: function() {
            this[jL][wf]()
        },
        getStyle: function(t, i) {
            var e = t._jk[i];
            return e !== n ? e: this[FL](i)
        },
        getDefaultStyle: function(t) {
            if (this._jk) {
                var i = this._jk[t];
                if (i !== n) return i
            }
            return WU[t]
        },
        _2l: function(t, i) {
            if (!this[zL] || this[zL][Ku](this.viewportBounds)) return i && i(),
            !1;
            t = this._1z(),
            this.stopAnimation();
            var n, e, s, h = this.viewportBounds,
            r = this.limitedBounds,
            a = h.width / this[zL].width,
            o = h.height / this.limitedBounds[Ca];
            if (1 >= a && 1 >= o) return n = r[Co] > h.left ? r.left: r[Gr] < h[Gr] ? h[Co] - (h[Gr] - r[Gr]) : h[Co],
            e = r.top > h.top ? r.top: r[Fr] < h.bottom ? h.top - (h[Fr] - r.bottom) : h.top,
            void this.translateTo( - n * this[p_], -e * this[p_], this[p_], !1, i);
            var f = a > o;
            s = Math.max(a, o),
            f ? (n = r.x, e = r.y + (h.top - r.top) * (1 - s) / s, e > r.y ? e = r.y: e < r[Fr] - h[Ca] / s && (e = r.bottom - h[Ca] / s)) : (e = r.y, n = r.x + (h.left - r[Co]) * (1 - s) / s, n > r.x ? n = r.x: n < r.right - h[Sa] / s && (n = r.right - h[Sa] / s)),
            s *= this.scale,
            n *= s,
            e *= s,
            this[HT]( - n, -e, s, t, i)
        },
        checkLimitedBounds: function(t) {
            return this[YL] || !this.limitedBounds || this[zL][Ku](this[vO]) ? !1 : (this[YL] = !0, void this.callLater(function() {
                this._2l(t,
                function() {
                    this[YL] = !1
                }.bind(this))
            },
            this))
        },
        zoomByMouseEvent: function(t, i, n, e) {
            var s = this[wL](t);
            return D(i) ? this[HL](Math.pow(this.scaleStep, i), s.x, s.y, n, e) : i ? this[UL](s.x, s.y, n, e) : this[WL](s.x, s.y, n, e)
        },
        resetScale: 1,
        translate: function(t, i, n) {
            return this.translateTo(this.tx + t, this.ty + i, this[p_], n)
        },
        translateTo: function(t, i, n, e, s) {
            if (n && (n = Math.min(this[Xx], Math.max(this[qL], n))), e) {
                var h = this._5e();
                return void h._l6(t, i, n, e, s)
            }
            var r = this._84[XL](t, i, n);
            return s && s(),
            r
        },
        centerTo: function(t, i, e, s, h) {
            return (!e || 0 >= e) && (e = this[p_]),
            s === n && (s = this._1z()),
            this[HT](this[Sa] / 2 - t * e, this[Ca] / 2 - i * e, e, s, h)
        },
        moveToCenter: function(t, i) {
            if (arguments[2] === !1 || !this._84[VL]()) {
                var n = this[no];
                return void this[KL](n.cx, n.cy, t, i)
            }
            return this._84._nek || (i = !1),
            this.callLater(this[ZL][fr](this, t, i, !1))
        },
        zoomToOverview: function(t, i) {
            if (arguments[2] === !1 || !this._84.isInvalidate()) {
                var n = this._84._1b();
                return void(n && (i && (n[p_] = Math.min(n[p_], i)), this[KL](n.cx, n.cy, n[p_], t)))
            }
            return this._84[nu] || (t = !1),
            this[JL](this[QL].bind(this, t, i, !1))
        },
        _1z: function() {
            return this._84[nu] ? this[tP] === n || null === this[tP] ? sz[iP] : this.zoomAnimation: !1
        },
        zoomAt: function(t, i, e, s, h) {
            s === n && (s = this._1z()),
            i === n && (i = this[Sa] / 2),
            i = i || 0,
            e === n && (e = this[Ca] / 2),
            e = e || 0;
            var r = this[p_];
            return t = Math.min(this[Xx], Math.max(this[qL], r * t)),
            i = t * (this.tx - i) / r + i,
            e = t * (this.ty - e) / r + e,
            this[HT](i, e, t, s, h)
        },
        zoomOut: function(t, i, n, e) {
            return this[HL](1 / this.scaleStep, t, i, n, e)
        },
        zoomIn: function(t, i, n, e) {
            return this[HL](this.scaleStep, t, i, n, e)
        },
        _5e: function() {
            return this._panAnimation || (this[nP] = new QU(this)),
            this[nP]
        },
        onAnimationStart: function() {},
        onAnimationEnd: function() {},
        isAnimating: function() {
            return this[nP] && this[nP]._e9()
        },
        enableInertia: !0,
        _ne0: function(t, i) {
            var n = this._5e();
            return n._gh(t || 0, i || 0)
        },
        stopAnimation: function() {
            this._panAnimation && this[nP]._mj()
        },
        getUI: function(t) {
            return Q(t) ? this._84._3f(t) : this._84._lp(t)
        },
        getUIByMouseEvent: function(t) {
            return this._84._3f(t)
        },
        hitTest: function(t) {
            return this._84[Zu](t)
        },
        globalToLocal: function(t) {
            return this._84._8h(t)
        },
        toCanvas: function(t, i) {
            return this._84._hq(t, i)
        },
        toLogical: function(t, i) {
            return Q(t) ? this._84._$c(t) : this._84._f8(t, i)
        },
        getElementByMouseEvent: function(t) {
            var i = this._84._3f(t);
            return i ? i[Mf] : void 0
        },
        getElement: function(t) {
            if (Q(t)) {
                var i = this._84._3f(t);
                return i ? i[Mf] : null
            }
            return this[jL][qd](t)
        },
        invalidate: function() {
            this._84[Hw]()
        },
        invalidateUI: function(t) {
            t[Yw](),
            this.invalidate()
        },
        invalidateElement: function(t) {
            this._84._3x(t)
        },
        getUIBounds: function(t) {
            return this._84._2o(t)
        },
        forEachVisibleUI: function(t, i) {
            return this._84._44(t, i)
        },
        forEachReverseVisibleUI: function(t, i) {
            return this._84._$v(t, i)
        },
        forEachUI: function(t, i) {
            return this._84._ee(t, i)
        },
        forEachReverseUI: function(t, i) {
            return this._84._42(t, i)
        },
        forEach: function(t, i) {
            return this[jL][Wf](t, i)
        },
        getElementByName: function(t) {
            var i;
            return this[jL].forEach(function(n) {
                return n[rr] == t ? (i = n, !1) : void 0
            }),
            i
        },
        focus: function(i) {
            if (i) {
                var n = t.scrollX || t[oa],
                e = t.scrollY || t[W_];
                return this.canvasPanel[eP](),
                void t[sd](n, e)
            }
            this.canvasPanel[eP]()
        },
        callLater: function(t, i, n) {
            this._84._ef(t, i, n)
        },
        exportImage: function(t, i) {
            return oh(this, t, i)
        },
        setSelection: function(t) {
            return this[jL][lv].set(t)
        },
        select: function(t) {
            return this._ktModel[lv].select(t)
        },
        unselect: function(t) {
            return this._ktModel[lv][sP](t)
        },
        reverseSelect: function(t) {
            return this[jL]._selectionModel.reverseSelect(t)
        },
        selectAll: function() {
            ah(this)
        },
        unSelectAll: function() {
            this[N_][wf]()
        },
        unselectAll: function() {
            this[hP]()
        },
        isSelected: function(t) {
            return this._ktModel[lv][Ku](t)
        },
        sendToTop: function(t) {
            Te(this[jL], t)
        },
        sendToBottom: function(t) {
            Oe(this[jL], t)
        },
        moveElements: function(t, i, n) {
            var e = [],
            s = new hz;
            return l(t,
            function(t) {
                t instanceof OU ? e[Xh](t) : t instanceof TU && s.add(t)
            }),
            this._en(e, i, n, s)
        },
        _en: function(t, i, n, e) {
            if (0 == i && 0 == n || 0 == t[Fh] && 0 == e[Fh]) return ! 1;
            if (0 != t.length) {
                var s = this._4f(t);
                e = this._4d(s, e),
                l(s,
                function(t) {
                    var e = t[NO];
                    e ? t.setLocation(e.x + i, e.y + n) : t[rP](i, n)
                })
            }
            return e && e[Fh] && this._eo(e, i, n),
            !0
        },
        _eo: function(t, i, n) {
            t[Wf](function(t) {
                t[Sg](i, n)
            })
        },
        _4d: function(t, i) {
            return this[B_].forEach(function(n) {
                n instanceof TU && this[aP](n) && t.contains(n[Ec]) && t[Ku](n[gc]) && i.add(n)
            },
            this),
            i
        },
        _4f: function(t) {
            var i = new hz;
            return l(t,
            function(t) { ! this.isMovable(t),
                i.add(t),
                pe(t, i, this._movableFilter)
            },
            this),
            i
        },
        reverseExpanded: function(t) {
            if (!t[BT]()) return ! 1;
            var i = t[xc](!0);
            return i ? i.reverseExpanded() !== !1 ? (this.invalidate(), !0) : void 0 : !1
        },
        _2m: null,
        _17: null,
        beforeInteractionEvent: function(t) {
            return this._17[sr](t)
        },
        onInteractionEvent: function(t) {
            this._17.onEvent(t)
        },
        addCustomInteraction: function(t) {
            this._2m[oP](t)
        },
        removeCustomInteraction: function(t) {
            this._2m.removeCustomInteraction(t)
        },
        enableWheelZoom: !0,
        enableTooltip: !0,
        getTooltip: function(t) {
            return t[TO] || t.name
        },
        updateViewport: function() {
            this._84._72()
        },
        destroy: function() {
            this._4b(new Tz(this, dg, !0, this[qE])),
            this[qE] = !0,
            Yz(t, gL, this._onresize),
            this._2m[dg](),
            this[B_] = new es;
            var i = this[fP];
            this._84._ii(),
            i && (i[cP] = "")
        },
        onPropertyChange: function(t, i, n) {
            this._$r[gv](function(e) {
                e.kind == t && i[zh](n, e)
            })
        },
        removeSelection: function() {
            var t = this.selectionModel._jg;
            return t && 0 != t.length ? (t = t[Hh](), this[jL][mc](t), t) : !1
        },
        removeSelectionByInteraction: function(t) {
            var i = this[N_][Mv];
            return i && 0 != i[Fh] ? void xY.confirm(uP + i[Fh],
            function() {
                var i = this[_P]();
                if (i) {
                    var n = new jh(this, jh[dP], t, i);
                    this[lP](n)
                }
            },
            this) : !1
        },
        createShapeByInteraction: function(t, i, n, e) {
            var s = new iH(i);
            i[Fh] > 2 && s.closePath();
            var h = this[ML](vP, s, n, e);
            this.onElementCreated(h, t);
            var r = new jh(this, jh[DL], t, h);
            return this.onInteractionEvent(r),
            h
        },
        createLineByInteraction: function(t, i, n, e) {
            var s = new iH(i),
            h = this[ML](bP, s, n, e);
            h[dT](xY[gP].SHAPE_FILL_COLOR, null),
            h[dT](xY[gP][xM], null),
            h[dT](xY[gP][AM], !0),
            this.onElementCreated(h, t);
            var r = new jh(this, jh[DL], t, h);
            return this.onInteractionEvent(r),
            h
        },
        createEdgeByInteraction: function(t, i, n, e) {
            var s = this[yP](xP, t, i);
            if (e) s._9m = e;
            else {
                var h = this.edgeUIClass,
                r = this[Hu];
                this.interactionProperties && (h = this[mP].uiClass || h, r = this.interactionProperties[Hu] || r),
                h && (s[iO] = h),
                r && (s[Hu] = r)
            }
            this[RL](s, n);
            var a = new jh(this, jh.ELEMENT_CREATED, n, s);
            return this[lP](a),
            s
        },
        onElementCreated: function(t) { ! t[bc] && this[JO] && (t[bc] = this.currentSubNetwork)
        },
        allowEmptyLabel: !1,
        startLabelEdit: function(t, i, n, e) {
            var s = this;
            n.startEdit(e.x, e.y, i[ao], this[cu](t, CU.LABEL_FONT_SIZE),
            function(n) {
                return s.onLabelEdit(t, i, n, i[bc])
            })
        },
        onLabelEdit: function(t, i, n, e) {
            return n || this[EP] ? void(Ep == i[rr] ? t.name = n: e._ga(i, n) === !1 && (i[ao] = n, this[pP](t))) : (xY.alert(wP), !1)
        },
        setInteractionMode: function(t, i) {
            this.interactionMode = t,
            this.interactionProperties = i
        },
        upSubNetwork: function() {
            return this._3i ? this[JO] = Qs(this._3i) : !1
        },
        _$l: !1,
        invalidateVisibility: function() {
            this._$l = !0,
            this[Yw]()
        },
        getBundleLabel: function(t) {
            var i = t[xc](!0);
            return i && i[TP] == t ? OP + i.bindableEdges.length: null
        },
        zoomAnimation: null,
        pauseRendering: function(t, i) { (this.delayedRendering || i) && this._84._6f(t)
        },
        _4g: n,
        enableRectangleSelectionByRightButton: !0
    },
    Z(qU[Jh], {
        center: {
            get: function() {
                return this.toLogical(this.html[P_] / 2, this.html.clientHeight / 2)
            }
        },
        visibleFilter: {
            get: function() {
                return this[NT]
            },
            set: function(t) {
                this[NT] = t,
                this[tO]()
            }
        },
        topCanvas: {
            get: function() {
                return this._84._topCanvas
            }
        },
        propertyChangeDispatcher: {
            get: function() {
                return this._$r
            }
        },
        listChangeDispatcher: {
            get: function() {
                return this._1d
            }
        },
        dataPropertyChangeDispatcher: {
            get: function() {
                return this._6
            }
        },
        selectionChangeDispatcher: {
            get: function() {
                return this._$k
            }
        },
        parentChangeDispatcher: {
            get: function() {
                return this._$y
            }
        },
        childIndexChangeDispatcher: {
            get: function() {
                return this._$h
            }
        },
        interactionDispatcher: {
            get: function() {
                return this._17
            }
        },
        cursor: {
            set: function(t) {
                this[IP][ta][MP] = t || this._2m[H_]
            },
            get: function() {
                return this[IP].style.cursor
            }
        },
        interactionMode: {
            get: function() {
                return this._2m[AP]
            },
            set: function(t) {
                var i = this[jP];
                i != t && (this._2m.currentMode = t, this._4b(new Tz(this, jP, t, i)))
            }
        },
        scaleStep: {
            get: function() {
                return this._84._ea
            },
            set: function(t) {
                this._84._ea = t
            }
        },
        maxScale: {
            get: function() {
                return this._84._h9
            },
            set: function(t) {
                this._84._h9 = t
            }
        },
        minScale: {
            get: function() {
                return this._84._hb
            },
            set: function(t) {
                this._84._hb = t
            }
        },
        scale: {
            get: function() {
                return this._84[vb]
            },
            set: function(t) {
                return this._84[vb] = t
            }
        },
        tx: {
            get: function() {
                return this._84._tx
            }
        },
        ty: {
            get: function() {
                return this._84._ty
            }
        },
        styles: {
            get: function() {
                return this._jk
            },
            set: function(t) {
                this._jk = t
            }
        },
        selectionModel: {
            get: function() {
                return this[jL][lv]
            }
        },
        graphModel: {
            get: function() {
                return this[jL]
            },
            set: function(t) {
                if (this[jL] == t) return ! 1;
                var i = this[jL],
                n = new Tz(this, B_, i, t);
                return this._1h(n) === !1 ? !1 : (null != i && (i[SP][Xl](this._$r, this), i.listChangeDispatcher.removeListener(this._1d, this), i[bv].removeListener(this._6, this), i[xv].removeListener(this._$y, this), i.childIndexChangeDispatcher[Xl](this._$h, this), i.selectionChangeDispatcher[Xl](this._$k, this)), this[jL] = t, this._ktModel && (this[jL].propertyChangeDispatcher.addListener(this._$r, this), this[jL][dv][gv](this._1d, this), this[jL][bv][gv](this._6, this), this[jL].parentChangeDispatcher.addListener(this._$y, this), this[jL][mv][gv](this._$h, this), this[jL][vv].addListener(this._$k, this)), this._84 && this._84._ln(), void this._4b(n))
            }
        },
        count: {
            get: function() {
                return this._ktModel[Fh]
            }
        },
        width: {
            get: function() {
                return this.html.clientWidth
            }
        },
        height: {
            get: function() {
                return this.html.clientHeight
            }
        },
        viewportBounds: {
            get: function() {
                return this._84[CP]
            }
        },
        bounds: {
            get: function() {
                return this._84._40()
            }
        },
        canvasPanel: {
            get: function() {
                return this._84[gT]
            }
        },
        html: {
            get: function() {
                return this._84._new[gx]
            }
        },
        navigationType: {
            get: function() {
                return this._84._6w
            },
            set: function(t) {
                this._84._3w(t)
            }
        },
        _3i: {
            get: function() {
                return this[jL]._3i
            }
        },
        currentSubNetwork: {
            get: function() {
                return this[jL][JO]
            },
            set: function(t) {
                this[jL][JO] = t
            }
        },
        limitedBounds: {
            get: function() {
                return this._limitedBounds
            },
            set: function(t) {
                return _z[_c](t, this[kP]) ? !1 : t ? void(this._limitedBounds = new _z(t)) : void(this._limitedBounds = null)
            }
        },
        ratio: {
            get: function() {
                return this._84[La]
            }
        },
        delayedRendering: {
            get: function() {
                return this._4g === n ? sz.DELAYED_RENDERING: this._4g
            },
            set: function(t) {
                t != this[LP] && (this._4g = t, this[PP](!1, !0))
            }
        },
        fullRefresh: {
            get: function() {
                return this._84.fullRefresh
            },
            set: function(t) {
                this._84[Kw] = t
            }
        }
    }),
    sz.DELAYED_RENDERING = !0,
    sz.GROUP_MIN_WIDTH = 60,
    sz.GROUP_MIN_HEIGHT = 60,
    th[Jh] = {
        initialize: function() {
            T(this, th, PI),
            this[zS]()
        },
        _ngd: function() {
            this._mm = new iH,
            this[US] = new YU(this._mm),
            this[US][If] = !1,
            this[RC](this.shape, 0),
            this[px] = this[US]
        },
        checkBody: function() {
            return this._5m() ? (this._1t = !0, this[US] ? (this[US][bT] = !0, this.body = this[US]) : (this[RP](), NU[NC](this)), void(this[Vx] && (this.image.visible = !1))) : (this.image ? (this.image.visible = !0, this[px] = this[Vx]) : this._nez(), void(this.shape && (this[US][bT] = !1)))
        },
        _5m: function() {
            return this.$data._i0() && this[Mf][nO]
        },
        _mm: null,
        _1t: !0,
        _5n: function() {
            this._1a = !0,
            this._1t = !0
        },
        doValidate: function() {
            if (this._1t && this._5m()) {
                if (this._1t = !1, this[US][uI](), this[Mf][oI]) {
                    this[US].data = this[Mf].groupImage;
                    var t = this._1x();
                    return this[US][xI] = t.x + t[Sa] / 2,
                    this.shape.offsetY = t.y + t[Ca] / 2,
                    this.shape[Uw] = {
                        width: t.width,
                        height: t[Ca]
                    },
                    _s.prototype[RI].call(this)
                }
                this[US][xI] = 0,
                this[US][mI] = 0;
                var i = this._86(this[Mf][aI]);
                this._mm[wf](),
                i instanceof _z ? Re(this._mm, i.x, i.y, i[Sa], i[Ca], i.rx, i.ry) : i instanceof Zi ? De(this._mm, i) : i instanceof Ji && Ne(this._mm, i),
                this._mm._6h = !0,
                this.shape.invalidateData()
            }
            return _s[Jh][RI][zh](this)
        },
        _7o: function(t, i, n, e, s) {
            switch (br != typeof e && (e = -i / 2), br != typeof s && (s = -n / 2), t) {
            case mY.GROUP_TYPE_CIRCLE:
                var h = Math.max(i, n) / 2;
                return new Zi(e + i / 2, s + n / 2, h);
            case mY[DP]:
                return new Ji(e + i / 2, s + n / 2, i, n);
            default:
                return new _z(e, s, i, n)
            }
        },
        _1x: function() {
            return this._86(null)
        },
        _86: function(t) {
            var i, e, s = this[ao],
            h = s[So],
            r = s[rI],
            a = sz[NP],
            o = sz[BP];
            if (r && (br == typeof r.width && (a = r.width), br == typeof r[Ca] && (o = r[Ca]), i = r.x, e = r.y), !s[$h]()) return this._7o(t, a, o, i, e);
            var f, c = this[Mf]._g2._jg; (t == mY[$P] || t == mY[DP]) && (f = []);
            for (var u, _, d, l, v = new _z,
            b = 0,
            g = c[Fh]; g > b; b++) {
                var y = c[b];
                if (this[zu].isVisible(y)) {
                    var x = this.graph.getUI(y);
                    x && (u = x.$x + x._fr.x, _ = x.$y + x._fr.y, d = x._fr[Sa], l = x._fr[Ca], v.addRect(u, _, d, l), f && (f[Xh]({
                        x: u,
                        y: _
                    }), f.push({
                        x: u + d,
                        y: _
                    }), f[Xh]({
                        x: u + d,
                        y: _ + l
                    }), f[Xh]({
                        x: u,
                        y: _ + l
                    })))
                }
            }
            var m = this[Mf][NO];
            m ? m[GP] && (m[GP] = !1, i === n && (m.x = v.cx), e === n && (m.y = v.cy)) : m = this[Mf][NO] = {
                x: v.cx,
                y: v.cy
            },
            h && v[of](h),
            br == typeof i && i + m.x < v.x && (v[Sa] += v.x - (i + m.x), v.x = i + m.x, f && f.push({
                x: v.x,
                y: v.cy
            })),
            br == typeof e && e + m.y < v.y && (v[Ca] += v.y - (v.y, e + m.y), v.y = e + m.y, f && f.push({
                x: v.cx,
                y: v.y
            }));
            var E, i = m.x,
            e = m.y;
            if (t == mY.GROUP_TYPE_CIRCLE) {
                E = Qi(f),
                E.cx -= i,
                E.cy -= e;
                var p = Math.max(a, o) / 2;
                return E.r < p && (E.cx += p - E.r, E.cy += p - E.r, E.r = p),
                E
            }
            return t == mY[DP] ? (E = tn(f, v), E.cx -= i, E.cy -= e, E[Sa] < a && (E.cx += (a - E[Sa]) / 2, E[Sa] = a), E.height < o && (E.cy += (o - E.height) / 2, E[Ca] = o), E) : (E = v, v.width < a && (v[Sa] = a), v[Ca] < o && (v[Ca] = o), v.offset( - i, -e), E)
        },
        _$t: function(t, i, n) {
            if (!this._5m()) return T(this, th, FP, arguments);
            var e = this[CC][PC](this, t, i, n);
            return e = kU[PC](this, t, i, n) || e,
            e = DU.onBindingPropertyChange(this, t, i, n) || e,
            NU[PC](this, t, i, n) || e
        }
    },
    p(th, _s),
    xY[zP] = th;
    var XU = {
        draw: function() {}
    };
    sz[g_] = null,
    sz[E_] = null;
    var VU = {
        position: Lw,
        "text-align": Vu
    },
    KU = {
        padding: YP,
        transition: HP
    },
    ZU = {
        position: d_,
        display: UP
    };
    gi(WP, "opacity:0.7;vertical-align:middle;"),
    gi(".Q-Graph-Nav img:hover,img.hover", qP),
    nz || (gi(XP, VP + Gz(KP) + ZP), gi(JP, QP + Gz(KP) + tR)),
    eh.prototype = {
        _nh8: function(t, i) {
            return t._i5 == i ? !1 : (t._i5 = i, void(t.style.visibility = i ? "visible": u_))
        },
        _3e: function(t, i) {
            var n = i / 2 - this[iR][nR][R_] / 2 + Pa;
            this._left[nR][ta].top = n,
            this._right[nR][ta].top = n,
            this[o_].style[Sa] = t + Pa,
            this._navPane[ta][Ca] = i + Pa
        },
        _ne8: function(t, i, n, e) {
            this[eR](this._top, t),
            this[eR](this[iR], i),
            this._nh8(this._ngottom, n),
            this._nh8(this[y_], e)
        },
        _ii: function() {
            var t = this[o_][gx];
            t && t[Ox](this[o_])
        },
        _jc: function() {
            var t = this[cc]._kt;
            if (t) {
                var i = t[no];
                if (i.isEmpty()) return void this._ne8(!1, !1, !1, !1);
                var n = t.viewportBounds,
                e = n.y > i.y + 1,
                s = n.x > i.x + 1,
                h = n[Fr] < i.bottom - 1,
                r = n.right < i.right - 1;
                this[sR](e, s, h, r)
            }
        }
    };
    var JU = 10;
    gi(hR, rR),
    gi(aR, "background-color: #7E7E7E;" + Gz(KP) + ": background-color 0.2s linear;"),
    gi(".Q-Graph-ScrollBar--V", "width: 8px;right: 0px;"),
    gi(".Q-Graph-ScrollBar--H", "height: 8px;bottom: 0px;"),
    gi(".Q-Graph-ScrollBar--V.Both", oR),
    gi(".Q-Graph-ScrollBar--H.Both", fR),
    nz || (gi(cR, VP + Gz(KP) + uR), gi(".Q-Graph:hover .Q-Graph-ScrollPane", QP + Gz(KP) + ":opacity 0.3s linear;")),
    sh[Jh] = {
        _ii: function() {
            this[_R]._ii(),
            this[dR]._ii(),
            delete this._verticalDragSupport,
            delete this[dR],
            this._mk.parentNode && this._mk.parentNode.removeChild(this._mk)
        },
        _mk: null,
        _ngw: null,
        _8x: null,
        init: function(t) {
            var n = i[Ga](i_);
            n[cr] = lR,
            li(n, {
                width: v_,
                height: v_,
                position: d_
            });
            var e = i[Ga](i_);
            e[cr] = "Q-Graph-ScrollBar Q-Graph-ScrollBar--V";
            var s = i[Ga](i_);
            s[cr] = "Q-Graph-ScrollBar Q-Graph-ScrollBar--H",
            n[lc](e),
            n[lc](s),
            t[lc](n),
            this._mk = n,
            this._8x = s,
            this[vR] = e,
            s.isH = !0;
            var h = this,
            r = {
                onstart: function(t, i) {
                    i[ur].add(k_)
                },
                onrelease: function(t, i) {
                    i[ur][mc](k_)
                },
                ondrag: function(t, i) {
                    var n = h._ngaseCanvas._kt;
                    if (n) {
                        var e = i.isH,
                        s = e ? t.dx: t.dy;
                        if (s && i[p_]) {
                            var r = n[p_] / i[p_];
                            e ? n.translate( - r * s, 0) : n.translate(0, -r * s),
                            xY[mL](t)
                        }
                    }
                },
                enddrag: function(t, i) {
                    var n = h[cc]._kt;
                    if (n && n[bR]) {
                        var e = i.isH,
                        s = e ? t.vx: t.vy;
                        if (Math.abs(s) > .1) {
                            var r = n.scale / i[p_];
                            s *= r,
                            e ? n[L_]( - s, 0) : n[L_](0, -s)
                        }
                    }
                }
            };
            this._verticalDragSupport = new xi(e, r),
            this[dR] = new xi(s, r)
        },
        _3e: function() {
            var t = this._ngaseCanvas._kt;
            t && t[JL](this._jc.bind(this))
        },
        _jc: function() {
            var t = this._ngaseCanvas._kt;
            if (t) {
                var i = t[no];
                if (i[Sf]()) return this._48(!1),
                void this._49(!1);
                var n = t[vO],
                e = t[Sa],
                s = t[Ca],
                h = t[p_],
                r = 1 / h,
                a = n.x > i.x + r || n.right < i[Gr] - r,
                o = n.y > i.y + r || n[Fr] < i[Fr] - r,
                f = a && o;
                f ? (P(this[vR], gR), P(this._8x, gR)) : (R(this._ngw, gR), R(this._8x, gR)),
                this._48(a, n, i, f ? e - JU: e),
                this._49(o, n, i, f ? s - JU: s)
            }
        },
        _48: function(t, i, n, e) {
            if (!t) return this._8x[ta].display = __,
            void(this._8x[p_] = 0);
            var s = Math.min(i.x, n.x),
            h = Math.max(i[Gr], n.right),
            r = h - s,
            a = e / r;
            this._8x[p_] = a,
            this._8x[ta][Co] = parseInt((i.x - s) * a) + Pa,
            this._8x[ta][Gr] = parseInt((h - i.right) * a) + Pa,
            this._8x.style[xw] = ""
        },
        _49: function(t, i, n, e) {
            if (!t) return this[vR][ta][xw] = __,
            void(this[vR][p_] = 0);
            var s = Math.min(i.y, n.y),
            h = Math.max(i[Fr], n[Fr]),
            r = h - s,
            a = e / r;
            this._ngw[p_] = a,
            this[vR][ta].top = parseInt((i.y - s) * a) + Pa,
            this[vR][ta].bottom = parseInt((h - i[Fr]) * a) + Pa,
            this[vR][ta][xw] = ""
        }
    },
    hh[Jh] = {
        shape: null,
        initialize: function() {
            T(this, hh, PI),
            this[cL](),
            GU[NC](this)
        },
        _nez: function() {
            this[Vx] = new UU(this[Mf].path),
            this.addChild(this[Vx], 0),
            this[px] = this[Vx]
        },
        invalidateShape: function() {
            this[Vx][uI](),
            this[JT]()
        },
        _$t: function(t, i, n) {
            var e = this._nhh.onBindingPropertyChange(this, t, i, n);
            return e = kU[PC](this, t, i, n) || e,
            GU[PC](this, t, i, n) || e
        },
        doValidate: function() {
            this.body && (this[Vx].data = this[ao][XO], this[px][Zo] = null != this._2i, this[px][UO] = this._2i);
            var t = this[Mf][NO],
            i = 0,
            n = 0;
            t && (i = t.x, n = t.y);
            var e = this.$x != i || this.$y != n;
            return e && (this.$invalidateBounds = !0),
            this.$x = i,
            this.$y = n,
            zU.prototype.doValidate.call(this) || e
        }
    },
    p(hh, zU),
    Z(hh[Jh], {
        path: {
            get: function() {
                return this[ao][XO]
            }
        },
        length: {
            get: function() {
                return this.data.length
            }
        }
    }),
    hh[Jh][ka] = function(t, i, n) {
        var e = this._i3(t, i),
        s = this[ao],
        h = mn(s[XO], e.x, e.y, n);
        h && (s[yR] = h)
    },
    rh[Jh] = {
        _mv: function() {
            this._j8[ta][Ex] = bT
        },
        _jh: function() {
            this._j8[ta].visibility = u_
        },
        clear: function() {
            this._9o.clear(),
            this[Hw]()
        },
        contains: function(t) {
            return t instanceof Object && t.id && (t = t.id),
            this._9o[uc](t)
        },
        _5g: function(t) {
            EU[dT](this._j8, r_, t ? lT + t[Zf](Ar) + ")": "")
        },
        addDrawable: function(t, i) {
            if (i) {
                var n = {
                    id: ++FF,
                    drawable: t,
                    scope: i
                };
                return this._9o.add(n),
                n
            }
            return t.id || (t.id = ++FF),
            this._9o.add(t),
            t
        },
        removeDrawable: function(t) {
            return t.id ? void this._9o[mc](t) : this._9o.removeById(t)
        },
        _9o: null,
        invalidate: function() {
            this[Hw]()
        },
        _nhf: function() {
            this[cc]._6h || this._jz()
        },
        _ir: function(t, i) {
            this._j8[Ya](t, i)
        },
        _jz: function() {
            var t = this._ngaseCanvas[vb],
            i = this.g;
            i._l3(),
            i[Cx](),
            this[cc]._9u(i);
            for (var n = this._9o._jg,
            e = 0,
            s = n[Fh]; s > e; e++) i[Cx](),
            i[Cm](),
            this._h5(i, n[e], t),
            i[Um]();
            i.restore()
        },
        _h5: function(t, i, n) {
            return i instanceof Function ? void i(t, n) : void(i.drawable instanceof Function && i[Wl] && i.drawable[zh](i[Wl], t, n))
        }
    },
    sz[iP] = !0;
    var QU = function(t) {
        this._kt = t
    };
    sz[xR] = 600,
    sz[mR] = vY.easeOut,
    QU[Jh] = {
        _kt: null,
        _ne: .001,
        _eq: null,
        _nhv: function(t) {
            return t > 1 ? 1 : -1 > t ? -1 : t
        },
        _gh: function(t, i, n) {
            this._mj(),
            t *= .6,
            i *= .6,
            t = this[ER](t),
            i = this[ER](i);
            var e = Math.sqrt(t * t + i * i);
            if (.01 > e) return ! 1;
            var s = Math.min(sz[xR], e / this._ne);
            this._speedX = t,
            this._speedY = i,
            this[pR] = t / s,
            this[wR] = i / s,
            this._7n(this._5o, s, vY.easeOutStrong, n)
        },
        _7n: function(t, i, n, e, s) {
            this._eq && this._eq._mj(),
            s && (this[TR] = !0, this._kt[PP](!0)),
            this._4i(),
            this._eq = new gY(t, this, i, n),
            this._eq._6r = this._6r[fr](this),
            this._eq._l5(e)
        },
        _4i: function() {
            this._kt[OR]()
        },
        _6r: function() {
            this[TR] && (this._kt.pauseRendering(!1), delete this[TR]),
            this._kt[IR]()
        },
        _e9: function() {
            return this._eq && this._eq._e9()
        },
        _5o: function(t, i) {
            if (0 != t) {
                var n = this[MR] * i - .5 * this._neX * i * i,
                e = this[AR] * i - .5 * this[wR] * i * i;
                this[MR] -= this[pR] * i,
                this[AR] -= this[wR] * i,
                this._kt[Ux](n, e)
            }
        },
        _mj: function() {
            this._eq && this._eq._mj()
        },
        _j5: function(t) {
            var i = this[jR] + (this[SR] - this[jR]) * t,
            n = this._fromTY + (this._toTY - this[CR]) * t,
            e = this[kR] + (this._toScale - this._fromScale) * t;
            this._kt.translateTo(i, n, e, this.toInt)
        },
        _l6: function(t, i, n, e, s) {
            this._mj();
            var h = this._kt,
            r = h.scale;
            if (0 >= n && (n = r), t != h.tx || i != h.ty || n != r) {
                var a, o, f;
                e instanceof Object && (a = e.duration, o = e[LR], f = e[PR]);
                var c = h.tx,
                u = h.ty;
                if (!a) if (n != r) {
                    var _ = n > r ? n / r: r / n;
                    _ = Math.log(_) / Math.log(1.3),
                    a = 60 * _
                } else {
                    var d = fz(t, i, c, u);
                    a = d / 2
                }
                o = o || sz[xR],
                f = f || sz.ANIMATION_TYPE,
                a = Math.min(o, a),
                this[jR] = c,
                this._fromTY = u,
                this[kR] = r,
                this[SR] = t,
                this[RR] = i,
                this[DR] = n,
                this._7n(this._j5, a, f, s, n != r)
            }
        }
    },
    sz[NR] = 8,
    sz[BR] = 4,
    sz[$R] = 30,
    sz[GR] = 20;
    var tW = Math.PI / 4;
    fh[Jh] = {
        onElementRemoved: function(t, i) {
            this[FR] && (t == this.element || $(t) && m(t, this[FR])) && this[dg](i)
        },
        onClear: function(t) {
            this[FR] && this[dg](t)
        },
        destroy: function() {
            delete this.element,
            this.removeDrawable()
        },
        invalidate: function() {
            this[z_][Yw]()
        },
        removeDrawable: function() {
            this[zR] && (this[z_].removeDrawable(this[zR]), delete this[zR], this[Yw]())
        },
        addDrawable: function() {
            this[zR] || (this[zR] = this.topCanvas[YR](this[HR], this).id, this[Yw]())
        },
        doDraw: function() {},
        escapable: !0,
        onkeydown: function(t, i) {
            this[UR] && 27 == t[Np] && (z(t), this[dg](i))
        }
    },
    xY.DrawableInteraction = fh,
    ch.prototype = {
        defaultCursor: U_,
        getInteractionInstances: function(t) {
            if (!this[Y_]) return null;
            for (var i = [], n = 0, e = this[Y_][Fh]; e > n; n++) {
                var s = this[Y_][n];
                s instanceof Function ? i.push(new s(t)) : s instanceof Object && i[Xh](s)
            }
            return i
        }
    },
    uh[Jh] = {
        _ev: null,
        _k7: null,
        destroy: function() {
            T(this, uh, dg, arguments),
            delete this._k7,
            delete this._9j,
            delete this._ev
        },
        doDraw: function(t) {
            var i = this.points;
            i && (i[Wf](function(i) {
                this[WR](t, i)
            },
            this), this[qR] && t[Vo](), this[XR](t))
        },
        styleDraw: function(t) {
            var i = _h(this.graph.interactionProperties, this[VR](this.graph));
            i[jf] && (t[jf] = i[jf], i[w_] && (t[w_] = i[w_]), i.lineJoin && (t[T_] = i[T_]), i[Lf] && (t[Lf] = i[Lf], t[Bf] = i[Bf] || 0), t[O_] = i.strokeStyle, t.stroke()),
            i[kx] && (t[kx] = i[kx], t[ro]())
        },
        drawPoint: function(t, i, n) {
            if (n) return void t[Pc](i.x, i.y);
            if (xY[xr](i)) {
                var e = i[0],
                s = i[1];
                t[DE](e.x, e.y, s.x, s.y)
            } else t[Rc](i.x, i.y)
        },
        setCurrentPoint: function(t) {
            this[KR] = t
        },
        addPoint: function(t) {
            this._k7 || (this._k7 = [], this[YR]()),
            this._k7.push(t),
            this[Yw]()
        }
    },
    Z(uh.prototype, {
        currentPoint: {
            get: function() {
                return this._9j
            },
            set: function(t) {
                this._9j = t,
                this[Yw]()
            }
        },
        prevPoint: {
            get: function() {
                return this._k7 && this._k7.length ? this._k7[this._k7[Fh] - 1] : null
            }
        },
        points: {
            get: function() {
                return this._9j && this._k7 && this._k7[Fh] ? this._k7[co](this._9j) : void 0
            }
        }
    }),
    p(uh, fh),
    xY[ZR] = uh,
    dh[Jh] = {
        destroy: function() {
            T(this, dh, dg, arguments),
            delete this[JR],
            delete this.start
        },
        doDraw: function(t, i) {
            return this._k7 ? this._k7[Fh] <= 1 ? bh[Jh].doDraw[zh](this, t, i) : void T(this, dh, HR, arguments) : void 0
        },
        ondblclick: function(t, i) {
            this[dg](i)
        },
        finish: function(t, i, n) {
            if (this._l5Time && Date.now() - this[JR] < 200) return void this[dg](i);
            var e;
            this._k7 && this._k7[Fh] >= 2 && (this._k7[hp](), e = new hz, l(this._k7,
            function(t) {
                if (xY[xr](t)) {
                    var i = t[0],
                    n = t[1];
                    e.add(new QY(mY[lm], [i.x, i.y, n.x, n.y]))
                } else e.add(new QY(mY[dm], [t.x, t.y]))
            },
            this)),
            i[QR](this[tD], n, t, e),
            this[dg](i)
        },
        onstart: function(t, i) {
            if (2 != t[ob]) {
                var n = t[eg]();
                if (this[tD]) {
                    var e = n instanceof OU && i[iD](n, this[tD]);
                    return e ? void this[nD](t, i, n) : void this.addPoint(this[eD](t))
                }
                var s = n instanceof OU && i.canLinkFrom(n);
                s && (this[tD] = n, this._l5Time = Date.now(), this[ka](this[eD](t)))
            }
        },
        onmousemove: function(t) {
            this.start && this[sD](this.toLogicalPoint(t))
        },
        toLogicalPoint: function(t) {
            return this.graph[hD](t)
        },
        startdrag: function(t) {
            this[tD] && (t[rD] = !0)
        },
        ondrag: function(t) {
            this[tD] && this[sD](this.toLogicalPoint(t))
        },
        enddrag: function(t, i) {
            if (this[tD]) {
                var n = t[eg](),
                e = n instanceof OU && i[iD](n, this[tD]);
                e && this[nD](t, i, n)
            }
        },
        getDefaultDrawStyles: function() {
            return {
                lineWidth: this[zu][FL](CU.EDGE_WIDTH),
                strokeStyle: this[zu][FL](CU[_L]),
                lineDash: this.graph[FL](CU[bj]),
                lineDashOffset: this[zu][FL](CU[ZS]),
                lineCap: this.graph.getDefaultStyle(CU[OM]),
                lineJoin: this.graph[FL](CU.LINE_JOIN)
            }
        }
    },
    p(dh, uh),
    xY[aD] = dh,
    lh[Jh] = {
        getDefaultDrawStyles: function() {
            return {
                lineWidth: this.graph[FL](CU[cM]),
                strokeStyle: this.graph[FL](CU[_M]),
                fillStyle: this[zu].getDefaultStyle(CU[gM])
            }
        },
        finish: function(t, i) {
            if (this._k7 && this._k7.length) {
                var n = this._k7,
                e = 0,
                s = 0,
                h = 0;
                n[Wf](function(t) {
                    return xY[xr](t) ? void t[Wf](function() {
                        e += t.x,
                        s += t.y,
                        h++
                    }) : (e += t.x, s += t.y, void h++)
                }),
                e /= h,
                s /= h;
                var r = [];
                n[Wf](function(t, i) {
                    if (0 == i) return void r[Xh](new QY(mY[_m], [t.x - e, t.y - s]));
                    if (xY[xr](t)) {
                        var n = t[0],
                        h = t[1];
                        r[Xh](new QY(mY[lm], [n.x - e, n.y - s, h.x - e, h.y - s]))
                    } else r.push(new QY(mY.SEGMENT_LINE_TO, [t.x - e, t.y - s]))
                }),
                this.createElement(t, r, e, s),
                this.destroy(i)
            }
        },
        startdrag: function(t) {
            t[rD] = !0
        },
        createElement: function(t, i, n, e) {
            return this[zu][oD](t, i, n, e)
        },
        onstart: function(t, i) {
            var n = i[hD](t);
            this._ev = n,
            this[ka](n)
        },
        onmousemove: function(t, i) {
            this._ev && (this[KR] = i[hD](t))
        },
        ondblclick: function(t, i) {
            if (this._ev) {
                if (this._k7[Fh] < 3) return void this[dg](i);
                delete this._k7[this._k7[Fh] - 1],
                this.finish(t, i)
            }
        },
        isClosePath: !0
    },
    p(lh, uh),
    xY.CreateShapeInteraction = lh,
    vh.prototype = {
        isClosePath: !1,
        createElement: function(t, i, n, e) {
            return this[zu].createLineByInteraction(t, i, n, e)
        },
        getDefaultDrawStyles: function() {
            return {
                lineWidth: WU[CU.SHAPE_STROKE],
                strokeStyle: WU[CU[_M]],
                lineDash: this.graph.getDefaultStyle(CU[lM]),
                lineDashOffset: this.graph[FL](CU[bM]),
                lineCap: this[zu].getDefaultStyle(CU[OM]),
                lineJoin: this[zu][FL](CU[BS])
            }
        }
    },
    p(vh, lh),
    xY[fD] = vh,
    bh[Jh] = {
        destroy: function(t) {
            T(this, bh, dg, arguments),
            t[MP] = "",
            this.start = null
        },
        doDraw: function(t) {
            if (this.start && this[KR]) {
                var i, n;
                this[zu][mP] && (i = this[zu][mP].uiClass, n = this[zu].interactionProperties.edgeType),
                i = i || this[zu].edgeUIClass || xY.EdgeUI,
                n = n || this.graph[Hu];
                var e = i[rL] || xY[cD][rL],
                s = this[zu].getUI(this.start);
                s && s[Uu] && (s = s[Uu][Vu], e(t, s, this[KR], n), this.styleDraw(t))
            }
        },
        canLinkFrom: function(t, i) {
            return t instanceof OU && i[uD](t)
        },
        canLinkTo: function(t, i) {
            return t instanceof OU && i[iD](t, this[tD])
        },
        startdrag: function(t, i) {
            var n = t[eg]();
            this[uD](n, i) && (t[rD] = !0, this.start = n, i[MP] = jg, this[YR]())
        },
        ondrag: function(t, i) {
            this[tD] && (xY[mL](t), this[KR] = i[hD](t), this.invalidate())
        },
        enddrag: function(t, i) {
            if (this[tD]) {
                this[Yw]();
                var n = t.getData();
                this[iD](n, i) && i[QR](this[tD], n, t),
                this.destroy(i)
            }
        },
        getDefaultDrawStyles: function() {
            return {
                lineWidth: this.graph[FL](CU.EDGE_WIDTH),
                strokeStyle: this.graph[FL](CU[_L]),
                lineDash: this.graph[FL](CU[bj]),
                lineDashOffset: this[zu].getDefaultStyle(CU.EDGE_LINE_DASH_OFFSET),
                lineCap: this[zu][FL](CU[OM]),
                lineJoin: this.graph[FL](CU.LINE_JOIN)
            }
        }
    },
    p(bh, uh),
    xY[_D] = bh,
    sz[dD] = !1,
    ph.prototype = {
        html: null,
        createHTML: function() {
            var t = i.createElement(lD);
            t[cr] = vD,
            t[ta][Of] = Lw,
            t.style[vk] = Vu,
            t[ta].border = bD,
            t[ta][So] = gD,
            t[ta].boxShadow = "0px 0px 10px rgba(40, 85, 184, 0.75)",
            t[ta].display = __,
            t[ta][Tw] = u_;
            var n = this;
            return t.oninput = function(t) {
                n[yD](t)
            },
            t[xD] = function(t) {
                return 27 == t.keyCode ? void n.cancelEdit() : void 0
            },
            t[mD] = function(i) {
                if (13 == i.keyCode || 10 == i[Np]) {
                    if (i.preventDefault(), i[ED] || i[va] || i[Dp]) return mh(t, qa),
                    void n[yD](i);
                    n[pD]()
                }
            },
            i[px][lc](t),
            t
        },
        setText: function(t, i) {
            this[fP].value = t || "",
            i && (this.html[ta][X_] = i),
            Eh(this[fP]),
            this[wD](this[fP])
        },
        onSizeChange: function(t) {
            var i = (t[cd], t[q_], xh(t));
            return t[ta][Sa] = i[Sa] + 30 + Pa,
            t[ta][Ca] = i.height + 10 + Pa,
            i
        },
        onValueChange: function(t) {
            var i = t.target;
            this[wD](i),
            i[ta][Co] = i.x - i[cd] / 2 + Pa
        },
        onClickOnWindow: function(t) {
            t[C_] != this[fP] && (sz[dD] ? this[pD]() : this.cancelEdit())
        },
        startEdit: function(i, n, e, s, h) {
            this[fP] || (this.html = this[TD]()),
            this[OD] || (this[OD] = function(t) {
                this[ID](t)
            } [fr](this)),
            t[Nv](Ib, this.stopEditWhenClickOnWindow, !0),
            this[ou] = h,
            this[fP].x = i,
            this[fP].y = n,
            this[fP].style.display = UP,
            yh(this[fP], i, n),
            this[MD](e, s || 10),
            yh(this[fP], i, n)
        },
        isEditing: function() {
            return __ != this[fP][ta][xw]
        },
        cancelEdit: function() {
            this.stopEdit(!0)
        },
        stopEdit: function(i) {
            if (this.isEditing()) {
                t.removeEventListener(Ib, this[OD]);
                var n = this[fP][ar];
                if (!i && this.callback && this[ou](n) === !1) return ! 1;
                this.html[ta][xw] = __,
                this.html[ar] = null,
                this[ou] = null
            }
        },
        destroy: function() {
            this.html && i[px].removeChild(this.html)
        }
    },
    xY.LabelEditor = ph;
    var iW = function(t) {
        this[zu] = t
    };
    iW[Jh] = {
        destroy: function(t) {
            t[AD] && (t.labelEditor[dg](), delete t[AD])
        },
        ondblclick: function(t, i) {
            var n = t[eg]();
            if (n) {
                if (n.dblclickable !== !1) {
                    if (i[jD] && i[SD](n)) {
                        var e = i[Zu](t);
                        if (e instanceof HU && e[jD] !== !1) {
                            var s = i[AD];
                            s || (i.labelEditor = s = new ph);
                            var h = e.getBounds();
                            return h = i[ZT](h.x + h[Sa] / 2, h.y + h[Ca] / 2),
                            h = gh(h.x, h.y, i[fP]),
                            void i[CD](n, e, s, h)
                        }
                    }
                    var r = n instanceof AU,
                    a = n instanceof TU && n[kD]();
                    return n._4r && (mi(t) || !r && !a) ? void(i.currentSubNetwork = n) : r ? (n.expanded = !n.expanded, void this[zu][lP](new jh(this.graph, jh[iI], t, n))) : void(a && this[zu][LD](n) && this[zu][lP](new jh(this[zu], jh.EDGE_BUNDLE, t, n)))
                }
            } else {
                if (i[JO]) return void i[PD]();
                if (i[RD]) {
                    var o = i[DD] || 1;
                    Math.abs(i[p_] - o) < 1e-4 ? i[QL]() : i[ZL](o)
                }
            }
        }
    };
    var nW = function(t) {
        this.graph = t
    };
    nW.prototype = {
        onkeydown: function(t, i) {
            if (i[jD]) {
                var n = t.keyCode;
                if (8 == n || 46 == n || 127 == n) return i.removeSelectionByInteraction(t),
                void G(t);
                if (mi(t)) {
                    if (67 == n);
                    else if (86 == n);
                    else if (90 == n);
                    else if (89 != n) return;
                    G(t)
                }
            }
        }
    },
    xY[ND] = nW;
    var eW = function(t) {
        this[zu] = t
    };
    eW.prototype = {
        onkeydown: function(i, n) {
            if (i.metaKey && 83 == i[Np]) {
                var e = n[BD](n.scale, n[vO]),
                s = t[Ta](),
                h = s[$D];
                h[GD] = FD + e[Sa] + zD + e[Ca];
                var r = h[Ga](e_);
                r.src = e[ao],
                h[px][lc](r),
                G(i)
            }
        }
    };
    var sW = function(t) {
        this.graph = t
    };
    sW[Jh] = {
        destroy: function() {
            delete this[YD],
            delete this[HD]
        },
        _2c: function(t) {
            var i = new hz;
            return t.selectionModel[Wf](function(n) {
                t[aP](n) && t[$_](n) && i.add(n)
            },
            this),
            i
        },
        onstart: function(t, i) {
            this.currentDraggingElement && this.destroy(i)
        },
        startdrag: function(t, i) {
            if (! (t.responded || t[Nr] && 1 != t[Nr][Fh])) {
                var n = t[eg]();
                if (!n || !i.isSelected(n) || !i.isMovable(n)) return void this[dg](i);
                t[rD] = !0,
                this.currentDraggingElement = n,
                this[YD] = this._2c(i);
                var e = new jh(i, jh[UD], t, this[HD], this[YD][Mv]);
                return i[WD](e) === !1 ? void this[dg](i) : void i[lP](e)
            }
        },
        ondrag: function(t, i) {
            if (this[HD]) {
                if (t[Nr] && 1 != t.touches[Fh]) return void this[tg](t, i);
                z(t);
                var n = t.dx,
                e = t.dy,
                s = i[p_];
                n /= s,
                e /= s;
                var h = new jh(i, jh[qD], t, this.currentDraggingElement, this[YD][Mv]);
                i.moveElements(this[YD][Mv], n, e),
                i.onInteractionEvent(h)
            }
        },
        enddrag: function(t, i) {
            if (this[HD]) {
                if (this[YD] && this[YD][Fh]) {
                    if (t.shiftKey) {
                        var n, e = i[hD](t),
                        s = e.x,
                        h = e.y;
                        i.forEachReverseVisibleUI(function(t) {
                            var i = t[ao];
                            if (!this[YD].contains(i) && t[$T].intersectsPoint(s - t.x, h - t.y) && t[Zu](s, h, 1)) {
                                if (i instanceof xY[xP]) {
                                    if (!i[t_]) return;
                                    for (var e = this[YD][Fh]; e-->0;) {
                                        var r = this[YD].get(e);
                                        if (r instanceof xY[OL] && r[XD](i)) return
                                    }
                                    return n = i,
                                    !1
                                }
                                return (i[t_] || i._i0() && i[nO]) && (n = i),
                                !1
                            }
                        },
                        this),
                        n && this.draggingElements.forEach(function(t) {
                            for (var i = t[bc]; i;) {
                                if (this[YD][Ku](i)) return;
                                i = i.parent
                            }
                            t[bc] = n
                        },
                        this)
                    }
                    var r = new jh(i, jh.ELEMENT_MOVE_END, t, this.currentDraggingElement, this[YD][Mv]);
                    i[lP](r)
                }
                this[dg](i)
            }
        },
        onpinch: function(t, i) {
            this[HD] && this.enddrag(t, i)
        },
        step: 1,
        onkeydown: function(t, i) {
            if (mi(t)) {
                var n, e;
                if (37 == t[Np] ? n = -1 : 39 == t[Np] ? n = 1 : 38 == t[Np] ? e = -1 : 40 == t.keyCode && (e = 1), n || e) {
                    var s = this._2c(i)[Mv];
                    if (0 != s[Fh]) {
                        G(t),
                        n = n || 0,
                        e = e || 0;
                        var h = this[VD] / i[p_],
                        r = new jh(i, jh[KD], t, null, s);
                        i[ZD](s, n * h, e * h),
                        i[lP](r)
                    }
                }
            }
        }
    };
    var hW = function(t) {
        this[zu] = t
    };
    hW[Jh] = {
        onkeydown: function(t, i) {
            mi(t) || (37 == t[Np] ? (this._5p(i, 1, 0), G(t)) : 39 == t.keyCode ? (this._5p(i, -1, 0), G(t)) : 38 == t[Np] ? (this._5p(i, 0, 1), G(t)) : 40 == t.keyCode && (this._5p(i, 0, -1), G(t)))
        },
        _5p: function(t, i, n) {
            t._ne0(i, n)
        },
        onstart: function(t, i) {
            this._l5 && this[dg](i)
        },
        _l5: !1,
        startdrag: function(t, i) {
            if (!t[rD]) {
                t.responded = !0,
                this._l5 = !0,
                i[MP] = fY;
                var n = new jh(i, jh[JD], t);
                i.onInteractionEvent(n)
            }
        },
        ondrag: function(t, i) {
            this._l5 && i.translate(t.dx || 0, t.dy || 0)
        },
        enddrag: function(t, i) {
            if (this._l5) {
                if (i[bR] !== !1) {
                    var n = t.vx,
                    e = t.vy; (Math.abs(n) > .1 || Math.abs(e) > .1) && i[L_](n, e)
                }
                this[dg](i);
                var s = new jh(i, jh[QD], t);
                i.onInteractionEvent(s)
            }
        },
        startpinch: function(t, i) {
            i[PP](!0)
        },
        onpinch: function(t, i) {
            this._l5 = !0;
            var n = t.dScale;
            if (n) {
                var e = i[wL](t[Vu]);
                i[HL](n, e.x, e.y, !1)
            }
        },
        endpinch: function(t, i) {
            i[PP](!1)
        },
        destroy: function(t) {
            this._l5 = !1,
            t[MP] = null
        }
    },
    wh[Jh] = {
        _1g: function(t) {
            this[FR] && t[Lo] == this.element && this[zu][JL](function() {
                this._jc()
            },
            this)
        },
        _5: function() {
            this[tN] || (this[tN] = !0, this[zu][iN][gv](this._1g, this))
        },
        _4: function() {
            this[tN] = !1,
            this[zu].dataPropertyChangeDispatcher[Xl](this._1g, this)
        },
        onElementRemoved: function(t, i) {
            this.element && (t == this[FR] || Array[xr](t) && m(t, this[FR])) && this[dg](i)
        },
        onClear: function(t) {
            this[FR] && this.destroy(t)
        },
        destroy: function() {
            this[zu][MP] = null,
            this[FR] && delete this.element[nN],
            this._mousePressed = !1,
            delete this[FR],
            delete this._9m,
            delete this._9j,
            delete this[eN],
            this._77(),
            this._4()
        },
        _77: function() {
            this.drawLineId && (this.topCanvas[sN](this.drawLineId), delete this[hN], this[z_][Yw]())
        },
        _nem: function() {
            this.drawLineId && this[z_][Ku](this[hN]) || (this[hN] = this[z_].addDrawable(this[rN], this).id, this[z_][Yw]())
        },
        _9m: null,
        _5s: function(t) {
            this._9m = t,
            this.invalidate()
        },
        _ff: function(t, i, n) {
            t.beginPath(),
            i[aN] ? t[vc](i.x - this[hd] / n, i.y - this[hd] / n, this[hd] / n * 2, this[hd] / n * 2) : t.arc(i.x, i.y, this[hd] / n, 0, 2 * Math.PI, !1),
            t[jf] = 1 / n,
            t.lineDash = [],
            t[O_] = A_,
            t[kx] = "rgba(255, 255, 0, 0.8)",
            t[ho](),
            t[ro]()
        },
        _g8: function(t, i, n, e) {
            e ? t[Pc](i, n) : t[Rc](i, n)
        },
        drawLine: function(t, i) {
            if (this._9m && this._9m[Fh]) {
                t[Cx]();
                var n = this[FR] instanceof IU;
                n && (t.translate(this.element.x, this[FR].y), this[FR].rotate && t[uo](this.element.rotate));
                var e, s = [];
                t.beginPath(),
                this._9m[Fh],
                this._9m[Wf](function(i) {
                    if (i[fo] != mY.SEGMENT_CLOSE) for (var n = 0,
                    h = i[ba]; n + 1 < h[Fh];) {
                        var r = h[n],
                        a = h[n + 1],
                        o = {
                            x: r,
                            y: a,
                            isControlPoint: this._75(i, n)
                        };
                        s[Xh](o),
                        this._g8(t, o.x, o.y, null == e),
                        e = o,
                        n += 2
                    }
                },
                this),
                t[jf] = 1 / i,
                t.lineDash = [2 / i, 3 / i],
                t[O_] = oN,
                t[ho](),
                s[Wf](function(n) {
                    this._ff(t, n, i)
                },
                this),
                t[Um]()
            }
        },
        invalidate: function() {
            this[z_][Yw]()
        },
        _3k: function(t) {
            if (this[FR] != t && (this.element && this[dg](), t && this.isEditable(t))) {
                var i = this._5u(t, this[zu]);
                i && (this[FR] = t, t[nN] = !0, this[eN] = !0, this._5s(i), this._5(), this[fN]())
            }
        },
        _jc: function() {
            if (this[hN] && this.element) {
                var t = this._5u(this[FR], this.graph);
                return t ? void this._5s(t) : void this[dg](this[zu])
            }
        },
        _5u: function(t, i) {
            if (i[SD](t)) {
                var n = t[yR] || [];
                n instanceof hz && (n = n[$u]());
                var e = i[Yu](t);
                if (e instanceof xY[cD]) {
                    var s = t[Ec],
                    h = t[gc],
                    r = i.getUI(s),
                    a = i[Yu](h),
                    o = r[Uu][qh](),
                    f = a[Uu][qh](),
                    c = o[Vu],
                    u = f[Vu],
                    _ = e[cu](xY[gP][Wu]),
                    d = e[cu](xY.Styles.EDGE_TO_OFFSET);
                    _ && (c.x += _.x || 0, c.y += _.y || 0),
                    d && (u.x += d.x || 0, u.y += d.y || 0),
                    n.splice(0, 0, new xY[ym](mY.SEGMENT_MOVE_TO, [c.x, c.y])),
                    n[Xh](new xY[ym](mY[_m], [u.x, u.y]))
                }
                return n
            }
        },
        _i3: function(t, i) {
            t -= this[FR].x,
            i -= this.element.y;
            var n = {
                x: t,
                y: i
            };
            return this[FR].rotate && Ns(n, -this[FR].rotate),
            n
        },
        onclick: function(t, i) {
            if (i.editable && t[ED] && this.element) {
                var n = this._g7(t, i);
                if (n && n.isControlPoint) return void this.element[cN](n[Kl]);
                if (this.element == t[eg]()) {
                    var e = i.toLogical(t),
                    s = i[Yu](this[FR]);
                    s[ka](e.x, e.y, this[hd] || 2)
                }
            }
        },
        isEditable: function(t) {
            return this.graph[SD](t) && (t instanceof IU || t instanceof TU && (!t.isLooped() || t.hasPathSegments()))
        },
        ondblclick: function(t, i) {
            if (!i.editable) return void(this.element && this[dg](i));
            var n = t[eg]();
            return ! n || n == this.element || n[nN] ? void this[dg](i) : void this._3k(n)
        },
        onstart: function(t, i) {
            if (this[uN] = !0, !i[jD]) return void(this.element && this[dg](i));
            if (!t.responded) {
                if (this[FR] && this._g7(t, i)) return void(t[rD] = !0);
                var n = t[eg]();
                return n && i[_N](n) && n instanceof IU ? void(this[FR] && n != this.element && this.destroy()) : void this._3k(n)
            }
        },
        onrelease: function() {
            this._mousePressed = !1,
            this[FR] && (this[eN] = !0)
        },
        _9j: null,
        _g7: function(t, i) {
            var n = i.toLogical(t);
            this[FR] instanceof IU && (n = this._i3(n.x, n.y));
            var e, s = i.scale,
            h = this[hd] / s,
            r = this._9m,
            a = r.length,
            o = this.element instanceof xY.Edge;
            return r[Wf](function(t, s) {
                for (var f = 0,
                c = t.points; f + 1 < c[Fh];) {
                    var u = c[f],
                    _ = c[f + 1],
                    d = fz(n.x, n.y, u, _);
                    if (h > d) {
                        if (e = {
                            oldPoints: c[Hh](0),
                            segment: t,
                            index: s,
                            pointIndex: f
                        },
                        o && (e.index -= 1), o && !Th(t) && (0 == s || s == r[Fh] - 1)) {
                            e.isEndPoint = !0;
                            var l = 0 == s;
                            e.isFrom = l;
                            var v = l ? xY[gP][Wu] : xY[gP].EDGE_TO_OFFSET,
                            b = i[cu](this[FR], v) || {};
                            e[dN] = [b.x || 0, b.y || 0]
                        }
                        return this._75(t, f) && (e.isControlPoint = !0, s > 0 && (e[lN] = r instanceof hz ? r[Hd](s - 1) : r[s - 1]), a > s + 1 && (e[vN] = r instanceof hz ? r[Hd](s + 1) : r[s + 1], e.nextSegment[ba] && (e[bN] = e[vN].points[Hh](0)))),
                        !1
                    }
                    f += 2
                }
            },
            this),
            e
        },
        _75: function(t, i) {
            return i == t[ba][Fh] - 2
        },
        startdrag: function(t, i) {
            if (this[FR] && this[eN] && (this._9j = this._g7(t, i), this._9j)) {
                this._77(),
                t[rD] = !0;
                var n = new jh(i, jh[gN], t, this.element);
                n[yN] = this._9j,
                i.onInteractionEvent(n)
            }
        },
        onkeyup: function(t, i) {
            this[uN] && 16 != !t[Np] && this[FR] && this._9j && this._9j[xN] && this._di(this._9j.delta.x, this._9j[xN].y, i, t, !1)
        },
        onkeydown: function(t, i) {
            this[uN] && this.element && this._9j && t.shiftKey && this._9j[xN] && this._di(this._9j.delta.x, this._9j.delta.y, i, t, !0)
        },
        _di: function(t, i, n, e, s) {
            var h = this._9j,
            r = this.element,
            a = h[dN],
            o = h.segment;
            if (h.isEndPoint) {
                var f = h[mN] ? xY[gP].EDGE_FROM_OFFSET: xY[gP][qu],
                c = {
                    x: a[0] + t,
                    y: a[1] + i
                };
                return void r[dT](f, c)
            }
            if (s && h.isControlPoint) {
                var u = {
                    x: a[a[Fh] - 2] + t,
                    y: a[a[Fh] - 1] + i
                },
                _ = h[lN],
                d = h[vN],
                l = 20 / n[p_],
                v = Number.MAX_VALUE,
                b = v,
                g = v,
                y = v;
                _ && (_ = _[oo], v = Math.abs(u.x - _.x), g = Math.abs(u.y - _.y)),
                d && (d = d.lastPoint, b = Math.abs(u.x - d.x), y = Math.abs(u.y - d.y)),
                l > v && b > v ? t += _.x - u.x: l > b && v > b && (t += d.x - u.x),
                l > g && y > g ? i += _.y - u.y: l > y && g > y && (i += d.y - u.y)
            }
            if (h[aN] && Th(o)) {
                for (var x = o[ba][Fh] - 4; x < o[ba][Fh];) {
                    var m = a[x] + t,
                    E = a[x + 1] + i;
                    o.points[x] = m,
                    o.points[x + 1] = E,
                    x += 2
                }
                if (h[vN] && Th(h.nextSegment)) {
                    var p = h.oldNextPoints,
                    m = p[0] + t,
                    E = p[1] + i;
                    h[vN][ba][0] = m,
                    h.nextSegment[ba][1] = E
                }
            } else {
                var x = h[EN],
                m = a[x] + t,
                E = a[x + 1] + i;
                o[ba][x] = m,
                o[ba][x + 1] = E
            }
            r.firePathChange();
            var w = new jh(n, jh[pN], e, r);
            w.point = h,
            n[lP](w)
        },
        ondrag: function(t, i) {
            if (this[FR] && this._9j) {
                var n = this._9j,
                e = this[FR],
                s = t[wN],
                h = t[yg],
                r = i[p_];
                if (s /= r, h /= r, e.rotate) {
                    var a = {
                        x: s,
                        y: h
                    };
                    Ns(a, -e[uo]),
                    s = a.x,
                    h = a.y
                }
                n[xN] = {
                    x: s,
                    y: h
                },
                this._di(s, h, i, t, t.shiftKey)
            }
        },
        enddrag: function(t, i) {
            if (this[FR] && this._9j) {
                this[fN](),
                this._jc();
                var n = new jh(i, jh.POINT_MOVE_END, t, this[FR]);
                n[yN] = this._9j,
                i[lP](n)
            }
        },
        onmousemove: function(t, i) {
            this[FR] && (i.cursor = t.altKey && (this._g7(t, i) || this[FR] == t[eg]()) ? "crosshair": null)
        }
    },
    sz[TN] = 1,
    sz[ON] = V(3724541951),
    sz.SELECTION_RECTANGLE_FILL_COLOR = V(1430753245);
    var rW = function(t) {
        this[zu] = t,
        this[z_] = t._84[PT]
    };
    rW[Jh] = {
        onstart: function(t, i) {
            this._l5 && this[dg](i)
        },
        startdrag: function(t, i) {
            t.responded || (t.responded = !0, this._l5 = i.toLogical(t), i.cursor = jg, this._$xId = this[z_][YR](this._$x, this).id)
        },
        ondrag: function(t, i) {
            if (this._l5) {
                z(t),
                this[IN] = i[hD](t),
                this[Yw]();
                var n = new jh(i, jh[MN], t, i[N_]);
                i.onInteractionEvent(n)
            }
        },
        enddrag: function(t, i) {
            if (this._l5) {
                this[AN] && (clearTimeout(this[AN]), this[AN] = null),
                this._fv(!0),
                this.destroy(i);
                var n = new jh(i, jh[jN], t, i[N_]);
                i.onInteractionEvent(n)
            }
        },
        onpinch: function(t, i) {
            this._l5 && this.enddrag(t, i)
        },
        _$x: function(t, i) {
            t[O_] = sz.SELECTION_RECTANGLE_STROKE_COLOR,
            t[kx] = sz.SELECTION_RECTANGLE_FILL_COLOR,
            t[jf] = sz[TN] / i;
            var n = this._l5.x,
            e = this._l5.y;
            t[vc](n, e, this._end.x - n, this._end.y - e),
            t[ro](),
            t[ho]()
        },
        invalidate: function() {
            return this[GP] ? void this[z_][Yw]() : (this[GP] = !0, void(this[AN] = setTimeout(this._fv.bind(this), 100)))
        },
        _fv: function(t) {
            if (this[GP] = !1, this[AN] = null, !this._l5 || WF && !t) return void this[z_].invalidate();
            var i = Math.min(this._l5.x, this[IN].x),
            n = Math.min(this._l5.y, this[IN].y),
            e = Math.abs(this._l5.x - this[IN].x),
            s = Math.abs(this._l5.y - this[IN].y);
            if (!e || !s) return void this.graph[N_][wf]();
            var h, r = [],
            a = this.graph.scale;
            if (this.graph[SN](function(t) {
                t._i5 && this.graph[G_](t[Mf]) && (h = t._fr, (ai(i, n, e, s, h.x + t._x, h.y + t._y, h[Sa], h[Ca]) || jn(i, n, e, s, t, a)) && r[Xh](t[Mf]))
            },
            this), this.graph.selectionModel.set(r), this.topCanvas.invalidate(), !t) {
                var o = new jh(this[zu], jh.SELECT_BETWEEN, null, this[zu][N_]);
                this[zu][lP](o)
            }
        },
        destroy: function(t) {
            this._l5 = null,
            t[MP] = null,
            this._$xId && (this.topCanvas.removeDrawable(this._$xId), delete this._$xId, this.topCanvas.invalidate())
        }
    };
    var aW = A({
        "super": rW,
        onstart: null,
        startdrag: null,
        ondrag: null,
        enddrag: null,
        accept: function(t, i, n) {
            return n[CN] !== !1
        },
        oncontextmenu: function(t, i) {
            i[kN] || z(t)
        },
        onstart2: function() {
            rW[Jh].onstart[Zh](this, arguments)
        },
        startdrag2: function(t, i) {
            t[rD] || (i[kN] && i[kN][LN] instanceof Function && i.popupmenu[LN](), rW[Jh][Xb][Zh](this, arguments))
        },
        ondrag2: function() {
            rW[Jh][Zb][Zh](this, arguments)
        },
        enddrag2: function() {
            rW.prototype[tg][Zh](this, arguments)
        }
    }),
    tW = Math.PI / 4;
    Oh[Jh] = {
        _f5: !1,
        _f6: !1,
        _1g: function(t) {
            this.element && t.source == this[FR] && this[zu].callLater(function() {
                this._9q()
            },
            this)
        },
        _5: function() {
            this[tN] || (this[tN] = !0, this[zu].dataPropertyChangeDispatcher[gv](this._1g, this))
        },
        _4: function() {
            this[tN] = !1,
            this[zu][iN][Xl](this._1g, this)
        },
        onElementRemoved: function(t, i) {
            this[FR] && (t == this[FR] || $(t) && m(t, this[FR])) && this[dg](i)
        },
        onClear: function(t) {
            this[FR] && this.destroy(t)
        },
        ondblclick: function(t, i) {
            this[FR] && this[dg](i)
        },
        destroy: function(t) {
            t[MP] = null,
            delete this[FR],
            delete this._d6,
            delete this[VC],
            delete this._9j,
            delete this._nhanEdit,
            delete this._k7,
            delete this[PN],
            delete this._f6,
            delete this._f5,
            delete this[RN],
            this._77(),
            this._4()
        },
        _77: function() {
            this[zR] && (this[z_][sN](this._g8Id), delete this[zR], this.topCanvas[Yw]())
        },
        _nem: function() {
            this[zR] && this[z_].contains(this._g8Id) || (this[zR] = this[z_][YR](this._g8, this).id, this[z_][Yw]())
        },
        _d6: null,
        _k7: null,
        _7x: function(t) {
            this._d6 = t;
            var i = this._d6.x,
            n = this._d6.y,
            e = this._d6.width,
            s = this._d6[Ca];
            if (this.element instanceof AU && this[FR].expanded, this._f6) {
                var h = [];
                h[Xh]({
                    x: i,
                    y: n,
                    p: lz[vl],
                    cursor: DN,
                    rotate: 5 * tW
                }),
                h[Xh]({
                    x: i + e / 2,
                    y: n,
                    p: lz[gl],
                    cursor: NN,
                    rotate: 6 * tW
                }),
                h[Xh]({
                    x: i + e,
                    y: n,
                    p: lz.RIGHT_TOP,
                    cursor: ad,
                    rotate: 7 * tW
                }),
                h[Xh]({
                    x: i,
                    y: n + s / 2,
                    p: lz[wl],
                    cursor: BN,
                    rotate: 4 * tW
                }),
                h[Xh]({
                    x: i,
                    y: n + s,
                    p: lz.LEFT_BOTTOM,
                    cursor: ad,
                    rotate: 3 * tW
                }),
                h[Xh]({
                    x: i + e,
                    y: n + s / 2,
                    p: lz.RIGHT_MIDDLE,
                    cursor: BN,
                    rotate: 0
                }),
                h.push({
                    x: i + e / 2,
                    y: n + s,
                    p: lz.CENTER_BOTTOM,
                    cursor: NN,
                    rotate: 2 * tW
                }),
                h[Xh]({
                    x: i + e,
                    y: n + s,
                    p: lz[pl],
                    cursor: DN,
                    rotate: tW
                }),
                this._k7 = h
            }
            this[PN] = this._f5 ? {
                x: i + e / 2,
                y: n,
                cursor: cY
            }: null,
            this[Hw]()
        },
        _ff: function(t, i, n, e) {
            t[Cm]();
            var s = (this[hd] - 1) / e;
            t[vc](i - s, n - s, 2 * s, 2 * s),
            t[jf] = 1 / e,
            t[Lf] = [],
            t[O_] = A_,
            t[kx] = "rgba(255, 255, 255, 0.8)",
            t[ho](),
            t[ro]()
        },
        _5r: function(t, i, n, e, s, h) {
            s = s || this[hd],
            h = h || $N,
            t[Cm](),
            s /= e,
            t.arc(i, n, s, 0, 2 * Math.PI, !1),
            t.lineWidth = 1 / e,
            t.lineDash = [],
            t[O_] = A_,
            t[kx] = h,
            t[ho](),
            t[ro]()
        },
        _i3: function(t, i) {
            t -= this[FR].x,
            i -= this[FR].y;
            var n = {
                x: t,
                y: i
            };
            return this[FR].rotate && Ns(n, -this[FR].rotate),
            n
        },
        _g8: function(t, i) {
            if (this._d6) {
                if (t.save(), t[Ux](this[FR].x, this[FR].y), this.element.rotate && t[uo](this[FR].rotate), this._rotatePoint) {
                    this._5r(t, 0, 0, i, 3, GN);
                    var n = this[PN].x,
                    e = this._rotatePoint.y - this._rotateHandleLength / i;
                    t[Cm](),
                    t.moveTo(n, this[PN].y),
                    t[Rc](n, e),
                    t.lineWidth = 1 / i,
                    t[O_] = oN,
                    t[ho](),
                    this._5r(t, n, e, i)
                }
                if (this._k7) {
                    var s = this._d6.x,
                    h = this._d6.y,
                    r = this._d6[Sa],
                    a = this._d6[Ca];
                    t.beginPath(),
                    t.rect(s, h, r, a),
                    t.lineWidth = 1 / i,
                    t[Lf] = [2 / i, 3 / i],
                    t.strokeStyle = oN,
                    t[ho](),
                    l(this._k7,
                    function(n) {
                        this._ff(t, n.x, n.y, i)
                    },
                    this)
                }
                t.restore()
            }
        },
        _nhf: function() {
            this.topCanvas[Yw]()
        },
        _3k: function(t, i, n, e) {
            this[FR] = t,
            this[fN]();
            var s = i[Yu](t);
            this[VC] = s.body,
            this._f6 = n,
            this._f5 = e,
            this._9q(),
            this._5()
        },
        _9q: function() {
            if (this[zR]) {
                var t = Ih(this[VC], this._ngody._ji),
                i = Ih(this._ngody, this[VC]._7w);
                this[RN] = new dz(t.y - i.y, t.x - i.x, i[Fr] - t[Fr], i.right - t[Gr]),
                this._7x(i)
            }
        },
        _ngo: function(t, i) {
            return i[_N](t)
        },
        _ngj: function(t, i) {
            return (!t._i0() || !t[nO]) && i[FN](t)
        },
        _db: function(t, i) {
            return t instanceof OU && i[SD](t)
        },
        onstart: function(t, i) {
            if (!i[jD]) return void(this[FR] && this[dg](i));
            if (!t.responded) {
                var n = i[Yu](t),
                e = t[eg]();
                if (e != this.element) {
                    if (this[FR]) {
                        if (this._g7(t, i)) return void(t[rD] = !0);
                        this[dg](i)
                    }
                    if (e && !e[nN] && this._db(e, i)) {
                        var s = this[zN](e, i, n),
                        h = this[YN](e, i, n); (s || h) && this._3k(e, i, s, h)
                    }
                }
            }
        },
        onrelease: function(t, i) {
            this[FR] && (this[eN] = !0, this[fN](), i.callLater(function() {
                this._9q()
            },
            this))
        },
        _9j: null,
        _g7: function(t, i) {
            var n = i[hD](t);
            n = this._i3(n.x, n.y);
            var e = i[p_],
            s = this[hd] / e;
            if (this[PN]) {
                var h = this[PN].x,
                r = this[PN].y - this[rd] / e;
                if (fz(n.x, n.y, h, r) < s) return this[PN]
            }
            if (this._k7 && this._k7[Fh]) {
                var a;
                return l(this._k7,
                function(t) {
                    return fz(n.x, n.y, t.x, t.y) < s ? (a = t, !1) : void 0
                },
                this),
                a
            }
        },
        onmousemove: function(t, i) {
            if (this.element) {
                var n = this._g7(t, i);
                if (!n) return void(i[MP] = null);
                if (n != this[PN] && this.element[uo]) {
                    var e = n[uo] + this[FR][uo];
                    return void(i.cursor = Mh(e))
                }
                i[MP] = n[MP]
            }
        },
        startdrag: function(t, i) {
            if (this[FR] && (this._77(), this._nhanEdit && (this._9j = this._g7(t, i), this._9j))) {
                if (t.responded = !0, this._9j == this[PN]) return this._9j[tD] = i[hD](t),
                void(this._9j[uo] = this.element[uo] || 0);
                var n = new jh(i, jh.RESIZE_START, t, this[FR]);
                n[yN] = this._9j,
                i[lP](n)
            }
        },
        _7a: function(t, i, n, e, s, h) {
            var r = this._d6,
            a = r.x,
            o = r.y,
            f = r[Sa],
            c = r[Ca];
            if (h) {
                var u = e != f;
                u ? s = e * c / f: e = s * f / c
            }
            var _ = t[XO]._fx,
            d = e / f,
            l = s / c,
            v = -a * d + i,
            b = -o * l + n;
            _[Wf](function(t) {
                if (t[fo] != mY[gm]) {
                    var e = t[ba];
                    if (e && e[Fh]) for (var s = 0,
                    h = e[Fh]; h > s; s += 2) {
                        var r = e[s],
                        f = e[s + 1];
                        e[s] = (r - a) * d + i - v,
                        e[s + 1] = (f - o) * l + n - b
                    }
                }
            }),
            this._d6.set(i - v, n - b, e, s),
            t[rP](t.x + v, t.y + b),
            t.firePathChange()
        },
        _9p: function(t, i, n, e, s) {
            this._d6.set(i, n, e, s),
            t[rI] = {
                x: i,
                y: n,
                width: e,
                height: s
            }
        },
        _4j: function(t, i, n, e, s) {
            if (this.element instanceof AU) return this._9p(this[FR], t, i, n, e, s);
            if (this[FR] instanceof IU) return this._7a(this[FR], t, i, n, e, s);
            var h = this[VC] instanceof HU;
            if (!h && s) {
                var r = this._d6,
                a = this[VC][HN],
                o = n != r[Sa];
                o ? e = n * a[Ca] / a[Sa] : n = e * a[Sa] / a[Ca]
            }
            var f = this[FR][UO],
            c = new uz(n - this[RN][Co] - this._insets.right, e - this[RN].top - this[RN][Fr]);
            if (c[Sa] < 1 && (n = this._insets[Co] + this[RN].right + 1, c[Sa] = 1), c[Ca] < 1 && (e = this._insets.top + this[RN][Fr] + 1, c[Ca] = 1), h ? this.element[dT](CU[IA], c) : this[FR][Uw] = c, f) {
                var u = fi(f, n, e),
                _ = u.x + t - (this[VC].offsetX || 0),
                d = u.y + i - (this[VC][mI] || 0);
                if (this._d6.set(t - _, i - d, n, e), this.element[uo]) {
                    var u = Ns({
                        x: _,
                        y: d
                    },
                    this.element.rotate);
                    _ = u.x,
                    d = u.y
                }
                this[FR].x += _,
                this[FR].y += d
            } else {
                var _ = this._d6.x * n / this._d6[Sa] - t,
                d = this._d6.y * e / this._d6[Ca] - i;
                if (this._d6.set(t + _, i + d, n, e), this[FR].rotate) {
                    var u = Ns({
                        x: _,
                        y: d
                    },
                    this.element[uo]);
                    _ = u.x,
                    d = u.y
                }
                this[FR].x -= _,
                this[FR].y -= d
            }
        },
        ondrag: function(t, i) {
            if (this[FR] && this._9j) if (this._9j != this[PN]) {
                var n = t.dx,
                e = t.dy,
                s = i[p_];
                if (n /= s, e /= s, this.element[uo]) {
                    var h = {
                        x: n,
                        y: e
                    };
                    Ns(h, -this.element[uo]),
                    n = h.x,
                    e = h.y
                }
                var r = this._9j.p,
                a = this._d6,
                o = a.x,
                f = a.y,
                c = a.width,
                u = a[Ca];
                r.horizontalPosition == vz ? n >= c ? (o += c, c = n - c || 1) : (o += n, c -= n) : r.horizontalPosition == gz && ( - n >= c ? (c = -n - c || 1, o -= c) : c += n),
                r[Hr] == yz ? e >= u ? (f += u, u = e - u || 1) : (f += e, u -= e) : r.verticalPosition == mz && ( - e >= u ? (u = -e - u || 1, f -= u) : u += e),
                this._4j(o, f, c, u, t[Dp]);
                var _ = new jh(i, jh[UN], t, this.element);
                _[yN] = this._9j,
                i[lP](_)
            } else {
                var h = i.toLogical(t),
                d = cn(h.x, h.y, this[FR].x, this[FR].y, this._9j[tD].x, this._9j.start.y, !0);
                d += this._9j[uo] || 0,
                t.shiftKey && (d = Math[eo](d / Math.PI * 4) * Math.PI / 4),
                this[FR][uo] = d % (2 * Math.PI);
                var _ = new jh(i, jh[WN], t, this.element)
            }
        },
        enddrag: function(t, i) {
            if (this[FR] && this._9j && this._9j != this[PN]) {
                var n = new jh(i, jh[qN], t, this[FR]);
                n[yN] = this._9j,
                i[lP](n)
            }
        }
    },
    xY[XN] = Oh;
    var oW = function(t) {
        this[zu] = t
    };
    oW[Jh] = {
        onmousedown: function(t, i) {
            nz || i[eP](!HF)
        },
        onstart: function(t, i) {
            if (!t[rD]) {
                var n = t[eg]();
                if (n && !i.isSelectable(n) && (n = null), n && mi(t)) {
                    i[VN](n);
                    var e = new jh(i, jh.SELECT, t, i[N_]);
                    return void i.onInteractionEvent(e)
                }
                if (!n || !i[N_][KN](n)) {
                    n ? (i.setSelection(n), i[ZN](n)) : i[JN](null);
                    var e = new jh(i, jh[QN], t, i[N_]);
                    i.onInteractionEvent(e)
                }
            }
        },
        onkeydown: function(t, i) {
            return 27 == t[Np] ? void i[hP]() : void(mi(t) && 65 == t[Np] && (i[tB](), G(t)))
        }
    };
    var fW = 0,
    cW = 15;
    sz[iB] = 3e3,
    sz[nB] = 1e3;
    var uW = eB;
    gi(Dr + uW, {
        "background-color": sB,
        overflow: u_,
        "box-shadow": "0 5px 10px rgba(136, 136, 136, 0.5)",
        color: Bx,
        "pointer-events": __,
        border: hB,
        padding: rB,
        display: UP,
        position: Lw
    });
    var _W = function(t) {
        this.graph = t,
        this._nef = {}
    };
    _W.prototype = {
        _nef: null,
        _ned: null,
        _nea: function() {
            delete this[aB],
            this._nef[ao] && (this._ned || (this[oB] = i.createElement(i_), this[oB].className = uW), this[oB][gx] || i[px].appendChild(this[oB]), this._d2(this[zu], this[fB][ao]))
        },
        _d2: function(t, i) {
            var n = t.getTooltip(i),
            e = id == i[cB];
            n && !e && (n = n[Xr](/\n/g, uB)),
            e ? this._ned[_B] = n || "": this[oB].innerHTML = n || "";
            var s = this[fB].evt[fa] + fW,
            h = this[fB].evt[ca] + cW;
            Ah(this._ned, s, h),
            this[dB] && (clearTimeout(this[dB]), delete this._deleteTimer),
            this[dB] = setTimeout(this._8a.bind(this), t.tooltipDuration || sz[iB])
        },
        _8a: function() {
            delete this._deleteTimer,
            this._ned && this._ned.parentNode && this[oB][gx][Ox](this[oB]),
            delete this[oB],
            this._nef = {}
        },
        _f2: function(t, i, n, e) {
            if (!this[oB]) {
                var s = e[lB];
                return isNaN(s) && (s = sz.TOOLTIP_DELAY),
                void(this._initTimer = setTimeout(this[vB][fr](this), s))
            }
            this._d2(e, t)
        },
        onstart: function(t, i) {
            this.destroy(i)
        },
        onmousemove: function(t, i) {
            if (i.enableTooltip) {
                var n = t[eg]();
                if (this[fB].evt = t, this[fB][ao] != n && (this[fB][ao] = n, this._initTimer && (clearTimeout(this[aB]), delete this[aB]), n)) {
                    var e = i[bB](n);
                    e && this._f2(n, e, t, i)
                }
            }
        },
        destroy: function() {
            this._initTimer && (clearTimeout(this[aB]), delete this[aB]),
            this[dB] && (clearTimeout(this[dB]), delete this[dB]),
            this[oB] && this._8a(),
            this[fB] = {}
        }
    };
    var dW = function(t) {
        this[zu] = t
    };
    dW.prototype = {
        _fv: function() {
            delete this._ld
        },
        destroy: function(t) {
            this._ld && this._fv(t)
        },
        onmousewheel: function(t, i) {
            if (i[gB] !== !1 && t.delta) {
                var n = t.delta > 0,
                e = i[p_];
                if (! (n && i[Xx] - e < 1e-4 || !n && e - i[qL] < 1e-4)) {
                    z(t);
                    var s = Math[Ka](Math.abs(t.delta));
                    n || (s = -s),
                    this._ld && clearTimeout(this._ld),
                    this._ld = setTimeout(this._fv[fr](this, i), 100),
                    i[yB](t, s)
                }
            }
        }
    };
    var lW = function(t) {
        this.graph = t
    };
    lW.prototype = {
        onclick: function(t, i) {
            i[yB](t, !mi(t))
        }
    };
    var vW = function(t) {
        this.graph = t
    };
    vW[Jh] = {
        onclick: function(t, i) {
            i.zoomByMouseEvent(t, mi(t))
        }
    },
    p(jh, wz),
    jh[UD] = xB,
    jh[qD] = mB,
    jh[KD] = EB,
    jh[DL] = pB,
    jh[dP] = wB,
    jh[gN] = TB,
    jh.POINT_MOVING = OB,
    jh.POINT_MOVE_END = IB,
    jh.RESIZE_START = MB,
    jh[UN] = AB,
    jh.RESIZE_END = jB,
    jh.ROTATING = SB,
    jh[CB] = kB,
    jh[JD] = LB,
    jh[QD] = PB,
    jh.GROUP_EXPANDED = RB,
    jh[DB] = NB,
    jh[QN] = ed,
    jh[MN] = BB,
    jh[$B] = GB,
    jh[jN] = FB,
    jh.LONG_CLICK = zB,
    Sh[Jh] = {
        _97: function(t) {
            if (this[YB]) switch (t.kind) {
            case Lz.KIND_REMOVE:
                this[YB]._onElementRemoved(t[ao]);
                break;
            case Lz[bL]:
                this[YB][HB](t[ao])
            }
        },
        destroy: function() {
            delete this._kt,
            delete this._50,
            this[YB] && (this._interactionSupport._ii(), delete this[YB])
        },
        _kt: null,
        _50: null,
        defaultMode: null,
        _h2: function(t, i, n) {
            this._50[t] = new ch(i, n),
            t == this[_d] && this._interactionSupport[UB](i)
        },
        addCustomInteraction: function(t) {
            this._interactionSupport[WB](t)
        },
        removeCustomInteraction: function(t) {
            this._interactionSupport[qB](t)
        },
        _n8: function(t) {
            var i = this._50[t];
            return i ? i: bW[t]
        }
    },
    Z(Sh[Jh], {
        defaultCursor: {
            get: function() {
                return this.currentInteractionMode ? this[XB][H_] : void 0
            }
        },
        currentMode: {
            get: function() {
                return this[AP]
            },
            set: function(t) {
                this._nhurrentMode != t && (this[AP], this._interactionSupport || (this[YB] = new hY(this._kt)), this._nhurrentMode = t, this[XB] = this._n8(this[AP]), this._kt.cursor = this[H_], this[YB][UB](this.currentInteractionMode ? this.currentInteractionMode[VB](this._kt) : []))
            }
        }
    });
    var bW = {};
    sz.registerInteractions = function(t, i, n) {
        var e = new ch(i, n);
        bW[t] = e
    },
    mY[KB] = ZB,
    mY[dd] = U_,
    mY[JB] = Q_,
    mY[QB] = t$,
    mY.INTERACTION_MODE_ZOOMOUT = i$,
    mY.INTERACTION_MODE_CREATE_SIMPLE_EDGE = n$,
    mY.INTERACTION_MODE_CREATE_EDGE = e$,
    mY[s$] = h$,
    mY[r$] = a$,
    sz.registerInteractions(mY[KB], [oW, hW, dW, eW, iW, _W, aW]),
    sz[o$](mY[f$], [nW, bh, oW, hW, dW, eW, _W]),
    sz[o$](mY[c$], [nW, dh, oW, hW, dW, eW, _W]),
    sz[o$](mY[s$], [nW, lh, oW, hW, dW, eW, _W]),
    sz.registerInteractions(mY.INTERACTION_MODE_CREATE_LINE, [vh, oW, hW, dW, eW, _W]),
    sz[o$](mY.INTERACTION_MODE_DEFAULT, [nW, Oh, wh, oW, sW, hW, dW, eW, iW, _W, aW]),
    sz[o$](mY[JB], [nW, Oh, wh, oW, sW, rW, hW, dW, eW, iW, _W]),
    sz[o$](mY[QB], [dW, eW, lW], rY),
    sz[o$](mY.INTERACTION_MODE_ZOOMOUT, [dW, eW, vW], aY),
    xY[u$] = hW,
    xY.SelectionInteraction = oW,
    xY.MoveInteraction = sW,
    xY[_$] = dW,
    xY.DoubleClickInteraction = iW,
    xY.ExportInteraction = eW,
    xY.TooltipInteraction = _W,
    xY[d$] = rW,
    xY.RectangleSelectionInteractionByRightButton = aW,
    xY[l$] = wh;
    var gW = function(t) {
        this[zu] = t
    };
    xY[v$] = gW,
    gW[Jh] = {
        getNodeBounds: function(t) {
            return this.graph[b$](t)
        },
        isLayoutable: function(t) {
            return this[zu][$_](t) && t[g$] !== !1
        },
        getLayoutResult: function() {},
        updateLocations: function(t, i, n, e, s) {
            if (i === !0) {
                if (this[y$] || (this[y$] = new ZW), n && (this[y$][x$] = n), e && (this[y$][PR] = e), this.animate[m$] = t, s) {
                    var h = s,
                    r = this;
                    s = function() {
                        h.call(r, t)
                    }
                }
                return void this.animate.start(s)
            }
            for (var a in t) {
                var o = t[a],
                f = o[E$];
                f[rP](o.x, o.y)
            }
            s && s[zh](this, t)
        },
        _ft: function(t) {
            var i, n, e, s = null;
            t && (i = t[p$], s = t[ou], n = t.duration, e = t.animationType);
            var h = this[w$](t);
            return h ? (this[T$](h, i, n, e, s), h) : !1
        },
        doLayout: function(t, i) {
            return this.graph && i !== !0 ? void this[zu].callLater(function() {
                this._ft(t)
            },
            this) : this._ft(t)
        }
    };
    var yW = 110,
    xW = 120,
    mW = 130,
    EW = 210,
    pW = 220,
    wW = 230,
    TW = 111,
    OW = 112,
    IW = 121,
    MW = 122,
    AW = 211,
    jW = 212,
    SW = 221,
    CW = 222;
    mY[O$] = yW,
    mY.DIRECTION_LEFT = xW,
    mY[I$] = mW,
    mY[M$] = EW,
    mY.DIRECTION_TOP = pW,
    mY[A$] = wW,
    mY[j$] = TW,
    mY[S$] = OW,
    mY.DIRECTION_LEFT_TOP = IW,
    mY.DIRECTION_LEFT_BOTTOM = MW,
    mY.DIRECTION_BOTTOM_LEFT = AW,
    mY.DIRECTION_BOTTOM_RIGHT = jW,
    mY.DIRECTION_TOP_LEFT = SW,
    mY[C$] = CW;
    var kW = k$,
    LW = L$,
    PW = P$,
    RW = R$;
    mY.LAYOUT_TYPE_EVEN = kW,
    mY[D$] = PW,
    mY[N$] = RW,
    mY[B$] = LW,
    xY[$$] = Ch;
    var DW = function(t) {
        this[zu] = t
    };
    DW[Jh] = {
        hGap: 50,
        vGap: 50,
        parentChildrenDirection: EW,
        layoutType: kW,
        defaultSize: {
            width: 50,
            height: 60
        },
        getNodeSize: function(t) {
            if (this[zu]._84[nu]) {
                var i = this[zu][Yu](t);
                if (i) return i._fr
            }
            return t[Vx] && t.image.bounds ? {
                width: t[Vx][no][Sa],
                height: t.image[no][Ca]
            }: this[G$]
        },
        _da: function(t, i) {
            if (this.isLayoutable(t)) {
                var n, e = this[F$](t);
                n = e instanceof _z ? [ - e.x, -e.y] : [e[Sa] / 2, e[Ca] / 2];
                var s = t.id,
                h = (t.parentChildrenDirection, i ? this._8y[i.id] : this._nej);
                this._8y[s] = new NW(this[z$](t), this.getVGap(t), this[Y$](t), t[H$], h, t, e[Sa], e.height, n)
            }
        },
        getHGap: function(t) {
            return t && D(t[U$]) ? t.hGap: this.hGap
        },
        getVGap: function(t) {
            return t && D(t[W$]) ? t.vGap: this[W$]
        },
        getLayoutType: function(t) {
            return t && t[q$] ? t[q$] : this.layoutType
        },
        _8y: null,
        _nej: null,
        _l3: function() {
            this._8y = null,
            this[X$] = null
        },
        getLayoutResult: function(t) {
            var i, n, e, s, h = this.graph;
            t instanceof Object && (i = t.x, n = t.y, h = t[V$] || this[zu], e = t[no], s = t[K$]),
            this._8y = {},
            this[X$] = new NW,
            this._nej._mz(this[U$], this[W$], this.parentChildrenDirection, this[q$]);
            var r = {},
            a = tq(h, this._da, this, !1, s);
            return a && (this[X$]._ft(i || 0, n || 0, r), e && e.set(this[X$].x, this[X$].y, this[X$][Sa], this[X$].height)),
            this._l3(),
            r
        },
        doLayout: function(t, i) {
            if (D(t)) {
                var n = t,
                e = 0;
                D(i) && (e = i),
                t = {
                    x: n,
                    y: e
                },
                i = !0
            }
            return T(this, DW, Z$, [t, i])
        }
    },
    p(DW, gW);
    var NW = function(t, i, n, e, s, h, r, a, o) {
        this._mp = t || 0,
        this._mq = i || 0,
        this.layoutType = n,
        this[H$] = e,
        this[J$] = s,
        s && s._g6(this),
        this[E$] = h,
        this._fj = r,
        this._dn = a,
        this[Q$] = o
    };
    NW[Jh] = {
        _mz: function(t, i, n, e) {
            this._mp = t,
            this._mq = i,
            this[H$] = n,
            this.layoutType = e
        },
        _81: function() {
            this._g2 = []
        },
        _mp: 0,
        _mq: 0,
        _g2: null,
        _fj: 0,
        _dn: 0,
        layoutType: null,
        parentChildrenDirection: null,
        _g6: function(t) {
            this._g2 || (this._g2 = []),
            this._g2[Xh](t)
        },
        _dk: function(t, i, n, e) {
            var s = new _z;
            return n(this._g2,
            function(n) {
                n._3q(t, i),
                s.add(n),
                e ? t += n[Sa] + this._mp: i += n.height + this._mq
            },
            this),
            s
        },
        _7z: function(t, i, n, e, s) {
            var h, r = e ? this._mp: this._mq,
            a = e ? this._mq: this._mp,
            o = e ? "width": Ca,
            f = e ? "height": Sa,
            c = e ? "_fj": tG,
            u = e ? "_dn": iG,
            _ = e ? "hostDX": nG,
            d = e ? "hostDY": eG,
            v = new _z,
            b = 0,
            g = 0,
            y = [],
            x = 0,
            m = 0;
            n(this._g2,
            function(n) {
                var s = m >= g;
                n[sG] = s ? e ? xW: pW: e ? yW: EW,
                n._3q(t, i),
                s ? (y[Xh](n), b = Math.max(b, n[o]), g += n[f] + a) : (h || (h = []), h[Xh](n), x = Math.max(x, n[o]), m += n[f] + a)
            },
            this),
            g -= a,
            m -= a;
            var E = Math.max(g, m),
            p = r,
            w = 0;
            this.node && (s && (p += this[c] + r, E > this[u] ? this[d] = (E - this[u]) / 2 : w = (this[u] - E) / 2), this[_] = b + p / 2 - this[c] / 2);
            var T = 0,
            O = w;
            return l(y,
            function(t) {
                e ? t[NI](b - t[o], O) : t.offset(O, b - t[o]),
                O += a + t[f],
                v.add(t)
            },
            this),
            h ? (O = w, T = b + p, l(h,
            function(t) {
                e ? t[NI](T, O) : t[NI](O, T),
                O += a + t[f],
                v.add(t)
            },
            this), v) : v
        },
        offset: function(t, i) {
            this.x += t,
            this.y += i,
            this[hG] += t,
            this[rG] += i,
            this._7j(t, i)
        },
        _ngf: function(t, i) {
            return 2 * this.cx - t - i - t
        },
        _ngl: function(t, i) {
            return 2 * this.cy - t - i - t
        },
        _mr: function(t) {
            if (this._g2 && 0 != this._g2[Fh]) {
                if (t) return this[E$] && (this[hG] += this._ngf(this.nodeX, this._fj)),
                void l(this._g2,
                function(t) {
                    t[NI](this._ngf(t.x, t.width), 0)
                },
                this);
                this[E$] && (this[rG] += this._ngl(this.nodeY, this._dn)),
                l(this._g2,
                function(t) {
                    t[NI](0, this[aG](t.y, t.height))
                },
                this)
            }
        },
        _7j: function(t, i) {
            this._g2 && l(this._g2,
            function(n) {
                n[NI](t, i)
            },
            this)
        },
        _3q: function(t, i) {
            return this.x = t || 0,
            this.y = i || 0,
            this._g2 && 0 != this._g2[Fh] ? void this._1f(this.x, this.y, this[q$]) : void(this[E$] && (this.width = this._fj, this.height = this._dn, this[hG] = this.x, this[rG] = this.y))
        },
        _7g: function(t) {
            if (this[E$]) {
                var i = this[Q$],
                n = i[0],
                e = i[1];
                t[this[E$].id] = {
                    node: this[E$],
                    x: this[hG] + n,
                    y: this.nodeY + e,
                    left: this.nodeX,
                    top: this[rG],
                    width: this._fj,
                    height: this._dn
                }
            }
            this._g2 && l(this._g2,
            function(i) {
                i._7g(t)
            },
            this)
        },
        _ft: function(t, i, n) {
            this._3q(t, i),
            this._7g(n)
        },
        _1f: function(t, i, e) {
            var s, h = t,
            r = i; ! this[H$] && this.parentBounds && (this[H$] = this._inheritedParentChildrenDirection || this[J$][H$]);
            var a = this[H$],
            o = Ch(a);
            if (this[E$]) {
                s = a == mW || a == wW;
                var f = kh(a);
                s || (o ? t += this._fj + this._mp: i += this._dn + this._mq)
            }
            var c, u = this.node && this[E$][oG] ? b: l;
            if (e == LW) c = this._7z(t, i, u, !o, s);
            else {
                var _;
                _ = e == kW ? !o: e == PW,
                c = this._dk(t, i, u, _, s)
            }
            var d = 0,
            v = 0;
            if (c && !c[Sf]() && (d = c[Sa], v = c[Ca], this.add(c)), this[E$]) {
                if (this.nodeX = h, this.nodeY = r, this[eG] !== n || this[nG] !== n) this[hG] += this[eG] || 0,
                this.nodeY += this[nG] || 0;
                else {
                    var g;
                    g = a == EW || a == pW || a == xW || a == yW ? 1 : a == jW || a == CW || a == MW || a == OW ? 0 : 2,
                    o ? 1 == g ? this[rG] += v / 2 - this._dn / 2 : 2 == g && (this[rG] += v - this._dn) : 1 == g ? this[hG] += d / 2 - this._fj / 2 : 2 == g && (this.nodeX += d - this._fj)
                }
                this.addRect(this.nodeX, this[rG], this._fj, this._dn),
                f && this._mr(o)
            }
        },
        node: null,
        uiBounds: null
    },
    p(NW, _z),
    Ph[Jh] = {
        layoutDatas: null,
        isMovable: function(t) {
            return ! this[fG][t.id]
        },
        _7e: !1,
        _3n: function() {
            this._7e = !0,
            this[zu]._1d[gv](this._95, this),
            this.graph._17[gv](this._21, this)
        },
        _1j: function() {
            this._7e = !1,
            this.graph._1d[Xl](this._95, this),
            this.graph._17.removeListener(this._21, this)
        },
        invalidateFlag: !0,
        invalidateLayoutDatas: function() {
            this.invalidateFlag = !0
        },
        resetLayoutDatas: function() {
            return this.invalidateFlag = !1,
            this[cG] = Lh[zh](this)
        },
        _21: function(t) {
            jh.ELEMENT_MOVE_START == t[Ml] ? (this[fG] = {},
            t[Mv][Wf](function(t) {
                this[fG][t.id] = t
            },
            this)) : jh[KD] == t[Ml] && (this[fG] = {})
        },
        _95: function() {
            this[uG]()
        },
        isRunning: function() {
            return this[_G] && this.timer._e9()
        },
        getLayoutResult: function() {
            this[dG](),
            this.resetLayoutDatas();
            for (var t = this[lG](this[cG][vG] || 0, this.layoutDatas.edgeCount || 0), i = 0; t > i && this[VD](!1) !== !1; i++);
            var n = this[cG][bG];
            return this[gG](),
            n
        },
        _lw: function() {
            return ! 1
        },
        step: function(t) {
            if (t === !1) return this._lw(this[yG]); (this[GP] || !this[cG]) && this[xG]();
            var i = this._lw(t),
            n = this[cG].nodes;
            for (var e in n) {
                var s = n[e],
                h = s[E$];
                this[aP](h) ? h.setLocation(s.x, s.y) : (s.x = h.x, s.y = h.y, s.vx = 0, s.vy = 0)
            }
            return i
        },
        onstop: function() {
            delete this[cG]
        },
        start: function(t) {
            if (this[mG]()) return ! 1;
            this._7e || this._3n(),
            this._jvr || (this[EG] = function(t) {
                return this[VD](t)
            } [fr](this)),
            this[uG](),
            this.timer = new bY(this._jvr);
            var i = this;
            return this.timer._l5(function() {
                i[gG](),
                t && t()
            }),
            !0
        },
        stop: function() {
            this.timer && (this[_G]._mj(), this[gG]())
        },
        getMaxIterations: function(t) {
            return Math.min(1e3, 3 * t + 10)
        },
        minEnergyFunction: function(t, i) {
            return 10 + Math.pow(t + i, 1.4)
        },
        resetGraph: function() {
            this._7e || this._3n(),
            this[xG]()
        },
        destroy: function() {
            this.stop(),
            this._1j()
        }
    },
    p(Ph, gW);
    var BW = function(t, i, n, e) {
        this[zu] = t,
        D(i) && (this.radius = i),
        D(n) && (this.gap = n),
        D(e) && (this.startAngle = e)
    };
    xY[pG] = BW;
    var $W = wG,
    GW = TG,
    FW = OG,
    zW = IG;
    mY[MG] = $W,
    mY.ANGLE_SPACING_REGULAR = GW,
    mY[AG] = FW,
    mY[jG] = zW,
    BW.prototype = {
        angleSpacing: $W,
        radiusMode: zW,
        gap: 4,
        radius: 50,
        startAngle: 0,
        _8y: null,
        _nej: null,
        _l3: function() {
            this._8y = null,
            this[X$] = null
        },
        getLayoutResult: function(t) {
            var i, n = 0,
            e = 0,
            s = this[zu];
            t instanceof Object && (n = t.cx || 0, e = t.cy || 0, s = t[V$] || this.graph, i = t[no]),
            this._8y = {},
            this[X$] = new UW(this);
            var h = {},
            r = iq(s, this._da, this);
            return r && (this[X$]._g2 && 1 == this._nej._g2.length && (this[X$] = this[X$]._g2[0]), this._nej._er(!0), this[X$]._64(n, e, this[SG], h, i)),
            this._l3(),
            h
        },
        _da: function(t, i) {
            if (this.isLayoutable(t)) {
                var n = i ? this._8y[i.id] : this._nej;
                this._8y[t.id] = new UW(this, t, n)
            }
        },
        defaultSize: 40,
        getRadius: function() {
            return this[Tl]
        },
        getNodeSize: function(t) {
            if (this.graph._84[nu]) {
                var i = this[zu].getUI(t);
                if (i) return (i._fr[Sa] + i._fr.height) / 2
            }
            return this[G$]
        },
        getGap: function() {
            return this.gap
        },
        _2x: function(t, i, n) {
            return this[F$](t, i, n) + this[CG](t, i, n)
        }
    };
    var YW = function(t) {
        var i, n = this._g2.length,
        e = 0,
        s = 0;
        if (l(this._g2,
        function(t) {
            var n = t._er();
            1 > n && (n = 1),
            s += n,
            n > e && (e = n, i = t)
        },
        this), n > 1) {
            var h = 0,
            r = {},
            a = s / n / 3;
            s = 0,
            l(this._g2,
            function(t) {
                var i = t._mx;
                a > i && (i = a),
                r[t.id] = i,
                s += i
            },
            this);
            var o = gU / s;
            l(this._g2,
            function(i, n) {
                var e = r[i.id],
                s = e * o;
                0 === n && (h = t ? -s / 2 : -s),
                i._l0 = h + s / 2,
                i._l1 = s,
                h += s
            },
            this)
        }
        return [e, i._l1]
    },
    HW = function(t) {
        var i = this._8p,
        n = 2 * Math.PI / i,
        e = 0,
        s = t ? 0 : i > 1 ? -n / 2 : 0;
        return l(this._g2,
        function(t) {
            t._l0 = s % gU,
            s += n,
            t._l1 = n;
            var i = t._er();
            i > e && (e = i)
        },
        this),
        [e, n]
    },
    UW = function(t, i, n) {
        this[kG] = t,
        i && (this._mo = i, this.id = i.id),
        n && (n._g6(this), n._mt = !1, this._kz = n._kz + 1)
    },
    gU = 2 * Math.PI;
    UW.prototype = {
        _l1: 0,
        _l0: 0,
        _k9: 0,
        _ew: 0,
        _nhz: 0,
        _kz: 0,
        _mt: !0,
        _mx: 0,
        _gc: 0,
        _g2: null,
        _mo: null,
        _g6: function(t) {
            this._g2 || (this._g2 = []),
            this._g2.push(t),
            t.parent = this
        },
        _ge: function(t) {
            if (this._l0 = (this._l0 + t) % gU, this._g2) {
                var i = this._g2[Fh];
                if (1 == i) return void this._g2[0]._ge(this._l0);
                t = this._l0 + Math.PI,
                l(this._g2,
                function(i) {
                    i._ge(t)
                },
                this)
            }
        },
        _8p: 0,
        _78: function(t) {
            return this._mo && (this._gc = this[kG]._2x(this._mo, this._kz, this._mt) / 2),
            this._g2 ? (this._gc, this._8p = this._g2[Fh], this._8p <= 2 || this[kG].angleSpacing == GW ? HW.call(this, t) : YW.call(this, t)) : null
        },
        _er: function(t) {
            var i = this._78(t);
            if (!i) return this._mx = this._gc;
            var n = i[0],
            e = i[1],
            s = this[kG][LG](this._mo, this._kz);
            if (s < this._gc && (s = this._gc), this._ew = s, this._gc + n > s && (s = this._gc + n), n && this._8p > 1 && e < Math.PI) {
                var h = n / Math.sin(e / 2);
                h > s && (s = h)
            }
            return this._k9 = s,
            this._mx = s + n,
            this._mo && this._g2 && this[kG][PG] == zW && l(this._g2,
            function(t) {
                var i = t._mx;
                1 == t._8p && (i /= 2);
                var n = this._gc + i,
                e = t._l1;
                if (e && e < Math.PI) {
                    var s = Math.sin(e / 2),
                    h = i / s;
                    h > i && (i = h)
                }
                n > i && (i = n),
                t._nhz = i
            },
            this),
            (!this._mo || t) && this._ge(0),
            this._mx
        },
        _64: function(t, i, n, e, s) {
            if (this._mo && (e[this._mo.id] = {
                x: t,
                y: i,
                node: this._mo
            },
            s && s[rl](t - this._gc / 2, i - this._gc / 2, this._gc, this._gc)), this._g2) {
                if (!this._mo && 1 == this._g2[Fh]) return void this._g2[0]._64(t, i, n, e, s);
                n = n || 0;
                var h = this._k9,
                r = this._ew;
                l(this._g2,
                function(a) {
                    var o = h;
                    a[RG] && (o = Math.max(r, a._nhz));
                    var f = a._l0 + n,
                    c = t + o * Math.cos(f),
                    u = i + o * Math.sin(f);
                    a._64(c, u, n, e, s)
                },
                this)
            }
        }
    },
    p(BW, gW);
    var WW = function() {
        w(this, WW, arguments)
    };
    p(WW, Rh);
    var qW = function(t, i) {
        this.node1 = t,
        this[DG] = i,
        t == i ? (this[Sc] = !0, this._kx = t._kw) : this._kx = new hz,
        this._8g = [],
        this._gf = sz[NG]
    };
    sz[NG] = !0,
    qW.prototype = {
        node1: null,
        node2: null,
        _kx: null,
        _gf: sz.EDGE_BUNDLE_EXPANDED,
        _8g: null,
        _gg: null,
        agentEdge: null,
        _ng4: function(t, i, n) {
            this._kx[Wf](function(e) {
                return n && e.$from != n && e[Ec] != n ? void 0 : t[zh](i, e)
            })
        },
        _66: 0,
        _68: 0,
        _j0: function(t, i) {
            return this._kx.add(t) === !1 ? !1 : (i == this[BG] ? this._66++:this._68++, this[nu] ? void this._11(t) : void(this._nek = !0))
        },
        _nhr: function(t, i) {
            return this._kx[mc](t) === !1 ? !1 : (i == this.node1 ? this._66--:this._68--, this._11(t), void this._kx[Wf](function(t) {
                t[rO] = !0,
                t[KT] = !0
            },
            this))
        },
        _11: function(t) {
            this._nhfBindableFlag = !0,
            this._6h = !0,
            t[rO] = !0,
            t.__4y = !0
        },
        _nhf: function() {
            this._6h || (this._6h = !0, this._kx.forEach(function(t) {
                t[rO] = !0
            }))
        },
        isEmpty: function() {
            return this._kx.isEmpty()
        },
        isPositiveOrder: function(t) {
            return this[BG] == t[kc] || this.node1 == t.fromAgent
        },
        canBind: function(t) {
            return t && this._6h && this._fv(t),
            this._kx[Fh] > 1 && this._8g.length > 1
        },
        _is: function(t) {
            return this._8g[Vh](t)
        },
        getYOffset: function(t) {
            return this._gg[t.id]
        },
        _4n: function(t) {
            if (!this.canBind()) return void(this._gg = {});
            var i = {},
            n = this._8g[Fh];
            if (! (2 > n)) {
                var e = 0,
                s = this._8g[0];
                i[s.id] = 0;
                for (var h = 1; n > h; h++) {
                    s = this._8g[h];
                    var r = t[cu](s, CU[$G]) || WU[CU[$G]];
                    e += r,
                    i[s.id] = e
                }
                if (!this[Sc]) for (var a = e / 2,
                h = 0; n > h; h++) s = this._8g[h],
                i[s.id] -= a;
                this._gg = i
            }
        },
        _ngh: function(t) {
            return this._gf == t ? !1 : (this._gf = t, this[Hw](), !0)
        },
        reverseExpanded: function() {
            return this[GG](!this._gf)
        },
        _18: function() {
            this[FG] = !1,
            this._8g.length = 0;
            var t;
            this._kx.forEach(function(i) {
                if (i[BT]()) {
                    if (!this.isPositiveOrder(i)) return t || (t = []),
                    void t[Xh](i);
                    this._8g[Xh](i)
                }
            },
            this),
            t && (this._8g = t[co](this._8g))
        },
        _ej: function(t) {
            return t == this[TP] || !this[zG]() || this._gf
        },
        _fv: function(t) {
            this._6h = !1,
            this._kx.forEach(function(t) {
                t._edgeBundleInvalidateFlag = !1
            }),
            this[FG] && this._18();
            var i = this._gf,
            n = this.canBind(),
            e = !n || i;
            l(this._8g,
            function(t) {
                t._$l = !0,
                t[YG] = e,
                e && (t[KT] = !0)
            },
            this),
            e ? this._ne5(null, t) : (this[HG](this._8g[0], t), this.agentEdge[YG] = !0, this[TP][KT] = !0),
            e && this._4n(t)
        },
        _ne5: function(t, i) {
            if (t != this[TP]) {
                var n = this.agentEdge;
                return this[TP] = t,
                i && i._4b(new Tz(this, TP, t, n)),
                !0
            }
        }
    },
    Z(qW.prototype, {
        bindableEdges: {
            get: function() {
                return this._8g
            }
        },
        edges: {
            get: function() {
                return this._kx._jg
            }
        },
        length: {
            get: function() {
                return this._kx ? this._kx[Fh] : 1
            }
        },
        expanded: {
            get: function() {
                return this._gf
            },
            set: function(t) {
                return this._gf == t ? !1 : (this._gf = t, void this[Hw]())
            }
        }
    });
    var XW = function() {
        function t(t, i) {
            this[E$] = t,
            this.body = i
        }
        function i() {
            this[UG] = [],
            this[WG] = 0
        }
        var n = -1e6,
        e = .8;
        i[Jh] = {
            isEmpty: function() {
                return 0 === this[WG]
            },
            push: function(i, n) {
                var e = this.stack[this[WG]];
                e ? (e[E$] = i, e.body = n) : this[UG][this[WG]] = new t(i, n),
                ++this[WG]
            },
            pop: function() {
                return this[WG] > 0 ? this[UG][--this.popIdx] : void 0
            },
            reset: function() {
                this.popIdx = 0
            }
        };
        var s = [],
        h = new i,
        r = function() {
            this[px] = null,
            this[qG] = [],
            this[XG] = 0,
            this[VG] = 0,
            this.massY = 0,
            this[Co] = 0,
            this.top = 0,
            this.bottom = 0,
            this[Gr] = 0,
            this[KG] = !1
        },
        a = [],
        o = 0,
        f = function() {
            var t;
            return a[o] ? (t = a[o], t.quads[0] = null, t[qG][1] = null, t[qG][2] = null, t[qG][3] = null, t[px] = null, t.mass = t.massX = t[ZG] = 0, t[Co] = t[Gr] = t.top = t.bottom = 0, t.isInternal = !1) : (t = new r, a[o] = t),
            ++o,
            t
        },
        c = f(),
        u = function(t, i) {
            var n = Math.abs(t.x - i.x),
            e = Math.abs(t.y - i.y);
            return 1e-8 > n && 1e-8 > e
        },
        _ = function(t) {
            for (h[JG](), h[Xh](c, t); ! h[Sf]();) {
                var i = h.pop(),
                n = i[E$],
                e = i.body;
                if (n[KG]) {
                    var s = e.x,
                    r = e.y;
                    n[XG] = n.mass + e.mass,
                    n[VG] = n[VG] + e.mass * s,
                    n[ZG] = n[ZG] + e.mass * r;
                    var a = 0,
                    o = n.left,
                    _ = (n[Gr] + o) / 2,
                    d = n.top,
                    l = (n[Fr] + d) / 2;
                    if (s > _) {
                        a += 1;
                        var v = o;
                        o = _,
                        _ += _ - v
                    }
                    if (r > l) {
                        a += 2;
                        var b = d;
                        d = l,
                        l += l - b
                    }
                    var g = n[qG][a];
                    g || (g = f(), g[Co] = o, g.top = d, g[Gr] = _, g[Fr] = l, n.quads[a] = g),
                    h.push(g, e)
                } else if (n[px]) {
                    var y = n[px];
                    if (n[px] = null, n[KG] = !0, u(y, e)) {
                        if (n[Gr] - n.left < 1e-8) return;
                        do {
                            var x = Math.random(), m = (n[Gr] - n[Co]) * x, E = (n[Fr] - n.top) * x;
                            y.x = n.left + m, y.y = n.top + E
                        } while ( u ( y , e ))
                    }
                    h.push(n, y),
                    h[Xh](n, e)
                } else n.body = e
            }
        },
        d = function(t) {
            var i, h, r, a, o = s,
            f = 1,
            u = 0,
            _ = 1;
            for (o[0] = c; f;) {
                var d = o[u],
                l = d[px];
                f -= 1,
                u += 1,
                l && l !== t ? (h = l.x - t.x, r = l.y - t.y, a = Math[Ka](h * h + r * r), 0 === a && (h = (Math[Ir]() - .5) / 50, r = (Math[Ir]() - .5) / 50, a = Math[Ka](h * h + r * r)), i = n * l[XG] * t[XG] / (a * a), -1e3 > i && (i = -1e3), i /= a, t.fx = t.fx + i * h, t.fy = t.fy + i * r) : (h = d.massX / d.mass - t.x, r = d.massY / d.mass - t.y, a = Math[Ka](h * h + r * r), 0 === a && (h = (Math[Ir]() - .5) / 50, r = (Math.random() - .5) / 50, a = Math.sqrt(h * h + r * r)), (d[Gr] - d.left) / a < e ? (i = n * d[XG] * t[XG] / (a * a), -1e3 > i && (i = -1e3), i /= a, t.fx = t.fx + i * h, t.fy = t.fy + i * r) : (d[qG][0] && (o[_] = d[qG][0], f += 1, _ += 1), d[qG][1] && (o[_] = d[qG][1], f += 1, _ += 1), d[qG][2] && (o[_] = d[qG][2], f += 1, _ += 1), d[qG][3] && (o[_] = d.quads[3], f += 1, _ += 1)))
            }
        },
        l = function(t, i) {
            n = i;
            var e, s = Number[al],
            h = Number[al],
            r = Number.MIN_VALUE,
            a = Number[QG],
            u = t,
            d = u[Fh];
            for (e = d; e--;) {
                var l = u[e].x,
                v = u[e].y;
                s > l && (s = l),
                l > r && (r = l),
                h > v && (h = v),
                v > a && (a = v)
            }
            var b = r - s,
            g = a - h;
            for (b > g ? a = h + b: r = s + g, o = 0, c = f(), c[Co] = s, c[Gr] = r, c.top = h, c[Fr] = a, e = d; e--;) _(u[e], c)
        };
        return {
            init: l,
            update: d
        }
    },
    VW = function(t) {
        t.fx -= t.x * this[tF],
        t.fy -= t.y * this[tF]
    },
    KW = function(t) {
        if (0 != t.k) {
            var i = this._d4,
            n = t[Tc],
            e = t.to,
            s = e.x - n.x,
            h = e.y - n.y,
            r = s * s + h * h,
            a = Math[Ka](r) || .1,
            o = (a - i) * t.k * this[iF];
            o /= a;
            var f = o * s,
            c = o * h;
            e.fx -= f,
            e.fy -= c,
            n.fx += f,
            n.fy += c
        }
    };
    Rh[Jh] = {
        appendNodeInfo: function(t, i) {
            i[XG] = t[nF] || 1,
            i.fx = 0,
            i.fy = 0,
            i.vx = 0,
            i.vy = 0
        },
        appendEdgeInfo: function(t, i) {
            i.k = t[eF] || 1
        },
        setMass: function(t, i) {
            t[nF] = i,
            this[cG] && this[cG].nodes && (t = this[cG].nodes[t.id], t && (t[XG] = i))
        },
        setElasticity: function(t, i) {
            t[eF] = i,
            this.layoutDatas && this[cG][AO] && (t = this[cG].edges[t.id], t && (t.k = i))
        },
        _d4: 50,
        _i2: .5,
        timeStep: .15,
        repulsion: 50,
        attractive: .1,
        elastic: 3,
        _mh: 1e3,
        _kk: function(t) {
            return this._mh + .3 * (t - this._mh)
        },
        _lw: function(t, i) {
            var n = (Date.now(), this[cG].nodes);
            for (var e in n) {
                var s = n[e];
                i && (s.x += Math[Ir]() - .5, s.y += Math.random() - .5),
                VW[zh](this, s)
            }
            var h = this[cG].groups;
            if (h) for (var e in h) {
                var r = h[e],
                a = r[Yh],
                o = 0,
                f = 0;
                a[Wf](function(t) {
                    o += t.x,
                    f += t.y
                }),
                o /= a[Fh],
                f /= a[Fh];
                var c = 10 * this.attractive;
                a[Wf](function(t) {
                    t.fx -= (t.x - o) * c,
                    t.fy -= (t.y - f) * c
                })
            }
            var u = this[sF];
            u || (u = this[sF] = XW()),
            u.init(this.layoutDatas[hF], -this[rF] * this[rF] * this.repulsion);
            for (var e in n) u[aF](n[e]);
            if (this[iF]) {
                var _ = this[cG].edges;
                for (var e in _) KW.call(this, _[e])
            }
            return this._lx(t)
        },
        _lx: function(t) {
            var i = this[cG].minEnergy,
            n = (this[cG][oF], this.layoutDatas[bG]),
            t = this[yG],
            e = 0,
            s = this._i2;
            for (var h in n) {
                var r = n[h],
                a = r.fx / r.mass,
                o = r.fy / r.mass,
                f = r.vx += a * t,
                c = r.vy += o * t;
                r.x += f * t,
                r.y += c * t,
                i > e && (e += 2 * (f * f + c * c)),
                r.fx = 0,
                r.fy = 0,
                r.vx *= s,
                r.vy *= s
            }
            return this[cG][oF] = e,
            e >= i
        }
    },
    p(Rh, Ph),
    xY[fF] = Rh;
    var ZW = function(t) {
        this[m$] = t
    };
    ZW[Jh] = {
        oldLocations: null,
        _eh: null,
        duration: 700,
        animationType: vY.easeOutStrong,
        _6n: function(t) {
            if (this._eh = t, this[cF] = {},
            t) for (var i in t) {
                var n = t[i],
                e = n.node;
                this[cF][i] = {
                    x: e.x,
                    y: e.y
                }
            }
        },
        setLocation: function(t, i, n) {
            t[rP](i, n)
        },
        forEach: function(t, i) {
            for (var n in this[m$]) {
                var e = this[cF][n],
                s = this[m$][n];
                t.call(i, e, s)
            }
        },
        _kb: function(t) {
            this[Wf](function(i, n) {
                var e = n[E$],
                s = i.x + (n.x - i.x) * t,
                h = i.y + (n.y - i.y) * t;
                this[rP](e, s, h)
            },
            this)
        },
        stop: function() {
            this[uF] && this[uF]._mj()
        },
        start: function(t) {
            this[uF] ? (this[uF]._mj(), this[uF]._ib = this[x$], this[uF][_F] = this[PR], this._nenimate[dF] = this[dF]) : this._nenimate = new gY(this._kb, this, this[x$], this.animationType),
            this[uF]._l5(t)
        }
    },
    Z(ZW.prototype, {
        locations: {
            get: function() {
                return this._eh
            },
            set: function(t) {
                this._eh != t && this._6n(t)
            }
        }
    });
    var JW = function(t) {
        var i, n = new hz;
        return t[Wf](function(t) {
            t instanceof OU && (t.hasInEdge() ? !i && t[lF]() && (i = t) : n.add(t))
        }),
        n[Sf]() && i && n.add(i),
        n
    },
    QW = function(t, i, n, e, s, h) {
        if (i instanceof Pz) return t(i, n, e, s, h),
        i;
        if (i instanceof qU) {
            var r = new hz;
            i._ktModel[Wf](function(t) {
                return i.isVisible(t) ? t._i0() && t._gf && t[$h]() ? void(t.$location && (t[NO][GP] = !1)) : void r.add(t) : void 0
            }),
            i = r
        }
        var i = JW(i, e);
        return l(i,
        function(i) {
            t(i, n, e, s, h)
        }),
        i
    },
    tq = function(t, i, n, e, s) {
        return QW(nq, t, i, n, e, s)
    },
    iq = function(t, i, n, e, s) {
        return QW(eq, t, i, n, e, s)
    };
    es.prototype.forEachByTopoDepthFirstSearch = function(t, i, n, e) {
        tq(this, t, i, n, e)
    },
    es.prototype[vF] = function(t, i, n, e) {
        iq(this, t, i, n, e)
    };
    var nq = function(t, i, n, e, s) {
        function h(t, i, n, e, s, r, a, o) {
            t._marker = r,
            e || i[zh](n, t, o, a),
            Dh(t,
            function(o) {
                h(o, i, n, e, s, r, a + 1, t)
            },
            o, s, r, n),
            e && i[zh](n, t, o, a)
        }
        h(t, i, n, e, s, {},
        0)
    },
    eq = function(t, i, n, e, s) {
        function h(t, i, n, e, s, r, a) {
            var o, f = t[Fh];
            t[Wf](function(t, h) {
                var c = t.v;
                c[xd] = r,
                e || i[zh](n, c, t[bF], a, h, f),
                Dh(c,
                function(t) {
                    o || (o = []),
                    t[xd] = r,
                    o[Xh]({
                        v: t,
                        _from: c
                    })
                },
                c, s, r, n)
            }),
            o && h(o, i, n, e, s, r, a + 1),
            e && t[Wf](function(t, e) {
                i[zh](n, t.v, t[bF], a, e, f)
            })
        }
        h([{
            v: t
        }], i, n, e, s, {},
        0)
    };
    xY[gF] = V,
    xY.log = ti,
    xY[Po] = ni,
    xY[$r] = ii,
    xY[yF] = HF,
    xY[xF] = YF,
    xY[mF] = qF,
    xY[EF] = XF,
    xY.isFirefox = VF,
    xY[pF] = ZF,
    xY[wF] = KF,
    xY[TF] = JF,
    xY[OF] = WU,
    xY.Defaults = sz,
    xY[gP] = CU,
    xY.Consts = mY,
    xY[IF] = sH,
    xY[MF] = qU,
    xY.BaseUI = jU,
    xY[AF] = zU,
    xY[jF] = _s,
    xY[cD] = us,
    xY[SF] = HU,
    xY[CF] = YU,
    xY[kF] = MU,
    xY[LF] = iH,
    xY[$k] = BY,
    xY.InteractionEvent = jh,
    xY[Ow] = wU,
    xY.Node = OU,
    xY[xP] = TU,
    xY.GraphModel = es,
    xY[PF] = qW,
    xY[RF] = DW,
    xY[rr] = DF;
    var sq = NF;
    return xY[$p] = BF,
    xY[zp] = $F,
    xY.copyright = "Copyright © 2016 Qunee.com",
    xY.css = li,
    xY.IDrawable = XU,
    ti = function() {},
    xY.publishDate = GF,
    xY
} (window, document);