// 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('xngl8'));
        // 指定图表的配置项和数据
        var option = {
    tooltip: {
        formatter: "{a} <br/>{b} : {c} ({d}%)",
        textStyle: {
            fontSize: 12
        }
    },
    legend: {
        orient: "vertical",
        x: "left",
        data: ["已使用", "未使用"],
        y: "top"
    },
    calculable: true,
    series: [
        {
            name: "内存",
            type: "pie",
            radius: ["50%", "70%"],
            itemStyle: {
                normal: {
                    label: {
                        show: false
                    },
                    labelLine: {
                        show: false
                    }
                }
            },
            data: [
                {
                    value: 2335,
                    name: "已使用"
                },
                {
                    value: 234,
                    name: "未使用"
                }
            ],
            center: ["50%", "60%"]
        }
    ],
    title: {
        x: "center",
        textStyle: {
            color: "rgb(0, 0, 0)",
            fontSize: 30
        },
        text: "内存",
        y: "40%",
        subtext: "已使用 23%",
        subtextStyle: {
            color: "rgb(57, 155, 255)",
            fontSize: 13
        }
    },
    backgroundColor: "rgba(0,0,0,0)",
    color: ["rgb(57, 155, 255)", "rgb(183, 182, 181)", "rgb(218, 112, 214)", "#32cd32", "#6495ed", "#ff69b4", "rgb(186, 85, 211)", "#cd5c5c", "#ffa500", "#40e0d0", "#1e90ff", "#ff6347", "rgb(123, 104, 238)", "#00fa9a", "#ffd700", "#FFFFFF", "#FFFFFF", "#FFFFFF", "#FFFFFF"]
}
// 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);